package demographics.snapshots;

import com.aim.automation.tests.base.PostTests;
import dtos.ErrorDTO;
import dtos.datamanager.MemberResponseDTO;
import dtos.demographics.snapshot.MemberDemographicsSnapshotDTO;
import helpers.constants.BasePathConstants;
import helpers.dataproviders.DataProviders;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.datamanager.MemberDataManagerSteps;
import steps.demographics.snapshots.PostMemberDemographicsSnapshotSteps;

import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_186;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_85;
import static org.apache.http.HttpStatus.SC_NOT_FOUND;

/**
 * Created by VBaliyska on 5/9/2019.
 */
public class PostMemberDemographicsSnapshotTest extends PostTests {
    private MemberResponseDTO memberResponseDTO;
    private MemberDataManagerSteps memberDataManagerSteps;
    private PostMemberDemographicsSnapshotSteps memberDemographicsSnapshotSteps;
    private String CLIENT_MEMBER_ID;

    @BeforeMethod
    public void initMethod() {
        CLIENT_MEMBER_ID = RandomStringUtils.randomNumeric(10) + RandomStringUtils.randomAlphabetic(5).toUpperCase();
    }

    @BeforeClass
    public void init() {
        basePath = BasePathConstants.BASE_PATH_MEMBER_DEMOGRAPHICS_SNAPSHOT_POST;

        pathParamsMap.clear();
        pathParamsMap.put("clientId", CLIENT_ID_186);
        pathParamsMap.put("memberId", "4249ee34-1856-413a-94c2-43efc85f73b6");
        body = "";
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-201---------------------------------------------

    @Test(dataProvider = "data-provider-clientId", dataProviderClass = DataProviders.class)
    public void whenPostValidMemberIdThenDemographicsSnapshotIsCreatedClient186and85(String clientId) {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberDemographicsSnapshotSteps = new PostMemberDemographicsSnapshotSteps(platformContextHeader, headers);

        memberResponseDTO = memberDataManagerSteps.createMember(clientId,CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();

        MemberDemographicsSnapshotDTO memberDemographicsSnapshotDTO = memberDemographicsSnapshotSteps.createMemberDemographicsSnapshot(clientId, memberId);

        String snapshotId = memberDemographicsSnapshotDTO.getSnapshotId();

        switch (clientId) {
            case CLIENT_ID_186:
                softly.then(memberDemographicsSnapshotDTO.getMemberDemographics().getHealthPlan()).contains(HEALTHPLAN_AUTHEM_BC);
                break;
            case CLIENT_ID_85:
                softly.then(memberDemographicsSnapshotDTO.getMemberDemographics().getHealthPlan()).contains(HEALTHPLAN_AUTHEM_CR);
                break;
            default:
                softly.then(memberDemographicsSnapshotDTO.getMemberDemographics().getHealthPlan()).isNotEmpty().isNotBlank().isNotNull();
                break;
        }

        softly.then(snapshotId).isNotEmpty();
        softly.then(memberDemographicsSnapshotDTO.getMemberDemographics().getClientId()).isEqualTo(clientId);
        softly.then(memberDemographicsSnapshotDTO.getMemberDemographics().getId()).isEqualTo(memberId);
        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-404---------------------------------------------

    @Test
    public void whenSendInvalidMemberIdThenServiceReturnsNotFoundResponseSC404() {
        memberDemographicsSnapshotSteps = new PostMemberDemographicsSnapshotSteps(platformContextHeader, headers);

        ErrorDTO error = memberDemographicsSnapshotSteps.createMemberDemographicsSnapshotError(CLIENT_ID_186, MEMBER_ID_TEST);

        softly.then(error.getCode()).isEqualTo(SC_NOT_FOUND);
        softly.then(error.getMessage()).contains(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }

    @Test
    public void whenSendInvalidMemberIdandInvalidClientIdThenServiceReturnsNotFoundResponseSC404() {
        memberDemographicsSnapshotSteps = new PostMemberDemographicsSnapshotSteps(platformContextHeader, headers);

        ErrorDTO error = memberDemographicsSnapshotSteps.createMemberDemographicsSnapshotError(MEMBER_ID_TEST, CLIENT_ID_TEST);

        softly.then(error.getCode()).isEqualTo(SC_NOT_FOUND);
        softly.then(error.getMessage()).contains(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }

    // TODO: The test is legal, but due to BUG https://jira.aimspecialtyhealth.com/browse/NCP-20854 it will fail. Uncomment once the bug is fixed.
//    @Test
    public void whenSendValidMemberIdandInvalidClientIdThenServiceReturnsNotFoundResponseSC404() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberDemographicsSnapshotSteps = new PostMemberDemographicsSnapshotSteps(platformContextHeader, headers);

        memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_TEST,CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();

        ErrorDTO error = memberDemographicsSnapshotSteps.createMemberDemographicsSnapshotError(CLIENT_ID_TEST, memberId);

        softly.then(error.getCode()).isEqualTo(SC_NOT_FOUND);
        softly.then(error.getMessage()).contains(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }

    @Override
    public void whenPostWithNoBodyThenServiceReturnsBadRequest() {
        // No need to do anything here
        // This endpoint does not have body
    }
}
