package com.abc.automation.factories.platformcontext;

import com.abc.servicemodel.domain.Enrollment;

import static com.abc.automation.helpers.constants.PlatformContextConstants.*;

public class EnrollmentPCDTOFactory {

    private String employerGroupCode = PC_ENROLLMENT_EMPLOYER_GROUP_CODE;
    private String networkCode = PC_ENROLLMENT_NETWORK_CODE;
    private String productCode = PC_ENROLLMENT_PRODUCT_CODE;
    private String issuanceStateCode = PC_ENROLLMENT_INSURANCE_STATE_CODE;
    private String jurisdictionCode = PC_ENROLLMENT_JURISDICTION_CODE;
    private String programCode = PC_ENROLLMENT_PROGRAM_CODE;
    private String lineOfBusinessCode = PC_ENROLLMENT_LINE_OF_BUSINESS_CODE;

    public Enrollment createEnrollmentPCDTO() {
        Enrollment enroll = new Enrollment();
        enroll.setEmployerGroupCode(employerGroupCode);
        enroll.setNetworkCode(networkCode);
        enroll.setProductCode(productCode);
        enroll.setIssuanceStateCode(issuanceStateCode);
        enroll.setJurisdictionCode(jurisdictionCode);
        enroll.setProgramCode(programCode);
        enroll.setLineOfBusinessCode(lineOfBusinessCode);

        return enroll;
    }

    public Enrollment createEnrollmentPCDTO(String employerGroupCode, String networkCode, String productCode,
                                            String issuanceStateCode, String jurisdictionCode,
                                            String programCode, String lineOfBusinessCode) {
        Enrollment enroll = new Enrollment();
        enroll.setEmployerGroupCode(employerGroupCode);
        enroll.setNetworkCode(networkCode);
        enroll.setProductCode(productCode);
        enroll.setIssuanceStateCode(issuanceStateCode);
        enroll.setJurisdictionCode(jurisdictionCode);
        enroll.setProgramCode(programCode);
        enroll.setLineOfBusinessCode(lineOfBusinessCode);

        return enroll;
    }
}
