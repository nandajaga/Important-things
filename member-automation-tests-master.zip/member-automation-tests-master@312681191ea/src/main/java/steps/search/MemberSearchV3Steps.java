package steps.search;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.search.GETMemberSearchDTO;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

import static helpers.constants.BasePathConstants.BASE_PATH_SEARCH_MEMBERS;
import static helpers.constants.BasePathConstants.BASE_PATH_V3_SEARCH_MEMBERS;
import static helpers.constants.Constants.*;

/**
 * Created by RKondakova on 6/7/2019.
 */
public class MemberSearchV3Steps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    //constructor
    public MemberSearchV3Steps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BASE_PATH_V3_SEARCH_MEMBERS);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    //for the positive tests
    public GETMemberSearchDTO getMemberSearch(String clientId, String clientMemberId, String dob, String firstName, String lastName,String userLocCode,String size) {

        Map<String, String> queryParamsMap = new HashMap<>();

        if (clientId != null) queryParamsMap.put(CLIENT_IDS, clientId);
        if (clientMemberId != null) queryParamsMap.put(CLIENT_MEMBER_IDS, clientMemberId);
        if (dob != null) queryParamsMap.put(ENROLLMENT_DOB, dob);
        if (firstName != null) queryParamsMap.put(FIRST_NAME, firstName);
        if (lastName != null) queryParamsMap.put(LAST_NAME, lastName);
        if (userLocCode != null) queryParamsMap.put(USER_LOC_CODE, userLocCode);
        if (size != null) queryParamsMap.put(SIZE, size);

        requestSpecification.addQueryParams(queryParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_OK);

        return result.as(GETMemberSearchDTO.class);

    }


}
