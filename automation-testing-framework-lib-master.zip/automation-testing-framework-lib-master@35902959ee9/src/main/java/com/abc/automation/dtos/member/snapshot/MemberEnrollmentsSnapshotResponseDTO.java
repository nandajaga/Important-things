package com.abc.automation.dtos.member.snapshot;

import com.abc.automation.dtos.member.enrollments.MemberEnrollmentDTO;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Created by PPetarcheva on 4/22/2019.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MemberEnrollmentsSnapshotResponseDTO {

    private MemberEnrollmentDTO memberEnrollment;
    private String snapshotId;

    public MemberEnrollmentDTO getMemberEnrollment() {
        return memberEnrollment;
    }

    public void setMemberEnrollment(MemberEnrollmentDTO memberEnrollment) {
        this.memberEnrollment = memberEnrollment;
    }

    public String getSnapshotId() {
        return snapshotId;
    }

    public void setSnapshotId(String snapshotId) {
        this.snapshotId = snapshotId;
    }
}
