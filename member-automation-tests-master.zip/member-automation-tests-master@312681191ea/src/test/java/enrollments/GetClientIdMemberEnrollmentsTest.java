package enrollments;

import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.datamanager.MemberResponseDTO;
import dtos.enrollments.MemberEnrollmentsDTO;
import dtos.search.GETMemberSearchDTO;
import helpers.constants.BasePathConstants;
import helpers.dataproviders.DataProviders;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.datamanager.MemberDataManagerSteps;
import steps.enrollments.MemberEnrollmentsSteps;
import steps.rabbitmqsimulator.PublishEventSteps;
import steps.search.MemberSearchSteps;

import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_85;
import static org.apache.http.HttpStatus.SC_NOT_FOUND;


/**
 * Created by RKondakova on 4/5/2019.
 */
public class GetClientIdMemberEnrollmentsTest extends GetTests {

    private static final String BASEID_ONE = "1";
    private static final String BASEID_TWO = "2";
    private static final String BASEID_THREE = "3";
    private MemberDataManagerSteps memberDataManagerSteps;
    private MemberEnrollmentsSteps memberEnrollmentsSteps;
    private String CLIENT_MEMBER_ID;

    @BeforeMethod
    public void initMethod() {
        CLIENT_MEMBER_ID = RandomStringUtils.randomNumeric(10) + RandomStringUtils.randomAlphabetic(5).toUpperCase();
    }

    @BeforeClass
    public void init() {
        basePath = BasePathConstants.BASE_PATH_ENROLLMENTS;

        pathParamsMap.clear();
        pathParamsMap.put("clientId", CLIENT_ID_85);
        pathParamsMap.put("memberId", MEMBER_ID_REAL);
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test
    public void whenGetAndValidClientIdAndMemberIdSentThenServiceReturnsEnrollments() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_186, CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_186, memberId);

        softly.then(memberEnrollmentsDTO.getId()).contains(memberId);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).contains(CLIENT_ID_186);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isEqualTo(MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAGHMO);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientMemberProductCode()).isNotNull();
        softly.assertAll();
    }

    @Test
    public void whenNullemployergroupcodeandNullIssuancestatecodeSendThenServiceReturnsEnrollments() {
        PlatformContextUtils platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeIssuanceStateCode(platformContextHeader, null);
        platformContextHeader = platformContextUtils.changeEmployerGroupCode(platformContextHeader, null);

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_186, CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_186, memberId);

        softly.then(memberEnrollmentsDTO.getId()).contains(memberId);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).contains(CLIENT_ID_186);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isEqualTo(MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAGHMO);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientMemberProductCode()).isNotNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getErisaIndicator()).isNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMarketSegmentCode()).isNull();
        softly.assertAll();
    }

    @Test
    public void whenGetAndClientId186AndMemberIdAndSourceSystemWGSSentThenServiceReturnsWMDSBaseId1SC200() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_186, ISSUANCE_STATE_CA, SS_WGS, CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_186, memberId);

        softly.then(memberEnrollmentsDTO.getId()).contains(memberId);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getBaseId()).contains(BASEID_ONE);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).contains(CLIENT_ID_186);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getIssuanceState()).contains(ISSUANCE_STATE_CA);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMedicalManagementSystem()).contains(MMS_WMDS);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getSourceSystem()).contains(SS_WGS);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isNotEmpty().isNotNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientMemberProductCode()).isNullOrEmpty();
        softly.assertAll();
    }

    @Test
    public void whenGetAndClientId186AndMemberIdAndSourceSystemISGSentThenServiceReturnsWMDSBaseId2SC200() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_186, ISSUANCE_STATE_CA, SS_ISG, CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_186, memberId);

        softly.then(memberEnrollmentsDTO.getId()).contains(memberId);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getBaseId()).contains(BASEID_TWO);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).contains(CLIENT_ID_186);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getIssuanceState()).contains(ISSUANCE_STATE_CA);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMedicalManagementSystem()).contains(MMS_WMDS);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getSourceSystem()).contains(SS_ISG);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isNotEmpty().isNotNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientMemberProductCode()).isNull();
        softly.assertAll();
    }

    @Test
    public void whenGetAndClientId186AndMemberIdAndSourceSystemNASCOSentThenServiceReturnsWMDSBaseId3SC200() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_186, ISSUANCE_STATE_CA, SS_NASCO, CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_186, memberId);

        softly.then(memberEnrollmentsDTO.getId()).contains(memberId);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getBaseId()).contains(BASEID_THREE);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).contains(CLIENT_ID_186);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getIssuanceState()).contains(ISSUANCE_STATE_CA);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMedicalManagementSystem()).contains(MMS_WMDS);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getSourceSystem()).contains(SS_NASCO);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isNotEmpty().isNotNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientMemberProductCode()).isNull();
        softly.assertAll();
    }

    @Test
    public void whenGetAndClientId210AndMemberIdAndSourceSystemNULLSentThenServiceReturnsFACETBaseId1SC200() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_210, ISSUANCE_STATE_CA, SS_NULL, CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_210, memberId);

        softly.then(memberEnrollmentsDTO.getId()).contains(memberId);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getBaseId()).contains(BASEID_ONE);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).contains(CLIENT_ID_210);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getIssuanceState()).contains(ISSUANCE_STATE_CA);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMedicalManagementSystem()).contains(MMS_FACET);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isNotEmpty().isNotNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientMemberProductCode()).isNull();
        softly.assertAll();
    }

    @Test(dataProvider = "validClientMemberProductCodeAndMixerCode", dataProviderClass = DataProviders.class)
    public void whenGetAndClientId210AndValidClientProductCodeAndMixerCodeSentThenServiceReturnsSC200(String mixerCode, String clientMemberProductCode) {

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_210, PC_ENROLLMENT_EMPLOYER_GROUP_CODE, 1, mixerCode, clientMemberProductCode, CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_210, memberId);

        softly.then(memberEnrollmentsDTO).isNotNull();
        if (mixerCode == null) {
            softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isNull();
        } else if (clientMemberProductCode == null) {
            softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientMemberProductCode()).isNull();
        } else {
            softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isNotNull();
            softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientMemberProductCode()).isNotNull();
            softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isEqualTo(MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAGHMO);
            softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientMemberProductCode()).isEqualTo(CLIENT_MEMBER_PRODUCT_CODE);
        }
        softly.assertAll();
    }

    @Test(dataProvider = "validClientIdAndProductCodesForReceivingValidMixerCode", dataProviderClass = DataProviders.class)
    public void whenGetAndValidClientIdAndMemberIdAndSpecificMixerCodeSentThenServiceReturnsEnrollmentsWithThisExactlyMixerCode(String clientId, String productCode, String mixerCode) {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(clientId, EMPLOYER_GROUP_NUMBER, NUMBER_OF_ENROLLMENTS_ONE, mixerCode, null, CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(clientId, memberId);

        softly.then(memberEnrollmentsDTO.getId()).contains(memberId);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).contains(clientId);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientMemberProductCode()).isNull();

        switch (productCode) {
            case PRODUCT_CODE_VAFHMO:
                softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isEqualTo(MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAFHMO);
                break;
            case PRODUCT_CODE_VAGHMO:
                softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isEqualTo(MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAGHMO);
                break;
            case PRODUCT_CODE_PIHMO:
                softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isEqualTo(MIXER_CODE_CLIENTID_185_PRODUCTCODE_PIHMO);
                break;
            case PRODUCT_CODE_PIXHMO:
                softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isEqualTo(MIXER_CODE_CLIENTID_185_PRODUCTCODE_PIXHMO);
                break;
            default:
                softly.then(memberEnrollmentsDTO.getId()).isNotNull().isNotEmpty().isNotBlank();
                softly.then(memberEnrollmentsDTO.getEnrollments()).isNotNull().isNotEmpty();
                softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).isNotBlank().isNotEmpty().isNotNull();
                softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientMemberProductCode()).isNotEmpty().isNotBlank().isNotNull();
                softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isNotNull().isNotBlank().isNotEmpty();
                break;
        }
        softly.assertAll();
    }

    /* https://dbg-jira.antheminc.com/browse/OSPP-10841
     * ClientId - 186
     * HCSC - Implement snapshot changes for enrollments
     * Updated by Rkohli on 02/12/2020
     */
    @Test
    public void whenGetAndClientId186AndAdditionalFiledSentThenSC200() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMemberWithSpecificClientIdAndAdditionalFields(CLIENT_ID_186, ADDITIONAL_FIELD_SUB_GROUP_CODE, ADDITIONAL_FIELD_CLIENT_ACCOUNT_NUMBER, ADDITIONAL_FIELD_CLIENT_LINE_OF_BUSINESS_CODE, ADDITIONAL_FIELD_BUSINESS_MARKET_SEGMENT_NAME, ADDITIONAL_FIELD_ALTERNATE_BENEFIT_PLAN_CODE, true, ADDITIONAL_FIELD_CLIENT_ACCOUNT_NAME, ADDITIONAL_FIELD_CLIENT_FUNDING_TYPE_CODE, CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_186, memberId);

        softly.then(memberEnrollmentsDTO.getId()).contains(memberId);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getAdditionalFields().get(0).getKey()).isNotEmpty();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getAdditionalFields().get(0).getValue()).isNotNull();
        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-404---------------------------------------------

    @Test
    public void whenGetAndNotValidClientIdSentThenServiceReturnsNotFoundResponseSC404() {
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);

        ErrorDTO error = memberEnrollmentsSteps.getMemberEnrollmentsErrors(CLIENT_ID_TEST, MEMBER_ID_TEST);

        softly.then(error.getCode()).isEqualTo(SC_NOT_FOUND);
        softly.then(error.getMessage()).contains(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }

    @Test
    public void whenGetAndNotValidMemberIdSentThenServiceReturnsNotFoundResponseSC404() {
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);

        ErrorDTO error = memberEnrollmentsSteps.getMemberEnrollmentsErrors(CLIENT_ID_186, MEMBER_ID_TEST);

        softly.then(error.getCode()).isEqualTo(SC_NOT_FOUND);
        softly.then(error.getMessage()).contains(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }

    @Test(dataProvider = "invalidClientMemberProductCodeAndMixerCode", dataProviderClass = DataProviders.class)
    public void whenValidateClientMemberProductCodeAndMixerCodeThenResponseSC422(String clientMemberProductCode, String mixerCode) {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        ErrorDTO memberResponseDTO = memberDataManagerSteps.createMemberWithClientMemberProductCodeAndMixerCodeWithError(CLIENT_ID_210, PC_ENROLLMENT_EMPLOYER_GROUP_CODE, 1, mixerCode, clientMemberProductCode, CLIENT_MEMBER_ID);

        softly.then(memberResponseDTO.getCode()).isEqualTo(HttpStatus.SC_UNPROCESSABLE_ENTITY);
        softly.then(memberResponseDTO.getMessage()).contains(VALIDATION_CLIENT_MEMBER_PRODUCT_CODE_ALPHANUMRIC);
        softly.assertAll();
    }

    //-----------------------------------MANUAL-ADD-TESTS---RABBITMQ-CONSUMER---------------------------------------------
    /*
     *Test the manual added member via RabbitMq is distributed to member-enrollments service
     */
    @Test
    public void whenSuccessfulAddMemberViaRabbitMqThenMemberIsLoadedInEnrollments() {
        // create member through Rabbit Mq
        String clientMemberId = RandomStringUtils.random(24, true, true);
        PublishEventSteps publishEventSteps = new PublishEventSteps(platformContextHeader, headers);
        publishEventSteps.publishEventMemberManualAdd(CLIENT_ID_85, clientMemberId);

        //get member uuid
        GETMemberSearchDTO memberSearchDTO = new MemberSearchSteps(platformContextHeader, headers).getMemberSearch(CLIENT_ID_85, clientMemberId, null, null, null);
        String id = memberSearchDTO.getMembers().get(0).getId();

        //get member enrollments
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_85, id);

        softly.then(memberEnrollmentsDTO.getId()).isEqualTo(id);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).isEqualTo(CLIENT_ID_85);
        softly.assertAll();

    }

    @Test(dataProvider = "contextModeValue", dataProviderClass = DataProviders.class)
    public void whenGetValidClientIdMemberIdAndSolutionIdSentWithTestContextModeThenServiceReturnsEnrollments(String contextMode) {
        PlatformContextUtils platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeContextMode(platformContextHeader, contextMode);

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_85, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        //get enrollments from the same DB
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_85, memberId);

        String enrollmentId = memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId();

        softly.then(enrollmentId).isNotEmpty().isNotBlank().isNotNull();
        softly.then(memberEnrollmentsDTO.getId()).contains(memberId);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).contains(CLIENT_ID_85);
        softly.assertAll();
    }

    @Test(dataProvider = "contextModeInDataBase", dataProviderClass = DataProviders.class)
    public void whenGetValidClientIdMemberIdAndSolutionIdSentWithReversedContextModeThenServiceReturnsSC404(String contextMode, String dataBaseMode) {
        PlatformContextUtils platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeContextMode(platformContextHeader, contextMode);

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_85, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        //get enrollments from different DB
        platformContextHeader = platformContextUtils.changeContextMode(platformContextHeader, dataBaseMode);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);

        ErrorDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollmentsErrors(CLIENT_ID_85, memberId);

        softly.then(memberEnrollmentsDTO.getCode()).isEqualTo(HttpStatus.SC_NOT_FOUND);
        softly.then(memberEnrollmentsDTO.getMessage()).isEqualTo(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }
}
