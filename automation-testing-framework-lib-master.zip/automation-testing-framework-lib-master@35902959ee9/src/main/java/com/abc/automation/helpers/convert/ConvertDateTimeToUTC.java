package com.abc.automation.helpers.convert;

import com.abc.automation.helpers.constants.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class ConvertDateTimeToUTC {
    private final static Logger LOGGER = LoggerFactory.getLogger(ConvertDateTimeToUTC.class);


    public String convertDateTimeToUTC(Date date) {
        return convertDateTimeToUTC(date, Constants.TIMEZONE_DATE_FORMAT);
    }

    public String convertDateTimeToUTC(Date date, String dateFormatPattern) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);

        DateFormat dateFormat = new SimpleDateFormat(dateFormatPattern);
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));

        return dateFormat.format(calendar.getTime());
    }

    public Date convertInputStringToUTCDate(String input, String format) {
        DateFormat dateFormat = new SimpleDateFormat(format);
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));

        if (input != null) {
            try {
                return dateFormat.parse(input);
            } catch (ParseException e) {
                LOGGER.error("An error occurred while parsing the date {} \n", input, e);
            }
        }

        return null;
    }

    public Date convertInputStringToUTCDate(String input) {
        return convertInputStringToUTCDate(input, Constants.TIMEZONE_DATE_FORMAT);
    }
}
