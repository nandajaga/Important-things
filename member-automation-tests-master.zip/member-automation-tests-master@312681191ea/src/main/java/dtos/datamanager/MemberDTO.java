package dtos.datamanager;

import dtos.demographics.MemberDemographicsDTO;
import dtos.enrollments.MemberEnrollmentDTO;
import dtos.enrollments.ReviewProgramsDTO;

import java.util.List;

public class MemberDTO {
    private String caseRequestId;
    private Boolean levelOfCare;
    private MemberDemographicsDTO memberDemographics;
    private List<MemberEnrollmentDTO> memberEnrollments;
    private List<ReviewProgramsDTO> reviewProgramCodes;

    public String getCaseRequestId() {
        return caseRequestId;
    }

    public void setCaseRequestId(String caseRequestId) {
        this.caseRequestId = caseRequestId;
    }

    public Boolean getLevelOfCare() {
        return levelOfCare;
    }

    public void setLevelOfCare(Boolean levelOfCare) {
        this.levelOfCare = levelOfCare;
    }

    public MemberDemographicsDTO getMemberDemographics() {
        return memberDemographics;
    }

    public void setMemberDemographics(MemberDemographicsDTO memberDemographics) {
        this.memberDemographics = memberDemographics;
    }

    public List<MemberEnrollmentDTO> getMemberEnrollments() {
        return memberEnrollments;
    }

    public void setMemberEnrollments(List<MemberEnrollmentDTO> memberEnrollments) {
        this.memberEnrollments = memberEnrollments;
    }

    public List<ReviewProgramsDTO> getReviewProgramCodes() {
        return reviewProgramCodes;
    }

    public void setReviewProgramCodes(List<ReviewProgramsDTO> reviewProgramCodes) {
        this.reviewProgramCodes = reviewProgramCodes;
    }
}
//AREA 51
