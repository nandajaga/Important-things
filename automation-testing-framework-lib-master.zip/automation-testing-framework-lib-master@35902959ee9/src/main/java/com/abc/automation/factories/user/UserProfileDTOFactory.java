package com.abc.automation.factories.user;

import com.abc.automation.dtos.user.UserProfileDTO;
import com.abc.automation.dtos.user.UserStateLicenseDTO;
import com.abc.automation.helpers.enums.user.UserRoleEnum;
import com.abc.automation.helpers.enums.user.UserStateLicenseEnum;
import org.apache.commons.lang3.RandomStringUtils;

import java.util.ArrayList;

public class UserProfileDTOFactory {

    private static final String USERNAME = "username";
    private static final String FIRST_NAME = "first";
    private static final String LAST_NAME = "last";
    private static final String EMAIL = "test@email.com";
    private static final String PHONE_NUMBER = "5555555555";
    private static final String STATUS = "A";
    private static final String SSO = "Y";

    private static final String RANDOM_INT_SIX_DIGITS_STR = RandomStringUtils.random(6, false, true);

    public UserProfileDTO createRandomUserProfile() {
        UserProfileDTO user = new UserProfileDTO();

        user.setUserName(USERNAME + System.currentTimeMillis());
        user.setFirstName(FIRST_NAME);
        user.setLastName(LAST_NAME);
        user.setEmail(EMAIL);
        user.setPhoneNumber(PHONE_NUMBER);
        user.setStatus(STATUS);
        user.setSso(SSO);
        user.setExternalUserIdNUM(RANDOM_INT_SIX_DIGITS_STR);
        user.setUserLocation(new UserLocationDTOFactory().createUserLocationDTO());
        user.setUserRole(new UserRoleDTOFactory().createUserRoleDTO());
        user.setUserStateLicenses(new UserStateLicenseDTOFactory().createStateLicensesDTO());
        return user;
    }

    public UserProfileDTO createUserProfile(UserRoleEnum role, UserStateLicenseEnum license) {
        UserProfileDTO user = createRandomUserProfile();

        if (role != null) {
            user.setUserRole(new UserRoleDTOFactory().createUserRoleDTO(role));
        }

        if (license != null) {
            ArrayList<UserStateLicenseDTO> userLicenses = new UserStateLicenseDTOFactory().createStateLicensesDTO(license);
            user.setUserStateLicenses(userLicenses);
        }

        return user;
    }

    public UserProfileDTO createUserProfileWithUserIdForRole(UserRoleEnum role, UserStateLicenseEnum license) {
        UserProfileDTO user = createUserProfile(role, license);
        user.setUserId(role.getUserId());
        return user;
    }

    public UserProfileDTO createUserProfileWithUserIdForRoleAndLocation(UserRoleEnum role, UserStateLicenseEnum license) {
        UserProfileDTO user = createUserProfile(role, license);
        user.setUserId(role.getUserId());
        user.setUserLocation(new UserLocationDTOFactory().createUserLocationDTORRS());
        return user;
    }
}
