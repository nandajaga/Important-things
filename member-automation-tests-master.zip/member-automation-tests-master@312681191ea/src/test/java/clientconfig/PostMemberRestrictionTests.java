package clientconfig;

import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.tests.base.PostTests;
import dtos.ErrorDTO;
import dtos.clientconfig.RestrictionTypeResponseDTO;
import dtos.datamanager.MemberResponseDTO;
import factories.clientconfig.MemberRestrictionDTOFactory;
import helpers.dataproviders.DataProviders;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.clientconfig.MembersRestrictionSteps;
import steps.datamanager.MemberDataManagerSteps;

import java.time.LocalDate;
import java.util.Date;

import static helpers.constants.BasePathConstants.BASE_PATH_MEMBER_RESTRICTION_POST;
import static helpers.constants.ClientConfigConstants.*;
import static helpers.constants.Constants.PC_CHANNEL_CODE_CC;
import static org.apache.http.HttpStatus.SC_BAD_REQUEST;
import static org.apache.http.HttpStatus.SC_UNPROCESSABLE_ENTITY;

/**
 * Created by VBaliyska on 6/20/2019.
 */
public class PostMemberRestrictionTests extends PostTests {

    private MemberDataManagerSteps memberDataManagerSteps;
    private PlatformContextUtils platformContextUtils;
    private String CLIENT_MEMBER_ID;

    @BeforeClass
    public void init() {
        basePath = BASE_PATH_MEMBER_RESTRICTION_POST;
        body = new MemberRestrictionDTOFactory().createRestrictionRequestMemberDTO(CLIENT_ID_183, EMPLOYER_GROUP_NUMBER_CLID183, null, RESTRICTION_HEALTH_PLAN, null);
    }

    @BeforeMethod
    public void initMethod() {
        platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeChannelCode(platformContextHeader, PC_CHANNEL_CODE_CC);
        CLIENT_MEMBER_ID = RandomStringUtils.randomNumeric(10) + RandomStringUtils.randomAlphabetic(5).toUpperCase();
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test(dataProvider = "clientIdEmployerCodeRestriction", dataProviderClass = DataProviders.class)
    public void whenPostClientIdAndEmployerGroupCodeThenServiceReturnsRestrictedHealthPlanTrue(String clientId, String employerGroupCode) {

        platformContextHeader = platformContextUtils.changeChannelCode(platformContextHeader, CHANNEL_CODE_P);

        RestrictionTypeResponseDTO restrictionTypeResponseDTO = new MembersRestrictionSteps(platformContextHeader, headers).postMemberRestrictionRequest(clientId, employerGroupCode, null, RESTRICTION_HEALTH_PLAN, null);

        softly.then(restrictionTypeResponseDTO.getIsRestricted()).isTrue();
        softly.then(restrictionTypeResponseDTO.getRestrictionType()).isEqualTo(RESTRICTION_HEALTH_PLAN);
        softly.assertAll();
    }

    @Test
    public void whenPostClientIdAndEmployerGroupCodeThenServiceReturnsRestrictedVIPAccountTrue() {

        RestrictionTypeResponseDTO restrictionTypeResponseDTO = new MembersRestrictionSteps(platformContextHeader, headers).postMemberRestrictionRequest(CLIENT_ID_202, null, DEPENDENT_RELATION_CODE_E, RESTRICTION_VIP_ACCOUNT, null);

        softly.then(restrictionTypeResponseDTO.getIsRestricted()).isTrue();
        softly.then(restrictionTypeResponseDTO.getRestrictionType()).isEqualTo(RESTRICTION_VIP_ACCOUNT);
        softly.assertAll();
    }

    @Test
    public void whenPostClientIdAndEmployerGroupCodeThenServiceReturnsRestrictedHouseAccountTrue() {

        RestrictionTypeResponseDTO restrictionTypeResponseDTO = new MembersRestrictionSteps(platformContextHeader, headers).postMemberRestrictionRequest(CLIENT_ID_85, EMPLOYER_GROUP_NUMBER_CLID85, null, RESTRICTION_HOUSE_ACCOUNT, null);

        softly.then(restrictionTypeResponseDTO.getIsRestricted()).isTrue();
        softly.then(restrictionTypeResponseDTO.getRestrictionType()).isEqualTo(RESTRICTION_HOUSE_ACCOUNT);
        softly.assertAll();
    }

    @Test
    public void whenPostClientIdAndMemberIdAndEmployerGroupCodeThenServiceReturnsRestrictedHouseAccountTrue() {

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_85, CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();

        RestrictionTypeResponseDTO restrictionTypeResponseDTO = new MembersRestrictionSteps(platformContextHeader, headers).postMemberRestrictionRequest(CLIENT_ID_85, null, null, null, memberId);

        softly.then(restrictionTypeResponseDTO.getIsRestricted()).isTrue();
        softly.then(restrictionTypeResponseDTO.getRestrictionType()).isEqualTo(RESTRICTION_HOUSE_ACCOUNT);
        softly.assertAll();
    }

    @Test
    public void whenPostNotRestrictedClientIdAndMemberIdThenServiceReturnsRestrictedFalse() {
        LocalDate lDate = LocalDate.now();
        Date date = java.sql.Date.valueOf(lDate.plusDays(0));
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(CLIENT_ID_210));
        platformContextHeader = platformContextUtils.changeRootLevelDateOfServiceDate(platformContextHeader, date);
        platformContextHeader = platformContextUtils.changeChannelCode(platformContextHeader, CHANNEL_CODE_P);

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_210, CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();

        RestrictionTypeResponseDTO restrictionTypeResponseDTO = new MembersRestrictionSteps(platformContextHeader, headers).postMemberRestrictionRequest(CLIENT_ID_210, null, null, null, memberId);

        softly.then(restrictionTypeResponseDTO.getIsRestricted()).isFalse();
        softly.then(restrictionTypeResponseDTO.getRestrictionType()).isEqualTo(NONE);
        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-422---------------------------------------------

    @Test
    public void whenPostInvalidClientIdAndValidMemberIdThenServiceReturnsSC422() {

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_85, CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();

        ErrorDTO error = new MembersRestrictionSteps(platformContextHeader, headers).postMemberRestrictionRequestError(CLIENT_ID_86, null, null, null, memberId);

        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.then(error.getMessage()).contains(MESSAGE_NOT_MATCHED_CLIENT);
        softly.assertAll();
    }

    @Test
    public void whenPostClientIdAndEmpGroupWithoutRestrictedTypeThenServiceReturnsSC422() {

        ErrorDTO error = new MembersRestrictionSteps(platformContextHeader, headers).postMemberRestrictionRequestError(CLIENT_ID_86, EMPLOYER_GROUP_NUMBER_CLID85, null, null, null);

        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.then(error.getMessage()).contains(MESSAGE_INVALID_RESTRICTED_ACCESS);
        softly.assertAll();
    }

    @Test
    public void whenPostWithoutClientIdThenServiceReturnsSC422() {

        ErrorDTO error = new MembersRestrictionSteps(platformContextHeader, headers).postMemberRestrictionRequestError(null, EMPLOYER_GROUP_NUMBER_CLID85, null, RESTRICTION_HOUSE_ACCOUNT, null);

        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.then(error.getMessage()).contains(MESSAGE_CLIENT_SHOULD_PROVIDED);
        softly.assertAll();
    }

    @Test
    public void whenPostWithInvalidMemberIdThenServiceReturnsSC422() {

        ErrorDTO error = new MembersRestrictionSteps(platformContextHeader, headers).postMemberRestrictionRequestError(CLIENT_ID_85, null, null, null, INVALID_MEMBER_ID);

        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.then(error.getMessage()).contains(MESSAGE_INVALID_UUID);
        softly.assertAll();
    }

    @Test
    public void whenPostWithInvalidDependentRelationCodeThenServiceReturnsSC422() {

        ErrorDTO error = new MembersRestrictionSteps(platformContextHeader, headers).postMemberRestrictionRequestError(CLIENT_ID_202, null, DEPENDENT_RELATION_CODE_INVALID, RESTRICTION_VIP_ACCOUNT, null);

        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.then(error.getMessage()).contains(MESSAGE_INVALID_DEPENDENT_RELATION_CODE);
        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-400---------------------------------------------
//need regression fix
    @Test
    public void whenPostWithInvalidRestrictionTypeThenServiceReturnsSC400() {

        ErrorDTO error = new MembersRestrictionSteps(platformContextHeader, headers).postMemberRestrictionRequestError(null, EMPLOYER_GROUP_NUMBER_CLID85, null, RESTRICTION_INVALID_ACCOUNT, null);

        softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
        //softly.then(error.getMessage()).contains(MESSAGE_INVALID_FORMAT);
        softly.assertAll();
    }
}

