package com.abc.automation.dtos.provider.providerQuestionAnswer;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class JustificationQuestionsResponseDTO {

    private String id;
    private List<QuestionDTO> questions;
    private String title;
    private String reviewProgramCode;
    private Boolean required;

    public String getReviewProgramCode() {
        return reviewProgramCode;
    }

    public void setReviewProgramCode(String reviewProgramCode) {
        this.reviewProgramCode = reviewProgramCode;
    }

    public Boolean getRequired() {
        return required;
    }

    public void setRequired(Boolean required) {
        this.required = required;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public List<QuestionDTO> getQuestions() {
        return questions;
    }

    public void setQuestions(List<QuestionDTO> questions) {
        this.questions = questions;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


}
