package com.abc.automation.helpers;

import com.abc.automation.helpers.constants.PlatformContextConstants;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.http.Method;
import io.restassured.internal.RestAssuredResponseImpl;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import org.testng.Reporter;

import java.io.InputStream;
import java.util.Map;

import static io.restassured.RestAssured.given;

/**
 * Contains the methods for sending requests using Rest-assured
 */
public class RequestOperationsHelper {

    /**
     * @param requestSpecification  everything that is defined between given() and then()
     * @param responseSpecification everything that is defined after then()
     * @param method                what type of request should be sent
     * @return response from the sent request
     */
    public Response sendRequest(RequestSpecification requestSpecification, ResponseSpecification responseSpecification, Method method) {

        // @formatter:off

        Response response =
                given()
                        .spec(requestSpecification)
                        .when()
                        .request(method);

        response.then()
                .spec(responseSpecification);

        // @formatter:on

        RestAssuredResponseImpl restAssuredResponse = (RestAssuredResponseImpl) response;

        Reporter.log(restAssuredResponse.getLogRepository().getRequestLog());
        Reporter.log(restAssuredResponse.getLogRepository().getResponseLog());

        return response;
    }

    public Response sendRequest(RequestSpecification requestSpecification, Method method) {
        return sendRequest(requestSpecification, given().then(), method);
    }

    /**
     * Sends POST request
     *
     * @param statusCode      - the expected response status code
     * @param platformContext - the value for the platform context header
     * @param headers         - values for all the required readers
     * @param bodyDTO         - the request body
     * @param basePath        - the base path to the endpoint
     * @param pathParamsMap   - the values for the path parameters
     * @param queryParamsMap  - the values for the query parameters
     * @return the response body as a string
     */
    public String sendPostRequest(int statusCode, String platformContext, Headers headers, Object bodyDTO, String basePath, Map<String, String> pathParamsMap, Map<String, String> queryParamsMap) {
        RequestSpecification requestSpecification = given();
        requestSpecification.headers(headers);
        requestSpecification.header(PlatformContextConstants.PLATFORM_CONTEXT, platformContext);
        requestSpecification.body(bodyDTO);
        requestSpecification.basePath(basePath);
        requestSpecification.pathParams(pathParamsMap);
        requestSpecification.queryParams(queryParamsMap);
        requestSpecification.contentType(ContentType.JSON);
        requestSpecification.relaxedHTTPSValidation();

        ResponseSpecification responseSpecification = given().then();
        responseSpecification.statusCode(statusCode);
        responseSpecification.contentType(ContentType.JSON);

        return sendRequest(requestSpecification, responseSpecification, Method.POST).then().extract().body().asString();
    }

    /**
     * Sends POST request with one file added as multiPart
     *
     * @param statusCode      - the expected response status code
     * @param platformContext - the value for the platform context header
     * @param headers         - values for all the required readers
     * @param controlName     - the control name to be used
     * @param fileName        - the file name to be used
     * @param stream          - the content to be attached
     * @param attachmentType  - the type of the attachment
     * @param basePath        - the base path to the endpoint
     * @param pathParamsMap   - the values for the path parameters
     * @param queryParamsMap  - the values for the query parameters
     * @return the response body as a string
     */
    public String sendPostRequestWithOneMultiPart(int statusCode, String platformContext, Headers headers, String controlName, String fileName, InputStream stream, String attachmentType, String basePath, Map<String, String> pathParamsMap, Map<String, String> queryParamsMap) {
        RequestSpecification requestSpecification = given();
        requestSpecification.headers(headers);
        requestSpecification.header(PlatformContextConstants.PLATFORM_CONTEXT, platformContext);
        requestSpecification.multiPart(controlName, fileName, stream, attachmentType);
        requestSpecification.basePath(basePath);
        requestSpecification.pathParams(pathParamsMap);
        requestSpecification.queryParams(queryParamsMap);
        requestSpecification.relaxedHTTPSValidation();

        ResponseSpecification responseSpecification = given().then();
        responseSpecification.statusCode(statusCode);

        return sendRequest(requestSpecification, responseSpecification, Method.POST).then().extract().body().asString();

    }

    /**
     * Method for performing generic HTTP POST request with a given pre-populated {@link RequestSpecification}.
     *
     * @param requestSpecification pre-populated {@link RequestSpecification} with the required properties (headers, body, etc.).
     * @return the request's {@link Response}.
     */
    public Response sendPostRequest(RequestSpecification requestSpecification) {
        return sendRequest(requestSpecification, Method.POST);
    }

    /**
     * Sends PUT request
     *
     * @param statusCode      - the expected response status code
     * @param platformContext - the value for the platform context header
     * @param headers         - values for all the required readers
     * @param bodyDTO         - the request body
     * @param basePath        - the base path to the endpoint
     * @param pathParamsMap   - the values for the path parameters
     * @param queryParamsMap  - the values for the query parameters
     * @return the response body as a string
     */
    public String sendPutRequest(int statusCode, String platformContext, Headers headers, Object bodyDTO, String basePath, Map<String, String> pathParamsMap, Map<String, String> queryParamsMap) {
        RequestSpecification requestSpecification = given();
        requestSpecification.headers(headers);
        requestSpecification.header(PlatformContextConstants.PLATFORM_CONTEXT, platformContext);
        requestSpecification.body(bodyDTO);
        requestSpecification.basePath(basePath);
        requestSpecification.pathParams(pathParamsMap);
        requestSpecification.queryParams(queryParamsMap);
        requestSpecification.contentType(ContentType.JSON);
        requestSpecification.relaxedHTTPSValidation();

        ResponseSpecification responseSpecification = given().then();
        responseSpecification.statusCode(statusCode);
        responseSpecification.contentType(ContentType.JSON);

        return sendRequest(requestSpecification, responseSpecification, Method.PUT).then().extract().body().asString();
    }

    /**
     * Generic method for performing HTTP PUT request with a given pre-populated {@link RequestSpecification}.
     *
     * @param requestSpecification pre-populated {@link RequestSpecification} with the required properties (headers, body, etc.).
     * @return the request's {@link Response}.
     */
    public Response sendPutRequest(RequestSpecification requestSpecification) {
        return sendRequest(requestSpecification, Method.PUT);
    }

    /**
     * Sends GET request
     *
     * @param statusCode      - the expected response status code
     * @param platformContext - the value for the platform context header
     * @param headers         - values for all the required readers
     * @param basePath        - the base path to the endpoint
     * @param pathParamsMap   - the values for the path parameters
     * @param queryParamsMap  - the values for the query parameters
     * @return the response body as a string
     */
    public String sendGetRequest(int statusCode, String platformContext, Headers headers, String basePath, Map<String, String> pathParamsMap, Map<String, String> queryParamsMap) {
        RequestSpecification requestSpecification = given();
        requestSpecification.headers(headers);
        requestSpecification.header(PlatformContextConstants.PLATFORM_CONTEXT, platformContext);
        requestSpecification.basePath(basePath);
        requestSpecification.pathParams(pathParamsMap);
        requestSpecification.queryParams(queryParamsMap);
        requestSpecification.contentType(ContentType.JSON);
        requestSpecification.relaxedHTTPSValidation();

        ResponseSpecification responseSpecification = given().then();
        responseSpecification.statusCode(statusCode);
        responseSpecification.contentType(ContentType.JSON);

        return sendRequest(requestSpecification, responseSpecification, Method.GET).then().extract().body().asString();
    }

    /**
     * Sends GET request with request body
     *
     * @param statusCode      - the expected response status code
     * @param platformContext - the value for the platform context header
     * @param headers         - values for all the required readers
     * @param bodyDTO         - the request body
     * @param basePath        - the base path to the endpoint
     * @param pathParamsMap   - the values for the path parameters
     * @param queryParamsMap  - the values for the query parameters
     * @return the response body as a string
     */
    public String sendGetRequestWithBody(int statusCode, String platformContext, Headers headers, Object bodyDTO, String basePath, Map<String, String> pathParamsMap, Map<String, String> queryParamsMap) {
        RequestSpecification requestSpecification = given();
        requestSpecification.headers(headers);
        requestSpecification.header(PlatformContextConstants.PLATFORM_CONTEXT, platformContext);
        requestSpecification.body(bodyDTO);
        requestSpecification.basePath(basePath);
        requestSpecification.pathParams(pathParamsMap);
        requestSpecification.queryParams(queryParamsMap);
        requestSpecification.contentType(ContentType.JSON);
        requestSpecification.relaxedHTTPSValidation();

        ResponseSpecification responseSpecification = given().then();
        responseSpecification.statusCode(statusCode);
        responseSpecification.contentType(ContentType.JSON);

        return sendRequest(requestSpecification, responseSpecification, Method.GET).then().extract().body().asString();
    }

    /**
     * Generic method for performing HTTP GET request with a given pre-populated {@link RequestSpecification}.
     *
     * @param requestSpecification pre-populated {@link RequestSpecification} with the required properties (headers, body, etc.).
     * @return the request's {@link Response}.
     */
    public Response sendGetRequest(RequestSpecification requestSpecification) {
        return sendRequest(requestSpecification, Method.GET);
    }

    /**
     * Sends DELETE request
     *
     * @param statusCode      - the expected response status code
     * @param platformContext - the value for the platform context header
     * @param headers         - values for all the required readers
     * @param basePath        - the base path to the endpoint
     * @param pathParamsMap   - the values for the path parameters
     * @param queryParamsMap  - the values for the query parameters
     * @return the response body as a string
     */
    public String sendDeleteRequest(int statusCode, String platformContext, Headers headers, String basePath, Map<String, String> pathParamsMap, Map<String, String> queryParamsMap) {
        RequestSpecification requestSpecification = given();
        requestSpecification.headers(headers);
        requestSpecification.header(PlatformContextConstants.PLATFORM_CONTEXT, platformContext);
        requestSpecification.basePath(basePath);
        requestSpecification.pathParams(pathParamsMap);
        requestSpecification.queryParams(queryParamsMap);
        requestSpecification.contentType(ContentType.JSON);
        requestSpecification.relaxedHTTPSValidation();

        ResponseSpecification responseSpecification = given().then();
        responseSpecification.statusCode(statusCode);
        responseSpecification.contentType(ContentType.JSON);

        return sendRequest(requestSpecification, responseSpecification, Method.DELETE).then().extract().body().asString();
    }

    /**
     * Generic method for performing HTTP DELETE request with a given pre-populated {@link RequestSpecification}.
     *
     * @param requestSpecification pre-populated {@link RequestSpecification} with the required properties (headers, body, etc.).
     * @return the request's {@link Response}.
     */
    public Response sendDeleteRequest(RequestSpecification requestSpecification) {
        return sendRequest(requestSpecification, Method.DELETE);
    }

    /**
     * Sends PATCH request
     *
     * @param statusCode      - the expected response status code
     * @param platformContext - the value for the platform context header
     * @param headers         - values for all the required readers
     * @param basePath        - the base path to the endpoint
     * @param pathParamsMap   - the values for the path parameters
     * @param queryParamsMap  - the values for the query parameters
     * @return the response body as a string
     */
    public String sendPatchRequest(int statusCode, String platformContext, Headers headers, Object bodyDTO, String basePath, Map<String, String> pathParamsMap, Map<String, String> queryParamsMap) {
        RequestSpecification requestSpecification = given();
        requestSpecification.headers(headers);
        requestSpecification.header(PlatformContextConstants.PLATFORM_CONTEXT, platformContext);
        requestSpecification.body(bodyDTO);
        requestSpecification.basePath(basePath);
        requestSpecification.pathParams(pathParamsMap);
        requestSpecification.queryParams(queryParamsMap);
        requestSpecification.contentType(ContentType.JSON);
        requestSpecification.relaxedHTTPSValidation();

        ResponseSpecification responseSpecification = given().then();
        responseSpecification.statusCode(statusCode);
        responseSpecification.contentType(ContentType.JSON);

        return sendRequest(requestSpecification, responseSpecification, Method.PATCH).then().extract().body().asString();
    }

    /**
     * Generic method for performing HTTP PATCH request with a given pre-populated {@link RequestSpecification}.
     *
     * @param requestSpecification pre-populated {@link RequestSpecification} with the required properties (headers, body, etc.).
     * @return the request's {@link Response}.
     */
    public Response sendPatchRequest(RequestSpecification requestSpecification) {
        return sendRequest(requestSpecification, Method.PATCH);
    }

    /**
     * Generic method for performing HTTP HEAD request with a given pre-populated {@link RequestSpecification}.
     *
     * @param requestSpecification pre-populated {@link RequestSpecification} with the required properties (headers, body, etc.).
     * @return the request's {@link Response}.
     */
    public Response sendHeadRequest(RequestSpecification requestSpecification) {
        return sendRequest(requestSpecification, Method.HEAD);
    }

}
