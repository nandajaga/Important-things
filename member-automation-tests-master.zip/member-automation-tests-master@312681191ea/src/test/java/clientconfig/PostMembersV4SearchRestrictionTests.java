package clientconfig;

import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.tests.base.GetTests;
import com.aim.automation.tests.base.PostTests;
import dtos.clientconfig.RestrictionTypeResponseDTO;
import dtos.datamanager.MemberResponseDTO;
import dtos.search.GETMemberSearchDTO;
import dtos.search.MemberSearchDTO;
import factories.clientconfig.MemberRestrictionDTOFactory;
import helpers.constants.BasePathConstants;
import helpers.dataproviders.DataProviders;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.clientconfig.MemberSearchRestrictionV4Steps;
import steps.datamanager.MemberDataManagerSteps;
import steps.search.MemberSearchV3Steps;

import java.text.ParseException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

import static helpers.constants.ClientConfigConstants.*;
import static helpers.constants.Constants.*;

/**
 * Created by sbioi on 6/28/2021.
 */
public class PostMembersV4SearchRestrictionTests extends PostTests {

    private String CLIENT_MEMBER;
    private String firstName;
    private String lastName;
    private MemberDataManagerSteps memberDataManagerSteps;
    private PlatformContextUtils platformContextUtils;
    Date date;

    @BeforeClass
    public void init() {
        basePath = BasePathConstants.BASE_PATH_V4_MEMBER_SEARCH_RESTRICTION;
        body = new MemberRestrictionDTOFactory().createRestrictionRequestMemberDTO(CLIENT_ID_183, EMPLOYER_GROUP_NUMBER_CLID183, null, RESTRICTION_HEALTH_PLAN, null, null, null);
        platformContextUtils = new PlatformContextUtils();
    }

    @BeforeMethod
    public void clientMemberID() throws ParseException {
        CLIENT_MEMBER = RandomStringUtils.randomNumeric(10) + RandomStringUtils.randomAlphabetic(5).toUpperCase();
        firstName = RandomStringUtils.random(10, true, false);
        lastName = RandomStringUtils.random(10, true, false);
        LocalDate lDate = LocalDate.now();
        date = java.sql.Date.valueOf(lDate.plusDays(0));
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test(dataProvider = "restrictedClientId", dataProviderClass = DataProviders.class)
    public void whenSearchedRestrictedMemberUsingclientIdAndmemberIdResponse200(String clientId) throws ParseException {
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));
        platformContextHeader = platformContextUtils.changeDateOfServiceDate(platformContextHeader, date);
        platformContextHeader = platformContextUtils.changeRootLevelDateOfServiceDate(platformContextHeader, date);
        platformContextHeader = platformContextUtils.changeChannelCode(platformContextHeader, PC_CHANNEL_CODE_CC);
        platformContextHeader = platformContextUtils.changeFundingType(platformContextHeader, CLIENT_FUNDINGTYPECODE_ASO);


        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(clientId, CLIENT_MEMBER);
        String memberId = memberResponseDTO.getId();
        RestrictionTypeResponseDTO[] restrictionTypeResponseDTO = new MemberSearchRestrictionV4Steps(platformContextHeader, headers).postMemberRestrictionRequest(clientId, null, null, null, memberId, null, "MEDICARE", USER_LOC_CODE_RESTRICTED);

        softly.then(restrictionTypeResponseDTO[0].getIsRestricted()).isTrue();
        softly.then(restrictionTypeResponseDTO[0].getRestrictionType()).isEqualTo(RESTRICTED_TYPE_EXPANDED_ACCESS);
        softly.assertAll();
    }

    @Test(dataProvider = "restrictedClientId", dataProviderClass = DataProviders.class)
    public void whenSearchedNonRestricteMemberUsingdMemberIdResponse200(String clientId) throws ParseException {
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));
        platformContextHeader = platformContextUtils.changeDateOfServiceDate(platformContextHeader, date);
        platformContextHeader = platformContextUtils.changeRootLevelDateOfServiceDate(platformContextHeader, date);
        platformContextHeader = platformContextUtils.changeChannelCode(platformContextHeader, PC_CHANNEL_CODE_P);

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMemberWithContacts(clientId, firstName, lastName, DOB, CLIENT_MEMBER);
        String memberId = memberResponseDTO.getId();
        RestrictionTypeResponseDTO[] restrictionTypeResponseDTO = new MemberSearchRestrictionV4Steps(platformContextHeader, headers).postMemberRestrictionRequest(clientId, null, null, null, memberId, null, null, USER_LOC_CODE_RESTRICTED);

        softly.then(restrictionTypeResponseDTO[0].getIsRestricted()).isFalse();
        softly.then(restrictionTypeResponseDTO[0].getRestrictionType()).isEqualTo(RESTRICTED_TYPE_EXPANDED_ACCESS_NONE);
        softly.assertAll();
    }
}