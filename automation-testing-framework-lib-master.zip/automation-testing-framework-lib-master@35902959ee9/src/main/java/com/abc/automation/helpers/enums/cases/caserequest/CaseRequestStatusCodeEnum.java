package com.abc.automation.helpers.enums.cases.caserequest;

public enum CaseRequestStatusCodeEnum {
    /**
     * Status code {@code O} is used to indicate that case request is {@code OPEN}.
     */
    OPEN("OPEN"),

    /**
     * Status code {@code C} is used to indicate that case request is {@code CLOSED}
     */
    CANCELED("CANCELED"),

    /**
     * Status code {@code SUBMITTED} is used to indicate that a case request is {@code SUBMITTED}
     */
    SUBMITTED("SUBMITTED"),
    INVALID_CODE("SDFGHJKL");

    private String status;

    CaseRequestStatusCodeEnum(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

}