# Member Automation Test Project
The purpose of this project is to automate the test process of the Member Domain.
It will contain the test cases for all Member services and their corresponding endpoints.

## Structure

>**src/main/java**

**dtos package** - containing dtos classes representing the json as java object, containing the properties and getters and setters

**factories package** - containing factories classes representing the dto object which fill the fields with values

**helpers package** - containing the common helper functionality needed for the tests and steps across the whole framework

**steps package** - containing all functions for the allowed operations for given endpoint, this is a place where the request is prepared and the response is converted to the needed dto object

>**src/test/java**

**tests package** - containing classes with the tests

>**src/test/resources**
- config properties - this properties file should be part of every domain project so it can be used to control the functionality. These options could also be provided as runtime parameters.
- smokesuite.xml - to be used for smoke test after deployment to check that the services are up and running
- functionalsuite.xml - to be used for functional testing of the services 


## How to run the test cases in the project
The first possible way is via command prompt by executing the following command: 
    **gradle test** with run time parameter `-DbaseURI`

    Example for DEV environment:   
    gradle test -DbaseURI=https://member.xformdevpoc.com/

The second approach is by running the test cases from IntelliJ IDE and passing the 'baseURI' as runtime parameter.
* Go to the *Run -> Edit Configuration* menu in IntelliJ IDE. Expand *Defaults* and navigate to *TestNG*
   Set value **-DbaseURI=https://member.xformdevpoc.com/** in VM Options field.
   Click *Apply*.
   
## Smokesuite and @DataProvider
When using  `@DataProvider` annotation to provide multiple data to a single test and this test needs to be added to `smokesuite.xml` additional modifications needs to be added to the data provider method in order to have only single execution of the test in the suite.
* `ITestContext` needs to be used in this case to get the needed parameters from the xml file 
* `<parameter name="<name>" value="<value>" />` needs to be added to the xml file under `<test>`  tag
* the parameter needs to be get from the xml file if provided `context.getCurrentXmlTest().getParameter("<name>)`
    

## Integration with shared testing lib
The project is integrated with the shared testing lib and uses the following features:
* `RequestOperationHelper`: The steps are using this class to send the rest-assured requests and to convert the response to the needed DTO class for better usage
* `CustomFilterableRequestSpecification`: Used in the steps for preparation of the request elements such as basePath, headers, body
* TestNG listeners and runner for better reporting and running of the fatJar in UCD
* `base tests`: common classes used for setup of the tests, the shared elements, test configuration and tests that executes additional checks for properly handling of the errors such as method not allowed, missing headers

## How to use the shared lib functionality
Here is a description how the benefits from the shared testing lib could be used
* base tests - to use the tests from the lib, the test class needs to extend the relevant class from the base package - <method>Tests (or <method>WithPlatformContextTests to get additional tests for the PC header) and to set `basePath`, `queryParams`, `pathParams` and `body` in `@BeforeClass` method
* helper functionality - just import the helper class where needed
* available dtos, factories and steps

## How to change the shared lib version
To update the version the following needs to be changed in *build.gradle*
    
    compile 'shared-tool-chain:automation-testing-framework-lib:<version>'
    compile 'shared-tool-chain:automation-testing-framework-lib:<version>:test'

## Build the project
Sonarqube analyze is performed for the project to verify good code quality of the automation project.
 
Before submitting code you need to analyze the code and fix all the issues in order to get successful build in Jenkins
    
    gradle sonarqube -x test

The building process used in Jenkins is: 
1. Build the project
2. Sonarqube analysis 
3. Check the quality gate
4. Build fatJaj 
5. Push to UCD
6. Deploy to UCD