package dtos.enrollments;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MemberEnrollmentsDTO {
    private String id;

    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
    )

    private Date createdOn;
    private List<MemberEnrollmentDTO> enrollments;

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getCreatedOn() {
        return this.createdOn != null ? new Date(this.createdOn.getTime()) : null;
    }

    public void setCreatedOn(Date createdOn) {
        if (createdOn != null) {
            this.createdOn = new Date(createdOn.getTime());
        }
    }

    public List<MemberEnrollmentDTO> getEnrollments() {
        return this.enrollments != null ? new ArrayList(this.enrollments) : null;
    }

    public void setEnrollments(List<MemberEnrollmentDTO> enrollments) {
        if (enrollments != null) {
            this.enrollments = new ArrayList(enrollments);
        }

    }
}
//AREA 51
