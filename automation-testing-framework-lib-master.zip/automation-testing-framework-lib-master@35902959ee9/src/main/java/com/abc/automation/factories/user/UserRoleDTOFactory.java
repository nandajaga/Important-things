package com.abc.automation.factories.user;

import com.abc.automation.dtos.user.UserRoleDTO;
import com.abc.automation.helpers.enums.user.UserRoleEnum;

import java.util.ArrayList;

public class UserRoleDTOFactory {

    private static final String VALID_ISPRIMARY = "Y";

    public ArrayList<UserRoleDTO> createUserRoleDTO(String id, String code, String name, String description, String isPrimary) {
        UserRoleDTO userRoleDTO = createUserRole(id, code, name, description, isPrimary);

        ArrayList<UserRoleDTO> userRoles = new ArrayList<>();
        userRoles.add(userRoleDTO);

        return userRoles;
    }

    public ArrayList<UserRoleDTO> createUserRoleDTO() {
        return createUserRoleDTO(UserRoleEnum.RS);
    }

    public ArrayList<UserRoleDTO> createUserRoleDTO(UserRoleEnum userRoleEnum) {
        return createUserRoleDTO(userRoleEnum.getId(), userRoleEnum.getCode(), userRoleEnum.getName(), userRoleEnum.getDescription(), VALID_ISPRIMARY);
    }

    private UserRoleDTO createUserRole(String id, String code, String name, String description, String isPrimary) {
        UserRoleDTO userRoleDTO = new UserRoleDTO();

        userRoleDTO.setId(id);
        userRoleDTO.setCode(code);
        userRoleDTO.setName(name);
        userRoleDTO.setDescription(description);
        userRoleDTO.setIsPrimary(isPrimary);

        return userRoleDTO;
    }
}
