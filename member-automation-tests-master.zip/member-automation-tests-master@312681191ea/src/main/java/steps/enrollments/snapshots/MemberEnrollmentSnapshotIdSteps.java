package steps.enrollments.snapshots;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.enrollments.snapshots.MemberEnrollmentSnapshotDTOV2GetOnly;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

import static helpers.constants.BasePathConstants.BASE_PATH_GET_ENROLLMENT_SNAPSHOT;

/**
 * Created by RKondakova on 5/2/2019.
 */
public class MemberEnrollmentSnapshotIdSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public MemberEnrollmentSnapshotIdSteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BASE_PATH_GET_ENROLLMENT_SNAPSHOT);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    public MemberEnrollmentSnapshotDTOV2GetOnly getMemberEnrollmentSnapshotId(String clientId, String snapshotId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);
        pathParamsMap.put("snapshotId", snapshotId);

        requestSpecification.addPathParams(pathParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_OK);

        return result.as(MemberEnrollmentSnapshotDTOV2GetOnly.class);
    }

    public ErrorDTO getMemberEnrollmentSnapshotIdErrors(String clientId, String snapshotId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);
        pathParamsMap.put("snapshotId", snapshotId);

        requestSpecification.addPathParams(pathParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorDTO.class);
    }
}
