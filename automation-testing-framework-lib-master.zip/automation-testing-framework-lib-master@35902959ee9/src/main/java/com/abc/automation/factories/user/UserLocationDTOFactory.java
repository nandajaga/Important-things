package com.abc.automation.factories.user;

import com.abc.automation.dtos.user.UserLocationDTO;

public class UserLocationDTOFactory {

    private static final String validLocationCode = "DF";
    private static final String validLocationCode_RRS = "RRS";

    public UserLocationDTO createUserLocationDTO(String locationCode) {
        UserLocationDTO userLocationDTO = new UserLocationDTO();
        userLocationDTO.setLocationCode(locationCode);
        return userLocationDTO;
    }

    public UserLocationDTO createUserLocationDTO() {
        return createUserLocationDTO(validLocationCode);
    }

    public UserLocationDTO createUserLocationDTORRS() {
        return createUserLocationDTO(validLocationCode_RRS);
    }
}
