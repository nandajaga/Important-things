package com.abc.automation.dtos.member.enrollments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.ArrayList;

/**
 * Created by PPetarcheva on 4/17/2019.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientSpecificEnrollmentsDTO {

    private String alternateProductId;
    private String affordableCareActMetalCategory;
    private Boolean alternateFlag;
    private String benefitCode;
    private Boolean callOutExclusionFlag;
    private String deliverySystem;
    private String exchangeIndicator;
    private Boolean exchangeTypeFlag;
    private String facetsProductId;
    private String groupName;
    private Boolean houseAccountFlag;
    private String medicalManagementSystem;
    private String networkCode;
    private Boolean preExistingCondition;
    private String productType;
    private String recipientId;
    private String regionCode;
    private String sourceSystem;
    private Boolean tmjFlag;
    private Boolean qhpCertificationIndicator;
    private Boolean transparencyIndicator;
    private String pricePointPlanCode;
    private Boolean calpersFlag;
    private String businessIndicator;
    private Boolean memberReviewByCompanyFlag;
    private String regulatorLicensedAnthemLegalEntityCode;
    private Boolean mrOnly;
    private String gracePeriod;
    private String mpc;
    private String mixerCode;
    private ArrayList<AdditionalFieldsDTO> additionalFields;
    private String subGroupCode;
    private String clientAccountNumber;
    private String clientLineOfBusinessCode;
    private String businessMarketSegmentName;
    private String alternateBenefitPlanCode;
    private Boolean preAcaHonorContractFlag;
    private String clientAccountName;
    private String clientFundingTypeCode;
    private String erisaIndicator;

    public String getErisaIndicator() { return erisaIndicator; }

    public void setErisaIndicator(String erisaIndicator) { this.erisaIndicator = erisaIndicator; }

    public String getAlternateProductId() {
        return this.alternateProductId;
    }

    public void setAlternateProductId(String alternateProductId) {
        this.alternateProductId = alternateProductId;
    }

    public String getAffordableCareActMetalCategory() {
        return this.affordableCareActMetalCategory;
    }

    public void setAffordableCareActMetalCategory(String affordableCareActMetalCategory) {
        this.affordableCareActMetalCategory = affordableCareActMetalCategory;
    }

    public Boolean getAlternateFlag() {
        return this.alternateFlag;
    }

    public void setAlternateFlag(Boolean alternateFlag) {
        this.alternateFlag = alternateFlag;
    }

    public String getBenefitCode() {
        return this.benefitCode;
    }

    public void setBenefitCode(String benefitCode) {
        this.benefitCode = benefitCode;
    }

    public Boolean getCallOutExclusionFlag() {
        return this.callOutExclusionFlag;
    }

    public void setCallOutExclusionFlag(Boolean callOutExclusionFlag) {
        this.callOutExclusionFlag = callOutExclusionFlag;
    }

    public String getDeliverySystem() {
        return this.deliverySystem;
    }

    public void setDeliverySystem(String deliverySystem) {
        this.deliverySystem = deliverySystem;
    }

    public String getExchangeIndicator() {
        return this.exchangeIndicator;
    }

    public void setExchangeIndicator(String exchangeIndicator) {
        this.exchangeIndicator = exchangeIndicator;
    }

    public Boolean getExchangeTypeFlag() {
        return this.exchangeTypeFlag;
    }

    public void setExchangeTypeFlag(Boolean exchangeTypeFlag) {
        this.exchangeTypeFlag = exchangeTypeFlag;
    }

    public String getFacetsProductId() {
        return this.facetsProductId;
    }

    public void setFacetsProductId(String facetsProductId) {
        this.facetsProductId = facetsProductId;
    }

    public String getGroupName() {
        return this.groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public Boolean getHouseAccountFlag() {
        return this.houseAccountFlag;
    }

    public void setHouseAccountFlag(Boolean houseAccountFlag) {
        this.houseAccountFlag = houseAccountFlag;
    }

    public String getMedicalManagementSystem() {
        return this.medicalManagementSystem;
    }

    public void setMedicalManagementSystem(String medicalManagementSystem) {
        this.medicalManagementSystem = medicalManagementSystem;
    }

    public String getNetworkCode() {
        return this.networkCode;
    }

    public void setNetworkCode(String networkCode) {
        this.networkCode = networkCode;
    }

    public Boolean getPreExistingCondition() {
        return this.preExistingCondition;
    }

    public void setPreExistingCondition(Boolean preExistingCondition) {
        this.preExistingCondition = preExistingCondition;
    }

    public String getProductType() {
        return this.productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getRecipientId() {
        return this.recipientId;
    }

    public void setRecipientId(String recipientId) {
        this.recipientId = recipientId;
    }

    public String getRegionCode() {
        return this.regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public String getSourceSystem() {
        return this.sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public Boolean getTmjFlag() {
        return this.tmjFlag;
    }

    public void setTmjFlag(Boolean tmjFlag) {
        this.tmjFlag = tmjFlag;
    }

    public Boolean getQhpCertificationIndicator() {
        return this.qhpCertificationIndicator;
    }

    public void setQhpCertificationIndicator(Boolean qhpCertificationIndicator) {
        this.qhpCertificationIndicator = qhpCertificationIndicator;
    }

    public Boolean getTransparencyIndicator() {
        return this.transparencyIndicator;
    }

    public void setTransparencyIndicator(Boolean transparencyIndicator) {
        this.transparencyIndicator = transparencyIndicator;
    }

    public String getPricePointPlanCode() {
        return this.pricePointPlanCode;
    }

    public void setPricePointPlanCode(String pricePointPlanCode) {
        this.pricePointPlanCode = pricePointPlanCode;
    }

    public Boolean getCalpersFlag() {
        return this.calpersFlag;
    }

    public void setCalpersFlag(Boolean calpersFlag) {
        this.calpersFlag = calpersFlag;
    }

    public String getBusinessIndicator() {
        return this.businessIndicator;
    }

    public void setBusinessIndicator(String businessIndicator) {
        this.businessIndicator = businessIndicator;
    }

    public Boolean getMemberReviewByCompanyFlag() {
        return this.memberReviewByCompanyFlag;
    }

    public void setMemberReviewByCompanyFlag(Boolean memberReviewByCompanyFlag) {
        this.memberReviewByCompanyFlag = memberReviewByCompanyFlag;
    }

    public String getRegulatorLicensedAnthemLegalEntityCode() {
        return this.regulatorLicensedAnthemLegalEntityCode;
    }

    public void setRegulatorLicensedAnthemLegalEntityCode(String regulatorLicensedAnthemLegalEntityCode) {
        this.regulatorLicensedAnthemLegalEntityCode = regulatorLicensedAnthemLegalEntityCode;
    }

    public Boolean getMrOnly() {
        return this.mrOnly;
    }

    public void setMrOnly(Boolean mrOnly) {
        this.mrOnly = mrOnly;
    }

    public String getGracePeriod() {
        return this.gracePeriod;
    }

    public void setGracePeriod(String gracePeriod) {
        this.gracePeriod = gracePeriod;
    }

    public String getMpc() {
        return mpc;
    }

    public void setMpc(String mpc) {
        this.mpc = mpc;
    }

    public String getMixerCode() {
        return mixerCode;
    }

    public void setMixerCode(String mixerCode) {
        this.mixerCode = mixerCode;
    }

    public ArrayList<AdditionalFieldsDTO> getAdditionalFields() {
        return additionalFields;
    }

    public void setAdditionalFields(ArrayList<AdditionalFieldsDTO> additionalFields) {
        this.additionalFields = additionalFields;
    }

    public String getSubGroupCode() {
        return subGroupCode;
    }

    public void setSubGroupCode(String subGroupCode) {
        this.subGroupCode = subGroupCode;
    }

    public String getClientAccountNumber() {
        return clientAccountNumber;
    }

    public void setClientAccountNumber(String clientAccountNumber) {
        this.clientAccountNumber = clientAccountNumber;
    }

    public String getClientLineOfBusinessCode() {
        return clientLineOfBusinessCode;
    }

    public void setClientLineOfBusinessCode(String clientLineOfBusinessCode) {
        this.clientLineOfBusinessCode = clientLineOfBusinessCode;
    }

    public String getBusinessMarketSegmentName() {
        return businessMarketSegmentName;
    }

    public void setBusinessMarketSegmentName(String businessMarketSegmentName) {
        this.businessMarketSegmentName = businessMarketSegmentName;
    }

    public String getAlternateBenefitPlanCode() {
        return alternateBenefitPlanCode;
    }

    public void setAlternateBenefitPlanCode(String alternateBenefitPlanCode) {
        this.alternateBenefitPlanCode = alternateBenefitPlanCode;
    }

    public Boolean getPreAcaHonorContractFlag() {
        return preAcaHonorContractFlag;
    }

    public void setPreAcaHonorContractFlag(Boolean preAcaHonorContractFlag) {
        this.preAcaHonorContractFlag = preAcaHonorContractFlag;
    }

    public String getClientAccountName() {
        return clientAccountName;
    }

    public void setClientAccountName(String clientAccountName) {
        this.clientAccountName = clientAccountName;
    }

    public String getClientFundingTypeCode() {
        return clientFundingTypeCode;
    }

    public void setClientFundingTypeCode(String clientFundingTypeCode) {
        this.clientFundingTypeCode = clientFundingTypeCode;
    }

}
