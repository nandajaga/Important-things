package com.abc.automation.tests.base;

import com.abc.automation.dtos.GenericErrorDTO;
import com.abc.automation.helpers.CustomFilterableRequestSpecification;
import com.abc.automation.helpers.constants.ErrorMessagesConstants;
import com.abc.automation.helpers.dataproviders.DataProviders;
import com.abc.automation.helpers.enums.RequestHeadersEnum;
import com.abc.automation.steps.ErrorsSteps;
import io.restassured.http.ContentType;
import io.restassured.http.Method;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static org.apache.http.HttpStatus.SC_BAD_REQUEST;
import static org.apache.http.HttpStatus.SC_METHOD_NOT_ALLOWED;

public class GetTests extends BaseTest {

    private CustomFilterableRequestSpecification specification;

    @BeforeMethod (alwaysRun = true)
    public void initGet() {
        specification = new CustomFilterableRequestSpecification();
        specification.addBasePath(basePath);
        specification.addPathParams(pathParamsMap);
        specification.addQueryParams(queryParamsMap);
        specification.setContentType(ContentType.JSON);
        specification.addHeaders(headers);
        specification.addHeaders(additionalHeaders);
        specification.addPlatformContextToRequest(platformContextHeader);
    }

    @Test
    public void whenPostOnGetEndpointThenServiceReturnsMethodNotAllowedResponse() {
        ErrorsSteps errorsSteps = new ErrorsSteps();
        GenericErrorDTO errorDTO = errorsSteps.sendPostRequestWithGenericError(specification);

        softNG.assertEquals(errorDTO.getStatus(), SC_METHOD_NOT_ALLOWED, "Status code is not correct!");
        softNG.assertEquals(errorDTO.getMessage(), String.format(ErrorMessagesConstants.METHOD_NOT_ALLOWED_MESSAGE, Method.POST), "Error message is not correct!");
        softNG.assertAll();
    }

    @Test
    public void whenPatchOnGetEndpointThenServiceReturnMethodNotAllowedResponse() {
        ErrorsSteps errorsSteps = new ErrorsSteps();
        GenericErrorDTO errorDTO = errorsSteps.sendPatchRequestWithGenericError(specification);

        softNG.assertEquals(errorDTO.getStatus(), SC_METHOD_NOT_ALLOWED, "Status code is not correct!");
        softNG.assertEquals(errorDTO.getMessage(), String.format(ErrorMessagesConstants.METHOD_NOT_ALLOWED_MESSAGE, Method.PATCH), "Error message is not correct!");
        softNG.assertAll();
    }

    @Test
    public void whenPutOnGetEndpointThenServiceReturnsMethodNotAllowedResponse() {
        ErrorsSteps errorsSteps = new ErrorsSteps();
        GenericErrorDTO errorDTO = errorsSteps.sendPutRequestWithGenericError(specification);

        softNG.assertEquals(errorDTO.getStatus(), SC_METHOD_NOT_ALLOWED, "Status code is not correct!");
        softNG.assertEquals(errorDTO.getMessage(), String.format(ErrorMessagesConstants.METHOD_NOT_ALLOWED_MESSAGE, Method.PUT), "Error message is not correct!");
        softNG.assertAll();
    }

    @Test
    public void whenDeleteOnGetEndpointThenServiceReturnMethodNotAllowedResponse() {
        ErrorsSteps errorsSteps = new ErrorsSteps();
        GenericErrorDTO errorDTO = errorsSteps.sendDeleteRequestWithGenericError(specification);

        softNG.assertEquals(errorDTO.getStatus(), SC_METHOD_NOT_ALLOWED, "Status code is not correct!");
        softNG.assertEquals(errorDTO.getMessage(), String.format(ErrorMessagesConstants.METHOD_NOT_ALLOWED_MESSAGE, Method.DELETE), "Error message is not correct!");
        softNG.assertAll();
    }

    @Test
    public void whenGetAndNoRequestHeaderSentThenServiceReturnsBadRequest() {
        ErrorsSteps errorsSteps = new ErrorsSteps();
        specification.getFilterableRequestSpecification().removeHeaders();
        specification.setContentType(ContentType.JSON);

        GenericErrorDTO errorDTO = errorsSteps.sendGetRequestWithGenericError(specification);

        softNG.assertEquals(errorDTO.getStatus(), SC_BAD_REQUEST, "Status code is not correct!");
        softNG.assertTrue(errorDTO.getMessage().startsWith(ErrorMessagesConstants.BAD_REQUEST_MESSAGE_START), "Error message is not correct!");
        softNG.assertTrue(errorDTO.getMessage().endsWith(ErrorMessagesConstants.BAD_REQUEST_MESSAGE_END), "Error message is not correct!");
        softNG.assertAll();
    }

    @Test(dataProvider = "Headers", dataProviderClass = DataProviders.class)
    public void whenGetWithMissingHeaderThenServiceReturnsBadRequest(RequestHeadersEnum missingHeader) {
        specification.removeHeader(missingHeader.getName());

        ErrorsSteps errorsSteps = new ErrorsSteps();
        GenericErrorDTO errorDTO = errorsSteps.sendGetRequestWithGenericError(specification);

        softNG.assertEquals(errorDTO.getStatus(), SC_BAD_REQUEST, "Status code is not correct!");
        softNG.assertEquals(errorDTO.getMessage(), String.format(ErrorMessagesConstants.BAD_REQUEST_MESSAGE, missingHeader.getName()), "Error message is not correct!");
        softNG.assertAll();
    }
}
