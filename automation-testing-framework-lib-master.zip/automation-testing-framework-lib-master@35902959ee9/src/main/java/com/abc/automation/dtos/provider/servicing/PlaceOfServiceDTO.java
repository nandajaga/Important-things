package com.abc.automation.dtos.provider.servicing;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
public class PlaceOfServiceDTO {

    private String code;
    private String name;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
