package dtos.search;

import java.util.ArrayList;

/**
 * Created by RKondakova on 6/10/2019.
 */
public class GETMemberSearchDTO {

    private int totalPages;
    private int totalElements;
    private String message;
    private ArrayList<MemberSearchDTO> members;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    public int getTotalElements() {
        return totalElements;
    }

    public void setTotalElements(int totalElements) {
        this.totalElements = totalElements;
    }

    public ArrayList<MemberSearchDTO> getMembers() {
        if (this.members != null) {
            return new ArrayList<>(members);
        }
        return null;
    }

    public void setMembers(ArrayList<MemberSearchDTO> members) {
        if (members != null) {
            this.members = new ArrayList<>(members);
        }
    }
}
