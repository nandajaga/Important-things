package com.abc.automation.steps.provider.ordering.snapshot;

import com.abc.automation.factories.provider.snapshot.CreateOrderingProviderSnapshotDTOFactory;
import com.abc.automation.helpers.CustomFilterableRequestSpecification;
import com.abc.automation.helpers.EnvironmentHelper;
import com.abc.automation.helpers.RequestOperationsHelper;
import com.abc.automation.helpers.constants.BasePathConstants;
import com.abc.automation.helpers.constants.PrepareHeadersWithUUID;
import com.abc.automation.helpers.enums.DomainEnum;
import com.abc.automation.steps.provider.ordering.CreateOrderingProviderSteps;
import com.abc.automation.dtos.provider.ordering.OrderingProviderSnapshotResponseDTO;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

/**
 * Created by PPetarcheva on 4/17/2019.
 */
public class OrderingProviderSnapshotSteps {
    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public OrderingProviderSnapshotSteps(String platformContext, Headers headers) {
        headers = new PrepareHeadersWithUUID().prepareHeaderWithUUID();
        requestSpecification = new CustomFilterableRequestSpecification();
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.addHeaders(headers);
        requestSpecification.setContentType(ContentType.JSON);
    }

    public OrderingProviderSnapshotSteps(CustomFilterableRequestSpecification requestSpecification) {
        Headers headers = new PrepareHeadersWithUUID().prepareHeaderWithUUID();

        this.requestSpecification = new CustomFilterableRequestSpecification();
        requestOperationsHelper = new RequestOperationsHelper();

        this.requestSpecification.addHeaders(headers);
        this.requestSpecification.setContentType(ContentType.JSON);
    }

    public Response createOrderingProviderSnapshotResponse(int clientId) {
        CreateOrderingProviderSteps createOrderingProviderSteps = new CreateOrderingProviderSteps(requestSpecification);
        String ngProviderId = createOrderingProviderSteps.createOrderingProviderAndGetNgProviderId(clientId);
        Integer providerClientId = createOrderingProviderSteps.createOrderingProviderAndGetProviderClientId(clientId);

        EnvironmentHelper environmentHelper = new EnvironmentHelper();

        requestSpecification.addBasePath(BasePathConstants.PROVIDER_CREATE_ORDERING_SNAPSHOT_BASE_PATH);
        requestSpecification.addBaseURI(environmentHelper.constructBaseURIForDomain(DomainEnum.PROVIDER));

        CreateOrderingProviderSnapshotDTOFactory createOrderingProviderSnapshotDTOFactory = new CreateOrderingProviderSnapshotDTOFactory();

        Object body = createOrderingProviderSnapshotDTOFactory.createOrderingProviderSnapshotDTO(providerClientId, ngProviderId);
        requestSpecification.addBodyToRequest(body);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        // TODO: Temporary fix for ESS search for provider. Remove when the bug is fixed - NCP-27111
        int count = 0;

        while (result.statusCode() == HttpStatus.SC_NOT_FOUND && count < 30) {
            count++;

            try {
                Thread.sleep(10000);
            } catch (InterruptedException e) {
                // No need to do anything here
                Thread.currentThread().interrupt();
            }

            result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());
        }

        return result;
    }

    public OrderingProviderSnapshotResponseDTO createOrderingProviderSnapshot(int clientId) {
        Response result = createOrderingProviderSnapshotResponse(clientId);

        result.then().statusCode(HttpStatus.SC_CREATED);

        return result.getBody().as(OrderingProviderSnapshotResponseDTO.class);
    }

    public String createOrderingProviderSnapshotAndSnapshotId(int clientId) {
        return createOrderingProviderSnapshot(clientId).getSnapshotId();
    }

}
