package com.abc.automation.dtos.member.snapshot;

import com.abc.automation.dtos.member.demographics.MemberDemographicsDTO;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MemberDemographicsSnapshotResponseDTO {

    private MemberDemographicsDTO memberDemographics;
    private String snapshotId;

    public MemberDemographicsDTO getMemberDemographics() {
        return memberDemographics;
    }

    public void setMemberDemographics(MemberDemographicsDTO memberDemographics) {
        this.memberDemographics = memberDemographics;
    }

    public String getSnapshotId() {
        return snapshotId;
    }

    public void setSnapshotId(String snapshotId) {
        this.snapshotId = snapshotId;
    }
}
