package dtos.rabbitmqsimulator;

/**
 * Created by VBaliyska on 10/2/2019.
 */
public class PayloadMixerCodeDTO {

    private int mixerCodeMapIdentifier;
    private String clientIdentifier;
    private String sourceSystemCode;
    private String employerGroupCode;
    private String mixerCode;
    private String effectiveStartDate;
    private String effectiveEndDate;
    private boolean manualAddEnableFlag;

    public int getMixerCodeMapIdentifier() {
        return mixerCodeMapIdentifier;
    }

    public void setMixerCodeMapIdentifier(int mixerCodeMapIdentifier) {
        this.mixerCodeMapIdentifier = mixerCodeMapIdentifier;
    }

    public String getClientIdentifier() {
        return clientIdentifier;
    }

    public void setClientIdentifier(String clientIdentifier) {
        this.clientIdentifier = clientIdentifier;
    }

    public String getSourceSystemCode() {
        return sourceSystemCode;
    }

    public void setSourceSystemCode(String sourceSystemCode) {
        this.sourceSystemCode = sourceSystemCode;
    }

    public String getEmployerGroupCode() {
        return employerGroupCode;
    }

    public void setEmployerGroupCode(String employerGroupCode) {
        this.employerGroupCode = employerGroupCode;
    }

    public String getMixerCode() {
        return mixerCode;
    }

    public void setMixerCode(String mixerCode) {
        this.mixerCode = mixerCode;
    }

    public String getEffectiveStartDate() {
        return effectiveStartDate;
    }

    public void setEffectiveStartDate(String effectiveStartDate) {
        this.effectiveStartDate = effectiveStartDate;
    }

    public String getEffectiveEndDate() {
        return effectiveEndDate;
    }

    public void setEffectiveEndDate(String effectiveEndDate) {
        this.effectiveEndDate = effectiveEndDate;
    }

    public boolean isManualAddEnableFlag() {
        return manualAddEnableFlag;
    }

    public void setManualAddEnableFlag(boolean manualAddEnableFlag) {
        this.manualAddEnableFlag = manualAddEnableFlag;
    }
}
