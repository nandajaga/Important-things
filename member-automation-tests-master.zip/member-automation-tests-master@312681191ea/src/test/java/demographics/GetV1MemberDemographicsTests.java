package demographics;

import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.datamanager.MemberResponseDTO;
import dtos.demographics.MemberDemographicsDTO;
import helpers.constants.BasePathConstants;
import helpers.constants.Constants;
import helpers.dataproviders.DataProviders;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.datamanager.MemberDataManagerSteps;
import steps.demographics.GetV1MemberDemographicsSteps;

import static helpers.constants.ConstantsClientIds.CLIENT_ID_186;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_85;
import static helpers.constants.ErrorMessagesForMemberEndpointsConstants.*;
import static org.apache.http.HttpStatus.SC_BAD_REQUEST;
import static org.apache.http.HttpStatus.SC_NOT_FOUND;

/**
 * Created by RKondakova on 7/2/2019.
 */
public class GetV1MemberDemographicsTests extends GetTests {

    private static final String FIRST_NAME = "Auto-";
    private static final String ADDRESS = "8600 W Bryn Mawr Ave";
    private static final String DATE_OF_BIIRTH = "1967-06-30";
    private static final String EMAIL = "automation@aimspecialtyhealth.com";
    private String CLIENT_MEMBER_ID;

    @BeforeClass
    public void init() {
        queryParamsMap.put("clientId", CLIENT_ID_186);
        queryParamsMap.put("memberId", "8af2f59a-74d8-4f79-9833-4396d13bc024");
        basePath = BasePathConstants.BASE_PATH_V1_MEMBER_DEMOGRAPHICS;
    }

    @BeforeMethod
    public void initMethod() {
        CLIENT_MEMBER_ID = RandomStringUtils.randomNumeric(10) + RandomStringUtils.randomAlphabetic(5).toUpperCase();
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test(dataProvider = "clientId-85-186-187-210", dataProviderClass = DataProviders.class)
    public void whenGetAndValidClientIdAndMemberIdAndCompareYearAndCompareDateSentThenServiceReturnsEnrollmentsPositiveTestsStatus200(String clientId) {
        MemberResponseDTO memberResponseDTO = new MemberDataManagerSteps(platformContextHeader, headers).createMember(clientId,CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        GetV1MemberDemographicsSteps getV1MemberDemographicsSteps = new GetV1MemberDemographicsSteps(platformContextHeader, headers);
        MemberDemographicsDTO response = getV1MemberDemographicsSteps.getMemberSearch(clientId, memberId);

        String email = response.getEmails().get(0).getValue();
        String phone = response.getPhones().get(0).getValue();
        boolean firstName = response.getFirstName().contains(FIRST_NAME);
        boolean address1 = response.getAddresses().get(0).getAddress1().contains(ADDRESS);
        boolean dateOfBirth = response.getDateOfBirth().toString().contains(DATE_OF_BIIRTH);
        boolean emailsValue = response.getEmails().get(0).getValue().contains(EMAIL);

        softly.then(email).isNotEmpty();
        softly.then(phone).isNotEmpty();
        softly.then(firstName).isNotNull();
        softly.then(address1).isNotNull();
        softly.then(dateOfBirth).isNotNull();
        softly.then(emailsValue).isNotNull();
        softly.then(response.getClientId()).isEqualTo(clientId);
        softly.then(response.getClientMemberId()).contains(CLIENT_MEMBER_ID);
        softly.assertAll();
    }

    @Test(dataProvider = "contextModeValue", dataProviderClass = DataProviders.class)
    public void whenCreateMemberWithSpecificDemographicsWithContextModeTestOrProdAndGetTheMemberDemographicsThenResponseSC201(String contextMode) {

        PlatformContextUtils platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeContextMode(platformContextHeader, contextMode);

        //Create unique clientMemberId, so the created member is unique and it is easier to find
        String clientMemberId = RandomStringUtils.random(10, true, true);

        //Create a member with specific enrollment and demographics
        MemberDataManagerSteps memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMemberClientMemberId(CLIENT_ID_85, clientMemberId);

        //Get the memberId that is created
        String memberId = memberResponseDTO.getId();

        //Check that memberId is created
        softly.then(memberId).isNotNull().isNotEmpty().isNotBlank();

        //Get the member demographics by memberId
        GetV1MemberDemographicsSteps getV1MemberDemographicsSteps = new GetV1MemberDemographicsSteps(platformContextHeader, headers);
        MemberDemographicsDTO response = getV1MemberDemographicsSteps.getMemberSearch(CLIENT_ID_85, memberId);

        softly.then(response.getId()).isEqualTo(memberId);
        softly.then(response.getClientMemberId()).isEqualTo(clientMemberId);
        softly.then(response.getClientId()).isEqualTo(CLIENT_ID_85);
        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-400-404-----------------------------------------

    @Test
    public void whenGetAndNegativeMemberIdThenResponseStatus404() {
        GetV1MemberDemographicsSteps getV1MemberDemographicsSteps = new GetV1MemberDemographicsSteps(platformContextHeader, headers);
        ErrorDTO error = getV1MemberDemographicsSteps.getMemberInvalidParamsSearch(CLIENT_ID_85, null);

        softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.then(error.getMessage()).isEqualTo(ERR_MSG_MEMBER_ID_NOT_PRESENT);
        softly.assertAll();
    }

    @Test(dataProvider = "memberIdNegative", dataProviderClass = DataProviders.class)
    public void whenGetWithoutCheckingForNullAndNegativeMemberIdSentThenResponseError(String memberId) {
        GetV1MemberDemographicsSteps getV1MemberDemographicsSteps = new GetV1MemberDemographicsSteps(platformContextHeader, headers);
        ErrorDTO error = getV1MemberDemographicsSteps.getMemberInvalidParamsSearchWithoutCheckingForNull(CLIENT_ID_85, memberId);
        if (memberId == null) {
            softly.then(error.getMessage()).isEqualTo(ERR_MSG_DEMOGRAPHIC_NOT_FOUND_FOR_CLIENT_ID + CLIENT_ID_85 + ERR_MSG_DEMOGRAPHIC_NOT_FOUND_FOR_CLIENT_ID_ADDITION);
        } else
            softly.then(error.getMessage()).isEqualTo(ERR_MSG_DEMOGRAPHIC_NOT_FOUND_FOR_CLIENT_ID + CLIENT_ID_85 + ERR_MSG_DEMOGRAPHIC_NOT_FOUND_FOR_CLIENT_ID_ADDITION + memberId.toString());

        softly.then(error.getCode()).isEqualTo(SC_NOT_FOUND);
        softly.assertAll();
    }

    @Test(dataProvider = "memberIdNegative", dataProviderClass = DataProviders.class)
    public void whenGetWithoutCheckingForNullAndNegativeMemberIdAndClientIdNullisSentResponseStatusError(String memberId) {
        GetV1MemberDemographicsSteps getV1MemberDemographicsSteps = new GetV1MemberDemographicsSteps(platformContextHeader, headers);
        ErrorDTO error = getV1MemberDemographicsSteps.getMemberInvalidParamsSearchWithoutCheckingForNull(null, memberId);

        softly.then(error.getMessage()).isEqualTo(ERR_MSG_ENTRY_NOT_FOUND);
        softly.then(error.getCode()).isEqualTo(SC_NOT_FOUND);
        softly.assertAll();
    }

    @Test(dataProvider = "contextModeInDataBase", dataProviderClass = DataProviders.class)
    public void whenCreateMemberWithContextModeTestOrProdAndGetTheMemberDemographicsWithDifferentContextModeThenResponseSC404(String contextMode, String dataBaseMode) {

        PlatformContextUtils platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeContextMode(platformContextHeader, contextMode);

        //Create unique clientMemberId, so the created member is unique and it is easier to find
        String clientMemberId = RandomStringUtils.random(10, true, true);

        //Create a member with specific enrollment and demographics
        MemberDataManagerSteps memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMemberClientMemberId(CLIENT_ID_85, clientMemberId);

        //Get the memberId that is created
        String memberId = memberResponseDTO.getId();

        //Check that memberId is created
        softly.then(memberId).isNotNull().isNotEmpty().isNotBlank();

        //Set different contextMode in the platformContext
        PlatformContextUtils platformContextUtilsDataBaseMde = new PlatformContextUtils();
        platformContextHeader = platformContextUtilsDataBaseMde.changeContextMode(platformContextHeader, dataBaseMode);

        //Get the member demographics by memberId
        GetV1MemberDemographicsSteps getV1MemberDemographicsSteps = new GetV1MemberDemographicsSteps(platformContextHeader, headers);
        ErrorDTO response = getV1MemberDemographicsSteps.getMemberInvalidParamsSearch(CLIENT_ID_85, memberId);

        softly.then(response.getCode()).isEqualTo(HttpStatus.SC_NOT_FOUND);
        softly.then(response.getMessage()).isEqualTo(String.format(ERR_MSG_NO_DEMOGRAPHICS_FOUND, memberId));
        softly.assertAll();

    }
}
