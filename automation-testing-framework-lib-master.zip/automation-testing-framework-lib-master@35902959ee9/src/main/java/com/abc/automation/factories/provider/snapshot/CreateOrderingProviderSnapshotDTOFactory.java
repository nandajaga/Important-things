package com.abc.automation.factories.provider.snapshot;

import com.abc.automation.dtos.provider.snapshot.CreateOrderingProviderSnapshotDTO;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
public class CreateOrderingProviderSnapshotDTOFactory {

    public CreateOrderingProviderSnapshotDTO createOrderingProviderSnapshotDTO(int providerClientId, String ngProviderId, Boolean isSanctioned, String sanctionReviewAnswerSnapshotId, boolean sanctionLookupCompletedFlag) {
        CreateOrderingProviderSnapshotDTO orderingProviderSnapshotAddV3DTO = new CreateOrderingProviderSnapshotDTO();

        orderingProviderSnapshotAddV3DTO.setNgProviderId(ngProviderId);
        orderingProviderSnapshotAddV3DTO.setProviderClientId(providerClientId);
        orderingProviderSnapshotAddV3DTO.setIsSanctioned(isSanctioned);
        orderingProviderSnapshotAddV3DTO.setSanctionReviewAnswerSnapshotId(sanctionReviewAnswerSnapshotId);
        orderingProviderSnapshotAddV3DTO.setSanctionLookupCompletedFlag(sanctionLookupCompletedFlag);

        return orderingProviderSnapshotAddV3DTO;
    }

    public CreateOrderingProviderSnapshotDTO createOrderingProviderSnapshotDTO(int providerClientId, String ngProviderId) {
        return createOrderingProviderSnapshotDTO(providerClientId, ngProviderId, null, null, false);
    }
}
