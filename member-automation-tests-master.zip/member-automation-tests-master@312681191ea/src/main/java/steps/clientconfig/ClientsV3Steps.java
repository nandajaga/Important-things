package steps.clientconfig;

import dtos.ErrorDTO;
import dtos.clientconfig.ClientResponseDTO;
import helpers.constants.BasePathConstants;
import io.restassured.http.Headers;

/**
 * Created by RKondakova on 7/22/2019.
 */
public class ClientsV3Steps {
    ClientV3V2Steps clientV3V2Steps;

    //for positive tests
    public ClientResponseDTO[] getClientV3PositiveDTO(String clientId, String fields, String platformContext, Headers headers) {
        clientV3V2Steps = new ClientV3V2Steps(platformContext, headers, BasePathConstants.BASE_PATH_GET_V3_CLIENTS);
        return clientV3V2Steps.getClientV2PositiveDTO(clientId, fields);
    }

    //for negative tests
    public ErrorDTO getClientRequestErrorDTO(String clientId, String fields, String platformContext, Headers headers) {
        clientV3V2Steps = new ClientV3V2Steps(platformContext, headers, BasePathConstants.BASE_PATH_GET_V3_CLIENTS);
        return clientV3V2Steps.getClientRequestErrorDTO(clientId, fields);
    }
}


