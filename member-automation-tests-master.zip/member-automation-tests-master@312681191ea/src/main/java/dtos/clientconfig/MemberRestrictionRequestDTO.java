package dtos.clientconfig;

/**
 * Created by VBaliyska on 6/21/2019.
 */
public class MemberRestrictionRequestDTO {

    private String clientId;
    private String memberId;
    private String dependentRelationCode;
    private String employerGroupNumber;
    private String restrictionType;
    private String issuanceStateCode;
    private String lineOfBusinessCode;

    public String getIssuanceStateCode() {
        return issuanceStateCode;
    }

    public void setIssuanceStateCode(String issuanceStateCode) {
        this.issuanceStateCode = issuanceStateCode;
    }

    public String getLineOfBusinessCode() {
        return lineOfBusinessCode;
    }

    public void setLineOfBusinessCode(String lineOfBusinessCode) {
        this.lineOfBusinessCode = lineOfBusinessCode;
    }


    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getDependentRelationCode() {
        return dependentRelationCode;
    }

    public void setDependentRelationCode(String dependentRelationCode) {
        this.dependentRelationCode = dependentRelationCode;
    }

    public String getEmployerGroupNumber() {
        return employerGroupNumber;
    }

    public void setEmployerGroupNumber(String employerGroupNumber) {
        this.employerGroupNumber = employerGroupNumber;
    }

    public String getRestrictionType() {
        return restrictionType;
    }

    public void setRestrictionType(String restrictionType) {
        this.restrictionType = restrictionType;
    }
}
