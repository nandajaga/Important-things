package workflow;

import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.tests.base.PostTests;
import dtos.workflow.MemberDemographicWorkflowResDTO;
import factories.workflow.DemographicEnsureWorkflowDTOFactory;
import helpers.constants.BasePathConstants;
import helpers.dataproviders.DataProviders;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.workflow.MemberDemographicEnsureWorkflowSteps;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Locale;

import static helpers.constants.ClientConfigConstants.CLIENT_ID_199;
import static helpers.constants.ClientConfigConstants.CLIENT_ID_210;
import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_212;

/**
 * Created by RKohli on 18/05/2020.
 */
public class PostMemberDemographicEnsureWorkflowTest extends PostTests {
    private MemberDemographicWorkflowResDTO[] memberDemographicWorkflowResDTO;
    private MemberDemographicEnsureWorkflowSteps memberDemographicEnsureWorkflowSteps;
    private PlatformContextUtils platformContextUtils;

    @BeforeClass
    public void init() {
        basePath = BasePathConstants.BASE_PATH_DEMOGRAPHIC_ENSURE_WORKFLOW;
        body = new DemographicEnsureWorkflowDTOFactory().createDisasterDTO(SUBCLIENT_CODE);
    }

    @BeforeMethod
    public void initMethod() {
        platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(CLIENT_ID_210));
        platformContextHeader = platformContextUtils.changeIssuanceStateCode(platformContextHeader, ISUUANCE_STATE_CODE_TX);
        platformContextHeader = platformContextUtils.changeStateCode(platformContextHeader, ISUUANCE_STATE_CODE_TX);
        platformContextHeader = platformContextUtils.changeSolutionId(platformContextHeader, String.valueOf(PC_SOLUTION_ID));
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    /* https://jira.aimspecialtyhealth.com/browse/OSPP-5169
     * ClientId - 210, Zipcode - 75006,75001 and StateCode - TX
     * Validate Member is in Disaster area and Hard stop is provided
     * Updated by RKohli on 18/05/2020
     */

    @Test(dataProvider = "validZipCodeForClient210DisasterDeclaration", dataProviderClass = DataProviders.class)
    public void whenPostMemberIsInDisasterAreaAndHardStopIsProvidedThenResponseSC200(String zipCode, String subClientCode) {

        platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeZipCode(platformContextHeader, zipCode);
        memberDemographicEnsureWorkflowSteps = new MemberDemographicEnsureWorkflowSteps(platformContextHeader, headers);

        memberDemographicWorkflowResDTO = memberDemographicEnsureWorkflowSteps.postDisasterDeclarationForPositiveTests(subClientCode);

        softly.then(memberDemographicWorkflowResDTO[0].getWorkFlow()).isNull();
        softly.then(memberDemographicWorkflowResDTO[0].getFlow()).isNull();
        softly.assertAll();
    }

    /* https://jira.aimspecialtyhealth.com/browse/OSPP-5169
     * ClientId - 212
     * Validate Member is not in Disaster area
     * Updated by Rkohli on 18/05/2020
     */
    @Test
    public void whenPostMemberIsNotInDisasterAreaThenResponseSC200() {
        platformContextHeader = platformContextUtils.changeZipCode(platformContextHeader, ZIP_CODE_75001);
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(CLIENT_ID_212));
        memberDemographicEnsureWorkflowSteps = new MemberDemographicEnsureWorkflowSteps(platformContextHeader, headers);

        memberDemographicWorkflowResDTO = memberDemographicEnsureWorkflowSteps.postDisasterDeclarationForPositiveTests(SUBCLIENT_CODE);

        softly.then(memberDemographicWorkflowResDTO[0].getFlow()).isNull();
        softly.then(memberDemographicWorkflowResDTO[0].getWorkFlow()).isNull();
        softly.assertAll();
    }

    //Can be modified when we get new configuration , So don't remove

    /* https://jira.aimspecialtyhealth.com/browse/OSPP-5169
     * ClientId - 85, Zipcode - 46403, 60423
     * Validate Member is in Disaster area and no Hard stop is provided
     * Updated by Sbioi on 18/05/2020
     */

    //@Test(dataProvider = "validZipCodeForClientDisasterDeclaration", dataProviderClass = DataProviders.class)
    public void whenPostMemberIsInDisasterAreaAndNoHardStopIsProvidedThenResponseSC200(String zipCode, String stateCode, String clientId) {

        platformContextHeader = platformContextUtils.changeZipCode(platformContextHeader, zipCode);
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));
        platformContextHeader = platformContextUtils.changeStateCode(platformContextHeader, stateCode);
        memberDemographicEnsureWorkflowSteps = new MemberDemographicEnsureWorkflowSteps(platformContextHeader, headers);

        memberDemographicWorkflowResDTO = memberDemographicEnsureWorkflowSteps.postDisasterDeclarationForPositiveTests(SUBCLIENT_CODE);

        softly.then(memberDemographicWorkflowResDTO[0].getFlow().getBusinessKey()).isEqualTo(BUSINESS_KEY);
        if (zipCode.equalsIgnoreCase(ZIP_CODE_46403)) {
            softly.then(memberDemographicWorkflowResDTO[0].getFlow().getBusinessKeyCode()).isEqualTo(BUSINESS_KEY_CODE_HURRICANE);
            softly.then(memberDemographicWorkflowResDTO[0].getFlow().getBusinessKeyCodeDescription()).isEqualTo(HURRICANE_WARNING);
            softly.then(memberDemographicWorkflowResDTO[0].getWorkFlow().getWorkFlowType()).isEqualTo(WORK_FLOW_TYPE);
            softly.then(memberDemographicWorkflowResDTO[0].getWorkFlow().getWorkFlowReason()).isEqualTo(WORK_FLOW_REASON_46403);
            softly.then(memberDemographicWorkflowResDTO[0].getWorkFlow().getWorkFlowMessaging()).isEqualTo(WORK_FLOW_MESSAGING_46403);
        } else if (zipCode.equals(ZIP_CODE_60423) || zipCode.equals(ZIP_CODE_12084)) {
            softly.then(memberDemographicWorkflowResDTO[0].getFlow().getBusinessKeyCode()).isEqualTo(BUSINESS_KEY_CODE_TORNADO);
            softly.then(memberDemographicWorkflowResDTO[0].getFlow().getBusinessKeyCodeDescription()).isEqualTo(TORNADO_ALERT);
            softly.then(memberDemographicWorkflowResDTO[0].getWorkFlow()).isNull();
        } else if (zipCode.equals(ZIP_CODE_30030)) {
            softly.then(memberDemographicWorkflowResDTO[0].getFlow().getBusinessKeyCode()).isEqualTo(BUSINESS_KEY_CODE_HURRICANE);
            softly.then(memberDemographicWorkflowResDTO[0].getFlow().getBusinessKeyCodeDescription()).isEqualTo(HURRICANE_WARNING);
            softly.then(memberDemographicWorkflowResDTO[0].getWorkFlow()).isNull();
        } else if (zipCode.equals(ZIP_CODE_80538)) {
            softly.then(memberDemographicWorkflowResDTO[0].getFlow().getBusinessKeyCode()).isEqualTo(BUSINESS_KEY_FIRE);
            softly.then(memberDemographicWorkflowResDTO[0].getFlow().getBusinessKeyCodeDescription()).isEqualTo(WILD_FIRE);
            softly.then(memberDemographicWorkflowResDTO[0].getWorkFlow()).isNull();
        } else if (zipCode.equals(ZIP_CODE_30080)) {
            softly.then(memberDemographicWorkflowResDTO[0].getFlow().getBusinessKeyCode()).isEqualTo(BUSINESS_KEY_FIRE);
            softly.then(memberDemographicWorkflowResDTO[0].getFlow().getBusinessKeyCodeDescription()).isEqualTo(FOREST_FIRE);
            softly.then(memberDemographicWorkflowResDTO[0].getWorkFlow()).isNull();
        } else if (zipCode.equals(ZIP_CODE_89002)) {
            softly.then(memberDemographicWorkflowResDTO[0].getFlow().getBusinessKeyCode()).isEqualTo(BUSINESS_KEY_HEAT);
            softly.then(memberDemographicWorkflowResDTO[0].getFlow().getBusinessKeyCodeDescription()).isEqualTo(HEAT_WAVE);
            softly.then(memberDemographicWorkflowResDTO[0].getWorkFlow()).isNull();
        }
        softly.assertAll();
    }

    /* https://dbg-jira.antheminc.com/browse/CAP-4607
     * ClientId - 199, employergroupcode -720902,720903,720904,720905,720906 ,Solution id-15
     * Validate Member hard stop is provided (but not deployed for Demographic only deployed for enrollment)
     * created by sbioi on 03/26/2021
     * May change when Test config is deployed
     */
    @Test(dataProvider = "employerGroupCode32BJ", dataProviderClass = DataProviders.class)
    public void whenPostMemberIsInDisasterAreaAndHardStopFor32BJThenResponseSC200(String employerGroupCode) {
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(CLIENT_ID_199));
        platformContextHeader = platformContextUtils.changeEmployerGroupCode(platformContextHeader, employerGroupCode);

        memberDemographicEnsureWorkflowSteps = new MemberDemographicEnsureWorkflowSteps(platformContextHeader, headers);

        memberDemographicWorkflowResDTO = memberDemographicEnsureWorkflowSteps.postDisasterDeclarationForPositiveTests(SUBCLIENT_CODE);

        softly.then(memberDemographicWorkflowResDTO[0].getFlow()).isNull();
        softly.then(memberDemographicWorkflowResDTO[0].getWorkFlow()).isNull();
        softly.assertAll();
    }
}