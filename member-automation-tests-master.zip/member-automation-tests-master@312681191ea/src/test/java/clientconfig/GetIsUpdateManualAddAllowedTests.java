package clientconfig;

import com.aim.automation.dtos.ErrorDTO;
import com.aim.automation.tests.base.GetTests;
import dtos.clientconfig.UpdateIsManualAddAllowedResponseDTO;
import helpers.constants.BasePathConstants;
import helpers.dataproviders.DataProviders;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import steps.clientconfig.UpdateMemberManualAddAllowedSteps;

import static helpers.constants.ClientConfigConstants.*;
import static helpers.constants.Constants.CLIENT_ID_85;
import static helpers.constants.Constants.ERROR_MESSAGE_CLIENT_ID_VALIDATION;
import static org.apache.http.HttpStatus.SC_BAD_REQUEST;

public class GetIsUpdateManualAddAllowedTests extends GetTests {

    private UpdateMemberManualAddAllowedSteps isUpdateManualAddAllowedSteps;

    @BeforeClass
    public void init() {
        basePath = BasePathConstants.BASE_PATH_UPDATE_MANUAL_ADD_ALLOWED;
        pathParamsMap.clear();
        pathParamsMap.put("clientId", CLIENT_ID_85);
    }

//-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test(dataProvider = "clientId-85-186-187-210-233-234", dataProviderClass = DataProviders.class)
    public void whenAllowedMemberIsManuallyAddedThenServiceResponseIs200(String clientId) {
        isUpdateManualAddAllowedSteps = new UpdateMemberManualAddAllowedSteps(platformContextHeader, headers);
        UpdateIsManualAddAllowedResponseDTO isManualAddAllowedResponse = isUpdateManualAddAllowedSteps.getIsManualAddAllowed(clientId);

        softly.then(isManualAddAllowedResponse).isNotNull();
        softly.then(isManualAddAllowedResponse.getIsManualAddAllowed()).isTrue();
        softly.then(isManualAddAllowedResponse.getMessage()).isNull();
        softly.then(isManualAddAllowedResponse.getScript()).isEqualTo(SCRIPT_MESSAGE);
        softly.then(isManualAddAllowedResponse.getScriptLabel()).isNull();
        softly.then(isManualAddAllowedResponse.getNote()).isEqualTo(MANUAL_ADD_NOTE_MESSAGE);
        softly.then(isManualAddAllowedResponse.getSecondNote()).isEqualTo(SECOND_NOTE_MESSAGE);
        softly.assertAll();
    }

    /**
     * As per OSPP-12095 Updated the Manual add and messaging configuration for client220
     */
    @Test
    public void whenAllowedMemberIsManuallyAddedForClient220ThenServiceResponseIs200() {
        isUpdateManualAddAllowedSteps = new UpdateMemberManualAddAllowedSteps(platformContextHeader, headers);
        UpdateIsManualAddAllowedResponseDTO isManualAddAllowedResponse = isUpdateManualAddAllowedSteps.getIsManualAddAllowed(CLIENT_ID_220);

        softly.then(isManualAddAllowedResponse).isNotNull();
        softly.then(isManualAddAllowedResponse.getIsManualAddAllowed()).isTrue();
        softly.then(isManualAddAllowedResponse.getMessage()).isNull();
        softly.then(isManualAddAllowedResponse.getScript()).isEqualTo(SCRIPT_MESSAGE_220);
        softly.then(isManualAddAllowedResponse.getScriptLabel()).isNull();
        softly.then(isManualAddAllowedResponse.getNote()).isNull();
        softly.then(isManualAddAllowedResponse.getSecondNote()).isNull();
        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-400---------------------------------------------
    @Test(dataProvider = "ClientIdNegative", dataProviderClass = DataProviders.class)
    public void whenSentInvalidClientIdThenSC400(String clientId) {
        isUpdateManualAddAllowedSteps = new UpdateMemberManualAddAllowedSteps(platformContextHeader, headers);
        ErrorDTO error = isUpdateManualAddAllowedSteps.getIsManualAddAllowedWithError(clientId);

        softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.then(error.getMessage()).isEqualTo(ERROR_MESSAGE_CLIENT_ID_VALIDATION);
        softly.assertAll();
    }
}
