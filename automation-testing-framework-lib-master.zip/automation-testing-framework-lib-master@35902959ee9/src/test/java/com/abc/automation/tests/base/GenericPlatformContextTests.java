package com.abc.automation.tests.base;

import com.abc.automation.dtos.GenericErrorDTO;
import com.abc.automation.factories.platformcontext.PlatformContextDTOFactory;
import com.abc.automation.helpers.CustomFilterableRequestSpecification;
import com.abc.automation.helpers.EditDTOHelper;
import com.abc.automation.helpers.convert.GenericConvertHelper;
import com.abc.automation.helpers.dataproviders.DataProviders;
import com.abc.automation.steps.ErrorsSteps;
import com.abc.servicemodel.domain.PlatformContext;
import com.abc.servicemodel.domain.User;
import io.restassured.http.ContentType;
import io.restassured.http.Method;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static com.abc.automation.helpers.constants.PlatformContextConstants.*;

public class GenericPlatformContextTests extends GenericTests {
    private CustomFilterableRequestSpecification specification;

    @BeforeMethod (alwaysRun = true)
    public void initWithPlatformContext() {
        specification = new CustomFilterableRequestSpecification();
        specification.addBasePath(basePath);
        specification.addPathParams(pathParamsMap);
        specification.addQueryParams(queryParamsMap);
        specification.addHeaders(headers);
        specification.addHeaders(additionalHeaders);
        specification.addPlatformContextToRequest(platformContextHeader);
        specification.setContentType(ContentType.JSON);
        if (endpointHttpMethod.equals(Method.POST) || endpointHttpMethod.equals(Method.PUT)) {
            specification.addBodyToRequest(body);
        }
    }

    @Test(dataProvider = "PlatformContextFieldsValidation", dataProviderClass = DataProviders.class)
    public void whenSendRequestAndPlatformContextWithNullValueThenServiceReturnBadResponse(String field, String errorMSG) {
        PlatformContextDTOFactory factory = new PlatformContextDTOFactory();
        PlatformContext platformContextDTOFalse = factory.createPlatformContextDTO();
        platformContextDTOFalse = factory.editPlatformContextDTO(platformContextDTOFalse, field, null);
        String platformContextFalse = new GenericConvertHelper().dtoToString(platformContextDTOFalse);
        specification.addPlatformContextToRequest(platformContextFalse);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        GenericErrorDTO errorDTO = errorsSteps.sendRequestWithGenericError(specification, endpointHttpMethod);

        softNG.assertEquals(errorDTO.getStatus(), HttpStatus.SC_BAD_REQUEST, "Status code is not correct.");
        softNG.assertEquals(errorDTO.getMessage().toLowerCase(), errorMSG, "Error message is not correct!");
        softNG.assertAll();
    }

    @Test
    public void whenSendRequestAndPlatformContextUserRolesAreNullThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        User tempUser = new User();
        tempUser.setId(PC_USER_ID);
        platformContextDTOFalse.setUser(tempUser);
        String platformContextFalse = new GenericConvertHelper().dtoToString(platformContextDTOFalse);
        specification.addPlatformContextToRequest(platformContextFalse);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        GenericErrorDTO errorDTO = errorsSteps.sendRequestWithGenericError(specification, endpointHttpMethod);

        softNG.assertEquals(errorDTO.getStatus(), HttpStatus.SC_BAD_REQUEST, "Status code is not correct.");
        softNG.assertEquals(errorDTO.getMessage().toLowerCase(), String.format(PLATFORM_CONTEXT_MISSING_FIELD, USER_ROLES).toLowerCase(), "Error message is not correct!");
        softNG.assertAll();
    }

    @Test
    public void whenSendRequestAndPlatformContextMemberLocationIsNullThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getMember().setLocation(null);
        String platformContextFalse = new GenericConvertHelper().dtoToString(platformContextDTOFalse);
        specification.addPlatformContextToRequest(platformContextFalse);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        GenericErrorDTO errorDTO = errorsSteps.sendRequestWithGenericError(specification, endpointHttpMethod);

        softNG.assertEquals(errorDTO.getStatus(), HttpStatus.SC_BAD_REQUEST, "Status code is not correct.");
        softNG.assertEquals(errorDTO.getMessage().toLowerCase(), String.format(PLATFORM_CONTEXT_MISSING_FIELD, MEMBER_LOCATION).toLowerCase(), "Error message is not correct!");
        softNG.assertAll();
    }

    @Test
// This is a separate test from whenSendRequestAndPlatformContextWithNullValueThenServiceReturnBadResponse, as the second uses editPlatformContextDTO, which can not work with lists, and Services are a list.
    public void whenSendRequestAndPlatformContextServicesTreatmentCodeIsNullThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getServices().get(0).setTreatmentCode(null);
        String platformContextFalse = new GenericConvertHelper().dtoToString(platformContextDTOFalse);
        specification.addPlatformContextToRequest(platformContextFalse);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        GenericErrorDTO errorDTO = errorsSteps.sendRequestWithGenericError(specification, endpointHttpMethod);

        softNG.assertEquals(errorDTO.getStatus(), HttpStatus.SC_BAD_REQUEST, "Status code is not correct.");
        softNG.assertEquals(errorDTO.getMessage().toLowerCase(), String.format(PLATFORM_CONTEXT_MISSING_FIELD, SERVICES_TREATMENT_CODE).toLowerCase(), "Error message is not correct!");
        softNG.assertAll();
    }

    @Test
// This is a separate test from whenSendRequestAndPlatformContextWithNullValueThenServiceReturnBadResponse, as the second uses editPlatformContextDTO, which can not work with lists, and Services are a list.
    public void whenSendRequestAndPlatformContextServicesTreatmentCodeTypeIsNullThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getServices().get(0).setTreatmentCodeType(null);
        String platformContextFalse = new GenericConvertHelper().dtoToString(platformContextDTOFalse);
        specification.addPlatformContextToRequest(platformContextFalse);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        GenericErrorDTO errorDTO = errorsSteps.sendRequestWithGenericError(specification, endpointHttpMethod);

        softNG.assertEquals(errorDTO.getStatus(), HttpStatus.SC_BAD_REQUEST, "Status code is not correct.");
        softNG.assertEquals(errorDTO.getMessage().toLowerCase(), String.format(PLATFORM_CONTEXT_MISSING_FIELD, SERVICES_TREATMENT_CODE_TYPE).toLowerCase(), "Error message is not correct!");
        softNG.assertAll();
    }

    @Test(dataProvider = "PlatformContextFieldsValidation", dataProviderClass = DataProviders.class)
    public void whenSendRequestAndPlatformContextWithMissingFieldThenServiceReturnsBadResponse(String field, String errorMSG) {
        PlatformContextDTOFactory factory = new PlatformContextDTOFactory();
        PlatformContext platformContextDTOFalse = factory.createPlatformContextDTO();
        platformContextDTOFalse = factory.editPlatformContextDTO(platformContextDTOFalse, field, null);
        String platformContextFalse = new EditDTOHelper().removeNullFieldFromJsonString(platformContextDTOFalse, field);
        specification.addPlatformContextToRequest(platformContextFalse);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        GenericErrorDTO errorDTO = errorsSteps.sendRequestWithGenericError(specification, endpointHttpMethod);

        softNG.assertEquals(errorDTO.getStatus(), HttpStatus.SC_BAD_REQUEST, "Status code is not correct.");
        softNG.assertEquals(errorDTO.getMessage().toLowerCase(), errorMSG, "Error message is not correct!");
        softNG.assertAll();
    }

    @Test
    public void whenSendRequestAndPlatformContextUserRolesAreMissingThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        User tempUser = new User();
        tempUser.setId(PC_USER_ID);
        platformContextDTOFalse.setUser(tempUser);
        String platformContextFalse = new EditDTOHelper().removeNullFieldFromJsonString(platformContextDTOFalse, USER_ROLES_FIELD);
        specification.addPlatformContextToRequest(platformContextFalse);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        GenericErrorDTO errorDTO = errorsSteps.sendRequestWithGenericError(specification, endpointHttpMethod);

        softNG.assertEquals(errorDTO.getStatus(), HttpStatus.SC_BAD_REQUEST, "Status code is not correct.");
        softNG.assertEquals(errorDTO.getMessage().toLowerCase(), String.format(PLATFORM_CONTEXT_MISSING_FIELD, USER_ROLES).toLowerCase(), "Error message is not correct!");
        softNG.assertAll();
    }

    @Test
    public void whenSendRequestAndPlatformContextMemberLocationIsMissingThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getMember().setLocation(null);
        String platformContextFalse = new EditDTOHelper().removeNullFieldFromJsonString(platformContextDTOFalse, MEMBER_LOCATION_FIELD);
        specification.addPlatformContextToRequest(platformContextFalse);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        GenericErrorDTO errorDTO = errorsSteps.sendRequestWithGenericError(specification, endpointHttpMethod);

        softNG.assertEquals(errorDTO.getStatus(), HttpStatus.SC_BAD_REQUEST, "Status code is not correct.");
        softNG.assertEquals(errorDTO.getMessage().toLowerCase(), String.format(PLATFORM_CONTEXT_MISSING_FIELD, MEMBER_LOCATION).toLowerCase(), "Error message is not correct!");
        softNG.assertAll();
    }

    @Test
    public void whenSendRequestAndPlatformContextServicesTreatmentCodeIsMissingThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getServices().get(0).setTreatmentCode(null);
        String platformContextFalse = new EditDTOHelper().removeNullFieldFromJsonString(platformContextDTOFalse, SERVICES_TREATMENT_CODE_FIELD);
        specification.addPlatformContextToRequest(platformContextFalse);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        GenericErrorDTO errorDTO = errorsSteps.sendRequestWithGenericError(specification, endpointHttpMethod);

        softNG.assertEquals(errorDTO.getStatus(), HttpStatus.SC_BAD_REQUEST, "Status code is not correct.");
        softNG.assertEquals(errorDTO.getMessage().toLowerCase(), String.format(PLATFORM_CONTEXT_MISSING_FIELD, SERVICES_TREATMENT_CODE).toLowerCase(), "Error message is not correct!");
        softNG.assertAll();
    }

    @Test
    public void whenSendRequestAndPlatformContextServicesTreatmentCodeTypeIsMissingThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getServices().get(0).setTreatmentCodeType(null);
        String platformContextFalse = new EditDTOHelper().removeNullFieldFromJsonString(platformContextDTOFalse, SERVICES_TREATMENT_CODE_TYPE_FIELD);
        specification.addPlatformContextToRequest(platformContextFalse);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        GenericErrorDTO errorDTO = errorsSteps.sendRequestWithGenericError(specification, endpointHttpMethod);

        softNG.assertEquals(errorDTO.getStatus(), HttpStatus.SC_BAD_REQUEST, "Status code is not correct.");
        softNG.assertEquals(errorDTO.getMessage().toLowerCase(), String.format(PLATFORM_CONTEXT_MISSING_FIELD, SERVICES_TREATMENT_CODE_TYPE).toLowerCase(), "Error message is not correct!");
        softNG.assertAll();
    }

}
