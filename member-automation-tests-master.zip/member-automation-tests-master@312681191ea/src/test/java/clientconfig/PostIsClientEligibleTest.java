package clientconfig;

import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.tests.base.PostTests;
import dtos.ErrorDTO;
import dtos.clientconfig.ClientEligibilityResponseDTOV2;
import dtos.datamanager.MemberResponseDTO;
import factories.clientconfig.ClientConfigEligibleDTOFactory;
import helpers.constants.BasePathConstants;
import helpers.constants.ConstantsClientIds;
import helpers.dataproviders.DataProviders;
import org.apache.commons.lang3.RandomStringUtils;
import org.assertj.core.api.BDDSoftAssertions;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.clientconfig.IsClientEligibleSteps;
import steps.datamanager.MemberDataManagerSteps;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static helpers.constants.ClientConfigConstants.*;
import static helpers.constants.ClientConfigConstants.CLIENT_ID_210;
import static helpers.constants.ClientConfigConstants.CLIENT_ID_212;
import static helpers.constants.ClientConfigConstants.DATE_OF_SERVICE;
import static helpers.constants.Constants.*;
import static helpers.constants.Constants.CLIENT_ID_85;
import static helpers.constants.ConstantsClientIds.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_186;
import static helpers.constants.ErrorMessagesForMemberEndpointsConstants.*;
import static org.apache.http.HttpStatus.*;

/**
 * Created by RKondakova on 7/10/2019.
 */

public class PostIsClientEligibleTest extends PostTests {

    private String memberId;
    private IsClientEligibleSteps isClientEligibleSteps;
    private PlatformContextUtils platformContextUtils;
    private SimpleDateFormat dateFormat;
    private Date date;
    ClientEligibilityResponseDTOV2 clientEligibilityResponseDTOV2;
    private String CLIENT_MEMBER_ID;

    @BeforeMethod
    public void initMethod() {
        CLIENT_MEMBER_ID = RandomStringUtils.randomNumeric(10) + RandomStringUtils.randomAlphabetic(5).toUpperCase();
    }

    @BeforeClass
    public void init() {
        basePath = BasePathConstants.BASE_PATH_POST_V2_IS_CLIENT_ELIGIBLE;
        body = new ClientConfigEligibleDTOFactory().setClientEligibility(SAMPLE_TIMESTAMP, "8af2f59a-74d8-4f79-9833-4396d13bc024", String.valueOf(PC_SOLUTION_ID), ISSUANCE_STATE_CA);
        dateFormat = new SimpleDateFormat("dd-mm-yyyy");
        platformContextUtils = new PlatformContextUtils();
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------
    public BDDSoftAssertions testPositiveEligibilityScenario(ClientEligibilityResponseDTOV2 clientEligibilityResponseDTOV2) {
        softly.then(clientEligibilityResponseDTOV2.getCode()).isEqualTo(CLIENT_ELIGIBLE_RESPONSE_CODE_006);
        softly.then(clientEligibilityResponseDTOV2.getMessage()).contains(CLIENT_ELIGIBLE_EMPTY_RESPONSE);
        softly.then(clientEligibilityResponseDTOV2.getScript()).contains(CLIENT_ELIGIBLE_EMPTY_RESPONSE);
        softly.then(clientEligibilityResponseDTOV2.isStatus()).isTrue();
        softly.assertAll();
        return softly;
    }

    @Test(dataProvider = "solutionIdTerminatedInConfig", dataProviderClass = DataProviders.class)
    public void whenPostMemberIdAndSolutionMemberIdWithDataProviderThenResponseStatus200(String solutionId, String clientId) {
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));

        MemberResponseDTO memberResponseDTO = new MemberDataManagerSteps(platformContextHeader, headers).createMember(clientId, CLIENT_MEMBER_ID);
        memberId = memberResponseDTO.getId();

        isClientEligibleSteps = new IsClientEligibleSteps(platformContextHeader, headers);
        clientEligibilityResponseDTOV2 = isClientEligibleSteps.postClientConfigEligibleRequest(DATE_OF_SERVICE, memberId, solutionId, SUBCLIENT_CODE);

        softly.then(clientEligibilityResponseDTOV2.getCode()).isEqualTo(CLIENT_ELIGIBLE_RESPONSE_CODE_001);
        softly.then(clientEligibilityResponseDTOV2.getMessage()).contains(CLIENT_ELIGIBLE_EMPTY_RESPONSE);
        softly.then(clientEligibilityResponseDTOV2.getScript()).contains(CLIENT_ELIGIBLE_EMPTY_RESPONSE);
        softly.then(clientEligibilityResponseDTOV2.isStatus()).isFalse();
        softly.assertAll();
    }

    @Test(dataProvider = "solutionIdIssuanceStateCodeLobEligible", dataProviderClass = DataProviders.class)
    public void whenPostMemberIdAndSolutionIssuanceCodeLOBDataProviderThenResponseStatus200(String solutionId, String clientId, String issuanceCode, String lob) {
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));
        platformContextHeader = platformContextUtils.changeSolutionId(platformContextHeader, solutionId);
        try {
            platformContextHeader = platformContextUtils.changeCaseCreationDate(platformContextHeader, new SimpleDateFormat("yyyy-mm-dd HH:mm:ss").parse(CASE_CREATION_DATE));

        } catch (ParseException e) {
            e.printStackTrace();
        }

        MemberResponseDTO memberResponseDTO = new MemberDataManagerSteps(platformContextHeader, headers).createMemberWithSpecificClientIdAndLOBAndIssuanceStateCode(clientId, issuanceCode, lob, CLIENT_MEMBER_ID);
        memberId = memberResponseDTO.getId();

        isClientEligibleSteps = new IsClientEligibleSteps(platformContextHeader, headers);
        clientEligibilityResponseDTOV2 = isClientEligibleSteps.postClientConfigEligibleRequest(DATE_OF_SERVICE, memberId, solutionId, SUBCLIENT_CODE);

        testPositiveEligibilityScenario(clientEligibilityResponseDTOV2);
    }

    @Test(dataProvider = "noSolutionEligibleClientId", dataProviderClass = DataProviders.class)
    public void whenPostMemberIdSolutionIdDataOfServiceAndSubClientCodeThenResponseStatus200AndStatusTrue(String clientId) {
        MemberResponseDTO memberResponseDTO = new MemberDataManagerSteps(platformContextHeader, headers).createMember(clientId, CLIENT_MEMBER_ID);
        memberId = memberResponseDTO.getId();

        isClientEligibleSteps = new IsClientEligibleSteps(platformContextHeader, headers);
        clientEligibilityResponseDTOV2 = isClientEligibleSteps.postClientConfigEligibleRequest(DATE_OF_SERVICE, memberId, null, SUBCLIENT_CODE);

        testPositiveEligibilityScenario(clientEligibilityResponseDTOV2);
    }

    //***************************** Few Nodes are terminated as part of story CAP-805 and CAP-1647*************************//
//    //CLIENT_CASE_CREATION_DATE_BEFORE_START_DATE_ERROR_CODE: 002
    @Test(dataProvider = "SolutionEligibleClientId", dataProviderClass = DataProviders.class)
    public void whenPostMemberIdWithDifferentSolutionIdAndMemberIdAndCaseCreationDateBeforeStartDateThenResponseStatus200(String solutionId) {
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(ConstantsClientIds.CLIENT_ID_85));
        platformContextHeader = platformContextUtils.changeSolutionId(platformContextHeader, solutionId);
        try {
            platformContextHeader = platformContextUtils.changeCaseCreationDate(platformContextHeader, new SimpleDateFormat("yyyy-mm-dd HH:mm:ss").parse(CASE_CREATION_DATE_NEGETIVE_SCNARIO));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        MemberResponseDTO memberResponseDTO = new MemberDataManagerSteps(platformContextHeader, headers).createMemberWithSpecificClientIdAndLOBAndIssuanceStateCode(ConstantsClientIds.CLIENT_ID_85, STATE_CODE_IN, COMMERCIAL_CODE, CLIENT_MEMBER_ID);
        memberId = memberResponseDTO.getId();

        isClientEligibleSteps = new IsClientEligibleSteps(platformContextHeader, headers);
        clientEligibilityResponseDTOV2 = isClientEligibleSteps.postClientConfigEligibleRequest(DATE_OF_SERVICE, memberId, solutionId, SUBCLIENT_CODE);
        switch (solutionId) {
            case SOLUTION_ID_15:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(CASE_CANNOT_BE_CREATED_MESSAGE_15);
                break;
            case SOLUTION_ID_16:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(CASE_CANNOT_BE_CREATED_MESSAGE_16);
                break;
            case SOLUTION_ID_17:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(CASE_CANNOT_BE_CREATED_MESSAGE_17);
                break;
            default:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isNotEmpty().isNotBlank().isNotNull();
                break;
        }
        softly.then(clientEligibilityResponseDTOV2.getMessage()).isEqualTo(MESSAGE_CASE_CANNOT_BE_CREATED);
        softly.then(clientEligibilityResponseDTOV2.getCode()).isEqualTo(CLIENT_CASE_CREATION_DATE_BEFORE_START_DATE_ERROR_CODE);
        softly.then(clientEligibilityResponseDTOV2.isStatus()).isFalse();
        softly.assertAll();
    }

    //CLIENT_CASE_CREATION_DATE_BEFORE_START_DATE_ERROR_CODE: 002
    @Test(dataProvider = "channelCodeIsClientEligible", dataProviderClass = DataProviders.class)
    public void whenPostMemberIdWithClientId186AndMemberIdAndCaseCreationDateBeforeStartDateThenResponseReturnedIsForChannelCode(String channelCode) {

        ClientEligibilityResponseDTOV2 clientEligibilityResponseDTOV2 = commonStepsForIsEligibleWithCaseCreationDate(channelCode, null, CLIENT_ID_186, CASE_CREATION_TEST_DATE);
        switch (channelCode) {
            case PC_CHANNEL_CODE_P:
                softly.then(clientEligibilityResponseDTOV2.getMessage()).isEqualTo(CLIENT_186_NAME.concat(COMMON_MESSAGE_P));
                softly.then(clientEligibilityResponseDTOV2.getScript()).isNull();
                break;
            case PC_CHANNEL_CODE_CC:
                softly.then(clientEligibilityResponseDTOV2.getMessage()).isEqualTo(CLIENT_186_NAME.concat(COMMON_MESSAGE_CC));
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(CLIENT_186_NAME.concat(COMMON_MESSAGE_P));
                break;
            default:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isNotEmpty().isNotBlank().isNotNull();
                break;
        }
        softly.then(clientEligibilityResponseDTOV2.getCode()).isEqualTo(CLIENT_CASE_CREATION_DATE_BEFORE_START_DATE_ERROR_CODE);
        softly.then(clientEligibilityResponseDTOV2.isStatus()).isFalse();
        softly.assertAll();
    }

    //CLIENT_CASE_CREATION_DATE_BEFORE_START_DATE_ERROR_CODE: 002
    @Test(dataProvider = "channelCodeIsClientEligible", dataProviderClass = DataProviders.class)
    public void whenPostMemberIdWithClientId210AndMemberIdAndCaseCreationDateBeforeStartDateThenResponseReturnedIsForChannelCode(String channelCode) {
        ClientEligibilityResponseDTOV2 clientEligibilityResponseDTOV2 = commonStepsForIsEligibleWithCaseCreationDate(channelCode, null, CLIENT_ID_210, CASE_CREATION_TEST_DATE);
        switch (channelCode) {
            case PC_CHANNEL_CODE_P:
                softly.then(clientEligibilityResponseDTOV2.getMessage()).isEqualTo(CLIENT_210_NAME.concat(COMMON_MESSAGE_P));
                softly.then(clientEligibilityResponseDTOV2.getScript()).isNull();
                break;
            case PC_CHANNEL_CODE_CC:
                softly.then(clientEligibilityResponseDTOV2.getMessage()).isEqualTo(CLIENT_210_NAME.concat(COMMON_MESSAGE_CC));
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(CLIENT_210_NAME.concat(COMMON_MESSAGE_P));
                break;
            default:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isNotEmpty().isNotBlank().isNotNull();
                break;
        }
        softly.then(clientEligibilityResponseDTOV2.getCode()).isEqualTo(CLIENT_CASE_CREATION_DATE_BEFORE_START_DATE_ERROR_CODE);
        softly.then(clientEligibilityResponseDTOV2.isStatus()).isFalse();
        softly.assertAll();
    }

    /* https://jira.aimspecialtyhealth.com/browse/OSPP-8135
     * Updated the validation for client id 212 for solutionId 15, 16 and 17
     * Updated by VHarugeri on 12/08/2020
     */
    //CLIENT_DOS_BEFORE_EFFECTIVE_DATE_ERROR_CODE: 003 for clientID 212 for solutionId 2 and 12
    //CLIENT_CASE_CREATION_DATE_BEFORE_START_DATE_ERROR_CODE: 002 for clientID 212 for solutionId 15, 16 and 17
    @Test(dataProvider = "SolutionEligibleClientId", dataProviderClass = DataProviders.class)
    public void whenPostMemberIdSolutionIdDateOfServiceBeforeEffectiveDateAndSubClientCodeThenResponseStatus200AndStatusTrueForClient212(String solutionId) {
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(ConstantsClientIds.CLIENT_ID_85));
        platformContextHeader = platformContextUtils.changeSolutionId(platformContextHeader, solutionId);

        MemberResponseDTO memberResponseDTO = new MemberDataManagerSteps(platformContextHeader, headers).createMemberWithSpecificClientIdAndLOBAndIssuanceStateCode(ConstantsClientIds.CLIENT_ID_85, STATE_CODE_IN, COMMERCIAL_CODE, CLIENT_MEMBER_ID);
        memberId = memberResponseDTO.getId();

        isClientEligibleSteps = new IsClientEligibleSteps(platformContextHeader, headers);
        clientEligibilityResponseDTOV2 = isClientEligibleSteps.postClientConfigEligibleRequest(DATE_OF_SERVICE1, memberId, solutionId, SUBCLIENT_CODE);
        switch (solutionId) {
            case SOLUTION_ID_15:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(CASE_CANNOT_BE_CREATED_MESSAGE_003_15);
                break;
            case SOLUTION_ID_16:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(CASE_CANNOT_BE_CREATED_MESSAGE_003_16);
                break;
            case SOLUTION_ID_17:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(CASE_CANNOT_BE_CREATED_MESSAGE_003_17);
                break;
            default:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isNotEmpty().isNotBlank().isNotNull();
                break;
        }
        softly.then(clientEligibilityResponseDTOV2.getMessage()).isEqualTo(MESSAGE_DOS_CANNOT_BE_BEFORE_CLIENT_EFFECTIVE_DATE);
        softly.then(clientEligibilityResponseDTOV2.getCode()).isEqualTo(CLIENT_DOS_BEFORE_EFFECTIVE_DATE_ERROR_CODE);
        softly.then(clientEligibilityResponseDTOV2.isStatus()).isFalse();
        softly.assertAll();
    }

    //CLIENT_DOS_BEFORE_EFFECTIVE_DATE_ERROR_CODE: 003 for clientID 210
//    @Test(dataProvider = "solutionIdIsClientEligible", dataProviderClass = DataProviders.class)
    public void whenPostMemberIdSolutionIdDateOfServiceBeforeEffectiveDateAndSubClientCodeThenResponseStatus200AndStatusTrue(String solutionId) {
        ClientEligibilityResponseDTOV2 clientEligibilityResponseDTOV2 = commonStepsMethodWithDOS(DOS_BEFORE_EFFECTIVE_DATE, solutionId, CLIENT_ID_210, PC_CHANNEL_CODE_CC);
        switch (solutionId) {
            case SOLUTION_ID_2:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(SCRIPT_CLIENT_ELIGIBILITY_FIRST_PART.concat(MESSAGE_SOLUTION_ID_2).concat(SCRIPT_CLIENT_ELIGIBILITY_SECOND_PART).concat(CLIENT_210_NAME).concat(SCRIPT_CLIENT_ELIGIBILITY_CODE_003_THIRD_PART));
                break;
            case SOLUTION_ID_12:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(SCRIPT_CLIENT_ELIGIBILITY_FIRST_PART.concat(MESSAGE_SOLUTION_ID_12).concat(SCRIPT_CLIENT_ELIGIBILITY_SECOND_PART).concat(CLIENT_210_NAME).concat(SCRIPT_CLIENT_ELIGIBILITY_CODE_003_THIRD_PART));
                break;
            case SOLUTION_ID_15:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(SCRIPT_CLIENT_ELIGIBILITY_FIRST_PART.concat(MESSAGE_SOLUTION_ID_15).concat(SCRIPT_CLIENT_ELIGIBILITY_SECOND_PART).concat(CLIENT_210_NAME).concat(SCRIPT_CLIENT_ELIGIBILITY_CODE_003_THIRD_PART));
                break;
            case SOLUTION_ID_16:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(SCRIPT_CLIENT_ELIGIBILITY_FIRST_PART.concat(MESSAGE_SOLUTION_ID_16).concat(SCRIPT_CLIENT_ELIGIBILITY_SECOND_PART).concat(CLIENT_210_NAME).concat(SCRIPT_CLIENT_ELIGIBILITY_CODE_003_THIRD_PART));
                break;
            case SOLUTION_ID_17:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(SCRIPT_CLIENT_ELIGIBILITY_FIRST_PART.concat(MESSAGE_SOLUTION_ID_17).concat(SCRIPT_CLIENT_ELIGIBILITY_SECOND_PART).concat(CLIENT_210_NAME).concat(SCRIPT_CLIENT_ELIGIBILITY_CODE_003_THIRD_PART));
                break;
            default:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isNotEmpty().isNotBlank().isNotNull();
                break;
        }
        softly.then(clientEligibilityResponseDTOV2.getMessage()).isEqualTo(MESSAGE_DOS_CANNOT_BE_BEFORE_CLIENT_EFFECTIVE_DATE);
        softly.then(clientEligibilityResponseDTOV2.getCode()).isEqualTo(CLIENT_DOS_BEFORE_EFFECTIVE_DATE_ERROR_CODE);
        softly.then(clientEligibilityResponseDTOV2.isStatus()).isFalse();
        softly.assertAll();
    }

    //CLIENT_DOS_BEFORE_EFFECTIVE_DATE_ERROR_CODE: 003
    @Test(dataProvider = "channelCodeIsClientEligible", dataProviderClass = DataProviders.class)
    public void whenPostMemberIdSolutionIdDateOfServiceBeforeEffectiveDateAndSubClientCodeThenResponseReturnedIsForChannelCode(String channelCode) {
        ClientEligibilityResponseDTOV2 clientEligibilityResponseDTOV2 = commonStepsMethodWithDOS(DOS_BEFORE_EFFECTIVE_DATE, null, CLIENT_ID_210, channelCode);
        switch (channelCode) {
            case PC_CHANNEL_CODE_P:
                softly.then(clientEligibilityResponseDTOV2.getMessage()).isEqualTo(CLIENT_210_NAME.concat(COMMON_MESSAGE_P));
                softly.then(clientEligibilityResponseDTOV2.getScript()).isNull();
                break;
            case PC_CHANNEL_CODE_CC:
                softly.then(clientEligibilityResponseDTOV2.getMessage()).isEqualTo(CLIENT_210_NAME.concat(COMMON_MESSAGE_CC));
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(CLIENT_210_NAME.concat(COMMON_MESSAGE_P));
                break;
            default:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isNotEmpty().isNotBlank().isNotNull();
                break;
        }
        softly.then(clientEligibilityResponseDTOV2.getCode()).isEqualTo(CLIENT_DOS_BEFORE_EFFECTIVE_DATE_ERROR_CODE);
        softly.then(clientEligibilityResponseDTOV2.isStatus()).isFalse();
        softly.assertAll();
    }

    //CLIENT_DOS_AFTER_TERMINATION_DATE_ERROR_CODE: 004
    @Test(dataProvider = "SolutionEligibleClientId", dataProviderClass = DataProviders.class)
    public void whenPostMemberIdSolutionIdDateOfServiceAfterTerminationDateAndSubClientCodeAndThenResponseStatus200AndStatusTrue(String solutionId) {
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(ConstantsClientIds.CLIENT_ID_85));
        platformContextHeader = platformContextUtils.changeSolutionId(platformContextHeader, solutionId);

        MemberResponseDTO memberResponseDTO = new MemberDataManagerSteps(platformContextHeader, headers).createMemberWithSpecificClientIdAndLOBAndIssuanceStateCode(ConstantsClientIds.CLIENT_ID_85, STATE_CODE_IN, COMMERCIAL_CODE, CLIENT_MEMBER_ID);
        memberId = memberResponseDTO.getId();

        isClientEligibleSteps = new IsClientEligibleSteps(platformContextHeader, headers);
        clientEligibilityResponseDTOV2 = isClientEligibleSteps.postClientConfigEligibleRequest(DOS_AFTER_TERMINATION_DATE, memberId, solutionId, SUBCLIENT_CODE);
        switch (solutionId) {
            case SOLUTION_ID_15:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(SCRIPT_HEALTH_PLAN_TERMINATED_CODE_004_FIRST_PART.concat(MESSAGE_SOLUTION_ID_15).concat(SCRIPT_HEALTH_PLAN_TERMINATED_CODE_004_SECOND_PART));
                break;
            case SOLUTION_ID_16:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(SCRIPT_HEALTH_PLAN_TERMINATED_CODE_004_FIRST_PART.concat(MESSAGE_SOLUTION_ID_16).concat(SCRIPT_HEALTH_PLAN_TERMINATED_CODE_004_SECOND_PART));
                break;
            case SOLUTION_ID_17:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(SCRIPT_HEALTH_PLAN_TERMINATED_CODE_004_FIRST_PART.concat(MESSAGE_SOLUTION_ID_17).concat(SCRIPT_HEALTH_PLAN_TERMINATED_CODE_004_SECOND_PART));
                break;
            default:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isNotEmpty().isNotBlank().isNotNull();
                break;
        }
        softly.then(clientEligibilityResponseDTOV2.getMessage()).isEqualTo(MESSAGE_HEALTH_PLAN_TERMINATED);
        softly.then(clientEligibilityResponseDTOV2.getCode()).isEqualTo(CLIENT_DOS_AFTER_TERMINATION_DATE_ERROR_CODE);
        softly.then(clientEligibilityResponseDTOV2.isStatus()).isFalse();
        softly.assertAll();
    }

    //CLIENT_DOS_BEFORE_EFFECTIVE_DATE_ERROR_CODE: 004, message with channel code will be fetched
//    @Test(dataProvider = "channelCodeIsClientEligible", dataProviderClass = DataProviders.class)
    public void whenPostMemberIdSolutionIdDateOfServiceAfterTerminationDateAndSubClientCodeAndThenResponseReturnedForChannelCode(String channelCode) {
        ClientEligibilityResponseDTOV2 clientEligibilityResponseDTOV2 = commonStepsMethodWithDOS(DOS_AFTER_TERMINATION_DATE, null, CLIENT_ID_210, channelCode);
        switch (channelCode) {
            case PC_CHANNEL_CODE_P:
                softly.then(clientEligibilityResponseDTOV2.getMessage()).isEqualTo(CLIENT_210_NAME.concat(COMMON_MESSAGE_P));
                softly.then(clientEligibilityResponseDTOV2.getScript()).isNull();
                break;
            case PC_CHANNEL_CODE_CC:
                softly.then(clientEligibilityResponseDTOV2.getMessage()).isEqualTo(CLIENT_210_NAME.concat(COMMON_MESSAGE_CC));
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(CLIENT_210_NAME.concat(COMMON_MESSAGE_P));
                break;
            default:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isNotEmpty().isNotBlank().isNotNull();
                break;
        }
        softly.then(clientEligibilityResponseDTOV2.getCode()).isEqualTo(CLIENT_DOS_AFTER_TERMINATION_DATE_ERROR_CODE);
        softly.then(clientEligibilityResponseDTOV2.isStatus()).isFalse();
        softly.assertAll();
    }

    //CLIENT_DOS_BEFORE_EFFECTIVE_DATE_ERROR_CODE: 004, message with channel code will be fetched
    @Test(dataProvider = "channelCodeIsClientEligible", dataProviderClass = DataProviders.class)
    public void whenPostMemberIdForClient185DateOfServiceAfterTerminationDateAndSubClientCodeAndThenResponseReturnedForChannelCode(String channelCode) {
        ClientEligibilityResponseDTOV2 clientEligibilityResponseDTOV2 = commonStepsMethodWithDOS(DOS_AFTER_TERMINATION_DATE, null, CLIENT_ID_185, channelCode);
        switch (channelCode) {
            case PC_CHANNEL_CODE_P:
                softly.then(clientEligibilityResponseDTOV2.getMessage()).isEqualTo(CLIENT_185_NAME.concat(COMMON_MESSAGE_P));
                softly.then(clientEligibilityResponseDTOV2.getScript()).isNull();
                break;
            case PC_CHANNEL_CODE_CC:
                softly.then(clientEligibilityResponseDTOV2.getMessage()).isEqualTo(CLIENT_185_NAME.concat(COMMON_MESSAGE_CC));
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(CLIENT_185_NAME.concat(COMMON_MESSAGE_P));
                break;
            default:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isNotEmpty().isNotBlank().isNotNull();
                break;
        }
        softly.then(clientEligibilityResponseDTOV2.getCode()).isEqualTo(CLIENT_DOS_AFTER_TERMINATION_DATE_ERROR_CODE);
        softly.then(clientEligibilityResponseDTOV2.isStatus()).isFalse();
        softly.assertAll();
    }

    //CLIENT_CASE_CREATION_DATE_AFTER_TERMINATION_DATE_ERROR_CODE: 005
    @Test(dataProvider = "solutionIdIsClientEligible", dataProviderClass = DataProviders.class)
    public void whenPostMemberIdWithDifferentSolutionIdMemberIdAndCaseCreationDateAfterTerminationDateThenResponseStatus200(String solutionId) {

        ClientEligibilityResponseDTOV2 clientEligibilityResponseDTOV2 = commonStepsForIsEligibleWithCaseCreationDate(CHANNEL_CODE_P, solutionId, CLIENT_ID_212, CASE_CREATION_DATE_AFTER_TERMINATION_DATE);
        switch (solutionId) {
            case SOLUTION_ID_15:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(SCRIPT_HEALTH_PLAN_DOES_NOT_PARTICIPATE_FIRST_PART.concat(MESSAGE_SOLUTION_ID_15).concat(SCRIPT_HEALTH_PLAN_DOES_NOT_PARTICIPATE_SECOND_PART));
                break;
            case SOLUTION_ID_16:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(SCRIPT_HEALTH_PLAN_DOES_NOT_PARTICIPATE_FIRST_PART.concat(MESSAGE_SOLUTION_ID_16).concat(SCRIPT_HEALTH_PLAN_DOES_NOT_PARTICIPATE_SECOND_PART));
                break;
            case SOLUTION_ID_17:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(SCRIPT_HEALTH_PLAN_DOES_NOT_PARTICIPATE_FIRST_PART.concat(MESSAGE_SOLUTION_ID_17).concat(SCRIPT_HEALTH_PLAN_DOES_NOT_PARTICIPATE_SECOND_PART));
                break;
            default:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isNotEmpty().isNotBlank().isNotNull();
                break;
        }
        softly.then(clientEligibilityResponseDTOV2.getMessage()).isEqualTo(MESSAGE_HEALTH_PLAN_TERMINATED);
        softly.then(clientEligibilityResponseDTOV2.getCode()).isEqualTo(CLIENT_CASE_CREATION_DATE_AFTER_TERMINATION_DATE_ERROR_CODE);
        softly.then(clientEligibilityResponseDTOV2.isStatus()).isFalse();
        softly.assertAll();
    }

    //CLIENT_DOS_BEFORE_EFFECTIVE_DATE_ERROR_CODE: 005, message with channel code will be fetched
    @Test(dataProvider = "channelCodeIsClientEligible", dataProviderClass = DataProviders.class)
    public void whenPostMemberIdForClient210DateOfServiceAfterTerminationDateAndSubClientCodeAndThenResponseReturnedForChannelCode(String channelCode) {
        ClientEligibilityResponseDTOV2 clientEligibilityResponseDTOV2 = commonStepsForIsEligibleWithCaseCreationDate(channelCode, null, CLIENT_ID_210, CASE_CREATION_DATE_AFTER_TERMINATION_DATE);
        switch (channelCode) {
            case PC_CHANNEL_CODE_P:
                softly.then(clientEligibilityResponseDTOV2.getMessage()).isEqualTo(CLIENT_210_NAME.concat(COMMON_MESSAGE_P));
                softly.then(clientEligibilityResponseDTOV2.getScript()).isNull();
                break;
            case PC_CHANNEL_CODE_CC:
                softly.then(clientEligibilityResponseDTOV2.getMessage()).isEqualTo(CLIENT_210_NAME.concat(COMMON_MESSAGE_CC));
                softly.then(clientEligibilityResponseDTOV2.getScript()).isEqualTo(CLIENT_210_NAME.concat(COMMON_MESSAGE_P));
                break;
            default:
                softly.then(clientEligibilityResponseDTOV2.getScript()).isNotEmpty().isNotBlank().isNotNull();
                break;
        }
        softly.then(clientEligibilityResponseDTOV2.getCode()).isEqualTo(CLIENT_CASE_CREATION_DATE_AFTER_TERMINATION_DATE_ERROR_CODE);
        softly.then(clientEligibilityResponseDTOV2.isStatus()).isFalse();
        softly.assertAll();
    }


    //  -----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-422---------------------------------------------

    @Test(dataProvider = "memberIdNegative", dataProviderClass = DataProviders.class)
    public void whenPostMemberIdIsNullOrInvalidInputThenServiceReturnsRestrictError400or422(String invalidMemberId) {
        isClientEligibleSteps = new IsClientEligibleSteps(platformContextHeader, headers);
        ErrorDTO error = isClientEligibleSteps.postClientConfigEligibleRequestErrorDTO(null, invalidMemberId, SOLUTION_ID_15, null);

        if (invalidMemberId == null) {
            softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
            softly.then(error.getMessage()).contains(ERR_MSG_VALIDATION_FAILED_NOT_NULL);
        } else {
            softly.then(error.getCode()).isEqualTo(SC_NOT_FOUND);

            if (invalidMemberId.isEmpty() || invalidMemberId.equals(" ")) {
                softly.then(error.getMessage()).contains(ERR_MSG_NO_MESSAGE_FOUND);
            } else {
                softly.then(error.getMessage()).contains(ERR_MSG_ENTRY_NOT_FOUND);
            }
        }
        softly.assertAll();
    }

    @Test(dataProvider = "solutionIdNegativeIsClientEligible", dataProviderClass = DataProviders.class)
    public void whenPostDateOfServiceIsNullOrInvalidInputThenServiceReturnsRestrictError400or422(String invalidSolutionId) {
        MemberResponseDTO memberResponseDTO = new MemberDataManagerSteps(platformContextHeader, headers).createMember(CLIENT_ID_85, CLIENT_MEMBER_ID);
        memberId = memberResponseDTO.getId();

        isClientEligibleSteps = new IsClientEligibleSteps(platformContextHeader, headers);
        ErrorDTO error = isClientEligibleSteps.postClientConfigEligibleRequestErrorDTO(null, memberId, invalidSolutionId, null);

        softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.then(error.getMessage()).contains(ERR_MSG_JSON_PARSE_INT);
        softly.assertAll();
    }

    //Date Validation is not happening currently, Keeping it as is, if any validation is provided then will uncomment the test
//    @Test(dataProvider = "invalidDate", dataProviderClass = DataProviders.class)
    public void whenPostSolutionIdIsNullOrInvalidInputThenServiceReturnsRestrictError400or422(String invalidDate) {
        MemberResponseDTO memberResponseDTO = new MemberDataManagerSteps(platformContextHeader, headers).createMember(CLIENT_ID_85, CLIENT_MEMBER_ID);
        memberId = memberResponseDTO.getId();

        isClientEligibleSteps = new IsClientEligibleSteps(platformContextHeader, headers);
        ErrorDTO error = isClientEligibleSteps.postClientConfigEligibleRequestErrorDTO(invalidDate, memberId, null, null);

        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.then(error.getMessage()).contains(ERR_MSG_VALIDATION_FAILED_NOT_NULL);
        softly.assertAll();
    }

    // --------------common method-------------------
    private ClientEligibilityResponseDTOV2 commonStepsForIsEligibleWithCaseCreationDate(String channelCode, String solutionId, String clientId, String caseDate) {
        MemberResponseDTO memberResponseDTO = new MemberDataManagerSteps(platformContextHeader, headers).createMember(clientId, CLIENT_MEMBER_ID);
        memberId = memberResponseDTO.getId();

        try {
            date = dateFormat.parse(caseDate);
        } catch (ParseException e) {
            e.getMessage();
        }
        platformContextHeader = platformContextUtils.changeCaseCreationDate(platformContextHeader, date);
        platformContextHeader = platformContextUtils.changeChannelCode(platformContextHeader, channelCode);
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));
        isClientEligibleSteps = new IsClientEligibleSteps(platformContextHeader, headers);

        return isClientEligibleSteps.postClientConfigEligibleRequestPositive(memberId, solutionId);

    }

    private ClientEligibilityResponseDTOV2 commonStepsMethodWithDOS(String dateOfService, String solutionId, String clientId, String channelCode) {
        MemberResponseDTO memberResponseDTO = new MemberDataManagerSteps(platformContextHeader, headers).createMember(clientId, CLIENT_MEMBER_ID);
        memberId = memberResponseDTO.getId();

        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));
        platformContextHeader = platformContextUtils.changeChannelCode(platformContextHeader, channelCode);
        isClientEligibleSteps = new IsClientEligibleSteps(platformContextHeader, headers);

        return isClientEligibleSteps.postClientConfigEligibleRequest(dateOfService, memberId, solutionId, SUBCLIENT_CODE);
    }

}