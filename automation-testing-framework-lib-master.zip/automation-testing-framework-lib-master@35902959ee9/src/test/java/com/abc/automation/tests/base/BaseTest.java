package com.abc.automation.tests.base;

import com.abc.automation.dtos.platformcontext.AbstractPlatformContext;
import com.abc.automation.helpers.CustomFilterableRequestSpecification;
import com.abc.automation.helpers.PlatformContextUtils;
import com.abc.automation.helpers.PropertiesUtils;
import com.abc.automation.helpers.enums.ContextModeEnum;
import com.abc.automation.helpers.enums.RequestHeadersEnum;
import com.abc.automation.helpers.enums.platformcontext.PlatformContextVersionEnum;
import com.abc.automation.steps.base.BasePreparationSteps;
import io.restassured.RestAssured;
import io.restassured.filter.log.LogDetail;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Headers;
import io.restassured.http.Method;
import org.assertj.core.api.BDDSoftAssertions;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.asserts.SoftAssert;

import java.util.*;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.proxy;

public class BaseTest {
    private static final String CONFIG = "config.properties";

    //TODO: Move to the classes where needed
    protected String uploadFileName;

    protected BDDSoftAssertions softly;
    protected SoftAssert softNG;

    protected CustomFilterableRequestSpecification requestSpecification;

    protected String basePath;
    protected Headers headers;
    protected Headers additionalHeaders;
    protected String platformContextHeader;
    protected Map<String, String> pathParamsMap;
    protected Map<String, String> queryParamsMap;
    protected Object body;
    protected PlatformContextVersionEnum platformContextVersion;
    protected Method endpointHttpMethod;
    protected List<Method> notAllowedMethodsList;
    protected ContextModeEnum contextMode;

    @BeforeSuite (alwaysRun = true)
    public void initSuiteBase() {
        baseURI = System.getProperty("baseURI");
        Properties props = new PropertiesUtils().loadProps(CONFIG);

        // Getting the configuration for the baseURI
        if (baseURI == null || baseURI.isEmpty()) {
            baseURI = props.getProperty("baseURI");

            // Getting the configuration for the proxy from config file
            if (Boolean.parseBoolean(props.getProperty("isProxyNeeded"))) {
                proxy(props.getProperty("proxyHost"), Integer.parseInt(props.getProperty("proxyPort")));
                RestAssured.useRelaxedHTTPSValidation();
            }
        }

        // Getting the configuration for the log
        String logEnabled = System.getProperty("isLogEnabled");
        if (logEnabled == null) {
            logEnabled = props.getProperty("isLogEnabled");
        }

        // Configuring the log for the requests and the responses
        boolean isLogEnabled = Boolean.parseBoolean(logEnabled);
        if (isLogEnabled) {
            RestAssured.replaceFiltersWith(new RequestLoggingFilter(LogDetail.ALL), new ResponseLoggingFilter(LogDetail.ALL));
        } else {
            RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();
        }

        // Getting the configuration for context mode in platform context from config file
        String cMode = props.getProperty("contextMode");
        if (cMode != null) {
            contextMode = ContextModeEnum.fromString(cMode);
        } else {
            contextMode = null;
        }
    }

    @BeforeClass (alwaysRun = true)
    public void initClassBase(ITestContext context) {
        // Getting the version of platform context from suite xml
        String pcv = context.getCurrentXmlTest().getParameter("platform-context-version");
        if (pcv != null) {
            platformContextVersion = PlatformContextVersionEnum.fromString(pcv);
        } else {
            platformContextVersion = PlatformContextVersionEnum.PC_V1;
        }

        // Getting the configuration for context mode in platform context from suite xml
        String cMode = context.getCurrentXmlTest().getParameter("context-mode");
        if (cMode != null) {
            contextMode = ContextModeEnum.fromString(cMode);
        }

        pathParamsMap = new HashMap<>();
        queryParamsMap = new HashMap<>();
        body = new Object();
        additionalHeaders = new Headers();
        notAllowedMethodsList = new ArrayList<>();
        notAllowedMethodsList.add(Method.GET);
        notAllowedMethodsList.add(Method.POST);
        notAllowedMethodsList.add(Method.PUT);
        notAllowedMethodsList.add(Method.PATCH);
        notAllowedMethodsList.add(Method.DELETE);
    }

    @BeforeMethod (alwaysRun = true)
    public void initBase() {
        BasePreparationSteps basePreparationSteps = new BasePreparationSteps();

        AbstractPlatformContext abstractPlatformContext = new AbstractPlatformContext(platformContextVersion);
        platformContextHeader = abstractPlatformContext.getPlatformContextAsString();
        headers = basePreparationSteps.prepareHeadersWithMissingHeader(RequestHeadersEnum.PLATFORM_CONTEXT, 10);

        if (contextMode != null) {
            platformContextHeader = new PlatformContextUtils().changeContextMode(platformContextHeader, contextMode.getMode());
        }

        requestSpecification = basePreparationSteps.initializeRequestSpecification(headers, platformContextHeader);

        softNG = new SoftAssert();
        softly = new BDDSoftAssertions();
    }

    // TODO: Not working properly for now, needs to be fixed to not skip tests when several asserts fail
//    @AfterMethod
    public void assertAll() {
        softNG.assertAll();

        softly.assertAll();
    }
}