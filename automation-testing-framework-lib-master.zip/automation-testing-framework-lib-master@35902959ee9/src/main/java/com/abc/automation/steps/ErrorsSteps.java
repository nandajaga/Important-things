package com.abc.automation.steps;

import com.abc.automation.helpers.CustomFilterableRequestSpecification;
import com.abc.automation.helpers.RequestOperationsHelper;
import com.abc.automation.helpers.convert.GenericConvertHelper;
import com.abc.automation.dtos.ErrorDTO;
import com.abc.automation.dtos.GenericErrorDTO;
import io.restassured.http.Headers;
import io.restassured.http.Method;
import io.restassured.response.Response;

import java.io.InputStream;
import java.util.Map;

/**
 * Created by PPetarcheva on 3/29/2019.
 */
public class ErrorsSteps {

    private RequestOperationsHelper requestOperationsHelper;

    public ErrorsSteps() {
        this.requestOperationsHelper = new RequestOperationsHelper();
    }

    public ErrorDTO sendPutRequestWithError(CustomFilterableRequestSpecification requestSpecification) {
        Response response = requestOperationsHelper.sendPutRequest(requestSpecification.getFilterableRequestSpecification());
        return response.getBody().as(ErrorDTO.class);
    }

    public GenericErrorDTO sendPutRequestWithGenericError(CustomFilterableRequestSpecification requestSpecification) {
        Response response = requestOperationsHelper.sendPutRequest(requestSpecification.getFilterableRequestSpecification());
        return response.getBody().as(GenericErrorDTO.class);
    }

    public ErrorDTO sendGetRequestWithError(CustomFilterableRequestSpecification requestSpecification) {
        Response response = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());
        return response.getBody().as(ErrorDTO.class);
    }

    public GenericErrorDTO sendGetRequestWithGenericError(CustomFilterableRequestSpecification requestSpecification) {
        Response response = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());
        return response.getBody().as(GenericErrorDTO.class);
    }

    public ErrorDTO sendPostRequestWithOneFileAsMultiPartAndError(int statusCode, String platformContext, Headers headers, String fileName, InputStream stream, String attachmentType, String basePath, Map<String, String> pathParamsMap, Map<String, String> queryParamsMap) {
        String result = requestOperationsHelper.sendPostRequestWithOneMultiPart(statusCode, platformContext, headers, "file", fileName, stream, attachmentType, basePath, pathParamsMap, queryParamsMap);

        return new GenericConvertHelper().stringToDTO(result, ErrorDTO.class);
    }

    public ErrorDTO sendPostRequestWithError(CustomFilterableRequestSpecification requestSpecification) {
        Response response = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());
        return response.getBody().as(ErrorDTO.class);
    }

    public GenericErrorDTO sendPostRequestWithGenericError(CustomFilterableRequestSpecification requestSpecification) {
        Response response = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());
        return response.getBody().as(GenericErrorDTO.class);
    }

    public GenericErrorDTO sendDeleteRequestWithGenericError(CustomFilterableRequestSpecification requestSpecification) {
        Response response = requestOperationsHelper.sendDeleteRequest(requestSpecification.getFilterableRequestSpecification());
        return response.getBody().as(GenericErrorDTO.class);
    }

    public ErrorDTO sendDeleteRequestWithError(CustomFilterableRequestSpecification requestSpecification) {
        Response response = requestOperationsHelper.sendDeleteRequest(requestSpecification.getFilterableRequestSpecification());
        return response.getBody().as(ErrorDTO.class);
    }

    public GenericErrorDTO sendPatchRequestWithGenericError(CustomFilterableRequestSpecification requestSpecification) {
        Response response = requestOperationsHelper.sendPatchRequest(requestSpecification.getFilterableRequestSpecification());
        return response.getBody().as(GenericErrorDTO.class);
    }

    public GenericErrorDTO sendRequestWithGenericError(CustomFilterableRequestSpecification requestSpecification, Method httpMethod) {
        Response response = requestOperationsHelper.sendRequest(requestSpecification.getFilterableRequestSpecification(), httpMethod);
        return response.getBody().as(GenericErrorDTO.class);
    }

}

