package com.abc.automation.helpers.enums.member;

public enum MemberRestrictionEnum {

    HOUSE_ACCOUNT("House Account"),
    VIP_MEMBER("Vip Member");

    private String restrictionType;

    MemberRestrictionEnum(String type) {
        restrictionType = type;
    }

    public String getMemberRestricionType() {
        return restrictionType;
    }
}
