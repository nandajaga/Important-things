package com.abc.automation.factories.platformcontext.version2;

import com.abc.servicemodel.domainV2.MemberV2;

import static com.abc.automation.helpers.constants.PlatformContextConstants.*;

public class MemberV2DTOFactory {

    public MemberV2 createMemberDTO(String countyCode, String zipCode, String networkCode, String programCode,
                                    String lineOfBusinessCode, String employerGroupCode, String alphaPrefixCode,
                                    String fundingTypeCode, String jurisdictionCode, Integer clientId,
                                    String stateCode, String issuanceStateCode,String productCode) {
        MemberV2 member = new MemberV2();

        member.setCountyCode(countyCode);
        member.setZipCode(zipCode);
        member.setNetworkCode(networkCode);
        member.setProgramCode(programCode);
        member.setLineOfBusinessCode(lineOfBusinessCode);
        member.setJurisdictionCode(jurisdictionCode);
        member.setClientId(clientId);
        member.setStateCode(stateCode);
        member.setIssuanceStateCode(issuanceStateCode);
        member.setProductCode(productCode);
        member.setEmployerGroupCode(employerGroupCode);

        return member;
    }

    public MemberV2 createMemberDTO() {
        return createMemberDTO(PC_LOCATION_REGION_CODE, PC_LOCATION_ZIP_CODE, PC_ENROLLMENT_NETWORK_CODE, PC_ENROLLMENT_PROGRAM_CODE,
                PC_ENROLLMENT_LINE_OF_BUSINESS_CODE, PC_ENROLLMENT_EMPLOYER_GROUP_CODE, PC_ALPHA_PREFIX_CODE, PC_FUNDING_TYPE_CODE,
                PC_ENROLLMENT_JURISDICTION_CODE, PC_MEMBER_CLIENT_ID, PC_LOCATION_STATE_CODE, PC_ENROLLMENT_INSURANCE_STATE_CODE, PC_ENROLLMENT_PRODUCT_CODE);
    }

}
