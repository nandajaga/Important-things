package com.abc.automation.tests.base;

import com.abc.automation.dtos.ErrorDTO;
import com.abc.automation.factories.platformcontext.PlatformContextDTOFactory;
import com.abc.automation.factories.platformcontext.UserDTOFactory;
import com.abc.automation.helpers.CustomFilterableRequestSpecification;
import com.abc.automation.helpers.dataproviders.DataProviders;
import com.abc.automation.helpers.enums.RequestHeadersEnum;
import com.abc.automation.steps.ErrorsSteps;
import com.abc.servicemodel.domain.PlatformContext;
import com.abc.servicemodel.domain.User;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static com.abc.automation.helpers.constants.PlatformContextConstants.*;
import static com.abc.automation.helpers.convert.ConvertPlatformContextPOJOToString.convertPlatformContextToString;

public class GetWithPlatformContextTests extends GetTests {

    private CustomFilterableRequestSpecification specification;

    @BeforeMethod (alwaysRun = true)
    public void initGetWithPlatformContext() {
        specification = new CustomFilterableRequestSpecification();
        specification.addBasePath(basePath);
        specification.addPathParams(pathParamsMap);
        specification.addQueryParams(queryParamsMap);
        specification.addHeaders(headers);
        specification.addHeaders(additionalHeaders);
        specification.addPlatformContextToRequest(platformContextHeader);
    }

    @Test(dataProvider = "PlatformContextFieldsValidation", dataProviderClass = DataProviders.class)
    public void whenGetAndPlatformContextWithNullValueThenServiceReturnBadResponse(String field, String errorMSG) {
        PlatformContextDTOFactory factory = new PlatformContextDTOFactory();
        PlatformContext platformContextDTOFalse = factory.createPlatformContextDTO();
        platformContextDTOFalse = factory.editPlatformContextDTO(platformContextDTOFalse, field, null);
        String platformContextFalse = convertPlatformContextToString(platformContextDTOFalse);

        specification.addCustomHeader(RequestHeadersEnum.PLATFORM_CONTEXT.getName(), platformContextFalse);
        ErrorsSteps errorsSteps = new ErrorsSteps();
        ErrorDTO errorDTO = errorsSteps.sendGetRequestWithError(specification);

        softNG.assertEquals(errorDTO.getMessage().toLowerCase(), errorMSG.toLowerCase());
        softNG.assertAll();
    }

    @Test
    public void whenGetAndPlatformContextMissingServicesTreatmentCodeThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getServices().get(0).setTreatmentCode(null);
        String platformContextFalse = convertPlatformContextToString(platformContextDTOFalse);

        specification.addCustomHeader(RequestHeadersEnum.PLATFORM_CONTEXT.getName(), platformContextFalse);
        ErrorsSteps errorsSteps = new ErrorsSteps();
        ErrorDTO errorDTO = errorsSteps.sendGetRequestWithError(specification);

        softNG.assertEquals(errorDTO.getMessage().toLowerCase(), String.format(PLATFORM_CONTEXT_MISSING_FIELD, SERVICES_TREATMENT_CODE).toLowerCase());
        softNG.assertAll();
    }

    @Test
    public void whenGetAndPlatformContextMissingServicesTreatmentCodeTypeThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getServices().get(0).setTreatmentCodeType(null);
        String platformContextFalse = convertPlatformContextToString(platformContextDTOFalse);

        specification.addCustomHeader(RequestHeadersEnum.PLATFORM_CONTEXT.getName(), platformContextFalse);
        ErrorsSteps errorsSteps = new ErrorsSteps();
        ErrorDTO errorDTO = errorsSteps.sendGetRequestWithError(specification);

        softNG.assertEquals(errorDTO.getMessage().toLowerCase(), String.format(PLATFORM_CONTEXT_MISSING_FIELD, SERVICES_TREATMENT_CODE_TYPE).toLowerCase());
        softNG.assertAll();
    }

    @Test
    public void whenGetAndPlatformContextMissingUserRolesThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        User tempUser = new User();
        tempUser.setId(PC_USER_ID);
        platformContextDTOFalse.setUser(tempUser);
        String platformContextFalse = convertPlatformContextToString(platformContextDTOFalse);

        specification.addCustomHeader(RequestHeadersEnum.PLATFORM_CONTEXT.getName(), platformContextFalse);
        ErrorsSteps errorsSteps = new ErrorsSteps();
        ErrorDTO errorDTO = errorsSteps.sendGetRequestWithError(specification);

        tempUser = new UserDTOFactory().createUserPCDTO();
        platformContextDTOFalse.setUser(tempUser);

        softNG.assertEquals(errorDTO.getMessage().toLowerCase(), String.format(PLATFORM_CONTEXT_MISSING_FIELD, USER_ROLES).toLowerCase());
        softNG.assertAll();
    }
}
