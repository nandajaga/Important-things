package com.abc.automation.helpers.convert;

import com.abc.automation.helpers.constants.Constants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import org.testng.Reporter;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class GenericConvertHelper {
    private ObjectMapper objectMapper;

    public GenericConvertHelper() {
        objectMapper = new ObjectMapper();
    }

    /**
     * Example: DTO dto = new GenericConvertHelper().stringToDTO(string, DTO.class);
     *
     * @param dateFormat       the format in which dates should be set
     * @param stringValueOfDTO the string that you want to map to a DTO
     * @param <T>              the type that will be returned
     * @return dto of type T with the information from the string
     */
    public <T> T stringToDTO(String stringValueOfDTO, Class<T> c, String dateFormat) {

        objectMapper.setDateFormat(new SimpleDateFormat(dateFormat));
        objectMapper.registerModule(createJavaTimeModuleLocalInstance());

        T dto = null;
        try {
            dto = objectMapper.readValue(stringValueOfDTO, c);
        } catch (IOException e) {
            Reporter.log(String.format("An error has occurred while converting string %s to DTO of type %s %n %s", stringValueOfDTO, c, e));
        }

        return dto;
    }

    /**
     * Example: DTO dto = new GenericConvertHelper().stringToDTO(string, DTO.class);
     *
     * @param stringValueOfDTO the string that you want to map to a DTO
     * @param <T>              the type that will be returned
     * @return dto of type T with the information from the string
     */
    public <T> T stringToDTO(String stringValueOfDTO, Class<T> c) {
        return stringToDTO(stringValueOfDTO, c, Constants.SAMPLE_DATE_FORMAT);
    }

    /**
     * @param dto is the object that you want to convert to string
     * @return the string representation of the dto
     */
    public String dtoToString(Object dto) {
        String dtoAsString = "Error while converting";
        objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        objectMapper.registerModule(createJavaTimeModuleLocalInstance());

        try {
            dtoAsString = objectMapper.writeValueAsString(dto);
        } catch (JsonProcessingException e) {
            Reporter.log(String.format("An error has occurred while converting DTO %s to string %n %s", dto, e));
        }
        return dtoAsString;
    }

    private JavaTimeModule createJavaTimeModuleLocalInstance() {
        JavaTimeModule javaTimeModule = new JavaTimeModule();
        javaTimeModule.addSerializer(LocalDateTime.class, new LocalDateTimeSerializer(Constants.DATE_TIME_FORMATTER));
        javaTimeModule.addSerializer(LocalDate.class, new LocalDateSerializer(Constants.DATE_FORMATTER));

        return javaTimeModule;
    }

    public <T> T convert(Object from, Class<T> toClass) {
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        return stringToDTO(dtoToString(from), toClass);
    }
}
