package com.abc.automation.steps.member.snapshot;

import com.abc.automation.helpers.CustomFilterableRequestSpecification;
import com.abc.automation.helpers.EnvironmentHelper;
import com.abc.automation.helpers.RequestOperationsHelper;
import com.abc.automation.helpers.constants.BasePathConstants;
import com.abc.automation.helpers.enums.DomainEnum;
import com.abc.automation.dtos.member.enrollments.MemberEnrollmentSnapshotDTOV3;
import com.abc.automation.dtos.member.snapshot.MemberEnrollmentsSnapshotResponseDTO;
import com.abc.automation.steps.member.enrollments.GetMemberEnrollmentsSteps;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by PPetarcheva on 4/22/2019.
 */
public class CreateMemberEnrollmentsSnapshotSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;
    EnvironmentHelper environmentHelper = new EnvironmentHelper();

    public CreateMemberEnrollmentsSnapshotSteps(String platformContext, Headers headers) {
        requestSpecification = new CustomFilterableRequestSpecification();
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.addHeaders(headers);
    }

    public CreateMemberEnrollmentsSnapshotSteps(CustomFilterableRequestSpecification requestSpecification) {
        this.requestSpecification = new CustomFilterableRequestSpecification();
        requestOperationsHelper = new RequestOperationsHelper();
        Headers headers = requestSpecification.getFilterableRequestSpecification().getHeaders();

        this.requestSpecification.addHeaders(headers);
    }

    public Response createMemberEnrollmentsSnapshotResponse(String clientId, String memberId) {
        GetMemberEnrollmentsSteps getMemberEnrollmentsSteps = new GetMemberEnrollmentsSteps(requestSpecification);
        String enrollmentId = getMemberEnrollmentsSteps.getMemberEnrollmentsId(clientId, memberId);

        requestSpecification.addBasePath(BasePathConstants.MEMBER_CREATE_ENROLLMENTS_SNAPSHOT_BASE_PATH);
        requestSpecification.addBaseURI(environmentHelper.constructBaseURIForDomain(DomainEnum.MEMBER));

        Map<String, String> pathParams = new HashMap<>();
        pathParams.put("clientId", clientId);
        pathParams.put("memberId", memberId);
        pathParams.put("enrollmentId", enrollmentId);

        requestSpecification.addPathParams(pathParams);

        return requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());
    }

    public Response createMemberEnrollmentSnapshotV3Response(String clientId, String memberId, String memberPcpSnapshotId) {
        String enrollmentId = new GetMemberEnrollmentsSteps(requestSpecification).getMemberEnrollmentsId(clientId, memberId);

        requestSpecification.addBasePath(BasePathConstants.MEMBER_CREATE_ENROLLMENTS_V3_SNAPSHOT_BASE_PATH);
        requestSpecification.addBaseURI(environmentHelper.constructBaseURIForDomain(DomainEnum.MEMBER));
        // Add Path and Query Param's
        Map<String, String> pathParams = new HashMap<>();
        Map<String, String> queryParams = new HashMap<>();
        pathParams.put("clientId", clientId);
        pathParams.put("memberId", memberId);
        pathParams.put("enrollmentId", enrollmentId);
        // ToDo : PCPShapshotId Filed should be updated to PCPSnapshotId
        queryParams.put("pcpShapshotId", memberPcpSnapshotId);

        requestSpecification.addPathParams(pathParams);
        requestSpecification.addQueryParams(queryParams);

        return new RequestOperationsHelper().sendPostRequest(requestSpecification.getFilterableRequestSpecification());

    }

    public MemberEnrollmentsSnapshotResponseDTO createMemberEnrollmentsSnapshot(String clientId, String memberId) {
        Response result = createMemberEnrollmentsSnapshotResponse(clientId, memberId);

        result.then().statusCode(HttpStatus.SC_CREATED);

        return result.as(MemberEnrollmentsSnapshotResponseDTO.class);
    }

    public MemberEnrollmentSnapshotDTOV3 createMemberEnrollmentSnapshotV3(String clientId, String memberId, String memberPcpSnapshotId) {
        Response response = createMemberEnrollmentSnapshotV3Response(clientId, memberId, memberPcpSnapshotId);

        response.then().statusCode(HttpStatus.SC_CREATED);

        return response.as(MemberEnrollmentSnapshotDTOV3.class);
    }

    public String createMemberEnrollmentsSnapshotAndGetSnapshotId(String clientId, String memberId) {
        MemberEnrollmentsSnapshotResponseDTO memberEnrollmentsSnapshotResponseDTO = createMemberEnrollmentsSnapshot(clientId, memberId);

        return memberEnrollmentsSnapshotResponseDTO.getSnapshotId();
    }

    public String createMemberEnrollmentSnapshotV3AndGetSnapshotId(String clientId, String memberId, String memberPcpSnapshotId) {

        MemberEnrollmentSnapshotDTOV3 memberEnrollmentSnapshotDTOV3 = createMemberEnrollmentSnapshotV3(clientId, memberId, memberPcpSnapshotId);

        return memberEnrollmentSnapshotDTOV3.getSnapshotId();
    }
}
