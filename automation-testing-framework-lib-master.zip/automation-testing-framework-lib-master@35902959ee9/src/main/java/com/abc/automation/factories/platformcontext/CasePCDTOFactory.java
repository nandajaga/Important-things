package com.abc.automation.factories.platformcontext;

import com.abc.servicemodel.domain.Case;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import static com.abc.automation.helpers.constants.PlatformContextConstants.PC_CASE_CREATION_START_DATE;

public class CasePCDTOFactory {

    private final static Logger LOGGER = LoggerFactory.getLogger(CasePCDTOFactory.class);

    public Case createCasePCDTO(String caseId) {
        Case casePC = new Case();
        DateFormat date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String timeStamp = PC_CASE_CREATION_START_DATE;

        try {
            casePC.setCreationDate(date.parse(timeStamp));
        } catch (ParseException e) {
            LOGGER.error("An error occurred while parsing the time stamp {} \n", timeStamp, e);
        }
        casePC.setCaseId(caseId);

        return casePC;
    }
}
