package com.abc.automation.helpers;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.testng.Reporter;

import java.io.IOException;
import java.io.InputStream;

public class ReadContentResourceFiles {

    public InputStream readContentResourceFile(String filePath) {
        InputStream is = ReadContentResourceFiles.class.getClassLoader().getResourceAsStream(filePath);

        if (is == null) {
            throw new RuntimeException(filePath);
        }
        return is;
    }

    /**
     * This is a generic method that reads a file as string, then converts it to the desired type
     *
     * @param filePath the path to the file (starts at resources level)
     * @param <T>      desired return type
     * @return the file content as dto
     */
    public <T> T readDtoFromFile(String filePath, Class<T> tClass) {
        InputStream inputStream = readContentResourceFile(filePath);
        T result = null;
        try {
            result = new ObjectMapper().readValue(inputStream, tClass);
        } catch (IOException e) {
            Reporter.log(String.format("Could not load JSON file data from file %s%n%s", filePath, e));
        }

        return result;
    }
}
