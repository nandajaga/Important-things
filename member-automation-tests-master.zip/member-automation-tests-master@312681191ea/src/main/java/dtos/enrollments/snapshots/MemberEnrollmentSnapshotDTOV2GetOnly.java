package dtos.enrollments.snapshots;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import dtos.enrollments.SolutionDTO;

import java.util.ArrayList;

/**
 * Created by RKondakova on 5/3/2019.
 */
//TODO This is added only to be used for v2. Once v2 is deprecated it should be removed
// Adding option to ignore all unknown properties in order to not add all the fields from the response - it seems that the dto is not properly created for this version of the endpoint
@JsonIgnoreProperties(ignoreUnknown = true)
public class MemberEnrollmentSnapshotDTOV2GetOnly {

    private String snapshotId;
    private String clientId;
    private String enrollmentId;
    private String healthPlan;
    private ArrayList<SolutionDTO> solutionDTO;


    public String getSnapshotId() {
        return snapshotId;
    }

    public String getEnrollmentId() {
        return enrollmentId;
    }

    public String getClientId() {
        return clientId;
    }

    public String getHealthPlan() {
        return healthPlan;
    }

    public ArrayList<SolutionDTO> getSolutions() {
        if (this.solutionDTO != null) {
            return new ArrayList<>(solutionDTO);
        }
        return null;
    }

    public void setSolutions(ArrayList<SolutionDTO> solutions) {
        if (solutions != null) {
            this.solutionDTO = new ArrayList<>(solutions);
        }
    }
}
