package steps.clientconfig;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.clientconfig.ReferenceDataV3DTO;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

import static helpers.constants.BasePathConstants.BASE_PATH_REFERENCES_DATA_V3;

/**
 * Created by VBaliyska on 8/23/2019.
 */
public class ClientReferencesDataSteps {
    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public ClientReferencesDataSteps(String platformContext, Headers headers) {

        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BASE_PATH_REFERENCES_DATA_V3);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }


    public ReferenceDataV3DTO getReferenceDataWithClientIdTests(String clientId){

        Map<String, String> pathParamsMap = new HashMap<>();

        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_OK);

        return result.as(ReferenceDataV3DTO.class);
    }

    public ErrorDTO getReferenceDataForNegativeTestsErrorDTO(String clientId) {

        Map<String, String> pathParamsMap = new HashMap<>();

        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorDTO.class);

    }
}
