package helpers.constants;

/**
 * Created by VBaliyska on 6/19/2019.
 */
public class ConstantsClientIds {

    public static final String CLIENT_ID_85 = "85";
    public static final String CLIENT_ID_186 = "186";
    public static final String CLIENT_ID_187 = "187";
    public static final String CLIENT_ID_210 = "210";
    public static final String CLIENT_ID_212 = "212";
    public static final String CLIENT_ID_220 = "220";
    public static final String CLIENT_ID_233 = "233";
    public static final String CLIENT_ID_234 = "234";
    public static final String CLIENT_ID_300 = "300";
}
