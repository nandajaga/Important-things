package dtos.enrollments;

public class ConsumerEngagementProgramDTO {
    private String programTypeCode;
    private String providerSelectionCode;
    private String memberEngagementCode;
    private String costCode;
    private String incentiveCode;
    private String benefitDifferentialCode;

    public String getProgramTypeCode() {
        return programTypeCode;
    }

    public void setProgramTypeCode(String programTypeCode) {
        this.programTypeCode = programTypeCode;
    }

    public String getProviderSelectionCode() {
        return providerSelectionCode;
    }

    public void setProviderSelectionCode(String providerSelectionCode) {
        this.providerSelectionCode = providerSelectionCode;
    }

    public String getMemberEngagementCode() {
        return memberEngagementCode;
    }

    public void setMemberEngagementCode(String memberEngagementCode) {
        this.memberEngagementCode = memberEngagementCode;
    }

    public String getCostCode() {
        return costCode;
    }

    public void setCostCode(String costCode) {
        this.costCode = costCode;
    }

    public String getIncentiveCode() {
        return incentiveCode;
    }

    public void setIncentiveCode(String incentiveCode) {
        this.incentiveCode = incentiveCode;
    }

    public String getBenefitDifferentialCode() {
        return benefitDifferentialCode;
    }

    public void setBenefitDifferentialCode(String benefitDifferentialCode) {
        this.benefitDifferentialCode = benefitDifferentialCode;
    }
}
