package steps.enrollments.snapshots;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.enrollments.snapshots.MemberEnrollmentsSnapshotDTO;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

import static helpers.constants.BasePathConstants.BASE_PATH_CREATE_ENROLLMENT_SNAPSHOT;

/**
 * Created by RKondakova on 4/25/2019.
 */
public class MemberEnrollmentSnapshotCreateSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public MemberEnrollmentSnapshotCreateSteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BASE_PATH_CREATE_ENROLLMENT_SNAPSHOT);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    public MemberEnrollmentsSnapshotDTO createMemberEnrollmentSnapshot(String clientId, String memberId, String enrollmentId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);
        pathParamsMap.put("memberId", memberId);
        pathParamsMap.put("enrollmentId", enrollmentId);

        requestSpecification.addPathParams(pathParamsMap);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_CREATED);

        return result.as(MemberEnrollmentsSnapshotDTO.class);
    }

    public ErrorDTO createSnapshotEnrollmentErrors(String clientId, String memberId, String enrollmentId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);
        pathParamsMap.put("memberId", memberId);
        pathParamsMap.put("enrollmentId", enrollmentId);

        requestSpecification.addPathParams(pathParamsMap);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorDTO.class);
    }

}