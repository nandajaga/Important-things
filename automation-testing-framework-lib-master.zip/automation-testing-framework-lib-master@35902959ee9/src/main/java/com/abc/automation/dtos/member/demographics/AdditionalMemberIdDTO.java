package com.abc.automation.dtos.member.demographics;

/**
 * Created by PPetarcheva on 4/17/2019.
 */
public class AdditionalMemberIdDTO {

    private String name;
    private String value;

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return this.value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
