package com.abc.automation.dtos.member.demographics;

/**
 * Created by PPetarcheva on 4/24/2019.
 */
public class RestrictedAccessesDTO {

    private String description;
    private String type;
    private boolean value;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean getValue() {
        return value;
    }

    public void setValue(boolean value) {
        this.value = value;
    }
}
