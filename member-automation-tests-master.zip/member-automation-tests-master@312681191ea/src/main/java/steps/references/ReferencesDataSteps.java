package steps.references;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.ErrorSpringDTO;
import dtos.referencedata.ReferenceDataResponseDTO;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

import static helpers.constants.BasePathConstants.BASE_PATH_REFERENCES_DATA;

/**
 * Created by RKondakova on 7/22/2019.
 */
public class ReferencesDataSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public ReferencesDataSteps(String platformContext, Headers headers) {

        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BASE_PATH_REFERENCES_DATA);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    //for the positive tests
    public ReferenceDataResponseDTO[] getReferenceDataForPositiveTests(String clientId, String types ){

        Map<String, String> queryParamsMap = new HashMap<>();
        Map<String, String> pathParamsMap = new HashMap<>();

        if(clientId != null) pathParamsMap.put("clientId", clientId);
        if(types != null) queryParamsMap.put("types", types);

        requestSpecification.addPathParams(pathParamsMap);
        requestSpecification.addQueryParams(queryParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_OK);

        return result.as(ReferenceDataResponseDTO[].class);
    }

    //for negative tests
    public ErrorSpringDTO getReferenceDataForNegativeTestsErrorSpringDTO(String clientId, String types) {

        Map<String, String> pathParamsMap = new HashMap<>();
        Map<String, String> queryParamsMap = new HashMap<>();

        pathParamsMap.put("clientId", clientId);
        queryParamsMap.put("types", types);

        requestSpecification.addPathParams(pathParamsMap);
        requestSpecification.addQueryParams(queryParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorSpringDTO.class);

    }

    public ErrorDTO getReferenceDataForNegativeTestsErrorDTO(String clientId, String types) {

        Map<String, String> pathParamsMap = new HashMap<>();
        Map<String, String> queryParamsMap = new HashMap<>();

        pathParamsMap.put("clientId", clientId);
        queryParamsMap.put("types", types);

        requestSpecification.addPathParams(pathParamsMap);
        requestSpecification.addQueryParams(queryParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorDTO.class);

    }


}
