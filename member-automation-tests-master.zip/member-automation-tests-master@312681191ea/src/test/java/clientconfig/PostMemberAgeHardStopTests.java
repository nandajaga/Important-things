package clientconfig;

import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.tests.base.PostTests;
import dtos.ErrorDTO;
import dtos.clientconfig.AgeBasedHardStopResponseDTOV3;
import factories.clientconfig.AgeBasedHardStopRequestDTOV3Factory;
import helpers.dataproviders.DataProviders;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.clientconfig.AgeBasedHardStopSteps;

import static helpers.constants.BasePathConstants.BASE_PATH_AGE_HARD_STOP;
import static helpers.constants.ClientConfigConstants.*;
import static helpers.constants.ClientConfigConstants.CLIENT_ID_210;
import static helpers.constants.ClientConfigConstants.LINE_OF_BUSINESS;
import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_186;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_187;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_85;

public class PostMemberAgeHardStopTests extends PostTests {

    private PlatformContextUtils platformContextUtils;

    @BeforeClass
    public void init() {
        basePath = BASE_PATH_AGE_HARD_STOP;
        body = new AgeBasedHardStopRequestDTOV3Factory().postMemberAgeHardStop(3);
    }

    @BeforeMethod
    public void initMethod() {
        platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeChannelCode(platformContextHeader, PC_CHANNEL_CODE_CC);
        platformContextHeader = platformContextUtils.changeSolutionId(platformContextHeader, String.valueOf(PC_SOLUTION_ID));
        platformContextHeader = platformContextUtils.changeLineOfBusinessCode(platformContextHeader, LINE_OF_BUSINESS);
        platformContextHeader = platformContextUtils.changeIssuanceStateCode(platformContextHeader, ISSUANCE_STATE_WI);
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(CLIENT_ID_210));
    }

    /* https://jira.aimspecialtyhealth.com/browse/OSPP-4173
     * Updated the validation for client id 187, 188, 189 for member upperLimit age 3
     * Updated by VHarugeri on 06/04/2020
     */

    @Test(dataProvider = "validClientIdAndValidAgeAge", dataProviderClass = DataProviders.class)
    public void whenValidClientIdAndSolutionIdAndLineOfBusinessThenResponseSC200(String clientId, int memberAge) {
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));
        platformContextHeader = platformContextUtils.changeIssuanceStateCode(platformContextHeader, ISSUANCE_STATE_CA);

        AgeBasedHardStopSteps postAgeBasedHardStopSteps = new AgeBasedHardStopSteps(platformContextHeader, headers);
        AgeBasedHardStopResponseDTOV3 responseDTO = postAgeBasedHardStopSteps.postMemberAgeHardStop(memberAge);

        switch (clientId) {
            case CLIENT_ID_85:
            case CLIENT_ID_184:
            case CLIENT_ID_187:
            case CLIENT_ID_188:
            case CLIENT_ID_189:
                softly.then(responseDTO.getIsAgeBasedHardStop()).isTrue();
                softly.then(responseDTO.getMessage()).isEqualTo(MEMBER_MESSAGE_AGE_HARD_STOP);
                break;
            case CLIENT_ID_186:
            case CLIENT_ID_185:
            case CLIENT_ID_199:
            case CLIENT_ID_183:
                softly.then(responseDTO.getIsAgeBasedHardStop()).isFalse();
                softly.then(responseDTO.getMessage()).isNull();
                break;
            default:
                softly.then(responseDTO.getIsAgeBasedHardStop()).isFalse();
                softly.then(responseDTO.getMessage()).isNull();
                break;
        }
        softly.assertAll();
    }

    /* https://jira.aimspecialtyhealth.com/browse/OSPP-4173
     * Updated the validation for client id 187, 188, 189 for member age 0 & 3 for Boundary Value Analysis
     * Updated data provider values for client id 187, 188, 189
     * Updated by VHarugeri on 06/04/2020
     */

    @Test(dataProvider = "validClientIdAndValidAgeAgeBoundaryValueAnalysis", dataProviderClass = DataProviders.class)
    public void whenValidClientIdAndAgeBoundaryValueAnalysisThenResponseSC200(String clientId, int memberAge) {
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));

        AgeBasedHardStopSteps postAgeBasedHardStopSteps = new AgeBasedHardStopSteps(platformContextHeader, headers);
        AgeBasedHardStopResponseDTOV3 responseDTO = postAgeBasedHardStopSteps.postMemberAgeHardStop(memberAge);

        switch (memberAge) {
            case MEMBER_AGE_4:
            case MEMBER_AGE_7:
            case MEMBER_AGE_11:
                softly.then(responseDTO.getIsAgeBasedHardStop()).isFalse();
                softly.then(responseDTO.getMessage()).isNull();
                break;
            case MEMBER_AGE_0:
                softly.then(responseDTO.getIsAgeBasedHardStop()).isTrue();
                softly.then(responseDTO.getMessage()).isEqualTo(MEMBER_MESSAGE_AGE_HARD_STOP);
                break;
            default:
                softly.then(responseDTO.getIsAgeBasedHardStop()).isFalse();
                softly.then(responseDTO.getMessage()).isNull();
                break;
        }

        softly.assertAll();
    }

    /* https://jira.aimspecialtyhealth.com/browse/OSPP-4173
     * Updated the hard stop member age as 3
     * Updated by VHarugeri on 06/04/2020
     */

    @Test
    public void whenInvalidClientIdAndValidMemberAgeTheResponseSC200() {
        String clientId = RandomStringUtils.random(3, false, true);

        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));

        AgeBasedHardStopSteps postAgeBasedHardStopSteps = new AgeBasedHardStopSteps(platformContextHeader, headers);
        AgeBasedHardStopResponseDTOV3 responseDTO = postAgeBasedHardStopSteps.postMemberAgeHardStop(MEMBER_AGE_3);

        softly.then(responseDTO.getIsAgeBasedHardStop()).isFalse();
        softly.then(responseDTO.getMessage()).isNull();
        softly.assertAll();
    }

    //--------------------------------------------------------------POSITIVE-TESTS-CLIENT-210------------------------------------------------------------------------------------

    /* https://jira.aimspecialtyhealth.com/browse/OSPP-4173
     * Removed the validation for Client id 210(WI) for hard stop member age 3
     * Updated by VHarugeri on 06/04/2020
     */

    @Test(dataProvider = "validMemberAgeForClient210boundaryValueAnalysis", dataProviderClass = DataProviders.class)
    public void whenPostClient210AndValidMemberAgeForClient210boundaryValueAnalysisThenResponseSC200(int memberAge) {
        platformContextHeader = platformContextUtils.changeLineOfBusinessCode(platformContextHeader, PC_ENROLLMENT_LINE_OF_BUSINESS_CODE);

        AgeBasedHardStopSteps postAgeBasedHardStopSteps = new AgeBasedHardStopSteps(platformContextHeader, headers);
        AgeBasedHardStopResponseDTOV3 responseDTO = postAgeBasedHardStopSteps.postMemberAgeHardStop(memberAge);

        switch (memberAge) {
            case MEMBER_AGE_0:
            case MEMBER_AGE_2:
            case MEMBER_AGE_3:
            case MEMBER_AGE_4:
                softly.then(responseDTO.getIsAgeBasedHardStop()).isFalse();
                softly.then(responseDTO.getMessage()).isNull();
                break;
            default:
                softly.then(responseDTO.getIsAgeBasedHardStop()).isFalse();
                softly.then(responseDTO.getMessage()).isNull();
                break;
        }

        softly.assertAll();
    }

    @Test
    public void whenPostInvalidIssuanceStateCodeAndClient210AndValidMemberAgeThenResponseSC200() {
        String issuanceStateCode = RandomStringUtils.random(2, true, false);

        platformContextHeader = platformContextUtils.changeLineOfBusinessCode(platformContextHeader, PC_ENROLLMENT_LINE_OF_BUSINESS_CODE);
        platformContextHeader = platformContextUtils.changeIssuanceStateCode(platformContextHeader, issuanceStateCode);

        AgeBasedHardStopSteps postAgeBasedHardStopSteps = new AgeBasedHardStopSteps(platformContextHeader, headers);
        AgeBasedHardStopResponseDTOV3 responseDTO = postAgeBasedHardStopSteps.postMemberAgeHardStop(MEMBER_AGE_2);

        softly.then(responseDTO.getIsAgeBasedHardStop()).isFalse();
        softly.then(responseDTO.getMessage()).isNull();
        softly.assertAll();
    }

    @Test
    public void whenPostCommercialLineOfBusinessAndClient210AndValidMemberAgeThenResponseSC200() {

        AgeBasedHardStopSteps postAgeBasedHardStopSteps = new AgeBasedHardStopSteps(platformContextHeader, headers);
        AgeBasedHardStopResponseDTOV3 responseDTO = postAgeBasedHardStopSteps.postMemberAgeHardStop(MEMBER_AGE_2);

        softly.then(responseDTO.getIsAgeBasedHardStop()).isFalse();
        softly.then(responseDTO.getMessage()).isNull();
        softly.assertAll();

    }

    @Test
    public void whenPostInvalidLineOfBusinessThenResponseSC() {
        String lineOfBusiness = RandomStringUtils.random(5, true, true);

        platformContextHeader = platformContextUtils.changeLineOfBusinessCode(platformContextHeader, lineOfBusiness);


        AgeBasedHardStopSteps postAgeBasedHardStopSteps = new AgeBasedHardStopSteps(platformContextHeader, headers);
        AgeBasedHardStopResponseDTOV3 responseDTO = postAgeBasedHardStopSteps.postMemberAgeHardStop(MEMBER_AGE_2);

        softly.then(responseDTO.getIsAgeBasedHardStop()).isFalse();
        softly.then(responseDTO.getMessage()).isNull();
        softly.assertAll();
    }

    //------------------------------------------------------------------------NEGATIVE-TESTS--------------------------------------------------------------------

    /* https://jira.aimspecialtyhealth.com/browse/OSPP-4173
     * Updated the test and dataProvider for client 187 & 188
     * Updated by VHarugeri on 06/04/2020
     */

    @Test(dataProvider = "validClientIdAndInvalidMemberAge", dataProviderClass = DataProviders.class)
    public void whenValidClientIdAndInvalidMemberAgeTheResponseSC422(String clientId, int memberAge) {
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));

        AgeBasedHardStopSteps postAgeBasedHardStopSteps = new AgeBasedHardStopSteps(platformContextHeader, headers);
        ErrorDTO responseDTO = postAgeBasedHardStopSteps.postMmberAgeHardStopWithError(memberAge);

        softly.then(responseDTO.getCode()).isEqualTo(HttpStatus.SC_UNPROCESSABLE_ENTITY);

        switch (clientId) {
            case CLIENT_ID_85:
                softly.then(responseDTO.getMessage()).isEqualTo(MEMBER_AGE_VALIDATION_AT_LEAST_0);
                break;
            case CLIENT_ID_184:
            case CLIENT_ID_187:
            case CLIENT_ID_188:
            case CLIENT_ID_189:
                softly.then(responseDTO.getMessage()).isEqualTo(MEMBER_AGE_VALIDATION);
                break;
            default:
                softly.then(responseDTO.getMessage()).isNotNull().isNotBlank().isNotEmpty();
                break;
        }
        softly.assertAll();
    }

    @Test
    public void whenInvalidClientIdAndInvalidMemberAgeThenResponseSC422() {
        int memberAge = Integer.valueOf(RandomStringUtils.random(3, false, true));
        String clientId = RandomStringUtils.random(3, false, true);

        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));

        AgeBasedHardStopSteps postAgeBasedHardStopSteps = new AgeBasedHardStopSteps(platformContextHeader, headers);
        ErrorDTO responseDTO = postAgeBasedHardStopSteps.postMmberAgeHardStopWithError(memberAge);

        softly.then(responseDTO.getCode()).isEqualTo(HttpStatus.SC_UNPROCESSABLE_ENTITY);
        softly.then(responseDTO.getMessage()).isEqualTo(MEMBER_AGE_VALIDATION);
        softly.assertAll();
    }
}
