package com.abc.automation.helpers;


import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;

public class ExcelUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExcelUtils.class);

    public Object[][] readDataFromXL(String fileLocation, String sheetName) {

        try {
            ClassLoader classLoader = getClass().getClassLoader();
            InputStream in = classLoader.getResourceAsStream(fileLocation);
            XSSFWorkbook workbook = new XSSFWorkbook(in);

            XSSFSheet worksheet = workbook.getSheet(sheetName);// get my sheet from workbook
            XSSFRow headerRow = worksheet.getRow(0);     //get my headerRow which start from 0

            int rowNum = worksheet.getPhysicalNumberOfRows();// count my number of Rows
            int colNum = headerRow.getLastCellNum(); // get last colNum

            DataFormatter formatter = new DataFormatter();
            Object data[][] = new Object[rowNum - 1][colNum]; // pass my  count data in array

            for (int i = 0; i < rowNum - 1; i++) //Loop work for Rows
            {
                XSSFRow row = worksheet.getRow(i + 1);

                for (int j = 0; j < colNum; j++) //Loop work for colNum
                {
                    if (row == null)
                        data[i][j] = "";
                    else {
                        XSSFCell cell = row.getCell(j);
                        if (cell == null)
                            data[i][j] = "";
                        else {
                            String value = formatter.formatCellValue(cell);
                            if (value.equals("null")) {
                                data[i][j] = null;
                            } else {
                                data[i][j] = value;
                            }
                        }
                    }
                }
            }

            return data;
        } catch (IOException e) {
            LOGGER.error("Could not load file {}", fileLocation);
        }

        return null;
    }
}
