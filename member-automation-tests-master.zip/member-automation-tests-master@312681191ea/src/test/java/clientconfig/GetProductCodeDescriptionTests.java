package clientconfig;

import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.clientconfig.GetProductCodeDescriptionResponseDTO;
import helpers.dataproviders.DataProviders;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import steps.clientconfig.GetProductCodeDescriptionSteps;

import static helpers.constants.BasePathConstants.BASE_PATH_GET_PRODUCT_CODE_DESCRIPTION;
import static helpers.constants.Constants.*;

public class GetProductCodeDescriptionTests extends GetTests {
    private GetProductCodeDescriptionSteps getProductCodeDescriptionSteps;
    private PlatformContextUtils platformContextUtils;

    @BeforeClass
    void init() {
        basePath = BASE_PATH_GET_PRODUCT_CODE_DESCRIPTION;
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test(dataProvider = "getProviderDescriptionClientIdAndProductCode", dataProviderClass = DataProviders.class)
    public void whenValidClientIdProductCodePassedGotResponse200(String clientId, String validProductCode, String LOB, String issuanceStateCode) {
        platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));
        platformContextHeader = platformContextUtils.changeProductCode(platformContextHeader, validProductCode);
        platformContextHeader = platformContextUtils.changeLineOfBusinessCode(platformContextHeader, LOB);
        platformContextHeader = platformContextUtils.changeIssuanceStateCode(platformContextHeader, issuanceStateCode);

        getProductCodeDescriptionSteps = new GetProductCodeDescriptionSteps(platformContextHeader, headers);
        GetProductCodeDescriptionResponseDTO responseDTO = getProductCodeDescriptionSteps.getProductCodeDescriptionResponse();

        softly.then(responseDTO.getCode()).isNotEmpty();
        softly.then(responseDTO.getDescription()).isNotNull();
        softly.then(responseDTO.getId()).isNotBlank();

        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-400---------------------------------------------

    @Test
    public void whenInvalidProductCodePassedResponse404() {
        platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(CLIENT_ID_85));
        platformContextHeader = platformContextUtils.changeProductCode(platformContextHeader, INVALID_PRODUCT_CODE);

        getProductCodeDescriptionSteps = new GetProductCodeDescriptionSteps(platformContextHeader, headers);
        ErrorDTO errorDTO = getProductCodeDescriptionSteps.getProductCodeErrorResponse();

        softly.then(errorDTO.getCode()).isEqualTo(404);
        softly.then(errorDTO.getMessage()).isEqualTo(ERROR_MSG_404);

        softly.assertAll();
    }


    @Test
    public void whenInvalidClientIdPassedResponse404() {
        platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(INVALID_CLIENT_ID_100));
        platformContextHeader = platformContextUtils.changeProductCode(platformContextHeader, PRODUCT_CODE_ECLPR0_212_MEDICARE);

        getProductCodeDescriptionSteps = new GetProductCodeDescriptionSteps(platformContextHeader, headers);
        ErrorDTO errorDTO = getProductCodeDescriptionSteps.getProductCodeErrorResponse();

        softly.then(errorDTO.getCode()).isEqualTo(404);
        softly.then(errorDTO.getMessage()).isEqualTo(ERROR_MSG_404);

        softly.assertAll();
    }

    @Test
    public void whenNullProductCodePassedResponse400() {
        platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(CLIENT_ID_85));
        platformContextHeader = platformContextUtils.changeProductCode(platformContextHeader, null);

        getProductCodeDescriptionSteps = new GetProductCodeDescriptionSteps(platformContextHeader, headers);
        ErrorDTO errorDTO = getProductCodeDescriptionSteps.getProductCodeErrorResponse();

        softly.then(errorDTO.getCode()).isEqualTo(400);
        softly.then(errorDTO.getMessage()).isEqualTo(PRODUCT_CODE_CANNOT_BE_NULL_ERROR__MSG);

        softly.assertAll();
    }

    @Test
    public void whenInvalidPlatformContextPassedResponse400() {
        getProductCodeDescriptionSteps = new GetProductCodeDescriptionSteps(INVALID_PLATFORMCONTEXT, headers);
        ErrorDTO errorDTO = getProductCodeDescriptionSteps.getProductCodeErrorResponse();

        softly.then(errorDTO.getCode()).isEqualTo(400);
        softly.then(errorDTO.getMessage()).isEqualTo(INVALID_PLATFORMCONTEXT_ERROR_MSG);

        softly.assertAll();
    }

}
