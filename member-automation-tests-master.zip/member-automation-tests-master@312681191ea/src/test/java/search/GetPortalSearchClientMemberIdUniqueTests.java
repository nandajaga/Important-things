package search;

import com.aim.automation.helpers.convert.ConvertDateTimeToUTC;
import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.search.GETMemberSearchDTO;
import dtos.search.MemberSearchDTO;
import helpers.dataproviders.DataProviders;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import steps.search.MemberSearchSteps;
import steps.search.SearchClientMemberUniqueSteps;

import java.io.IOException;
import java.util.ArrayList;

import static helpers.constants.BasePathConstants.BASE_PATH_MEMBERS_UNIQUE;
import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_85;
import static helpers.constants.ErrorMessagesForMemberEndpointsConstants.*;
import static org.apache.http.HttpStatus.SC_BAD_REQUEST;
import static org.apache.http.HttpStatus.SC_UNPROCESSABLE_ENTITY;

/**
 * Only the positive tests are included in the smokesuite.xml
 * The rest of the tests will be included in the functionalsuite.xml
 */
public class GetPortalSearchClientMemberIdUniqueTests extends GetTests {

    private static final String MESSAGE_PAGE_SIZE_FIRST_PART = "For input string: \"";
    private static final String MESSAGE_PAGE_SIZE_SECOND_PART = "\"";

    @BeforeClass
    public void init() {
        basePath = BASE_PATH_MEMBERS_UNIQUE;
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test(dataProvider = "sortPositive", dataProviderClass = DataProviders.class)
    public void whenAGetAndAllValidQueryParametersSentThenServiceReturnsSuccessResponseSC200(String sort) {
        GETMemberSearchDTO memberSearchDTO = new SearchClientMemberUniqueSteps(platformContextHeader, headers).getMemberSearchWithValidParams(CLIENT_ID_85, CLIENT_MEMBER_ID, DOB, DEPENDENT_CODE, FIRST_NAME_STARTS_WITH, sort);

        softly.then(memberSearchDTO.getTotalPages()).isGreaterThan(0);
        softly.then(memberSearchDTO.getTotalElements()).isGreaterThan(0);
        softly.then(memberSearchDTO.getMembers()).isNotEmpty();

        ArrayList<MemberSearchDTO> members = memberSearchDTO.getMembers();

        ConvertDateTimeToUTC convertDateTimeToUTC = new ConvertDateTimeToUTC();
        String pattern = "yyyy-MM-dd";

        for (MemberSearchDTO member : members) {
            softly.then(member.getClientId()).isEqualTo(CLIENT_ID_85);
            softly.then(convertDateTimeToUTC.convertDateTimeToUTC(member.getDateOfBirth(), pattern)).isEqualTo(DOB);
            softly.then(member.getDependentCode()).containsSequence(DEPENDENT_CODE);
            softly.then(member.getFirstName()).containsSequence(FIRST_NAME_STARTS_WITH);
            softly.then(member.getManuallyCreated()).isTrue();
        }
        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-400---------------------------------------------

    @Test
    public void whenGetAndNotValidParamSize0SentThenServiceReturnsBadRequestSC400() throws IOException {
        GETMemberSearchDTO memberSearchDTO = new MemberSearchSteps(platformContextHeader, headers).getMemberSearchWithInvalidParamPage(CLIENT_ID_85, CLIENT_MEMBER_ID, DOB, FIRST_NAME_STARTS_WITH, LAST_NAME_STARTS_WITH, ZERO_CHAR, null, null);

        softly.then(memberSearchDTO.getTotalPages()).isEqualTo(0);
        softly.then(memberSearchDTO.getTotalElements()).isGreaterThanOrEqualTo(0);
        softly.then(memberSearchDTO.getMembers()).isEmpty();
        softly.assertAll();
    }

    @Test(dataProvider = "sortNegative", dataProviderClass = DataProviders.class)
    public void whenGetAndNotValidParamSortWithNotValidDifferentCredentialsSentThenServiceReturnsBadRequestSC400(String sort) {
        ErrorDTO error = new SearchClientMemberUniqueSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(CLIENT_ID_85, CLIENT_MEMBER_ID, DOB, DEPENDENT_CODE, FIRST_NAME_STARTS_WITH, ZERO_CHAR, null, sort);

        if (INVALID_SORT_FIRST_NAME_WITH_DOT.equals(sort)) {
            //https://jira.aimspecialtyhealth.com/browse/NCP-17468
            softly.then(error.getMessage()).contains(ERR_MSG_SORT_PROPERTY);
        } else {
            softly.then(error.getMessage()).contains(ERR_MSG_SORT_FORMAT_INCORRECT);
        }
        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.assertAll();
    }
    //----------------------NEGATIVE-TESTS-Not-Valid-Client-member-id--RESPONSE-CODES-422-------------------------------

    @Test(dataProvider = "clientMemberIdNegative", dataProviderClass = DataProviders.class)
    public void whenGetAndNotValidClientMemberIdWithNotValidCredentialsSentThenServiceReturnsSC422And400(String clientMemberId) {
        ErrorDTO error = new SearchClientMemberUniqueSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(CLIENT_ID_85, clientMemberId, DOB, DEPENDENT_CODE, FIRST_NAME_STARTS_WITH, ZERO_CHAR, null, SORT_VALID_CLIENT_MEMBER_ID);

        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.then(error.getMessage()).contains(ERR_MSG_CLIENT_MEMBER_ID_NOT_LENGTH);
        softly.assertAll();
    }

    //----------------------NEGATIVE-TESTS-Not-Valid-First-Name---RESPONSE-CODES-422------------------------------------

    @Test(dataProvider = "FirstName", dataProviderClass = DataProviders.class)
    public void whenGetAndNotValidFirstNameWithDifferentNotValidCredentialsSentThenServiceReturnsSC422(String firstName) {
        ErrorDTO error = new SearchClientMemberUniqueSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(CLIENT_ID_85, CLIENT_MEMBER_ID, DOB, DEPENDENT_CODE, firstName, ZERO_CHAR, null, SORT_VALID_CLIENT_MEMBER_ID);

        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.then(error.getMessage()).contains(ERR_MSG_FIRST_LAST_NAME);
        softly.assertAll();
    }

    //--------------------------NEGATIVE-TESTS-Not-Valid-Client-Id---RESPONSE-CODES-422---------------------------------

    @Test(dataProvider = "ClientIdNegative", dataProviderClass = DataProviders.class)
    public void whenGetAndNotValidClientIdWithNotValidDifferentValuesSentThenServiceReturnsSC422(String clientId) {
        ErrorDTO error = new SearchClientMemberUniqueSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(clientId, CLIENT_MEMBER_ID, DOB, DEPENDENT_CODE, FIRST_NAME_STARTS_WITH, ZERO_CHAR, null, SORT_VALID_CLIENT_MEMBER_ID);

        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.then(error.getMessage()).contains(ERR_MSG_CLIENT_ID_LENGTH);
        softly.assertAll();
    }

    //------------------------NEGATIVE-TESTS-Not-Valid-Dependent-Code--RESPONSE-CODES-422-------------------------------

    @Test(dataProvider = "DependentCode", dataProviderClass = DataProviders.class)
    public void whenGetAndNotValidDependentCodeWithWrongCredentialsSentThenServiceReturnsSC422(String dependentCode) {
        ErrorDTO error = new SearchClientMemberUniqueSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(CLIENT_ID_85, CLIENT_MEMBER_ID, DOB, dependentCode, FIRST_NAME_STARTS_WITH, ZERO_CHAR, null, SORT_VALID_CLIENT_MEMBER_ID);

        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.then(error.getMessage()).contains(ERR_MSG_DEPENDENT_CODE_FORMAT);
        softly.assertAll();
    }

    //----------------------NEGATIVE-TESTS-Not-Valid-Date-Of-Birth--RESPONSE-CODES-400-422------------------------------

    @Test(dataProvider = "invalidDate", dataProviderClass = DataProviders.class)
    public void whenGetAndNotValidDOBSentThenServiceReturnsSC400And422(String dob) {
        ErrorDTO error = new SearchClientMemberUniqueSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(CLIENT_ID_85, CLIENT_MEMBER_ID, dob, DEPENDENT_CODE, FIRST_NAME_STARTS_WITH, ZERO_CHAR, null, SORT_VALID_CLIENT_MEMBER_ID);
        if (dob == null) {
            softly.then(error.getMessage()).contains(ERR_MSG_DOB_NOT_MET_FOR_ACTUAL_PARAMETERS);
            softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);

        } else {
            switch (dob) {
                case INVALID_DOB:
                    softly.then(error.getMessage()).contains(ERR_MSG_DOB_YEAR_FORMAT);
                    softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
                    break;
                case INVALID_DOB_MONTH:
                    softly.then(error.getMessage()).contains(ERR_MSG_DOB_MONTH_FORMAT);
                    softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
                    break;
                case INVALID_DOB_DATE:
                    softly.then(error.getMessage()).contains(ERR_MSG_DOB_DAY_FORMAT);
                    softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
                    break;
                case DOB_150Plus:
                case INVALID_DOB_YEAR:
                    softly.then(error.getMessage()).contains(ERR_MSG_DOB_VALID_PERIOD);
                    softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
                    break;
                default:
                    softly.then(error.getMessage()).contains(ERR_MSG_DOB_FORMAT);
                    softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
                    break;
            }
        }

        softly.assertAll();
    }

    @Test(dataProvider = "pageInvalid", dataProviderClass = DataProviders.class)
    public void whenGetAndNotValidPageSizeWithWrongCredentialsSentThenServiceReturnsSC422(String pageSize) {
        ErrorDTO error = new SearchClientMemberUniqueSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(CLIENT_ID_85, CLIENT_MEMBER_ID, DOB, DEPENDENT_CODE, FIRST_NAME_STARTS_WITH, pageSize, null, SORT_VALID_CLIENT_MEMBER_ID);

        softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.then(error.getMessage()).contains(concatMessagePage(pageSize));
        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-400---------------------------------------------

    @Test
    public void whenGetAndParamClientIdNotSentThenServiceReturnsSC400() {
        ErrorDTO error = new SearchClientMemberUniqueSteps(platformContextHeader, headers).getMemberSearchWithValidParamsReturnErrorDTO(null, CLIENT_MEMBER_ID, DOB, DEPENDENT_CODE, FIRST_NAME_STARTS_WITH, SORT_VALID_CLIENT_MEMBER_ID);

        softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.then(error.getMessage()).contains(ERR_MSG_CLIENT_ID_NOT_PRESENT);
        softly.assertAll();
    }

    @Test
    public void whenGetAndParamClientMemberIdNotSentThenServiceReturnsSC400() {
        ErrorDTO error = new SearchClientMemberUniqueSteps(platformContextHeader, headers).getMemberSearchWithValidParamsReturnErrorDTO(CLIENT_ID_85, null, DOB, DEPENDENT_CODE, FIRST_NAME_STARTS_WITH, SORT_VALID_CLIENT_MEMBER_ID);

        softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.then(error.getMessage()).contains(ERR_MSG_CLIENT_MEMBER_ID_NOT_PRESENT);
        softly.assertAll();
    }

    @Test
    public void whenGetAndParamDOBNotSentThenServiceReturnsSC400() {
        ErrorDTO error = new SearchClientMemberUniqueSteps(platformContextHeader, headers).getMemberSearchWithValidParamsReturnErrorDTO(CLIENT_ID_85, CLIENT_MEMBER_ID, null, DEPENDENT_CODE, FIRST_NAME_STARTS_WITH, SORT_VALID_CLIENT_MEMBER_ID);

        softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.then(error.getMessage()).contains(ERR_MSG_DOB_NOT_PRESENT);
        softly.assertAll();
    }

    @Test
    public void whenGetAndParamDependentCodeNotSentThenServiceReturnsSC400() {
        ErrorDTO error = new SearchClientMemberUniqueSteps(platformContextHeader, headers).getMemberSearchWithValidParamsReturnErrorDTO(CLIENT_ID_85, CLIENT_MEMBER_ID, DOB, null, FIRST_NAME_STARTS_WITH, SORT_VALID_CLIENT_MEMBER_ID);

        softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.then(error.getMessage()).contains(ERR_MSG_DEPENDENT_CODE_NOT_PRESENT);
        softly.assertAll();
    }

    @Test
    public void whenGetAndParamFirstNameNotSentThenServiceReturnsSC400() {
        ErrorDTO error = new SearchClientMemberUniqueSteps(platformContextHeader, headers).getMemberSearchWithValidParamsReturnErrorDTO(CLIENT_ID_85, CLIENT_MEMBER_ID, DOB, DEPENDENT_CODE, null, SORT_VALID_CLIENT_MEMBER_ID);

        softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.then(error.getMessage()).contains(ERR_MSG_FIRST_NAME_NOT_PRESENT);
        softly.assertAll();
    }

    private String concatMessagePage(String message) {
        return MESSAGE_PAGE_SIZE_FIRST_PART.concat(message).concat(MESSAGE_PAGE_SIZE_SECOND_PART);
    }
}
