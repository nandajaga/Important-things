package com.abc.automation.helpers.constants;

import com.abc.automation.helpers.enums.RequestHeadersEnum;
import com.abc.automation.helpers.enums.platformcontext.PlatformContextVersionEnum;
import com.abc.automation.steps.base.BasePreparationSteps;
import io.restassured.http.Header;
import io.restassured.http.Headers;

import java.util.ArrayList;

public class PrepareHeadersWithUUID {

    public Headers prepareHeaderWithUUID() {
        ArrayList<Header> headerList = new ArrayList<>();
        headerList.add(new Header(RequestHeadersEnum.PLATFORM_CONTEXT.getName(), new BasePreparationSteps().preparePlatformContext(PlatformContextVersionEnum.PC_V1)));
        for (RequestHeadersEnum r : RequestHeadersEnum.values()) {
            String generateUUID = String.valueOf(java.util.UUID.randomUUID());
            if (r.getName() != RequestHeadersEnum.PLATFORM_CONTEXT.getName()) {
                headerList.add(new Header(r.getName(), generateUUID));
            }
        }
        Headers headers = new Headers(headerList);
        return headers;
    }

    public Headers prepareHeaderWithUUID(PlatformContextVersionEnum platformContextVersion) {
        ArrayList<Header> headerList = new ArrayList<>();
        headerList.add(new Header(RequestHeadersEnum.PLATFORM_CONTEXT.getName(), new BasePreparationSteps().preparePlatformContext(PlatformContextVersionEnum.PC_V1)));
        for (RequestHeadersEnum r : RequestHeadersEnum.values()) {
            String generateUUID = String.valueOf(java.util.UUID.randomUUID());
            if (r.getName() != RequestHeadersEnum.PLATFORM_CONTEXT.getName()) {
                headerList.add(new Header(r.getName(), generateUUID));
            }
        }
        Headers headers = new Headers(headerList);
        return headers;
    }
}

