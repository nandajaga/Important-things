package com.abc.automation.factories.platformcontext;

import com.abc.servicemodel.domain.Location;

import static com.abc.automation.helpers.constants.PlatformContextConstants.*;

public class LocationDTOFactory {
    private String stateCode = PC_LOCATION_STATE_CODE;
    private String regionCode = PC_LOCATION_REGION_CODE;
    private String zipCode = PC_LOCATION_ZIP_CODE;

    public Location createLocationPCDTO() {
        Location location = new Location();
        location.setStateCode(stateCode);
        location.setRegionCode(regionCode);
        location.setZipCode(zipCode);

        return location;
    }

    public Location createLocationPCDTO(String stateCode, String regionCode, String zipCode) {
        Location location = new Location();
        location.setStateCode(stateCode);
        location.setZipCode(regionCode);
        location.setZipCode(zipCode);

        return location;
    }
}
