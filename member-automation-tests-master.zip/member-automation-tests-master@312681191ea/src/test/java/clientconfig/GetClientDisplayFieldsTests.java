package clientconfig;

import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.clientconfig.DisplayFieldsDTO;
import helpers.dataproviders.DataProviders;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import steps.clientconfig.ClientDisplayFieldsSteps;

import java.util.List;

import static helpers.constants.BasePathConstants.BASE_PATH_GET_V2_CLIENT_DISPLAY_FIELDS;
import static helpers.constants.ClientConfigConstants.CLIENT_ID_85;
import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_212;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_220;
import static org.apache.http.HttpStatus.SC_UNPROCESSABLE_ENTITY;

/**
 * Created by RKondakova on 7/18/2019.
 */
public class GetClientDisplayFieldsTests extends GetTests {

    @BeforeClass
    public void init() {
        basePath = BASE_PATH_GET_V2_CLIENT_DISPLAY_FIELDS;
        pathParamsMap.clear();
        pathParamsMap.put("clientId", CLIENT_ID_85);
        pathParamsMap.put("screen", DISPLAY_PARAMETER_MANUAL_ADD);
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test(dataProvider = "clientId-85-186-187-210", dataProviderClass = DataProviders.class)
    public void whenGetClientDisplayFieldWithValidClientIdThenValidResponseAndStatus200(String clientId) {
        ClientDisplayFieldsSteps clientDisplayFieldsSteps = new ClientDisplayFieldsSteps(platformContextHeader, headers);
        List<Object> clientDisplayFieldsResponseDTOV2 = clientDisplayFieldsSteps.getClientDisplayFieldsRequestReturningListObjects(clientId, DISPLAY_PARAMETER_MANUAL_ADD);

        softly.then(clientDisplayFieldsResponseDTOV2.get(0).toString()).isNotEmpty();
        softly.then(clientDisplayFieldsResponseDTOV2.get(1).toString()).isNotEmpty();
        softly.then(clientDisplayFieldsResponseDTOV2.get(2).toString()).isNotEmpty();
        softly.assertAll();
    }


    @Test(dataProvider = "screenValid", dataProviderClass = DataProviders.class)
    public void whenGetClientDisplayFieldWithValidScreenInputThenValidResponseAndStatus200(String screen) {
        ClientDisplayFieldsSteps clientDisplayFieldsSteps = new ClientDisplayFieldsSteps(platformContextHeader, headers);
        List<Object> clientDisplayFieldsResponseDTOV2 = clientDisplayFieldsSteps.getClientDisplayFieldsRequestReturningListObjects(CLIENT_ID_85, screen);

        softly.then(clientDisplayFieldsResponseDTOV2.get(0).toString()).isNotEmpty();
        softly.then(clientDisplayFieldsResponseDTOV2.get(1).toString()).isNotEmpty();
        softly.then(clientDisplayFieldsResponseDTOV2.get(2).toString()).isNotEmpty();
        softly.assertAll();
    }


    @Test(dataProvider = "clientId-210-212", dataProviderClass = DataProviders.class)
    public void whenGetClientDisplayFieldWithValidClientId210And212ThenValidResponseAndStatus200(String clientId) {
        ClientDisplayFieldsSteps clientDisplayFieldsSteps = new ClientDisplayFieldsSteps(platformContextHeader, headers);
        List<DisplayFieldsDTO> displayFieldsDTOS = clientDisplayFieldsSteps.getClientDisplayFieldsRequestReturningList(clientId, DISPLAY_PARAMETER_MANUAL_ADD);

        for (DisplayFieldsDTO displayFieldsDTO : displayFieldsDTOS) {
            if (displayFieldsDTO.getLabel().equals(LABEL_SUB_CLIENT_CODE)) {
                if (clientId.equals(CLIENT_ID_212)) {
                    softly.then(displayFieldsDTO.isVisible()).isFalse();
                } else {
                    softly.then(displayFieldsDTO.isVisible()).isTrue();
                }
                softly.then(displayFieldsDTO.isRequired()).isTrue();
            }
        }
        softly.assertAll();
    }

    /* https://jira.aimspecialtyhealth.com/browse/OSPP-9127
     * Added the test for clients NEMO & HCSC(client Id's 220, 233 & 234)
     */
    @Test(dataProvider = "clientId-220-233-234-and-ValidScreen", dataProviderClass = DataProviders.class)
    public void whenGetClientDisplayFieldWithValidScreenInputAndValidClientIdThenValidResponseAndStatus200(String clientId, String screen) {
        ClientDisplayFieldsSteps clientDisplayFieldsSteps = new ClientDisplayFieldsSteps(platformContextHeader, headers);
        List<DisplayFieldsDTO> clientDisplayFieldsResponseDTOV2 = clientDisplayFieldsSteps.getClientDisplayFieldsRequestReturningList(clientId, screen);

        for (DisplayFieldsDTO displayFieldsDTO : clientDisplayFieldsResponseDTOV2) {
            if (displayFieldsDTO.getLabel().equals("Dependent Code") && screen.equals(DISPLAY_PARAMETER_MANUAL_ADD)) {
                softly.then(displayFieldsDTO.getDefaultValue()).isEqualTo("00");
            }
            if (displayFieldsDTO.getLabel().equals("Subgroup") && clientId.equals(CLIENT_ID_220)) {
                softly.then(displayFieldsDTO.getDefaultValue()).isEqualTo("0000");
            }
            if (displayFieldsDTO.getLabel().equals("Network Code") && clientId.equals(CLIENT_ID_220)) {
                softly.then(displayFieldsDTO.isRequired()).isEqualTo(true);
                softly.then(displayFieldsDTO.isVisible()).isEqualTo(true);
            }
        }
        softly.then(clientDisplayFieldsResponseDTOV2.get(0).toString()).isNotEmpty();
        softly.then(clientDisplayFieldsResponseDTOV2.get(1).toString()).isNotEmpty();
        softly.then(clientDisplayFieldsResponseDTOV2.get(2).toString()).isNotEmpty();
        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-422---------------------------------------------

    @Test(dataProvider = "screenNegative", dataProviderClass = DataProviders.class)
    public void whenGetClientDisplayFieldWithInvalidScreenInputThenValidResponseAndStatus422(String screen) {
        ClientDisplayFieldsSteps clientDisplayFieldsSteps = new ClientDisplayFieldsSteps(platformContextHeader, headers);

        ErrorDTO error = clientDisplayFieldsSteps.getClinetDisplayFieldsRequestErrorDTO(CLIENT_ID_85, screen);
        softly.then(error.getMessage()).isEqualTo(ERR_MESSAGE_DISPLAY_NOT_SUPPORTED);
        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.assertAll();
    }

    //TODO The response should return status different from 200 and validate negative data
//    @Test(dataProvider = "clientIdNegative", dataProviderClass =  DataProviders.class)
    public void whenGetClientDisplayFieldWithInvalidClientIdInputThenValidResponseAndStatus422(String clientId) {
        ClientDisplayFieldsSteps clientDisplayFieldsSteps = new ClientDisplayFieldsSteps(platformContextHeader, headers);

        ErrorDTO error = clientDisplayFieldsSteps.getClinetDisplayFieldsRequestErrorDTO(clientId, DISPLAY_PARAMETER_MANUAL_ADD);
        softly.then(error.getMessage()).isEqualTo(ERR_MESSAGE_DISPLAY_NOT_SUPPORTED);
        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.assertAll();
    }
}
