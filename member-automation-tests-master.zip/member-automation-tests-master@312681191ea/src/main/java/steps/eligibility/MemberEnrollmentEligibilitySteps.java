package steps.eligibility;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.eligibility.MemberEligibilityDTO;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

import static helpers.constants.BasePathConstants.BASE_PATH_GET_ENROLLMENT_ELIGIBILITY;
import static helpers.constants.Constants.*;

/**
 * Created by RKondakova on 5/8/2019.
 */
public class MemberEnrollmentEligibilitySteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public MemberEnrollmentEligibilitySteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BASE_PATH_GET_ENROLLMENT_ELIGIBILITY);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    public MemberEligibilityDTO getMemberEligibility(String clientId, String memberId, String compareDate, String solutionId) {
        Response result = getMemberEligibilityResponse(clientId, memberId, compareDate, solutionId);

        result.then().statusCode(HttpStatus.SC_OK);

        return result.as(MemberEligibilityDTO.class);
    }

    public MemberEligibilityDTO getMemberEligibility(String clientId, String memberId, String compareDate) {
        Response result = getMemberEligibilityResponse(clientId, memberId, compareDate);

        result.then().statusCode(HttpStatus.SC_OK);

        return result.as(MemberEligibilityDTO.class);
    }


    public ErrorDTO getMemberErrors(String clientId, String memberId, String compareDate, String solutionId) {

        Response result = getMemberEligibilityResponse(clientId, memberId, compareDate, solutionId);

        return result.as(ErrorDTO.class);
    }

    public ErrorDTO getMemberErrors(String clientId, String memberId, String compareDate) {

        Response result = getMemberEligibilityResponse(clientId, memberId, compareDate);

        return result.as(ErrorDTO.class);
    }

    private Response getMemberEligibilityResponse(String clientId, String memberId, String compareDate, String solutionId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put(CLIENT_ID, clientId);
        pathParamsMap.put(MEMBER_ID, memberId);

        requestSpecification.addPathParams(pathParamsMap);

        Map<String, String> queryParamsMap = new HashMap<>();
        queryParamsMap.put(COMPARE_DATE_PATH_PARM, compareDate);
        queryParamsMap.put(SOLUTION_ID, solutionId);

        requestSpecification.addQueryParams(queryParamsMap);

        return requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

    }

    private Response getMemberEligibilityResponse(String clientId, String memberId, String compareDate) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put(CLIENT_ID, clientId);
        pathParamsMap.put(MEMBER_ID, memberId);

        requestSpecification.addPathParams(pathParamsMap);

        Map<String, String> queryParamsMap = new HashMap<>();
        queryParamsMap.put(COMPARE_DATE_PATH_PARM, compareDate);

        requestSpecification.addQueryParams(queryParamsMap);

        return requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

    }

}
