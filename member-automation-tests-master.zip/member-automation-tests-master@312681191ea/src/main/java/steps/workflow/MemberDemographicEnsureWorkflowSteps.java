package steps.workflow;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.workflow.MemberDemographicWorkflowResDTO;
import factories.workflow.DemographicEnsureWorkflowDTOFactory;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import static helpers.constants.BasePathConstants.BASE_PATH_DEMOGRAPHIC_ENSURE_WORKFLOW;

/**
 * Created by Rkohli on 18/05/2020.
 */
public class MemberDemographicEnsureWorkflowSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public MemberDemographicEnsureWorkflowSteps(String platformContext, Headers headers) {

        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BASE_PATH_DEMOGRAPHIC_ENSURE_WORKFLOW);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    public MemberDemographicWorkflowResDTO[] postDisasterDeclarationForPositiveTests(String subClientCode) {
        Object payLoad = new DemographicEnsureWorkflowDTOFactory().createDisasterDTO(subClientCode);
        requestSpecification.addBodyToRequest(payLoad);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_OK);

        return result.as(MemberDemographicWorkflowResDTO[].class);
    }
}
