package dtos.enrollments;

/**
 * Created by SDoneva on 10/14/2019
 */

public class MemberEnrollmentMixerCodeResponseDTO {

    private MemberEnrollmentDTO memberEnrollment;

    private boolean mixerCodeEnabled;

    public MemberEnrollmentDTO getMemberEnrollment() {
        return memberEnrollment;
    }

    public void setMemberEnrollment(MemberEnrollmentDTO memberEnrollment) {
        this.memberEnrollment = memberEnrollment;
    }

    public boolean getMixerCodeEnabled() {
        return mixerCodeEnabled;
    }

    public void setMixerCodeEnabled(boolean mixerCodeEnabled) {
        this.mixerCodeEnabled = mixerCodeEnabled;
    }
}
