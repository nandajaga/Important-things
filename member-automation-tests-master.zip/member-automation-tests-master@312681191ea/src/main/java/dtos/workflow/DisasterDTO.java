package dtos.workflow;

public class DisasterDTO {
    private String subClientCode;

    public String getSubClientCode() {
        return subClientCode;
    }

    public void setSubClientCode(String subClientCode) {
        this.subClientCode = subClientCode;
    }

}
