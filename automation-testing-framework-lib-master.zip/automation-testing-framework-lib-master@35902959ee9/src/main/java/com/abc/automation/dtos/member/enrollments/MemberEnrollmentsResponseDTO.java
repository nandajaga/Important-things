package com.abc.automation.dtos.member.enrollments;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by PPetarcheva on 4/24/2019.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MemberEnrollmentsResponseDTO {

    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
    )
    private Date createdOn;
    private List<MemberEnrollmentDTO> enrollments;
    private String id;

    public Date getCreatedOn() {
        if (createdOn != null) {
            return new Date(createdOn.getTime());
        } else {
            return null;
        }
    }

    public void setCreatedOn(Date createdOn) {
        if (createdOn != null) {
            this.createdOn = new Date(createdOn.getTime());
        } else {
            this.createdOn = null;
        }
    }

    public List<MemberEnrollmentDTO> getEnrollments() {
        if (enrollments != null) {
            return new ArrayList<>(enrollments);
        } else {
            return null;
        }
    }

    public void setEnrollments(List<MemberEnrollmentDTO> enrollments) {
        if (enrollments != null) {
            this.enrollments = new ArrayList<>(enrollments);
        } else {
            this.enrollments = null;
        }
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
