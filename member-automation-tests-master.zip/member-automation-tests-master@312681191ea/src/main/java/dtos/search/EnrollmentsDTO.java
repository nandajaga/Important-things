package dtos.search;

public class EnrollmentsDTO {
    private String employerGroupCode;
    private String fundType;
    private String issuanceState;
    private String productCode;
    private String lineOfBusiness;
    private String baseIdentifier;
    private String effectiveStartDate;
    private String effectiveEndDate;

    public String getEmployerGroupCode() {
        return employerGroupCode;
    }

    public void setEmployerGroupCode(String employerGroupCode) {
        this.employerGroupCode = employerGroupCode;
    }

    public String getFundType() {
        return fundType;
    }

    public void setFundType(String fundType) {
        this.fundType = fundType;
    }

    public String getIssuanceState() {
        return issuanceState;
    }

    public void setIssuanceState(String issuanceState) {
        this.issuanceState = issuanceState;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getLineOfBusiness() {
        return lineOfBusiness;
    }

    public void setLineOfBusiness(String lineOfBusiness) {
        this.lineOfBusiness = lineOfBusiness;
    }

    public String getBaseIdentifier() {
        return baseIdentifier;
    }

    public void setBaseIdentifier(String baseIdentifier) {
        this.baseIdentifier = baseIdentifier;
    }

    public String getEffectiveStartDate() {
        return effectiveStartDate;
    }

    public void setEffectiveStartDate(String effectiveStartDate) {
        this.effectiveStartDate = effectiveStartDate;
    }

    public String getEffectiveEndDate() {
        return effectiveEndDate;
    }

    public void setEffectiveEndDate(String effectiveEndDate) {
        this.effectiveEndDate = effectiveEndDate;
    }
}
