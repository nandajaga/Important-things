package demographics;

import com.aim.automation.dtos.cases.actionlog.ActionLogDTO;
import com.aim.automation.dtos.platformcontext.AbstractPlatformContext;
import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.helpers.enums.RequestHeadersEnum;
import com.aim.automation.steps.base.BasePreparationSteps;
import com.aim.automation.steps.cases.actionlog.ActionLogSteps;
import com.aim.automation.tests.base.PutTests;
import dtos.ErrorDTO;
import dtos.datamanager.MemberResponseDTO;
import dtos.demographics.EmailsDTO;
import dtos.demographics.PhonesDTO;
import dtos.search.GETMemberSearchDTO;
import factories.demographics.EmailsDTOFactory;
import factories.demographics.MemberUpdateDTOFactory;
import factories.demographics.PhonesDTOFactory;
import helpers.constants.BasePathConstants;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.datamanager.MemberDataManagerSteps;
import steps.demographics.PutMemberDemographicsSteps;
import steps.rabbitmqsimulator.PublishEventSteps;
import steps.search.MemberSearchSteps;

import java.util.ArrayList;
import java.util.List;

import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_186;


/**
 * Created by PPetarcheva on 3/20/2019.
 */
public class PutDemographicsByMember extends PutTests {

    private static final String CONFIRMED = "Confirmed";
    private static final String NOT_PROVIDED = "NotProvided";
    private static final String PERSONAL_EMAIL_TYPE = "Personal";

    private static final String ERROR_MESSAGE_422 = "Contact Information does not meet any of the requirements for update, confirmation or noPhoneInformationProvided case.";
    private static final String ERROR_MESSAGE_500 = "Can not update client loaded memberContacts";
    private String confirmedDisplayNameTemplate = "Confirmation Of %s Information";
    private String notProvidedDisplayNameTemplate = "Member %s Information Not Provided";
    private String notProvidedMessageTemplate = "Member %s Information Unknown.";

    private static String memberId;
    private static String memberIdClientSourceTrue;
    private static ArrayList<PhonesDTO> phones;
    private static ArrayList<EmailsDTO> emails;
    private static ArrayList<PhonesDTO> phonesClientSourceTrue;
    private static ArrayList<EmailsDTO> emailsClientSourceTrue;

    private String confirmedEventType = "InformationConfirmedEvent";
    private String notProvidedEventType = "InformationNotProvidedEvent";

    private String confirmedMessageTemplate = "Member's %s confirmed at ";
    private String emailLabel = "Email";
    private String phoneLabel = "Phone";
    private String emailSuffix = "@aimspecialtyhealth.com";
    private String firstName;
    private String lastName;
    private String email;
    private String caseRequestId;
    private String clientId;
    private MemberDataManagerSteps memberDataManagerSteps;
    private ActionLogSteps actionLogSteps;
    private PutMemberDemographicsSteps putMemberDemographicsSteps;

    @BeforeClass
    public void initClass() {
        basePath = BasePathConstants.BASE_PATH_PUT_DEMOGRAPHICS;

        queryParamsMap.clear();
        pathParamsMap.clear();
        pathParamsMap.put("clientId", CLIENT_ID_85);
        pathParamsMap.put("memberId", "8af2f59a-74d8-4f79-9833-4396d13bc024");
        body = new MemberUpdateDTOFactory().createMemberUpdateDTO(CLIENT_ID_85, "8af2f59a-74d8-4f79-9833-4396d13bc024", null, null, true, true, false, false);

        firstName = FIRST_NAME_STARTS_WITH + RandomStringUtils.random(5, true, false);
        lastName = LAST_NAME_STARTS_WITH + RandomStringUtils.random(5, true, false);
        email = firstName + "." + lastName + emailSuffix;

        clientId = CLIENT_ID_85;

        BasePreparationSteps basePreparationSteps = new BasePreparationSteps();
        AbstractPlatformContext abstractPlatformContext = new AbstractPlatformContext(platformContextVersion);

        platformContextHeader = abstractPlatformContext.getPlatformContextAsString();
        headers = basePreparationSteps.prepareHeadersWithMissingHeader(RequestHeadersEnum.PLATFORM_CONTEXT, 10);
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        phones = new PhonesDTOFactory().createPhonesDTO(false, "Home", "7234567890");
        emails = new EmailsDTOFactory().createEmailsDTO(false, PERSONAL_EMAIL_TYPE, email);

        // Create member contact details
        memberId = memberDataManagerSteps.createMemberWithContacts(clientId, firstName, lastName, emails, phones,CLIENT_MEMBER_ID);

        firstName = FIRST_NAME_STARTS_WITH + RandomStringUtils.random(5, true, false);
        phonesClientSourceTrue = new PhonesDTOFactory().createPhonesDTO(true, "Home", "7234567890");
        emailsClientSourceTrue = new EmailsDTOFactory().createEmailsDTO(true, PERSONAL_EMAIL_TYPE, email);

        // Create member contact details
        memberIdClientSourceTrue = memberDataManagerSteps.createMemberWithContacts(clientId, firstName, lastName, emailsClientSourceTrue, phonesClientSourceTrue,CLIENT_MEMBER_ID);
    }

    @BeforeMethod
    public void init() {
        caseRequestId = "caseRequest" + RandomStringUtils.random(10, true, true);

        // Update platform context
        PlatformContextUtils platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeChannelCode(platformContextHeader, PC_CHANNEL_CODE_CC);
        platformContextHeader = platformContextUtils.changeSolutionId(platformContextHeader, String.valueOf(PC_SOLUTION_ID));
        platformContextHeader = platformContextUtils.changeCaseRequestId(platformContextHeader, caseRequestId);

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        putMemberDemographicsSteps = new PutMemberDemographicsSteps(platformContextHeader, headers);
        actionLogSteps = new ActionLogSteps();
    }

    @Test
    public void whenPhoneAndEmailTheSameAndClientSourceTrueThenError500() {
        // Update member contact details
        ErrorDTO errorDTO = putMemberDemographicsSteps.updateMemberContactsWithError(HttpStatus.SC_INTERNAL_SERVER_ERROR, memberIdClientSourceTrue, clientId, emailsClientSourceTrue, phonesClientSourceTrue, false, false, false, false);

        softly.then(errorDTO.getMessage()).isNotEmpty();
        softly.then(errorDTO.getMessage()).isEqualTo(ERROR_MESSAGE_500);

        softly.assertAll();
    }

    @Test
    public void whenPhoneTheSameAndClientSourceTrueThenError500() {
        // Update member contact details
        ErrorDTO errorDTO = putMemberDemographicsSteps.updateMemberContactsWithError(HttpStatus.SC_INTERNAL_SERVER_ERROR, memberIdClientSourceTrue, clientId, null, phonesClientSourceTrue, false, false, false, false);

        softly.then(errorDTO.getMessage()).isNotEmpty();
        softly.then(errorDTO.getMessage()).isEqualTo(ERROR_MESSAGE_500);

        softly.assertAll();
    }

    @Test
    public void whenEmailTheSameAndClientSourceTrueThenError500() {
        // Update member contact details
        ErrorDTO errorDTO = putMemberDemographicsSteps.updateMemberContactsWithError(HttpStatus.SC_INTERNAL_SERVER_ERROR, memberIdClientSourceTrue, clientId, emailsClientSourceTrue, null, false, false, false, false);

        softly.then(errorDTO.getMessage()).isNotEmpty();
        softly.then(errorDTO.getMessage()).isEqualTo(ERROR_MESSAGE_500);

        softly.assertAll();
    }

    @Test
    public void whenPhoneAndEmailAndConfirmedTrueAndNotProvidedFalseAndClientSourceFalseThenError422() {
        // Update member contact details
        ErrorDTO errorDTO = putMemberDemographicsSteps.updateMemberContactsWithError(HttpStatus.SC_UNPROCESSABLE_ENTITY, memberId, clientId, emails, phones, true, true, false, false);

        softly.then(errorDTO.getMessage()).isNotEmpty();

        softly.then(errorDTO.getMessage()).contains(ERROR_MESSAGE_422);

        softly.assertAll();
    }

    @Test
    public void whenPhoneAndEmailAndConfirmedFalseAndNotProvidedFalseAndClientSourceFalseThenUpdateMember() {
        // Update member contact details
        MemberResponseDTO memberResponseDTO = putMemberDemographicsSteps.updateMemberContacts(memberId, clientId, emails, phones, false, false, false, false);

        softly.then(memberId).isEqualTo(memberResponseDTO.getId());

        // Check message for Email
        checkActionLogMessageIsNotCreated(emailLabel, caseRequestId, CONFIRMED);
        checkActionLogMessageIsNotCreated(emailLabel, caseRequestId, NOT_PROVIDED);

        // Check message for Phone
        checkActionLogMessageIsNotCreated(phoneLabel, caseRequestId, CONFIRMED);
        checkActionLogMessageIsNotCreated(phoneLabel, caseRequestId, NOT_PROVIDED);

        softly.assertAll();
    }

    @Test
    public void whenPhoneAndEmailDifferentAndConfirmedFalseAndNotProvidedFalseAndClientSourceFalseThenUpdateMember() {
        email = firstName + emailSuffix;
        phones = new PhonesDTOFactory().createPhonesDTO(false, "Home", "7234586790");
        emails = new EmailsDTOFactory().createEmailsDTO(false, PERSONAL_EMAIL_TYPE, email);

        // Update member contact details
        MemberResponseDTO memberResponseDTO = putMemberDemographicsSteps.updateMemberContacts(memberId, clientId, emails, phones, false, false, false, false);

        softly.then(memberId).isEqualTo(memberResponseDTO.getId());

        // Check message for Email
        checkActionLogMessageIsNotCreated(emailLabel, caseRequestId, CONFIRMED);
        checkActionLogMessageIsNotCreated(emailLabel, caseRequestId, NOT_PROVIDED);

        // Check message for Phone
        checkActionLogMessageIsNotCreated(phoneLabel, caseRequestId, CONFIRMED);
        checkActionLogMessageIsNotCreated(phoneLabel, caseRequestId, NOT_PROVIDED);

        softly.assertAll();
    }

    @Test
    public void whenPhoneAndEmailAndConfirmedFalseAndNotProvidedTrueAndClientSourceFalseThenError422() {
        // Update member contact details
        ErrorDTO errorDTO = putMemberDemographicsSteps.updateMemberContactsWithError(HttpStatus.SC_UNPROCESSABLE_ENTITY, memberId, clientId, emails, phones, false, false, true, true);

        softly.then(errorDTO.getMessage()).isNotEmpty();

        softly.then(errorDTO.getMessage()).contains(ERROR_MESSAGE_422);

        softly.assertAll();
    }

    @Test
    public void whenPhoneAndEmailAndConfirmedTrueAndNotProvidedTrueAndClientSourceFalseThenError422() {
        // Update member contact details
        ErrorDTO errorDTO = putMemberDemographicsSteps.updateMemberContactsWithError(HttpStatus.SC_UNPROCESSABLE_ENTITY, memberId, clientId, emails, phones, true, true, true, true);

        softly.then(errorDTO.getMessage()).isNotEmpty();

        softly.then(errorDTO.getMessage()).contains(ERROR_MESSAGE_422);

        softly.assertAll();
    }

    @Test
    public void whenPhoneAndEmailNullAndConfirmedTrueAndNotProvidedFalseAndClientSourceFalseThenConfirmedActionLogMessageIsCreated() {
        // Update member contact details
        MemberResponseDTO memberResponseDTO = putMemberDemographicsSteps.updateMemberContacts(memberId, clientId, null, null, true, true, false, false);

        softly.then(memberId).isEqualTo(memberResponseDTO.getId());

        // Check message for Email
        checkActionLogMessage(emailLabel, caseRequestId, CONFIRMED);
        checkActionLogMessageIsNotCreated(emailLabel, caseRequestId, NOT_PROVIDED);

        // Check message for Phone
        checkActionLogMessage(phoneLabel, caseRequestId, CONFIRMED);
        checkActionLogMessageIsNotCreated(phoneLabel, caseRequestId, NOT_PROVIDED);

        softly.assertAll();
    }

    @Test
    public void whenPhoneAndEmailNullAndConfirmedFalseAndNotProvidedFalseAndClientSourceFalseThenError422() {
        // Update member contact details
        ErrorDTO errorDTO = putMemberDemographicsSteps.updateMemberContactsWithError(HttpStatus.SC_UNPROCESSABLE_ENTITY, memberId, clientId, null, null, false, false, false, false);

        softly.then(errorDTO.getMessage()).isNotEmpty();

        softly.then(errorDTO.getMessage()).contains(ERROR_MESSAGE_422);

        softly.assertAll();
    }

    @Test
    public void whenPhoneAndEmailNullAndConfirmedFalseAndNotProvidedTrueAndClientSourceFalseThenNotProvidedActionLogMessageIsCreated() {
        // Update member contact details
        MemberResponseDTO memberResponseDTO = putMemberDemographicsSteps.updateMemberContacts(memberId, clientId, null, null, false, false, true, true);

        softly.then(memberId).isEqualTo(memberResponseDTO.getId());

        // Check message for Email
        checkActionLogMessageIsNotCreated(emailLabel, caseRequestId, CONFIRMED);
        checkActionLogMessage(emailLabel, caseRequestId, NOT_PROVIDED);

        // Check message for Phone
        checkActionLogMessageIsNotCreated(phoneLabel, caseRequestId, CONFIRMED);
        checkActionLogMessage(phoneLabel, caseRequestId, NOT_PROVIDED);

        softly.assertAll();
    }

    @Test
    public void whenPhoneAndEmailNullAndConfirmedTrueAndNotProvidedTrueAndClientSourceFalseThenError422() {
        // Update member contact details
        ErrorDTO errorDTO = putMemberDemographicsSteps.updateMemberContactsWithError(HttpStatus.SC_UNPROCESSABLE_ENTITY, memberId, clientId, null, null, true, true, true, true);

        softly.then(errorDTO.getMessage()).isNotEmpty();

        softly.then(errorDTO.getMessage()).contains(ERROR_MESSAGE_422);

        softly.assertAll();
    }

    @Test
    public void whenPhoneAndEmailEmptyAndConfirmedTrueAndNotProvidedFalseAndClientSourceFalseThenConfirmedActionLogMessageIsCreated() {
        // Update member contact details
        MemberResponseDTO memberResponseDTO = putMemberDemographicsSteps.updateMemberContacts(memberId, clientId, new ArrayList<>(), new ArrayList<>(), true, true, false, false);

        softly.then(memberId).isEqualTo(memberResponseDTO.getId());

        // Check message for Email
        checkActionLogMessage(emailLabel, caseRequestId, CONFIRMED);
        checkActionLogMessageIsNotCreated(emailLabel, caseRequestId, NOT_PROVIDED);

        // Check message for Phone
        checkActionLogMessage(phoneLabel, caseRequestId, CONFIRMED);
        checkActionLogMessageIsNotCreated(phoneLabel, caseRequestId, NOT_PROVIDED);

        softly.assertAll();
    }

    @Test
    public void whenPhoneAndEmailEmptyAndConfirmedFalseAndNotProvidedFalseAndClientSourceFalseThenError422() {
        // Update member contact details
        ErrorDTO errorDTO = putMemberDemographicsSteps.updateMemberContactsWithError(HttpStatus.SC_UNPROCESSABLE_ENTITY, memberId, clientId, new ArrayList<>(), new ArrayList<>(), false, false, false, false);

        softly.then(errorDTO.getMessage()).isNotEmpty();

        softly.then(errorDTO.getMessage()).contains(ERROR_MESSAGE_422);

        softly.assertAll();
    }

    @Test
    public void whenPhoneAndEmailEmptyAndConfirmedFalseAndNotProvidedTrueAndClientSourceFalseThenNotProvidedActionLogMessageIsCreated() {
        // Update member contact details
        MemberResponseDTO memberResponseDTO = putMemberDemographicsSteps.updateMemberContacts(memberId, clientId, new ArrayList<>(), new ArrayList<>(), false, false, true, true);

        softly.then(memberId).isEqualTo(memberResponseDTO.getId());

        // Check message for Email
        checkActionLogMessageIsNotCreated(emailLabel, caseRequestId, CONFIRMED);
        checkActionLogMessage(emailLabel, caseRequestId, NOT_PROVIDED);

        // Check message for Phone
        checkActionLogMessageIsNotCreated(phoneLabel, caseRequestId, CONFIRMED);
        checkActionLogMessage(phoneLabel, caseRequestId, NOT_PROVIDED);

        softly.assertAll();
    }

    @Test
    public void whenPhoneAndEmailEmptyAndConfirmedTrueAndNotProvidedTrueAndClientSourceFalseThenError422() {
        // Update member contact details
        ErrorDTO errorDTO = putMemberDemographicsSteps.updateMemberContactsWithError(HttpStatus.SC_UNPROCESSABLE_ENTITY, memberId, clientId, new ArrayList<>(), new ArrayList<>(), true, true, true, true);

        softly.then(errorDTO.getMessage()).isNotEmpty();

        softly.then(errorDTO.getMessage()).contains(ERROR_MESSAGE_422);

        softly.assertAll();
    }

    @Test
    public void whenPhoneAndConfirmedTrueAndNotProvidedFalseAndClientSourceFalseThenError422() {
        // Update member contact details
        ErrorDTO errorDTO = putMemberDemographicsSteps.updateMemberContactsWithError(HttpStatus.SC_UNPROCESSABLE_ENTITY, memberId, clientId, null, phones, true, false, false, false);

        softly.then(errorDTO.getMessage()).isNotEmpty();

        softly.then(errorDTO.getMessage()).contains(ERROR_MESSAGE_422);

        softly.assertAll();
    }

    @Test
    public void whenPhoneAndConfirmedFalseAndNotProvidedFalseAndClientSourceFalseThenUpdateMember() {
        // Update member contact details
        MemberResponseDTO memberResponseDTO = putMemberDemographicsSteps.updateMemberContacts(memberId, clientId, null, phones, false, false, false, false);

        softly.then(memberId).isEqualTo(memberResponseDTO.getId());

        // Check message for Email
        checkActionLogMessageIsNotCreated(emailLabel, caseRequestId, CONFIRMED);
        checkActionLogMessageIsNotCreated(emailLabel, caseRequestId, NOT_PROVIDED);

        // Check message for Phone
        checkActionLogMessageIsNotCreated(phoneLabel, caseRequestId, CONFIRMED);
        checkActionLogMessageIsNotCreated(phoneLabel, caseRequestId, NOT_PROVIDED);

        softly.assertAll();
    }

    @Test
    public void whenPhoneDifferentAndConfirmedFalseAndNotProvidedFalseAndClientSourceFalseThenUpdateMember() {
        phones = new PhonesDTOFactory().createPhonesDTO(false, "Home", "7234876590");

        // Update member contact details
        MemberResponseDTO memberResponseDTO = putMemberDemographicsSteps.updateMemberContacts(memberId, clientId, null, phones, false, false, false, false);

        softly.then(memberId).isEqualTo(memberResponseDTO.getId());

        // Check message for Email
        checkActionLogMessageIsNotCreated(emailLabel, caseRequestId, CONFIRMED);
        checkActionLogMessageIsNotCreated(emailLabel, caseRequestId, NOT_PROVIDED);

        // Check message for Phone
        checkActionLogMessageIsNotCreated(phoneLabel, caseRequestId, CONFIRMED);
        checkActionLogMessageIsNotCreated(phoneLabel, caseRequestId, NOT_PROVIDED);

        softly.assertAll();
    }

    @Test
    public void whenPhoneAndConfirmedFalseAndNotProvidedTrueAndClientSourceFalseThenError422() {
        // Update member contact details
        ErrorDTO errorDTO = putMemberDemographicsSteps.updateMemberContactsWithError(HttpStatus.SC_UNPROCESSABLE_ENTITY, memberId, clientId, null, phones, false, false, false, true);

        softly.then(errorDTO.getMessage()).isNotEmpty();

        softly.then(errorDTO.getMessage()).contains(ERROR_MESSAGE_422);

        softly.assertAll();
    }

    @Test
    public void whenPhoneAndConfirmedTrueAndNotProvidedTrueAndClientSourceFalseThenError422() {
        // Update member contact details
        ErrorDTO errorDTO = putMemberDemographicsSteps.updateMemberContactsWithError(HttpStatus.SC_UNPROCESSABLE_ENTITY, memberId, clientId, null, phones, true, false, false, true);

        softly.then(errorDTO.getMessage()).isNotEmpty();

        softly.then(errorDTO.getMessage()).contains(ERROR_MESSAGE_422);

        softly.assertAll();
    }

    @Test
    public void whenPhoneEmptyAndConfirmedTrueAndNotProvidedFalseAndClientSourceFalseThenConfirmedActionLogMessageIsCreated() {
        // Update member contact details
        MemberResponseDTO memberResponseDTO = putMemberDemographicsSteps.updateMemberContacts(memberId, clientId, null, new ArrayList<>(), true, false, false, false);

        softly.then(memberId).isEqualTo(memberResponseDTO.getId());

        // Check message for Email
        checkActionLogMessageIsNotCreated(emailLabel, caseRequestId, CONFIRMED);
        checkActionLogMessageIsNotCreated(emailLabel, caseRequestId, NOT_PROVIDED);

        // Check message for Phone
        checkActionLogMessage(phoneLabel, caseRequestId, CONFIRMED);
        checkActionLogMessageIsNotCreated(phoneLabel, caseRequestId, NOT_PROVIDED);

        softly.assertAll();
    }

    @Test
    public void whenPhoneEmptyAndConfirmedFalseAndNotProvidedFalseAndClientSourceFalseThenError422() {
        // Update member contact details
        ErrorDTO errorDTO = putMemberDemographicsSteps.updateMemberContactsWithError(HttpStatus.SC_UNPROCESSABLE_ENTITY, memberId, clientId, null, new ArrayList<>(), false, false, false, false);

        softly.then(errorDTO.getMessage()).isNotEmpty();

        softly.then(errorDTO.getMessage()).contains(ERROR_MESSAGE_422);

        softly.assertAll();
    }

    @Test
    public void whenPhoneEmptyAndConfirmedFalseAndNotProvidedTrueAndClientSourceFalseThenNotProvidedActionLogMessageIsCreated() {
        // Update member contact details
        MemberResponseDTO memberResponseDTO = putMemberDemographicsSteps.updateMemberContacts(memberId, clientId, null, new ArrayList<>(), false, false, false, true);

        softly.then(memberId).isEqualTo(memberResponseDTO.getId());

        // Check message for Email
        checkActionLogMessageIsNotCreated(emailLabel, caseRequestId, CONFIRMED);
        checkActionLogMessageIsNotCreated(emailLabel, caseRequestId, NOT_PROVIDED);

        // Check message for Phone
        checkActionLogMessageIsNotCreated(phoneLabel, caseRequestId, CONFIRMED);
        checkActionLogMessage(phoneLabel, caseRequestId, NOT_PROVIDED);

        softly.assertAll();
    }

    @Test
    public void whenPhoneEmptyAndConfirmedTrueAndNotProvidedTrueAndClientSourceFalseThenError422() {
        // Update member contact details
        ErrorDTO errorDTO = putMemberDemographicsSteps.updateMemberContactsWithError(HttpStatus.SC_UNPROCESSABLE_ENTITY, memberId, clientId, null, new ArrayList<>(), true, false, false, true);

        softly.then(errorDTO.getMessage()).isNotEmpty();

        softly.then(errorDTO.getMessage()).contains(ERROR_MESSAGE_422);

        softly.assertAll();
    }

    @Test
    public void whenEmailAndConfirmedTrueAndNotProvidedFalseAndClientSourceFalseThenError422() {
        // Update member contact details
        ErrorDTO errorDTO = putMemberDemographicsSteps.updateMemberContactsWithError(HttpStatus.SC_UNPROCESSABLE_ENTITY, memberId, clientId, emails, null, false, true, false, false);

        softly.then(errorDTO.getMessage()).isNotEmpty();

        softly.then(errorDTO.getMessage()).contains(ERROR_MESSAGE_422);

        softly.assertAll();
    }

    @Test
    public void whenEmailAndConfirmedFalseAndNotProvidedFalseAndClientSourceFalseThenUpdateMember() {
        // Update member contact details
        MemberResponseDTO memberResponseDTO = putMemberDemographicsSteps.updateMemberContacts(memberId, clientId, emails, null, false, false, false, false);

        softly.then(memberId).isEqualTo(memberResponseDTO.getId());

        // Check message for Email
        checkActionLogMessageIsNotCreated(emailLabel, caseRequestId, CONFIRMED);
        checkActionLogMessageIsNotCreated(emailLabel, caseRequestId, NOT_PROVIDED);

        // Check message for Phone
        checkActionLogMessageIsNotCreated(phoneLabel, caseRequestId, CONFIRMED);
        checkActionLogMessageIsNotCreated(phoneLabel, caseRequestId, NOT_PROVIDED);

        softly.assertAll();
    }

    @Test
    public void whenEmailDifferentAndConfirmedFalseAndNotProvidedFalseAndClientSourceFalseThenUpdateMember() {
        email = lastName + emailSuffix;
        emails = new EmailsDTOFactory().createEmailsDTO(false, PERSONAL_EMAIL_TYPE, email);

        // Update member contact details
        MemberResponseDTO memberResponseDTO = putMemberDemographicsSteps.updateMemberContacts(memberId, clientId, emails, null, false, false, false, false);

        softly.then(memberId).isEqualTo(memberResponseDTO.getId());

        // Check message for Email
        checkActionLogMessageIsNotCreated(emailLabel, caseRequestId, CONFIRMED);
        checkActionLogMessageIsNotCreated(emailLabel, caseRequestId, NOT_PROVIDED);

        // Check message for Phone
        checkActionLogMessageIsNotCreated(phoneLabel, caseRequestId, CONFIRMED);
        checkActionLogMessageIsNotCreated(phoneLabel, caseRequestId, NOT_PROVIDED);

        softly.assertAll();
    }

    @Test
    public void whenEmailAndConfirmedFalseAndNotProvidedTrueAndClientSourceFalseThenError422() {
        // Update member contact details
        ErrorDTO errorDTO = putMemberDemographicsSteps.updateMemberContactsWithError(HttpStatus.SC_UNPROCESSABLE_ENTITY, memberId, clientId, emails, null, false, false, true, false);

        softly.then(errorDTO.getMessage()).isNotEmpty();

        softly.then(errorDTO.getMessage()).contains(ERROR_MESSAGE_422);

        softly.assertAll();
    }

    @Test
    public void whenEmailAndConfirmedTrueAndNotProvidedTrueAndClientSourceFalseThenError422() {
        // Update member contact details
        ErrorDTO errorDTO = putMemberDemographicsSteps.updateMemberContactsWithError(HttpStatus.SC_UNPROCESSABLE_ENTITY, memberId, clientId, emails, null, false, true, true, false);

        softly.then(errorDTO.getMessage()).isNotEmpty();

        softly.then(errorDTO.getMessage()).contains(ERROR_MESSAGE_422);

        softly.assertAll();
    }

    @Test
    public void whenEmailEmptyAndConfirmedTrueAndNotProvidedFalseAndClientSourceFalseThenConfirmedActionLogMessageIsCreated() {
        // Update member contact details
        MemberResponseDTO memberResponseDTO = putMemberDemographicsSteps.updateMemberContacts(memberId, clientId, new ArrayList<>(), null, false, true, false, false);

        softly.then(memberId).isEqualTo(memberResponseDTO.getId());

        // Check message for Email
        checkActionLogMessage(emailLabel, caseRequestId, CONFIRMED);
        checkActionLogMessageIsNotCreated(emailLabel, caseRequestId, NOT_PROVIDED);

        // Check message for Phone
        checkActionLogMessageIsNotCreated(phoneLabel, caseRequestId, CONFIRMED);
        checkActionLogMessageIsNotCreated(phoneLabel, caseRequestId, NOT_PROVIDED);

        softly.assertAll();
    }

    @Test
    public void whenEmailEmptyAndConfirmedFalseAndNotProvidedFalseAndClientSourceFalseThenError422() {
        // Update member contact details
        ErrorDTO errorDTO = putMemberDemographicsSteps.updateMemberContactsWithError(HttpStatus.SC_UNPROCESSABLE_ENTITY, memberId, clientId, new ArrayList<>(), null, false, false, false, false);

        softly.then(errorDTO.getMessage()).isNotEmpty();

        softly.then(errorDTO.getMessage()).contains(ERROR_MESSAGE_422);

        softly.assertAll();
    }

    @Test
    public void whenEmailEmptyAndConfirmedFalseAndNotProvidedTrueAndClientSourceFalseThenNotProvidedActionLogMessageIsCreated() {
        // Update member contact details
        MemberResponseDTO memberResponseDTO = putMemberDemographicsSteps.updateMemberContacts(memberId, clientId, new ArrayList<>(), null, false, false, true, false);

        softly.then(memberId).isEqualTo(memberResponseDTO.getId());

        // Check message for Email
        checkActionLogMessageIsNotCreated(emailLabel, caseRequestId, CONFIRMED);
        checkActionLogMessage(emailLabel, caseRequestId, NOT_PROVIDED);

        // Check message for Phone
        checkActionLogMessageIsNotCreated(phoneLabel, caseRequestId, CONFIRMED);
        checkActionLogMessageIsNotCreated(phoneLabel, caseRequestId, NOT_PROVIDED);

        softly.assertAll();
    }

    @Test
    public void whenEmailEmptyAndConfirmedTrueAndNotProvidedTrueAndClientSourceFalseThenError422() {
        // Update member contact details
        ErrorDTO errorDTO = putMemberDemographicsSteps.updateMemberContactsWithError(HttpStatus.SC_UNPROCESSABLE_ENTITY, memberId, clientId, new ArrayList<>(), null, false, true, true, false);

        softly.then(errorDTO.getMessage()).isNotEmpty();

        softly.then(errorDTO.getMessage()).contains(ERROR_MESSAGE_422);

        softly.assertAll();
    }

    @Test
    public void whenUpdateManualAddedMemberViaRabbitMqThenDemographicsIsUpdated() {
        // create member through Rabbit Mq
        String clientMemberId = RandomStringUtils.random(24, true, true);

        PublishEventSteps publishEventSteps = new PublishEventSteps(platformContextHeader, headers);
        publishEventSteps.publishEventMemberManualAdd(CLIENT_ID_186, clientMemberId);

        //get member uuid
        GETMemberSearchDTO memberSearchDTO = new MemberSearchSteps(platformContextHeader, headers).getMemberSearch(CLIENT_ID_186, clientMemberId, null, null, null);
        String id = memberSearchDTO.getMembers().get(0).getId();

        //Update member contact details
        email = lastName + emailSuffix;
        emails = new EmailsDTOFactory().createEmailsDTO(false, PERSONAL_EMAIL_TYPE, email);
        MemberResponseDTO memberResponseDTO = putMemberDemographicsSteps.updateMemberContacts(id, CLIENT_ID_186, emails, null, false, false, false, false);

        softly.then(memberResponseDTO.getId()).isEqualTo(id);
        softly.assertAll();
    }

    private void checkActionLogMessage(String contact, String caseRequestId, String eventType) {
        String actionLogMessageType = "";
        String displayName = "";
        String confirmationMessage = "";

        switch (eventType) {
            case CONFIRMED:
                actionLogMessageType = contact + confirmedEventType;
                displayName = String.format(confirmedDisplayNameTemplate, contact);
                confirmationMessage = String.format(confirmedMessageTemplate, contact.toLowerCase());
                break;
            case NOT_PROVIDED:
                actionLogMessageType = "Member" + contact + notProvidedEventType;
                displayName = String.format(notProvidedDisplayNameTemplate, contact);
                confirmationMessage = String.format(notProvidedMessageTemplate, contact);
                break;
            default:
                break;
        }

        // Check action log message
        List<ActionLogDTO> actionLogs = actionLogSteps.getActionLogMessageByType(caseRequestId, PC_SOLUTION_ID, actionLogMessageType);

        softly.then(actionLogs.size()).isNotZero();

        for (ActionLogDTO actionLog : actionLogs) {
            softly.then(actionLog.getRequestIdentifier().equals(caseRequestId));
            softly.then(actionLog.getDisplayName().equals(displayName));
            softly.then(actionLog.getMessage().startsWith(confirmationMessage));
        }
    }

    private void checkActionLogMessageIsNotCreated(String contact, String caseRequestId, String eventType) {
        String actionLogMessageType = "";

        switch (eventType) {
            case CONFIRMED:
                actionLogMessageType = contact + confirmedEventType;
                break;
            case NOT_PROVIDED:
                actionLogMessageType = "Member" + contact + notProvidedEventType;
                break;
            default:
                break;
        }

        // Check action log message
        List<ActionLogDTO> actionLogs = actionLogSteps.getActionLogMessageByType(caseRequestId, PC_SOLUTION_ID, actionLogMessageType);

        softly.then(actionLogs.size()).isZero();
    }

    @Override
    public void whenGetOnPutEndpointThenServiceReturnsMethodNotAllowedResponse() {
        // No need to do anything here
        // GET endpoint with the same path exist and is a valid one
    }

}
