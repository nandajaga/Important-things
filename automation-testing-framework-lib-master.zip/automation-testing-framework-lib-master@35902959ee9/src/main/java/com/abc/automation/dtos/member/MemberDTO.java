package com.abc.automation.dtos.member;

import com.abc.automation.dtos.member.demographics.MemberDemographicsDTO;
import com.abc.automation.dtos.member.enrollments.MemberEnrollmentDTO;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by PPetarcheva on 4/17/2019.
 */
public class MemberDTO {
    private String caseRequestId;
    private Boolean levelOfCare;
    private MemberDemographicsDTO memberDemographics;
    private List<MemberEnrollmentDTO> memberEnrollments;

    public String getCaseRequestId() {
        return caseRequestId;
    }

    public void setCaseRequestId(String caseRequestId) {
        this.caseRequestId = caseRequestId;
    }

    public Boolean getLevelOfCare() {
        return levelOfCare;
    }

    public void setLevelOfCare(Boolean levelOfCare) {
        this.levelOfCare = levelOfCare;
    }

    public MemberDemographicsDTO getMemberDemographics() {
        return memberDemographics;
    }

    public void setMemberDemographics(MemberDemographicsDTO memberDemographics) {
        this.memberDemographics = memberDemographics;
    }

    public List<MemberEnrollmentDTO> getMemberEnrollments() {
        if (memberEnrollments != null) {
            return new ArrayList<>(memberEnrollments);
        } else {
            return null;
        }
    }

    public void setMemberEnrollments(List<MemberEnrollmentDTO> memberEnrollments) {
        if (memberEnrollments != null) {
            this.memberEnrollments = new ArrayList<>(memberEnrollments);
        } else {
            this.memberEnrollments = null;
        }
    }
}
