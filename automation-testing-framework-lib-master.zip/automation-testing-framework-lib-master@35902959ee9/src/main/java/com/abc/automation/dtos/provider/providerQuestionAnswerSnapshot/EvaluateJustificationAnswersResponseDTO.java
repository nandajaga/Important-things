package com.abc.automation.dtos.provider.providerQuestionAnswerSnapshot;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EvaluateJustificationAnswersResponseDTO {

    private Object outcome;

    public Object getOutcome() {
        return outcome;
    }

    public void setOutcome(Object outcome) {
        this.outcome = outcome;
    }


}
