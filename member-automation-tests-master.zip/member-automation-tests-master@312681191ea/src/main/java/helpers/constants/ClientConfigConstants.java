package helpers.constants;

import java.util.Arrays;
import java.util.List;

public class ClientConfigConstants {

    //isManualAddAllowed
    public static final String CLIENT_ID_40 = "40";
    public static final String CLIENT_ID_55 = "55";
    public static final String CLIENT_ID_85 = "85";
    public static final String CLIENT_ID_86 = "86";
    public static final String CLIENT_ID_183 = "183";
    public static final String CLIENT_ID_184 = "184";
    public static final String CLIENT_ID_185 = "185";
    public static final String CLIENT_ID_186 = "186";
    public static final String CLIENT_ID_187 = "187";
    public static final String CLIENT_ID_188 = "188";
    public static final String CLIENT_ID_189 = "189";
    public static final String CLIENT_ID_199 = "199";
    public static final String CLIENT_ID_202 = "202";
    public static final String CLIENT_ID_210 = "210";
    public static final String CLIENT_ID_212 = "212";
    public static final String CLIENT_ID_220 = "220";
    public static final String CLIENT_ID_218 = "218";
    public static final String CLIENT_ID_219 = "219";
    public static final String CLIENT_ID_160 = "160";

    public static final String MESSAGE_ELIGIBLE = "A three-way call with a Health Plan representative is required.";
    public static final String SCRIPT = "An AIM Number cannot be given for this member at this time. This does not mean that a Number is not required. Please contact the member's health plan using the number on the back of the member's card. If the representative verifies a Number is required from AIM, please ask then to initiate a three way conference call to AIM so we can get the correct information and start a case for the member.";
    public static final String MESSAGE_NOT_ELIGIBLE = "A three-way call with a Health Plan representative is required.";
    public static final String MESSAGE_ADD_NOT_ALLOWED = "Manual add is not allowed for this health plan.";
    public static final String SCRIPT_LABEL = "If a Health Plan representative is not on the line, read the script:";

    //isUpdateManualAddAllowed messages
    public static final String SCRIPT_MESSAGE = "Based on the information provided, this member is not part of our database. An Order number cannot be processed for this member at this time. Please contact the member's health plan if you have questions.";
    public static final String MANUAL_ADD_NOTE_MESSAGE = "If caller insists on additional information, inform them that an Order number is not required for this member.";
    public static final String SECOND_NOTE_MESSAGE = "If a Health Plan representative is on the phone, a member add can be completed.";
    public static final String SCRIPT_MESSAGE_220 = "Based on the search criteria you have entered, the member you are looking for is not part of our database. An Order request cannot be processed for this member at this time. Please modify your search criteria and try again, or contact the telephone number on the back of the member's ID card.";

    //allowed-eligibility-override-and-messaging
    public static final String ELIGIBILITY_SCRIPT_MESSAGE = "Rehabilitation services for this member for the service date entered do not require pre-authorization by AIM. Please note that benefit limits, if applicable, will still be applied.";
    public static final String NOTE_MESSAGE = "If a Healthplan representative is on the phone, the member eligibility override can be completed.";
    public static final String ELIGIBILITY_SCRIPT_MESSAGE_SOLUTION_OPTIONAL = "Services for this member for the service date entered do not require authorization by AIM. Please note that benefit limits, if applicable, will still be applied.\n\nNote: If a Healthplan representative is on the phone, the member eligibility override can be completed";
    public static final String NOTE_SOLUTION_OPTIONAL_CHANNEL_CODE_CC = "All enrollments for this member are termed for the service date entered";
    public static final String NOTE_SOLUTION_OPTIONAL_CHANNEL_CODE_P = "Services for this member for the service date entered do not require authorization by AIM. Please note that benefit limits, if applicable, will still be applied.";
    public static final String ELIGIBILITY_SCRIPT_MESSAGE_220 = "The selected member does not require an Order ID. Please contact the health plan using the number on the back of the member's ID card to determine if an Order ID number is needed.";
    public static final String ELIGIBILITY_SCRIPT_MESSAGE_SOLUTION_OPTIONAL_220 = "Based on the Date of Service entered, the selected member is currently not eligible for an Order ID. Please contact the health plan";
    public static final String invalidSolutionId = "736377";


    public static final String EMPLOYER_GROUP_NUMBER_CLID183 = "BCBSGA0340";
    public static final String EMPLOYER_GROUP_NUMBER_CLID85 = "00218646";
    public static final String CHANNEL_CODE_P = "P";
    public static final String RESTRICTION_HEALTH_PLAN = "Health Plan";
    public static final String RESTRICTION_VIP_ACCOUNT = "VIP Account";
    public static final String RESTRICTION_HOUSE_ACCOUNT = "House Account";
    public static final String RESTRICTION_INVALID_ACCOUNT = "House Account#$";
    public static final String DEPENDENT_RELATION_CODE_E = "E";
    public static final String DEPENDENT_RELATION_CODE_INVALID = "EV";
    public static final String INVALID_MEMBER_ID = "invalid!@#memberid";
    public static final int INVALID_CHANNEL_CODE = 210;
    public static final String EMPLOYER_GROUP_NUMBER_CLID_184 = "57ADQM";
    public static final String EMPLOYER_GROUP_NUMBER_CLID_185 = "1300BS";
    public static final String EMPLOYER_GROUP_NUMBER_CLID_186 = "1300BR";
    public static final String EMPLOYER_GROUP_NUMBER_CLID_187 = "340000000";
    public static final String EMPLOYER_GROUP_NUMBER_CL1ID_188 = "340000001";
    public static final String EMPLOYER_GROUP_NUMBER_CLID_189 = "340000002";
    public static final String EMPLOYER_GROUP_NUMBER_CLID_199 = "";
    public static final String EMPLOYER_GROUP_NUMBER_CLID_218 = "Y00164";
    public static final String EMPLOYER_GROUP_NUMBER_CLID_216 = "";
    public static final String EMPLOYER_GROUP_NUMBER_CLID_219 = "0FEPMT";
    public static final String EMPLOYER_GROUP_NUMBER_CLID_220 = "190482";
    public static final String EMPLOYER_GROUP_NUMBER_CLID_55 = "385000";
    public static final String EMPLOYER_GROUP_NUMBER_CLID_212 = "";
    public static final String EMPLOYER_GROUP_NUMBER_CLID_210 = "";
    public static final String EMPLOYER_GROUP_NUMBER_CLID_202 = "";
    public static final String EMPLOYER_GROUP_NUMBER_CLID_160 = "15443";


    public static final String MESSAGE_NOT_MATCHED_CLIENT = "Requested clientId: 86 does NOT matches the retrieved clientId: 85";
    public static final String MESSAGE_INVALID_RESTRICTED_ACCESS = "Validation failed. [Invalid Restricted Access Request!]";
    public static final String MESSAGE_CLIENT_SHOULD_PROVIDED = "Validation failed. [Please provide clientId]";
    public static final String MESSAGE_INVALID_FORMAT = "value not one of declared Enum instance names: [None, VIP Account, Health Plan, House Account]";
    public static final String MESSAGE_INVALID_UUID = "Validation failed. [Please provide valid UUID format of memberId]";
    public static final String MESSAGE_INVALID_DEPENDENT_RELATION_CODE = "Validation failed. [Please provide valid dependentRelationCode with one letter only]";
    public static final String PLATFORM_CONTEXT_MISSING_FIELD_CC = "PlatformContext channelCode cannot be null or empty";
    public static final String NONE = "None";
    public static final String RESTRICTED_ACCESS_INVALID_DEPENDENTCODE_ERROR_MSG = "Validation failed. [Please provide valid dependentRelationCode with one letter only]";
    public static final String RESTRICTED_ACCESS_INVALID_MEMBERID_ERROR_MSG = "Validation failed. [Please provide valid UUID format of memberId]";
    public static final String RESTRICTED_ACCESS_INVALID_CLIENT_ID_ERROR_MSG = "Validation failed. [Please provide clientId]";

    public static final String RESTRICTED_ACCESS_INVALID_RESTRCITIONTYPE_ERROR_MSG = "Invalid Restricted AccessRequest!";
    public static final String EMPLOYERGROUPCODE_220_1 = "491511";
    public static final String EMPLOYERGROUPCODE_220_2 = "0FEPNM";
    public static final String EMPLOYERGROUPCODE_220_3 = "000L01364";
    public static final String EMPLOYERGROUPCODE_220_4 = "113793";
    public static final String EMPLOYERGROUPCODE_220_5 = "000L00023";
    public static final String EMPLOYERGROUPCODE_220_6 = "190482";
    public static final String EMPLOYERGROUPCODE_220_7 = "111003";
    public static final String INVALID_MEMMBER_ID = "111003";
    public static final String NONE_VALUE = "None";
    public static final String UUID_220_SG_EMPLOYEE = "afd8b46a-f839-4d71-b76b-6eac20c84877";
    public static final String UUID_220_SG_FEP = "b4b2d53e-7f87-4cf4-94dd-728a2a6998e9";
    public static final String UUID_220_AIM_OFFSHORE_USER = "4a441a11-5011-4f61-81a6-4b00d65be407";
    public static final String UUID_220_AIM_INVALID_USER = "4a441a11-5011-4f61-81a6-4b00";
    public static final String UUID_220_AIM_NO_ENTITLEMENT = "c48fa62a-2e1a-4b2b-9fd6-072f52a98da2";

    //ageHardStopSteps
    public static final int MEMBER_AGE_0 = 0;
    public static final int MEMBER_AGE_2 = 2;
    public static final int MEMBER_AGE_3 = 3;
    public static final int MEMBER_AGE_6 = 6;
    public static final int MEMBER_AGE_10 = 10;
    public static final int MEMBER_AGE_4 = 4;
    public static final int MEMBER_AGE_7 = 7;
    public static final int MEMBER_AGE_11 = 11;
    public static final int MEMBER_AGE_MINUS_ONE = -1;
    public static final int MEMBER_AGE_151 = 151;
    public static final String MEMBER_MESSAGE_AGE_HARD_STOP = "An authorization from AIM is not required at this time due to the age of this member.";
    public static final String LINE_OF_BUSINESS = "COMMERCIAL";
    public static final String MEMBER_AGE_VALIDATION = "Validation failed. [member must be at most 150 years old]";
    public static final String MEMBER_AGE_VALIDATION_AT_LEAST_0 = "Validation failed. [member must be at least 0 years old]";

    //GetReferenceData
    public static final String SUBSCRIBER = "Subscriber";
    public static final String SPOUSE = "Spouse";
    public static final String CHILD = "Child";
    public static final String OTHER = "Other";
    public static final String ALLOWED_SOURCE_SYSTEMS_FACETS = "FACETS";
    public static final String ALLOWED_SOURCE_SYSTEMS_ISG = "ISG";
    public static final String ALLOWED_SOURCE_SYSTEMS_NASCO = "NASCO";
    public static final String ALLOWED_SOURCE_SYSTEMS_WGS = "WGS";

    //clientconfig
    public static final String DATE_OF_SERVICE = "2021-01-01";
    public static final String CASE_CREATION_DATE = "2021-12-31 00:00:00";
    public static final String CASE_CREATION_DATE_NEGETIVE_SCNARIO = "2000-12-31 00:00:00";
    public static final String DATE_OF_SERVICE1 = "1800-12-22";


    public static final String CLIENT_FUNDINGTYPECODE_PREM = "PREM";
    public static final String CLIENT_FUNDINGTYPECODE_MPP = "MPP";
    public static final String CLIENT_FUNDINGTYPECODE_COST = "COST";
    public static final String CLIENT_FUNDINGTYPECODE_FI = "FI";
    public static final String CLIENT_FUNDINGTYPECODE_ASO = "ASO";
    public static final String CLIENT_FUNDINGTYPECODE_BASO = "BASO";
    public static final String CLIENT_FUNDINGTYPECODE_SERV = "SERV";
    public static final String CLIENT_FUNDINGTYPECODE_PAR = "PAR";
    public static final String CLIENT_FUNDINGTYPECODE_ACAP = "ACAP";
    public static final String CLIENT_FUNDTYPE_FLF = "FLF";
    public static final String CLIENT_FUNDTYPE_ASO = "ASO";
    public static final String CLIENT_BUSINESS_MARKET_SEGMENT_LARGEGROUP = "Large Group";
    public static final String CLIENT_BUSINESS_MARKET_SEGMENT_MIDMARKET = "Mid-Market";
    public static final String CLIENT_BUSINESS_MARKET_SEGMENT_SMALLGROUP = "Small Group";
    public static final String CLIENT_BUSINESS_MARKET_SEGMENT_RETAIL = "Retail";
    public static final String CLIENT_BUSINESS_MARKET_SEGMENT_NMCC = "NMCC";
    public static final String CLIENT_220_NETWORK_CODE_BAV = "BAV";
    public static final String CLIENT_220_NETWORK_CODE_CNN = "CNN";
    public static final String CLIENT_220_NETWORK_CODE_EPN = "EPN";
    public static final String CLIENT_220_NETWORK_CODE_HMO = "HMO";
    public static final String CLIENT_220_NETWORK_CODE_HPN = "HPN";
    public static final String CLIENT_220_NETWORK_CODE_MCD = "MCD";
    public static final String CLIENT_220_NETWORK_CODE_NL1 = "NL1";
    public static final String CLIENT_220_NETWORK_CODE_NL2 = "NL2";
    public static final String CLIENT_220_NETWORK_CODE_PPO = "PPO";
    public static final String[] clientFundingTypeCode = {CLIENT_FUNDINGTYPECODE_PREM, CLIENT_FUNDINGTYPECODE_MPP, CLIENT_FUNDINGTYPECODE_COST, CLIENT_FUNDINGTYPECODE_FI, CLIENT_FUNDINGTYPECODE_ASO, CLIENT_FUNDINGTYPECODE_BASO, CLIENT_FUNDINGTYPECODE_SERV, CLIENT_FUNDINGTYPECODE_PAR, CLIENT_FUNDINGTYPECODE_ACAP};
    public static final String[] clientFundType = {CLIENT_FUNDTYPE_FLF, CLIENT_FUNDTYPE_FLF, CLIENT_FUNDTYPE_FLF, CLIENT_FUNDTYPE_FLF, CLIENT_FUNDTYPE_ASO, CLIENT_FUNDTYPE_ASO, CLIENT_FUNDTYPE_ASO, CLIENT_FUNDTYPE_ASO, CLIENT_FUNDTYPE_ASO};

    //IsMemberReviewProgramEligible
    public static final List<String> REVIEW_PROGRAMS_SOC = Arrays.asList("SOC");
    public static final List<String> MULTIPLE_REVIEW_PROGRAMS = Arrays.asList("SOC", "LOC");
    public static final String REVIEW_PROGRAM_CODE = "SOC";
    public static final String REVIEW_PROGRAM_CODE_LOC = "LOC";
    public static final String SITE_OF_CARE = "Site Of Care";
    public static final boolean IS_ELIGIBLE = true;
    public static final boolean IS_ELIGIBLE_FALSE = false;

}
