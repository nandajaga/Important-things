package com.abc.automation.factories.member;

import com.abc.automation.factories.member.demographics.MemberDemographicsDTOFactory;
import com.abc.automation.dtos.member.MemberDTO;
import com.abc.automation.dtos.member.demographics.EmailsDTO;
import com.abc.automation.dtos.member.demographics.PhonesDTO;
import com.abc.automation.factories.member.enrollments.MemberEnrollmentDTOFactory;
import com.abc.automation.helpers.constants.MemberConstants;
import org.apache.commons.lang3.RandomStringUtils;

import java.util.ArrayList;

/**
 * Created by PPetarcheva on 4/17/2019.
 */
public class MemberDTOFactory {

    public MemberDTO createMemberDTO(String clientId) {
        return createMemberDTO(clientId, null);
    }

    public MemberDTO createMemberDTO(String clientId, String alternateBenefitPlanCode) {

        return createMemberDTO(clientId, alternateBenefitPlanCode, null, null);
    }

    public MemberDTO createMemberDTO(String clientId, String alternateBenefitPlanCode, String erisaIndicator, String caseFundType) {
        String firstName = MemberConstants.FIRST_NAME_STARTS_WITH + RandomStringUtils.random(5, true, false);
        String lastName = MemberConstants.LAST_NAME_STARTS_WITH + RandomStringUtils.random(5, true, false);
        ArrayList<EmailsDTO> emails = new ArrayList<>();
        ArrayList<PhonesDTO> phones = new ArrayList<>();

        MemberDTO memberDTO = new MemberDTO();
        memberDTO.setCaseRequestId(MemberConstants.CASE_REQUEST_ID);
        memberDTO.setLevelOfCare(Boolean.TRUE);
        memberDTO.setMemberDemographics(new MemberDemographicsDTOFactory().createMemberDemographicsDTO(clientId, firstName, lastName, emails, phones));
        memberDTO.setMemberEnrollments(new MemberEnrollmentDTOFactory().createMemberEnrollmentDTO(clientId, alternateBenefitPlanCode, erisaIndicator, caseFundType));

        return memberDTO;
    }
}
