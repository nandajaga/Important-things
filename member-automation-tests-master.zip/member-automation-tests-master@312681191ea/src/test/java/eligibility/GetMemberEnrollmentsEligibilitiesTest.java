package eligibility;

import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.datamanager.MemberResponseDTO;
import dtos.eligibility.MemberEligibilityDTO;
import dtos.enrollments.SolutionDTO;
import helpers.dataproviders.DataProviders;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.datamanager.MemberDataManagerSteps;
import steps.eligibility.MemberEnrollmentEligibilitySteps;

import java.util.ArrayList;

import static helpers.constants.BasePathConstants.BASE_PATH_GET_ENROLLMENT_ELIGIBILITY;
import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_85;
import static helpers.constants.ConstantsClientIds.*;
import static org.apache.http.HttpStatus.SC_NOT_FOUND;


/**
 * Created by RKondakova on 5/8/2019.
 */

public class GetMemberEnrollmentsEligibilitiesTest extends GetTests {

    private MemberDataManagerSteps memberDataManagerSteps;
    private MemberEnrollmentEligibilitySteps memberEnrollmentEligibilitySteps;

    private static final String ELIGIBLE_MESSAGE = "The enrollments are eligible.";
    private static final String NOT_ELIGIBLE_MESSAGE = "No solutions were found!";
    private static final String NOT_IN_RANGE_MESSAGE = "No enrollments with the proper solution id were found in the enrollment range!";
    private static final String NO_ENROLLMENT_MESSAGE = "No enrollments were found for the given date.";
    private static final String FUTURE_DATE = "2021-01-01";
    private String CLIENT_MEMBER_ID;

    @BeforeMethod
    public void initMethod() {
        CLIENT_MEMBER_ID = RandomStringUtils.randomNumeric(10) + RandomStringUtils.randomAlphabetic(5).toUpperCase();
    }

    @BeforeClass
    public void init() {
        basePath = BASE_PATH_GET_ENROLLMENT_ELIGIBILITY;

        pathParamsMap.clear();
        pathParamsMap.put(CLIENT_ID, CLIENT_ID_85);
        pathParamsMap.put(MEMBER_ID, MEMBER_ID_REAL);

        queryParamsMap.clear();
        queryParamsMap.put(COMPARE_DATE_PATH_PARM, COMPARE_DATE);
        queryParamsMap.put(SOLUTION_ID, SOLUTION_ID_1);
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test(dataProvider = "solutionIdOneAndEmptyForEligibilityCheck", dataProviderClass = DataProviders.class)
    public void whenGetAndValidClientId85AndMemberIdAndSolutionIdSentThenServiceReturnsEnrollmentsEligibility(String solutionId) {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentEligibilitySteps = new MemberEnrollmentEligibilitySteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_85, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEligibilityDTO memberEligibilityDTO = memberEnrollmentEligibilitySteps.getMemberEligibility(CLIENT_ID_85, memberId, COMPARE_DATE, solutionId);

        softly.then(memberEligibilityDTO.getStatus()).isTrue();
        softly.then(memberEligibilityDTO.getMessage()).contains(ELIGIBLE_MESSAGE);
        softly.then(memberEligibilityDTO.getMemberEnrollmentList().get(0).getClientId()).contains(CLIENT_ID_85);
        softly.then(memberEligibilityDTO.getMemberEnrollmentList().get(0).getHealthPlan()).contains(HEALTHPLAN_AUTHEM_CR);

        ArrayList<SolutionDTO> solutions = memberEligibilityDTO.getMemberEnrollmentList().get(0).getSolutions();

        for (SolutionDTO solution : solutions) {
            if (solution.isLevelOfCare() && solution.getProgramType().equals(SOLUTION_PROGRAM_TYPE)) {
                softly.then(solution.getSolutionId()).isIn(SOLUTION_ID_1, SOLUTION_ID_2);
            }
        }

        softly.assertAll();
    }

    @Test(dataProvider = "solutionIdOneAndEmptyForEligibilityCheck", dataProviderClass = DataProviders.class)
    public void whenGetAndValidClientId186AndMemberIdAndSolutionIdSentThenServiceReturnsEnrollmentsEligibility(String solutionId) {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentEligibilitySteps = new MemberEnrollmentEligibilitySteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_186, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEligibilityDTO memberEligibilityDTO = memberEnrollmentEligibilitySteps.getMemberEligibility(CLIENT_ID_186, memberId, COMPARE_DATE, solutionId);

        softly.then(memberEligibilityDTO.getStatus()).isTrue();
        softly.then(memberEligibilityDTO.getMessage()).contains(ELIGIBLE_MESSAGE);
        softly.then(memberEligibilityDTO.getMemberEnrollmentList().get(0).getClientId()).contains(CLIENT_ID_186);
        softly.then(memberEligibilityDTO.getMemberEnrollmentList().get(0).getHealthPlan()).contains(HEALTHPLAN_AUTHEM_BC);

        ArrayList<SolutionDTO> solutions = memberEligibilityDTO.getMemberEnrollmentList().get(0).getSolutions();
        for (SolutionDTO solution : solutions) {
            if (solution.isLevelOfCare() && solution.getProgramType().equals(SOLUTION_PROGRAM_TYPE)) {
                softly.then(solution.getSolutionId()).isIn(SOLUTION_ID_1, SOLUTION_ID_2);
            }
        }
        softly.assertAll();
    }

    @Test(dataProvider = "solutionIdOneAndEmptyForEligibilityCheck", dataProviderClass = DataProviders.class)
    public void whenGetAndValidClientId210FLAndMemberIdAndSolutionIdSentThenServiceReturnsEnrollmentsEligibility(String solutionId) {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentEligibilitySteps = new MemberEnrollmentEligibilitySteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_210, ISSUANCE_STATE_FL, SS_WGS, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();
        softly.then(memberId).isNotEmpty().isNotBlank().isNotNull();

        MemberEligibilityDTO memberEligibilityDTO = memberEnrollmentEligibilitySteps.getMemberEligibility(CLIENT_ID_210, memberId, COMPARE_DATE, solutionId);

        softly.then(memberEligibilityDTO.getStatus()).isTrue();
        softly.then(memberEligibilityDTO.getMessage()).contains(ELIGIBLE_MESSAGE);
        softly.then(memberEligibilityDTO.getMemberEnrollmentList().get(0).getClientId()).contains(CLIENT_ID_210);
        softly.then(memberEligibilityDTO.getMemberEnrollmentList().get(0).getHealthPlan()).contains(HEALTHPLAN_AMERIGROUP_FL);

        ArrayList<SolutionDTO> solutions = memberEligibilityDTO.getMemberEnrollmentList().get(0).getSolutions();

        for (SolutionDTO solution : solutions) {
            if (solution.isLevelOfCare() && solution.getProgramType().equals(SOLUTION_PROGRAM_TYPE)) {
                softly.then(solution.getSolutionId()).isIn(SOLUTION_ID_1);
            }
        }

        softly.assertAll();
    }

    /**
     * https://jira.aimspecialtyhealth.com/browse/OSPP-4733
     * solutionId is optional
     * Parameters= memberId,compareDate,clientId
     * clientId=85
     *
     * @author = Rishibha Kohli
     */
    @Test
    public void whenGetAndValidClientId85AndMemberIdAndSolutionIdIsOptionalSentThenServiceReturnsEnrollmentsEligibility() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentEligibilitySteps = new MemberEnrollmentEligibilitySteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_85, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEligibilityDTO memberEligibilityDTO = memberEnrollmentEligibilitySteps.getMemberEligibility(CLIENT_ID_85, memberId, COMPARE_DATE);

        softly.then(memberEligibilityDTO.getStatus()).isTrue();
        softly.then(memberEligibilityDTO.getMessage()).contains(ELIGIBLE_MESSAGE);
        softly.then(memberEligibilityDTO.getMemberEnrollmentList().get(0).getClientId()).contains(CLIENT_ID_85);
        softly.then(memberEligibilityDTO.getMemberEnrollmentList().get(0).getHealthPlan()).contains(HEALTHPLAN_AUTHEM_CR);

        ArrayList<SolutionDTO> solutions = memberEligibilityDTO.getMemberEnrollmentList().get(0).getSolutions();

        for (SolutionDTO solution : solutions) {
            if (solution.isLevelOfCare() && solution.getProgramType().equals(SOLUTION_PROGRAM_TYPE)) {
                softly.then(solution.getSolutionId()).isIn(SOLUTION_ID_1, SOLUTION_ID_2);
            }
        }

        softly.assertAll();
    }

    /**
     * https://jira.aimspecialtyhealth.com/browse/OSPP-4733
     * solutionId is optional
     * Parameters= memberId,compareDate,clientId
     * clientId=186
     *
     * @author = Rishibha Kohli
     */
    @Test
    public void whenGetAndValidClientId186AndMemberIdAndSolutionIdIsOptionalSentThenServiceReturnsEnrollmentsEligibility() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentEligibilitySteps = new MemberEnrollmentEligibilitySteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_186, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEligibilityDTO memberEligibilityDTO = memberEnrollmentEligibilitySteps.getMemberEligibility(CLIENT_ID_186, memberId, COMPARE_DATE);

        softly.then(memberEligibilityDTO.getStatus()).isTrue();
        softly.then(memberEligibilityDTO.getMessage()).contains(ELIGIBLE_MESSAGE);
        softly.then(memberEligibilityDTO.getMemberEnrollmentList().get(0).getClientId()).contains(CLIENT_ID_186);
        softly.then(memberEligibilityDTO.getMemberEnrollmentList().get(0).getHealthPlan()).contains(HEALTHPLAN_AUTHEM_BC);

        ArrayList<SolutionDTO> solutions = memberEligibilityDTO.getMemberEnrollmentList().get(0).getSolutions();
        for (SolutionDTO solution : solutions) {
            if (solution.isLevelOfCare() && solution.getProgramType().equals(SOLUTION_PROGRAM_TYPE)) {
                softly.then(solution.getSolutionId()).isIn(SOLUTION_ID_1, SOLUTION_ID_2);
            }
        }
        softly.assertAll();
    }

    /**
     * https://jira.aimspecialtyhealth.com/browse/OSPP-4733
     * solutionId is optional
     * Parameters= memberId,compareDate,clientId
     * clientId=210
     *
     * @author = Rishibha Kohli
     */
    @Test
    public void whenGetAndValidClientId210FLAndMemberIdAndSolutionIdIsOptionalSentThenServiceReturnsEnrollmentsEligibility() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentEligibilitySteps = new MemberEnrollmentEligibilitySteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_210, ISSUANCE_STATE_FL, SS_WGS, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();
        softly.then(memberId).isNotEmpty().isNotBlank().isNotNull();

        MemberEligibilityDTO memberEligibilityDTO = memberEnrollmentEligibilitySteps.getMemberEligibility(CLIENT_ID_210, memberId, COMPARE_DATE);

        softly.then(memberEligibilityDTO.getStatus()).isTrue();
        softly.then(memberEligibilityDTO.getMessage()).contains(ELIGIBLE_MESSAGE);
        softly.then(memberEligibilityDTO.getMemberEnrollmentList().get(0).getClientId()).contains(CLIENT_ID_210);
        softly.then(memberEligibilityDTO.getMemberEnrollmentList().get(0).getHealthPlan()).contains(HEALTHPLAN_AMERIGROUP_FL);

        ArrayList<SolutionDTO> solutions = memberEligibilityDTO.getMemberEnrollmentList().get(0).getSolutions();

        for (SolutionDTO solution : solutions) {
            if (solution.isLevelOfCare() && solution.getProgramType().equals(SOLUTION_PROGRAM_TYPE)) {
                softly.then(solution.getSolutionId()).isIn(SOLUTION_ID_1);
            }
        }

        softly.assertAll();
    }
    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-404---------------------------------------------

    @Test(dataProvider = "invalidSolutionIdForEligibility", dataProviderClass = DataProviders.class)
    public void whenGetAndValidClientId85AndMemberIdAndInvalidSolutionIdSentThenServiceReturnsEnrollmentsEligibilityNotFound(String solutionId) {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentEligibilitySteps = new MemberEnrollmentEligibilitySteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_85, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEligibilityDTO memberEligibilityDTO = memberEnrollmentEligibilitySteps.getMemberEligibility(CLIENT_ID_85, memberId, COMPARE_DATE, solutionId);

        softly.then(memberEligibilityDTO.getStatus()).isFalse();
        softly.then(memberEligibilityDTO.getMessage()).contains(NOT_ELIGIBLE_MESSAGE);

        softly.assertAll();
    }

    @Test
    public void whenGetAndValidClientId85AndInvalidMemberIdAndSolutionIdSentThenServiceReturnsError() {
        memberEnrollmentEligibilitySteps = new MemberEnrollmentEligibilitySteps(platformContextHeader, headers);

        ErrorDTO error = memberEnrollmentEligibilitySteps.getMemberErrors(CLIENT_ID_85, MEMBER_ID_TEST, COMPARE_DATE, SOLUTION_ID_1);

        softly.then(error.getCode()).isEqualTo(SC_NOT_FOUND);
        softly.then(error.getMessage()).contains(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }

    //Todo this test is legal, but due to BUG https://jira.aimspecialtyhealth.com/browse/NCP-20854 it will fail. Uncomment once the bug is fixed.
//    @Test
    public void whenGetAndInvalidClientIdAndMemberIdAndSolutionIdSentThenServiceReturnsEnrollmentsEligibilityNotFound() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentEligibilitySteps = new MemberEnrollmentEligibilitySteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_85, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();
        softly.then(memberId).isNotEmpty().isNotBlank().isNotNull();

        MemberEligibilityDTO memberEligibilityDTO = memberEnrollmentEligibilitySteps.getMemberEligibility(CLIENT_ID_TEST, memberId, COMPARE_DATE, SOLUTION_ID_1);

        softly.then(memberEligibilityDTO.getStatus()).isFalse();
        softly.then(memberEligibilityDTO.getMessage()).contains(NOT_ELIGIBLE_MESSAGE);

        softly.assertAll();
    }

    @Test
    public void whenGetAndValidClientId186AndMemberIdSentThenServiceReturnsEnrollmentsAndInvalidEnrollmentsId() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentEligibilitySteps = new MemberEnrollmentEligibilitySteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_85, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();
        softly.then(memberId).isNotEmpty().isNotBlank().isNotNull();

        MemberEligibilityDTO memberEligibilityDTO = memberEnrollmentEligibilitySteps.getMemberEligibility(CLIENT_ID_85, memberId, COMPARE_DATE_TEST, SOLUTION_ID_1);

        softly.then(memberEligibilityDTO.getStatus()).isFalse();
        softly.then(memberEligibilityDTO.getMessage()).contains(NOT_IN_RANGE_MESSAGE);

        softly.assertAll();
    }

    @Test(dataProvider = "contextModeValue", dataProviderClass = DataProviders.class)
    public void whenGetValidClientIdMemberIdAndSolutionIdSentWithTestContextModeThenServiceReturnsEnrollmentsEligibility(String contextMode) {
        PlatformContextUtils platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeContextMode(platformContextHeader, contextMode);

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentEligibilitySteps = new MemberEnrollmentEligibilitySteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_85, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEligibilityDTO memberEligibilityDTO = memberEnrollmentEligibilitySteps.getMemberEligibility(CLIENT_ID_85, memberId, COMPARE_DATE, SOLUTION_ID_1);

        softly.then(memberEligibilityDTO.getStatus()).isTrue();
        softly.then(memberEligibilityDTO.getMessage()).contains(ELIGIBLE_MESSAGE);
        softly.then(memberEligibilityDTO.getMemberEnrollmentList().get(0).getClientId()).contains(CLIENT_ID_85);
        softly.assertAll();
    }

    /**
     * https://jira.aimspecialtyhealth.com/browse/OSPP-4733
     * solutionId is optional
     * Parameters= memberId,compareDate,clientId
     * clientId=85
     * compareDate=null
     * memberId=null
     *
     * @author = Rishibha Kohli
     */
    @Test
    public void whenGetAndValidClientId85AndNullMemberIdAndCompareDateSentThenServiceReturnsError() {
        memberEnrollmentEligibilitySteps = new MemberEnrollmentEligibilitySteps(platformContextHeader, headers);

        ErrorDTO error = memberEnrollmentEligibilitySteps.getMemberErrors(CLIENT_ID_85, null, null);

        softly.then(error.getCode()).isEqualTo(SC_NOT_FOUND);
        softly.then(error.getMessage()).contains(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }

    /**
     * https://jira.aimspecialtyhealth.com/browse/OSPP-4733
     * solutionId is optional
     * Parameters= memberId,compareDate,clientId
     * clientId=186
     * compareDate=future date
     *
     * @author = Rishibha Kohli
     */
    @Test
    public void whenGetAndValidClientId85AndMemberIdAndNullCompareDateSentThenServiceReturnsError() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentEligibilitySteps = new MemberEnrollmentEligibilitySteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_186, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();
        softly.then(memberId).isNotEmpty().isNotBlank().isNotNull();

        MemberEligibilityDTO memberEligibilityDTO = memberEnrollmentEligibilitySteps.getMemberEligibility(CLIENT_ID_186, memberId, FUTURE_DATE);


        softly.then(memberEligibilityDTO.getStatus()).isFalse();
        softly.then(memberEligibilityDTO.getMessage()).contains(NO_ENROLLMENT_MESSAGE);

        softly.assertAll();
    }


}
