package com.abc.automation.dtos.provider.providerQuestionAnswerSnapshot;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CreateJustificationQuestionsSnapshotDTO {

    private String configurationId;
    private List<QuestionAnswerDTO> questionsAndAnswers;

    public String getConfigurationId() {
        return configurationId;
    }

    public void setConfigurationId(String configurationId) {
        this.configurationId = configurationId;
    }

    public List<QuestionAnswerDTO> getQuestionsAndAnswers() {
        return questionsAndAnswers;
    }

    public void setQuestionsAndAnswers(List<QuestionAnswerDTO> questionsAndAnswers) {
        this.questionsAndAnswers = questionsAndAnswers;
    }
}
