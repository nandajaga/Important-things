package steps.clientconfig;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.clientconfig.DisplayFieldsDTO;
import helpers.constants.BasePathConstants;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.*;

/**
 * Created by RKondakova on 7/12/2019.
 */
public class ClientDisplayFieldsSteps {
    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public ClientDisplayFieldsSteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BasePathConstants.BASE_PATH_GET_V2_CLIENT_DISPLAY_FIELDS);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    //for positive tests
    public List<DisplayFieldsDTO> getClientDisplayFieldsRequestReturningList(String clientId, String screen) {

        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);
        pathParamsMap.put("screen", screen);

        requestSpecification.addPathParams(pathParamsMap);

        Response response = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());
        List<DisplayFieldsDTO> displayFieldsDTOS = Arrays.asList(response.getBody().as(DisplayFieldsDTO[].class));
        response.then().statusCode(HttpStatus.SC_OK);

        return displayFieldsDTOS;
    }

    public List<Object> getClientDisplayFieldsRequestReturningListObjects(String clientId, String screen) {

        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);
        pathParamsMap.put("screen", screen);

        requestSpecification.addPathParams(pathParamsMap);

        Response response = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());
        response.then().statusCode(HttpStatus.SC_OK);
        List<Object> objectList = Arrays.asList(response.getBody().as(Object[].class));

        return objectList;
    }

    //for negative tests
    public ErrorDTO getClinetDisplayFieldsRequestErrorDTO(String clientId, String screen) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);
        pathParamsMap.put("screen", screen);

        requestSpecification.addPathParams(pathParamsMap);
        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorDTO.class);
    }
}
