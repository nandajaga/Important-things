package clientconfig;

import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.ErrorSpringDTO;
import dtos.clientconfig.ClientEligibilitySystemDTO;
import helpers.constants.ClientConfigConstants;
import helpers.dataproviders.DataProviders;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import steps.clientconfig.ClientEligibilitySteps;

import static helpers.constants.BasePathConstants.BASE_PATH_GET_CLIENT_ELIGIBILITY;
import static helpers.constants.Constants.*;
import static helpers.constants.ErrorMessagesForMemberEndpointsConstants.ERR_MSG_LIST_PARAMETER_NOT_PRESENT;
import static helpers.constants.ErrorMessagesForMemberEndpointsConstants.ERR_MSG_LIST_POVIDE_VALID_FORMAT_CLIENT_ID;
import static org.apache.http.HttpStatus.SC_BAD_REQUEST;

/**
 * Created by RKondakova on 7/5/2019.
 */
public class GetClientEligibilityTest extends GetTests {

    private ClientEligibilitySteps clientEligibilitySteps;

    @BeforeClass
    public void init() {
        basePath = BASE_PATH_GET_CLIENT_ELIGIBILITY;
        pathParamsMap.put(CLIENT_ID_PARAM, ClientConfigConstants.CLIENT_ID_85);
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test(dataProvider = "clientId-210-212", dataProviderClass = DataProviders.class)
    public void whenGetClientEligibilitySystemAndPutValidPathClientId210And212ThenReturnStatus200(String clientId) {
        clientEligibilitySteps = new ClientEligibilitySteps(platformContextHeader, headers);
        ClientEligibilitySystemDTO clientEligibilitySystemDTO = clientEligibilitySteps.getClientEligibility(clientId);

        softly.then(clientEligibilitySystemDTO.get(0)).contains(AVAILITY_MEMBER);
        softly.assertAll();
    }

    @Test(dataProvider = "clientId-85-186-187", dataProviderClass = DataProviders.class)
    public void whenGetClientEligibilitySystemAndPutValidPathClientId85And186And187ThenReturnStatus200(String clientId) {
        clientEligibilitySteps = new ClientEligibilitySteps(platformContextHeader, headers);
        ClientEligibilitySystemDTO clientEligibilitySystemDTO = clientEligibilitySteps.getClientEligibility(clientId);

        softly.then(clientEligibilitySystemDTO.get(0)).contains(NAVINET_MEMBER);
        softly.then(clientEligibilitySystemDTO.get(1)).contains(WEBDENIS_MEMBER);
        softly.then(clientEligibilitySystemDTO.get(2)).contains(BLUUE_MEMBER);
        softly.then(clientEligibilitySystemDTO.get(3)).contains(AVAILITY_MEMBER);
        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-400---------------------------------------------

    @Test(dataProvider = "clientIdNegative", dataProviderClass = DataProviders.class)
    public void whenGetClientEligibilitySystemAndPutInvalidPathClientIdThenReturnStatus400(String clientId) {
        clientEligibilitySteps = new ClientEligibilitySteps(platformContextHeader, headers);
        ErrorDTO error = clientEligibilitySteps.getMemberEligibilityResponseNegativeErrorWithoutCheckForNull(clientId);

        softly.then(error.getMessage()).isEqualTo(ERR_MSG_LIST_POVIDE_VALID_FORMAT_CLIENT_ID);
        softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.assertAll();
    }

    @Test(dataProvider = "emptyStringAndDot", dataProviderClass = DataProviders.class)
    public void whenGetClientEligibilitySystemAndPutEmptyStringWithNoSpacesThenReturnStatus400(String clientId) {
        clientEligibilitySteps = new ClientEligibilitySteps(platformContextHeader, headers);
        ErrorSpringDTO error = clientEligibilitySteps.getMemberEligibilityResponseNegativeErrorSpring(clientId);

        softly.then(error.getMessage()).isEqualTo(ERR_MSG_LIST_PARAMETER_NOT_PRESENT);
        softly.then(error.getStatus()).isEqualTo(SC_BAD_REQUEST);
        softly.assertAll();
    }
}
