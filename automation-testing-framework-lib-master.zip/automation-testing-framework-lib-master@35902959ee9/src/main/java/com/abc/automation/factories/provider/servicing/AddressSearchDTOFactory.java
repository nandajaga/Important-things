package com.abc.automation.factories.provider.servicing;

import com.abc.automation.dtos.provider.ordering.AddressSearchDTO;
import com.abc.automation.helpers.constants.ProviderConstants;
import org.apache.commons.lang3.RandomStringUtils;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
public class AddressSearchDTOFactory {

    public AddressSearchDTO setAddressDTO() {
        AddressSearchDTO payload = new AddressSearchDTO();
        payload.setLine1("AutoAddress1-" + RandomStringUtils.random(10, true, true));
        payload.setLine2(ProviderConstants.ADDRESS_LINE_2);
        payload.setCity(ProviderConstants.CITY_NAME);
        payload.setStateCode(ProviderConstants.STATE_CODE);
        payload.setZipCode(ProviderConstants.ZIP_CODE);

        return payload;
    }
}
