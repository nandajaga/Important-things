package com.abc.automation.dtos.provider.snapshot;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
public class CreateOrderingProviderSnapshotDTO {

    private String clientPhysicianId;
    private boolean isServicingProvider;
    private String ngProviderId;
    private Integer providerClientId;
    private Boolean sanctionLookupCompletedFlag;
    private String sanctionReviewAnswerSnapshotId;
    private Boolean isSanctioned;

    public String getNgProviderId() {
        return ngProviderId;
    }

    public void setNgProviderId(String ngProviderId) {
        this.ngProviderId = ngProviderId;
    }

    public Integer getProviderClientId() {
        return providerClientId;
    }

    public void setProviderClientId(Integer providerClientId) {
        this.providerClientId = providerClientId;
    }

    public boolean getIsServicingProvider() {
        return isServicingProvider;
    }

    public void setIsServicingProvider(boolean servicingProvider) {
        isServicingProvider = servicingProvider;
    }

    public String getClientPhysicianId() {
        return clientPhysicianId;
    }

    public void setClientPhysicianId(String clientPhysicianId) {
        this.clientPhysicianId = clientPhysicianId;
    }

    public Boolean getSanctionLookupCompletedFlag() {
        return sanctionLookupCompletedFlag;
    }

    public void setSanctionLookupCompletedFlag(Boolean sanctionLookupCompletedFlag) {
        this.sanctionLookupCompletedFlag = sanctionLookupCompletedFlag;
    }

    public String getSanctionReviewAnswerSnapshotId() {
        return sanctionReviewAnswerSnapshotId;
    }

    public void setSanctionReviewAnswerSnapshotId(String sanctionReviewAnswerSnapshotId) {
        this.sanctionReviewAnswerSnapshotId = sanctionReviewAnswerSnapshotId;
    }

    public Boolean getIsSanctioned() {
        return isSanctioned;
    }

    public void setIsSanctioned(Boolean sanctioned) {
        isSanctioned = sanctioned;
    }
}
