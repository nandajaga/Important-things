package dtos.referencedata;

import java.util.List;

/**
 * Created by RKondakova on 7/22/2019.
 */
public class ReferenceDataResponseDTO {

    private String referenceType;
    private List<ReferenceDataDTO> references;

    public String getReferenceType() {
        return referenceType;
    }

    public void setReferenceType(String referenceType) {
        this.referenceType = referenceType;
    }

    public List<ReferenceDataDTO> getReferences() {
        return references;
    }

    public void setReferences(List<ReferenceDataDTO> references) {
        this.references = references;
    }
}
