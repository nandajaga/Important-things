package factories.demographics;

import dtos.demographics.AddressesDTO;
import java.util.ArrayList;
import static helpers.constants.Constants.*;

public class AddressesDTOFactory {

    public ArrayList<AddressesDTO> createAddressesDTO (){
        ArrayList<AddressesDTO> list = new ArrayList<>();
        AddressesDTO address = new AddressesDTO();
        address.setAddress1(ADDRESS_1);
        address.setCity(CITY_NAME);
        address.setState(STATE_CODE);
        address.setZipCode(ZIP_CODE);
        address.setZipExtension(ZIP_EXTENSION);

        list.add(address);

        return list;
    }
}
//AREA 51

