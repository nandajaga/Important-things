package steps.sharedreferencedata;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.sharedreferencedata.SharedReferenceDataResponseDTO;
import factories.sharedreferencedata.SharedReferenceDataRequestDTOFactory;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

import static helpers.constants.BasePathConstants.BASE_PATH_SHARED_REFERENCE_DATA;


/**
 * Created by RKohli on 15/09/2020.
 */
public class SharedReferenceDataSearchSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public SharedReferenceDataSearchSteps(String platformContext, Headers headers) {

        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BASE_PATH_SHARED_REFERENCE_DATA);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);

    }

    public SharedReferenceDataResponseDTO[] postSharedReferenceDataForPositiveTests(HashMap searchCriteria, String effectiveDate) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("referenceType", "clientProductCode");

        requestSpecification.addPathParams(pathParamsMap);
        Object payLoad = new SharedReferenceDataRequestDTOFactory().createSharedReferneceDataDTO(searchCriteria, effectiveDate);
        requestSpecification.addBodyToRequest(payLoad);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_OK);
        pathParamsMap.clear();

        return result.as(SharedReferenceDataResponseDTO[].class);
    }


}
