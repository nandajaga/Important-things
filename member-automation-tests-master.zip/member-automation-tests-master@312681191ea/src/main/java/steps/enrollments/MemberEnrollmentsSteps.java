package steps.enrollments;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.enrollments.MemberEnrollmentsDTO;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

import static helpers.constants.BasePathConstants.BASE_PATH_ENROLLMENTS;

/**
 * Created by RKondakova on 4/11/2019.
 */
public class MemberEnrollmentsSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;


    public MemberEnrollmentsSteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BASE_PATH_ENROLLMENTS);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    public MemberEnrollmentsDTO getMemberEnrollments(String clientId, String memberId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);
        pathParamsMap.put("memberId", memberId);

        requestSpecification.addPathParams(pathParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_OK);

        return result.as(MemberEnrollmentsDTO.class);
    }

    public ErrorDTO getMemberEnrollmentsErrors(String clientId, String memberId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);
        pathParamsMap.put("memberId", memberId);

        requestSpecification.addPathParams(pathParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorDTO.class);
    }

}
