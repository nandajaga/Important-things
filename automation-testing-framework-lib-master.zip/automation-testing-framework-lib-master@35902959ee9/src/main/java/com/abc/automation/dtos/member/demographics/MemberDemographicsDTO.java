package com.abc.automation.dtos.member.demographics;

import com.abc.automation.helpers.constants.Constants;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by PPetarcheva on 4/17/2019.
 */
public class MemberDemographicsDTO {
    @JsonIgnore
    private String id;
    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = Constants.TIMEZONE_DATE_FORMAT
    )
    @JsonIgnore
    private Date createdOn;
    private List<AdditionalMemberIdDTO> additionalMemberIds;
    private List<AddressesDTO> addresses;
    private String clientDependentRelationCode;
    private String clientId;
    @JsonIgnore
    private String clientMemberCode;
    private String clientMemberId;
    private ClientSpecificDemographicsDTO clientSpecificDemographics;
    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = Constants.SAMPLE_DATE_FORMAT
    )
    private Date dateOfBirth;
    private String dependentCode;
    @JsonIgnore
    private String dependentRelationCode;
    @JsonIgnore
    private String dependentRelationName;
    @JsonIgnore
    private String doNotCallRecords;
    private List<EmailsDTO> emails;
    private String firstName;
    private String gender;
    @JsonIgnore
    private String healthPlan;
    private String lastName;
    private String legacyMemberId;
    private Boolean manuallyCreated;
    private Boolean manuallyUpdated;
    private String memberPrefix;
    private List<PhonesDTO> phones;
    @JsonIgnore
    private List<RestrictedAccessesDTO> restrictedAccesses;
    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = Constants.TIMEZONE_DATE_FORMAT

    )
    @JsonIgnore
    private Date updateDate;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getCreatedOn() {
        if (createdOn != null) {
            return new Date(createdOn.getTime());
        } else {
            return null;
        }
    }

    public void setCreatedOn(Date createdOn) {
        if (createdOn != null) {
            this.createdOn = new Date(createdOn.getTime());
        } else {
            this.createdOn = null;
        }
    }

    public List<AdditionalMemberIdDTO> getAdditionalMemberIds() {
        if (additionalMemberIds != null) {
            return new ArrayList<>(additionalMemberIds);
        } else {
            return null;
        }
    }

    public void setAdditionalMemberIds(List<AdditionalMemberIdDTO> additionalMemberIds) {
        if (additionalMemberIds != null) {
            this.additionalMemberIds = new ArrayList<>(additionalMemberIds);
        } else {
            this.additionalMemberIds = null;
        }
    }

    public List<AddressesDTO> getAddresses() {
        if (addresses != null) {
            return new ArrayList<>(addresses);
        } else {
            return null;
        }
    }

    public void setAddresses(List<AddressesDTO> addresses) {
        if (addresses != null) {
            this.addresses = new ArrayList<>(addresses);
        } else {
            this.addresses = null;
        }
    }

    public String getClientDependentRelationCode() {
        return clientDependentRelationCode;
    }

    public void setClientDependentRelationCode(String clientDependentRelationCode) {
        this.clientDependentRelationCode = clientDependentRelationCode;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientMemberCode() {
        return clientMemberCode;
    }

    public void setClientMemberCode(String clientMemberCode) {
        this.clientMemberCode = clientMemberCode;
    }

    public String getClientMemberId() {
        return clientMemberId;
    }

    public void setClientMemberId(String clientMemberId) {
        this.clientMemberId = clientMemberId;
    }

    public ClientSpecificDemographicsDTO getClientSpecificDemographics() {
        return clientSpecificDemographics;
    }

    public void setClientSpecificDemographics(ClientSpecificDemographicsDTO clientSpecificDemographics) {
        this.clientSpecificDemographics = clientSpecificDemographics;
    }

    public Date getDateOfBirth() {
        if (dateOfBirth != null) {
            return new Date(dateOfBirth.getTime());
        } else {
            return null;
        }
    }

    public void setDateOfBirth(Date dateOfBirth) {
        if (dateOfBirth != null) {
            this.dateOfBirth = new Date(dateOfBirth.getTime());
        } else {
            this.dateOfBirth = null;
        }
    }

    public String getDependentCode() {
        return dependentCode;
    }

    public void setDependentCode(String dependentCode) {
        this.dependentCode = dependentCode;
    }

    public String getDependentRelationCode() {
        return dependentRelationCode;
    }

    public void setDependentRelationCode(String dependentRelationCode) {
        this.dependentRelationCode = dependentRelationCode;
    }

    public String getDependentRelationName() {
        return dependentRelationName;
    }

    public void setDependentRelationName(String dependentRelationName) {
        this.dependentRelationName = dependentRelationName;
    }

    public String getDoNotCallRecords() {
        return doNotCallRecords;
    }

    public void setDoNotCallRecords(String doNotCallRecords) {
        this.doNotCallRecords = doNotCallRecords;
    }

    public List<EmailsDTO> getEmails() {
        if (emails != null) {
            return new ArrayList<>(emails);
        } else {
            return null;
        }
    }

    public void setEmails(List<EmailsDTO> emails) {
        if (emails != null) {
            this.emails = new ArrayList<>(emails);
        } else {
            this.emails = null;
        }
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getHealthPlan() {
        return healthPlan;
    }

    public void setHealthPlan(String healthPlan) {
        this.healthPlan = healthPlan;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLegacyMemberId() {
        return legacyMemberId;
    }

    public void setLegacyMemberId(String legacyMemberId) {
        this.legacyMemberId = legacyMemberId;
    }

    public Boolean getManuallyCreated() {
        return manuallyCreated;
    }

    public void setManuallyCreated(Boolean manuallyCreated) {
        this.manuallyCreated = manuallyCreated;
    }

    public Boolean getManuallyUpdated() {
        return manuallyUpdated;
    }

    public void setManuallyUpdated(Boolean manuallyUpdated) {
        this.manuallyUpdated = manuallyUpdated;
    }

    public String getMemberPrefix() {
        return memberPrefix;
    }

    public void setMemberPrefix(String memberPrefix) {
        this.memberPrefix = memberPrefix;
    }

    public List<PhonesDTO> getPhones() {
        if (phones != null) {
            return new ArrayList<>(phones);
        } else {
            return null;
        }
    }

    public void setPhones(List<PhonesDTO> phones) {
        if (phones != null) {
            this.phones = new ArrayList<>(phones);
        } else {
            this.phones = null;
        }
    }

    public List<RestrictedAccessesDTO> getRestrictedAccesses() {
        if (restrictedAccesses != null) {
            return new ArrayList<>(restrictedAccesses);
        } else {
            return null;
        }
    }

    public void setRestrictedAccesses(List<RestrictedAccessesDTO> restrictedAccesses) {
        if (restrictedAccesses != null) {
            this.restrictedAccesses = new ArrayList<>(restrictedAccesses);
        } else {
            this.restrictedAccesses = null;
        }
    }

    public Date getUpdateDate() {
        if (updateDate != null) {
            return new Date(updateDate.getTime());
        } else {
            return null;
        }
    }

    public void setUpdateDate(Date updateDate) {
        if (updateDate != null) {
            this.updateDate = new Date(updateDate.getTime());
        } else {
            this.updateDate = null;
        }
    }
}
