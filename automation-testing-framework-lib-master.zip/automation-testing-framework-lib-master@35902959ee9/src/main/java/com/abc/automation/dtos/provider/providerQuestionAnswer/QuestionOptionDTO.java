package com.abc.automation.dtos.provider.providerQuestionAnswer;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class QuestionOptionDTO {

    private String id;
    private List<OptionDTO> options;
    private String type;
    private ValidationDTO validation;
    private VisibilityDTO visibility;

    public ValidationDTO getValidation() {
        return validation;
    }

    public void setValidation(ValidationDTO validation) {
        this.validation = validation;
    }

    public VisibilityDTO getVisibility() {
        return visibility;
    }

    public void setVisibility(VisibilityDTO visibility) {
        this.visibility = visibility;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public List<OptionDTO> getOptions() {
        return options;
    }

    public void setOptions(List<OptionDTO> options) {
        this.options = options;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


}
