package datamanager;

import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.tests.base.PostTests;
import dtos.ErrorDTO;
import dtos.ErrorSpringDTO;
import dtos.datamanager.MemberResponseDTO;
import dtos.demographics.EmailsDTO;
import dtos.demographics.MemberDemographicsDTO;
import dtos.demographics.PhonesDTO;
import dtos.search.GETMemberSearchDTO;
import dtos.search.MemberSearchDTO;
import factories.datamanager.MemberDTOFactory;
import factories.demographics.EmailsDTOFactory;
import factories.demographics.PhonesDTOFactory;
import helpers.dataproviders.DataProviders;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.datamanager.MemberDataManagerSteps;
import steps.demographics.GetMemberDemographicsSteps;
import steps.enrollments.MemberEnrollmentsSteps;
import steps.rabbitmqsimulator.PublishEventSteps;
import steps.search.MemberSearchSteps;

import java.util.ArrayList;

import static helpers.constants.BasePathConstants.BASE_PATH_ADD_MEMBERS;
import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_85;
import static org.apache.http.HttpStatus.*;


public class PostAddMemberV2Tests extends PostTests {

    private static final String ERROR_MESSAGE_400 = "Required request body is missing: public org.springframework.http.ResponseEntity com.aim.member.datamanager.controller.V2Controller.addMember(java.lang.String,java.lang.String,java.lang.String,java.lang.String,java.lang.String,java.lang.String,java.lang.String,com.aim.member.dto.MemberDTO) throws java.io.IOException";
    private MemberDataManagerSteps memberDataManagerSteps;
    private String CLIENT_MEMBER_ID;

    @BeforeMethod
    public void initMethod() {
        CLIENT_MEMBER_ID = RandomStringUtils.randomNumeric(10) + RandomStringUtils.randomAlphabetic(5).toUpperCase();
    }

    @BeforeClass
    public void init() {
        basePath = BASE_PATH_ADD_MEMBERS;

        pathParamsMap.put("clientId", CLIENT_ID_186);
        body = new MemberDTOFactory().createMemberDTO(CLIENT_ID_186, CLIENT_MEMBER_ID);
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-201---------------------------------------------
    @Test(dataProvider = "data-provider-clientId", dataProviderClass = DataProviders.class)
    public void whenPostAndValidBodyDTOSentThenServiceReturnsMemberIdSC201(String clientId) {
        platformContextHeader=new PlatformContextUtils().changeClientId(platformContextHeader, Integer.valueOf(clientId));
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(clientId, CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();
        softly.then(memberId).isNotEmpty().isNotBlank().isNotNull();
        softly.assertAll();
    }

    @Test(dataProvider = "data-provider-issuanceState", dataProviderClass = DataProviders.class)
    public void whenPostAndValidBodyDTOSentFor210ThenServiceReturnsMemberIdSC201(String issuanceState) {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_210, issuanceState, SS_WGS, CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();
        softly.then(memberId).isNotEmpty().isNotBlank().isNotNull();
        softly.assertAll();
    }

    @Test
    public void whenPostAndValidBodyDTOFor186WithEmployerGroupSentThenServiceReturnsMemberIdSC201() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_186, EMPLOYER_GROUP_NUMBER, 1, null, null, CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();
        softly.then(memberId).isNotEmpty().isNotBlank().isNotNull();
        softly.assertAll();
    }

    @Test
    public void whenPostValidMixerCodeWithSpaceOn4thPositionFor186SentThenServiceReturnsMemberIdSC201() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_186, EMPLOYER_GROUP_NUMBER, 1, MIXER_CODE_SPACE_ON_4TH_POSITION, null, CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();
        softly.then(memberId).isNotEmpty().isNotBlank().isNotNull();
        softly.assertAll();
    }

    //-----------------------------------RabbitMQ-consumer-DELETE-MEMBER----------------------------------------------

    @Test
    public void whenDeleteMemberViaRabbitMQEventThenEnrollmentAndDemographicsAreAlsoDeletedIdSC201() {
        //Create a member
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_85, CLIENT_MEMBER_ID);
        String id = memberResponseDTO.getId();

        //Get clientMemberId from Demographics information
        GetMemberDemographicsSteps memberDemographicsSteps = new GetMemberDemographicsSteps(platformContextHeader, headers);
        MemberDemographicsDTO response = memberDemographicsSteps.getMemberDemographics(CLIENT_ID_85, id);
        String clientMemberId = response.getClientMemberId();

        //Delete the member via RabbitMQ
        PublishEventSteps publishEventSteps = new PublishEventSteps(platformContextHeader, headers);
        publishEventSteps.publishDeleteMemberEvent(CLIENT_ID_85, id);

        //Verify there is no enrollment info for this member
        MemberEnrollmentsSteps memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        ErrorDTO errorEnrollment = memberEnrollmentsSteps.getMemberEnrollmentsErrors(CLIENT_ID_85, id);

        //Verify there is no demographics information for this member
        memberDemographicsSteps = new GetMemberDemographicsSteps(platformContextHeader, headers);
        ErrorDTO errorDemographics = memberDemographicsSteps.getMemberDemographicsSC404(CLIENT_ID_85, clientMemberId);

        //Search can't find this member
        GETMemberSearchDTO memberSearchDTO = new MemberSearchSteps(platformContextHeader, headers).getMemberSearch(CLIENT_ID_85, clientMemberId, null, null, null);
        ArrayList<MemberSearchDTO> members = memberSearchDTO.getMembers();
        for (MemberSearchDTO member : members) {
            softly.then(member.getClientId()).isEqualTo(CLIENT_ID_85);
            softly.then(member.getId()).isNotEqualTo(id);
        }
        softly.then(errorEnrollment.getCode()).isEqualTo(SC_NOT_FOUND);
        softly.then(errorEnrollment.getMessage()).contains(ERROR_ENTITY_NOT_FOUND);
        softly.then(errorDemographics.getCode()).isEqualTo(SC_NOT_FOUND);
        softly.then(errorDemographics.getMessage()).contains(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }

    //-----------------------------------RabbitMQ-consumer-DELETE-MEMBER-NEGATIVE-TESTS----------------------------------------------

    @Test
    public void whenDeleteMemberButInvalidClientIDViaRabbitMQEventThenEnrollmentAndDemographicsAreNotDeletedIdSC201() {
        //Create a member
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_85, CLIENT_MEMBER_ID);
        String id = memberResponseDTO.getId();

        //Try to delete with invalid header
        PublishEventSteps publishEventSteps = new PublishEventSteps(platformContextHeader, headers);
        publishEventSteps.publishInvalidDeleteMemberEvent(CLIENT_ID_85, id);

        //The member and its demographics is not deleted
        GetMemberDemographicsSteps memberDemographicsSteps = new GetMemberDemographicsSteps(platformContextHeader, headers);
        MemberDemographicsDTO memberDemographicsDTO = memberDemographicsSteps.getMemberDemographics(CLIENT_ID_85, id);

        softly.then(memberDemographicsDTO.getId()).isEqualTo(id);
        softly.then(memberDemographicsDTO.getClientId()).isEqualTo(CLIENT_ID_85);
        softly.assertAll();
    }

    //This Test is failing in QA..
    // @Test(dataProvider = "contextModeValue", dataProviderClass = DataProviders.class)
    public void whenCreateMemberWithSpecificDemographicsAndEnrollmentWithTestModeThenResponseSC201(String contextMode) throws InterruptedException {

        PlatformContextUtils platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeContextMode(platformContextHeader, contextMode);

        //Create unique clientMemberId, so the created member is unique and it is easier to find
        String clientMemberId = RandomStringUtils.random(10, true, true);

        //Create a member with specific enrollment and demographics
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMemberClientMemberId(CLIENT_ID_85, clientMemberId);

        //Get the memberId that is created
        String memberId = memberResponseDTO.getId();

        //Check that memberId is created
        softly.then(memberId).isNotNull().isNotEmpty().isNotBlank();

        //search the member in the member-search for client 85 and the unique clientMemberId, for which the member is created
        GETMemberSearchDTO memberSearchDTO = new MemberSearchSteps(platformContextHeader, headers).getMemberSearch(CLIENT_ID_85, clientMemberId, DOB, null, null);
        ArrayList<MemberSearchDTO> members = memberSearchDTO.getMembers();

        //Check that the search is returning a list of members which is greater than 0 and check that the list is not empty
        softly.then(memberSearchDTO.getTotalPages()).isGreaterThan(0);
        softly.then(memberSearchDTO.getTotalElements()).isGreaterThan(0);
        softly.then(memberSearchDTO.getMembers()).isNotEmpty();

        //Check that the found members's clientMemberId is the unique one that we are looking for
        for (MemberSearchDTO member : members) {
            softly.then(member.getClientMemberId()).isEqualTo(clientMemberId);
            softly.then(member.getId()).isEqualTo(memberId);
        }

        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-409---------------------------------------------
    @Test
    public void whenPostAndValidBodyDTOButOfExistingMemberSentThenServiceReturnsConflictSC409() {

        ArrayList<EmailsDTO> emails = new EmailsDTOFactory().createEmailsDTO(true, EMAIL_TYPE, EMAIL_VALUE);
        ArrayList<PhonesDTO> phones = new PhonesDTOFactory().createPhonesDTO(true, PHONE_TYPE, PHONE_VALUE);

        String firstName = RandomStringUtils.random(10, true, false);
        String lastName = RandomStringUtils.random(10, true, false);

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        //Create member
        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_85, firstName, lastName, emails, phones, HttpStatus.SC_CREATED, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        softly.then(memberId).isNotNull().isNotBlank().isNotEmpty();

        //Create duplicate member
        MemberResponseDTO memberResponseDTODuplicate = memberDataManagerSteps.createMember(CLIENT_ID_85, firstName, lastName, emails, phones, SC_CONFLICT, CLIENT_MEMBER_ID);

        softly.then(memberResponseDTODuplicate.getId()).isNotNull().isNotBlank().isNotEmpty();
        softly.then(memberResponseDTODuplicate.getId()).isEqualTo(memberId);
        softly.assertAll();
    }

    @Test
    public void whenPostAndInvalidClientIDSentThenServiceReturnsErrorSC400() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        ErrorSpringDTO errorSpring = memberDataManagerSteps.createMemberWithoutBody(CLIENT_ID_TEST);

        softly.then(errorSpring.getStatus()).isEqualTo(SC_BAD_REQUEST);
        softly.then(errorSpring.getMessage()).contains(ERROR_MESSAGE_400);
        softly.assertAll();
    }

    @Test
    public void whenPostAndInvalidClientIDSentThenServiceReturnsErrorSC422() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        ErrorDTO error = memberDataManagerSteps.createMemberErrors(CLIENT_ID_TEST, CLIENT_MEMBER_ID);

        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.assertAll();
    }

    //TODO opened a bug for fixing the error message - Response status is 422 with invalid mixer code NCP-27892
    @Test(dataProvider = "invalid-mixer-codes", dataProviderClass = DataProviders.class)
    public void whenPostAndInvalidMixerCodesSentThenServiceReturnsErrorSC422(String mixerCode) {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        ErrorDTO error = memberDataManagerSteps.createMemberWithClientMemberProductCodeAndMixerCodeWithError(CLIENT_ID_186, EMPLOYER_GROUP_NUMBER, 1, mixerCode, null, CLIENT_MEMBER_ID);

        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.then(error.getMessage()).contains(VALIDATION_MIXER_CODE_ALPHANUMRIC);
        softly.assertAll();
    }

    @Test(dataProvider = "contextModeInDataBase", dataProviderClass = DataProviders.class)
    public void whenCreateMemberWithSpecificEnrollmentWithContextModeTestAndSearchForTheCreatedMemberWithContextModeProdThenEmptyListIsReturnedAndResponseSC201(String contextMode, String dataBaseMode) {

        //Create platformContext with contextMode test
        PlatformContextUtils platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeContextMode(platformContextHeader, contextMode);

        //Create specific clientMemberId for TEST
        String clientMemberId = RandomStringUtils.random(10, true, true);

        //Create a member with specific enrollment and demographics
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMemberClientMemberId(CLIENT_ID_85, clientMemberId);
        String memberId = memberResponseDTO.getId();

        softly.then(memberId).isNotNull().isNotEmpty().isNotBlank();

        //Create platformContext with contextMode PROD
        PlatformContextUtils platformContextUtilsPROD = new PlatformContextUtils();
        platformContextHeader = platformContextUtilsPROD.changeContextMode(platformContextHeader, dataBaseMode);

        //search for the member for PROS in the member-search with clientMemberId that is created for TEST
        GETMemberSearchDTO memberSearchDTO = new MemberSearchSteps(platformContextHeader, headers).getMemberSearch(CLIENT_ID_85, clientMemberId, DOB, null, null);
        ArrayList<MemberSearchDTO> members = memberSearchDTO.getMembers();

        softly.then(members).isEmpty();
        softly.assertAll();
    }
}

