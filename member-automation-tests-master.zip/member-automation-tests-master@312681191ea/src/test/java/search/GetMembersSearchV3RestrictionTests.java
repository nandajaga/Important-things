package search;

import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.tests.base.GetTests;
import dtos.datamanager.MemberResponseDTO;
import dtos.search.GETMemberSearchDTO;
import dtos.search.MemberSearchDTO;
import helpers.constants.BasePathConstants;
import helpers.dataproviders.DataProviders;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.datamanager.MemberDataManagerSteps;
import steps.search.MemberSearchV3Steps;

import java.text.ParseException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

import static helpers.constants.ClientConfigConstants.CLIENT_ID_183;
import static helpers.constants.ClientConfigConstants.CLIENT_ID_184;
import static helpers.constants.Constants.*;

/**
 * Created by sbioi on 6/5/2019.
 */
public class GetMembersSearchV3RestrictionTests extends GetTests {

    private String CLIENT_MEMBER;
    private String firstName;
    private String lastName;
    private MemberDataManagerSteps memberDataManagerSteps;
    private PlatformContextUtils platformContextUtils;
    private Date date;

    @BeforeClass
    public void init() {
        basePath = BasePathConstants.BASE_PATH_V3_SEARCH_MEMBERS;
        platformContextUtils = new PlatformContextUtils();
    }

    @BeforeMethod
    public void clientMemberID() throws ParseException {
        CLIENT_MEMBER = RandomStringUtils.randomNumeric(10) + RandomStringUtils.randomAlphabetic(5).toUpperCase();
        firstName = RandomStringUtils.random(10, true, false);
        lastName = RandomStringUtils.random(10, true, false);
        LocalDate lDate = LocalDate.now();
        date = java.sql.Date.valueOf(lDate.plusDays(0));
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test(dataProvider = "restrictedClientId", dataProviderClass = DataProviders.class)
    public void whenSearchedNonRestrictedMmberUsingClientidFirstnameLastnameAndDOBResponse200(String clientId) throws ParseException {
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));
        platformContextHeader = platformContextUtils.changeDateOfServiceDate(platformContextHeader, date);
        platformContextHeader = platformContextUtils.changeRootLevelDateOfServiceDate(platformContextHeader, date);
        platformContextHeader = platformContextUtils.changeChannelCode(platformContextHeader, PC_CHANNEL_CODE_P);

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMemberWithContacts(clientId, firstName, lastName, DOB, CLIENT_MEMBER);

        GETMemberSearchDTO memberSearchDTO = new MemberSearchV3Steps(platformContextHeader, headers).getMemberSearch(clientId, CLIENT_MEMBER, null, null, null, USER_LOC_CODE_RESTRICTED, SIZE_RESULT);

        softly.then(memberSearchDTO.getTotalPages()).isGreaterThan(0);
        softly.then(memberSearchDTO.getTotalElements()).isGreaterThan(0);
        softly.then(memberSearchDTO.getMembers()).isNotEmpty();

        ArrayList<MemberSearchDTO> members = memberSearchDTO.getMembers();
        for (MemberSearchDTO member : members) {
            softly.then(member.getClientId()).isEqualTo(clientId);
            softly.then(member.getFirstName()).containsSequence(firstName);
            softly.then(member.getLastName()).containsSequence(lastName);
        }
        softly.assertAll();
    }

    @Test(dataProvider = "restrictedClientId", dataProviderClass = DataProviders.class)
    public void whenSearchedRestrictedMemberUsingClientidAndclientMemberIdResponse200(String clientId) throws ParseException {
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));
        platformContextHeader = platformContextUtils.changeDateOfServiceDate(platformContextHeader, date);
        platformContextHeader = platformContextUtils.changeRootLevelDateOfServiceDate(platformContextHeader, date);
        platformContextHeader = platformContextUtils.changeChannelCode(platformContextHeader, PC_CHANNEL_CODE_CC);

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMemberWithContacts(clientId, firstName, lastName, DOB, CLIENT_MEMBER);

        GETMemberSearchDTO memberSearchDTO = new MemberSearchV3Steps(platformContextHeader, headers).getMemberSearch(clientId, CLIENT_MEMBER, null, null, null, USER_LOC_CODE_RESTRICTED, SIZE_RESULT);

        softly.then(memberSearchDTO.getMessage()).isEqualTo(MEMBER_RESTRICTED_MESSAGE);
        softly.then(memberSearchDTO.getTotalPages()).isEqualTo(0);
        softly.then(memberSearchDTO.getTotalElements()).isEqualTo(0);
        softly.then(memberSearchDTO.getMembers()).isEmpty();

        softly.assertAll();
    }

    @Test(dataProvider = "restrictedClientId", dataProviderClass = DataProviders.class)
    public void whenSearchedRestrictedMemberUsingClientidLastNameFirstNameAndDOBdResponse200(String clientId) throws ParseException {
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));
        platformContextHeader = platformContextUtils.changeDateOfServiceDate(platformContextHeader, date);
        platformContextHeader = platformContextUtils.changeRootLevelDateOfServiceDate(platformContextHeader, date);
        platformContextHeader = platformContextUtils.changeChannelCode(platformContextHeader, PC_CHANNEL_CODE_CC);

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMemberWithContacts(clientId, firstName, lastName, DOB, CLIENT_MEMBER);

        GETMemberSearchDTO memberSearchDTO = new MemberSearchV3Steps(platformContextHeader, headers).getMemberSearch(clientId, CLIENT_MEMBER, DOB_1, firstName, lastName, USER_LOC_CODE_RESTRICTED, SIZE_RESULT);

        softly.then(memberSearchDTO.getMessage()).isEqualTo(MEMBER_RESTRICTED_MESSAGE);
        softly.then(memberSearchDTO.getTotalPages()).isEqualTo(0);
        softly.then(memberSearchDTO.getTotalElements()).isEqualTo(0);
        softly.then(memberSearchDTO.getMembers()).isEmpty();

        softly.assertAll();
    }

    //********************************************************* Negetive scenario******************************************************
    @Test(dataProvider = "restrictedClientId", dataProviderClass = DataProviders.class)
    public void whenSearchedRestrictedMmberUsingClientidAndClientmemberIdWronglocationCodeResponse200(String clientId) throws ParseException {
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));
        platformContextHeader = platformContextUtils.changeDateOfServiceDate(platformContextHeader, date);
        platformContextHeader = platformContextUtils.changeRootLevelDateOfServiceDate(platformContextHeader, date);
        platformContextHeader = platformContextUtils.changeChannelCode(platformContextHeader, PC_CHANNEL_CODE_CC);

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMemberWithContacts(clientId, firstName, lastName, DOB, CLIENT_MEMBER);

        GETMemberSearchDTO memberSearchDTO = new MemberSearchV3Steps(platformContextHeader, headers).getMemberSearch(clientId, CLIENT_MEMBER, null, null, null, WRONG_USER_LOC_CODE_RESTRICTED, SIZE_RESULT);

        softly.then(memberSearchDTO.getTotalPages()).isGreaterThan(0);
        softly.then(memberSearchDTO.getTotalElements()).isGreaterThan(0);
        softly.then(memberSearchDTO.getMembers()).isNotEmpty();

        ArrayList<MemberSearchDTO> members = memberSearchDTO.getMembers();
        for (MemberSearchDTO member : members) {
            softly.then(member.getClientId()).isEqualTo(clientId);
            softly.then(member.getFirstName()).containsSequence(firstName);
            softly.then(member.getLastName()).containsSequence(lastName);
        }
        softly.assertAll();
    }

    @Test
    public void whenSearchedRestrictedMemberUsingClientidAndclientMemberIdResponse400() throws ParseException {
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(CLIENT_ID_183));
        platformContextHeader = platformContextUtils.changeDateOfServiceDate(platformContextHeader, date);
        platformContextHeader = platformContextUtils.changeRootLevelDateOfServiceDate(platformContextHeader, date);
        platformContextHeader = platformContextUtils.changeChannelCode(platformContextHeader, PC_CHANNEL_CODE_CC);

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMemberWithContacts(CLIENT_ID_183, firstName, lastName, DOB, CLIENT_MEMBER);

        GETMemberSearchDTO memberSearchDTO = new MemberSearchV3Steps(platformContextHeader, headers).getMemberSearch(CLIENT_ID_184, CLIENT_MEMBER, null, null, null, USER_LOC_CODE_RESTRICTED, SIZE_RESULT);

        softly.then(memberSearchDTO.getTotalPages()).isEqualTo(0);
        softly.then(memberSearchDTO.getTotalElements()).isEqualTo(0);
        softly.then(memberSearchDTO.getMembers()).isEmpty();

        softly.assertAll();
    }
}