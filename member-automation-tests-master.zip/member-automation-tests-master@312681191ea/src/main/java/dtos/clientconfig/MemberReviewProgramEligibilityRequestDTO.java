package dtos.clientconfig;

import java.util.List;

public class MemberReviewProgramEligibilityRequestDTO {
    private List<String> reviewPrograms;

    public List<String> getReviewPrograms() {
        return reviewPrograms;
    }

    public void setReviewPrograms(List<String> reviewPrograms) {
        this.reviewPrograms = reviewPrograms;
    }


}
