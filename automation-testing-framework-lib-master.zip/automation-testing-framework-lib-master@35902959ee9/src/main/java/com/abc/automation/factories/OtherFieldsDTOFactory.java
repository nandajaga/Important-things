package com.abc.automation.factories;

import com.abc.automation.dtos.OtherFieldsDTO;

/**
 * Created by HKirazyan on 4/10/2019
 */
public class OtherFieldsDTOFactory {

    //TODO elaborate when otherFields are used and move them to more common location
    private static final String OTHER = "other";

    public OtherFieldsDTO addOtherFields() {
        OtherFieldsDTO otherFields = new OtherFieldsDTO();
        otherFields.setOther(OTHER);
        return otherFields;
    }
}
