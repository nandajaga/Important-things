package steps.clientconfig;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.clientconfig.MemberRestrictionRequestDTO;
import dtos.clientconfig.RestrictionTypeResponseDTO;
import factories.clientconfig.MemberRestrictionDTOFactory;
import helpers.constants.BasePathConstants;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

/**
 * Created by VBaliyska on 6/21/2019.
 */
public class MembersRestrictionSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public MembersRestrictionSteps(String platformContext, Headers headers){
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BasePathConstants.BASE_PATH_MEMBER_RESTRICTION_POST);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    public RestrictionTypeResponseDTO postMemberRestrictionRequest(String clientId, String employerGroupNumber, String dependentRelationCode, String restrictionType, String memberId){
        MemberRestrictionRequestDTO requestBody = new MemberRestrictionDTOFactory().createRestrictionRequestMemberDTO(clientId, employerGroupNumber, dependentRelationCode, restrictionType, memberId);
        requestSpecification.addBodyToRequest(requestBody);
        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_OK);

        return result.as(RestrictionTypeResponseDTO.class);
    }

    public ErrorDTO postMemberRestrictionRequestError(String clientId, String employerGroupNumber, String dependentRelationCode, String restrictionType, String memberId) {
        MemberRestrictionRequestDTO requestBody = new MemberRestrictionDTOFactory().createRestrictionRequestMemberDTO(clientId, employerGroupNumber, dependentRelationCode, restrictionType, memberId);
        requestSpecification.addBodyToRequest(requestBody);
        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorDTO.class);
    }
}
