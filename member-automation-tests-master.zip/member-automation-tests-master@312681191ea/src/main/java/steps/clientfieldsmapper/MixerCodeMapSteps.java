package steps.clientfieldsmapper;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.clientfieldsmapper.MixerCodeMapRequestDTO;
import dtos.clientfieldsmapper.MixerCodeMapResponseDTO;
import factories.clientfieldsmapper.MixerCodeMapRequestDTOFactory;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import static helpers.constants.BasePathConstants.BASE_PATH_CLIENT_FIELDS_MAPPER;

/**
 * Created by VBaliyska on 10/11/2019.
 */
public class MixerCodeMapSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public MixerCodeMapSteps(String platformContext, Headers headers) {

        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BASE_PATH_CLIENT_FIELDS_MAPPER);
        requestSpecification.addHeaders(headers);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
    }

    public MixerCodeMapResponseDTO postRetrieveMixerCode(String clientId, String employerGroupNumber, String sourceSystem) {

        MixerCodeMapRequestDTO requestDTO = new MixerCodeMapRequestDTOFactory().createMixerCodeMapRequestBody(clientId, employerGroupNumber, sourceSystem);
        requestSpecification.addBodyToRequest(requestDTO);
        Response response = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());
        response.then().statusCode(HttpStatus.SC_OK);

        return response.as(MixerCodeMapResponseDTO.class);
    }

    public ErrorDTO postRetrieveMixerCodeWithError(String clientId, String employerGroupNumber, String sourceSystem) {

        MixerCodeMapRequestDTO requestDTO = new MixerCodeMapRequestDTOFactory().createMixerCodeMapRequestBody(clientId, employerGroupNumber, sourceSystem);
        requestSpecification.addBodyToRequest(requestDTO);
        Response response = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        return response.as(ErrorDTO.class);
    }
}
