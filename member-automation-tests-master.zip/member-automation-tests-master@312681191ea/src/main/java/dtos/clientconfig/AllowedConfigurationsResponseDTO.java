package dtos.clientconfig;

/**
 * Created by VBaliyska on 8/22/2019.
 */
public class AllowedConfigurationsResponseDTO {

    private String key;

    private String value;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}
