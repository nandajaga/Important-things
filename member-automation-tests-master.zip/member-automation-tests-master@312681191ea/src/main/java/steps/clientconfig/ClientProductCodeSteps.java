package steps.clientconfig;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.clientconfig.ClientProductCodesResponseDTO;
import helpers.constants.BasePathConstants;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by RKondakova on 7/12/2019.
 */
public class ClientProductCodeSteps {
    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public ClientProductCodeSteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BasePathConstants.BASE_PATH_GET_V2_CLIENT_PRODUCT_CODES);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    //for positive tests
    public ClientProductCodesResponseDTO[] getClientProductCodesRequestPositive(String clientId, String issuanceState, String lineOfBusiness) {

        Map<String, String> pathParamsMap = new HashMap<>();
        Map<String, String> queryParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);
        if (issuanceState != null) {
            queryParamsMap.put("state-of-issuance", issuanceState);
        }
        if(lineOfBusiness!=null){
            queryParamsMap.put("line-of-business-code", lineOfBusiness);
        }

        requestSpecification.addPathParams(pathParamsMap);
        requestSpecification.addQueryParams(queryParamsMap);

        Response response = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        response.then().statusCode(HttpStatus.SC_OK);

        return response.as(ClientProductCodesResponseDTO[].class);
    }

    //for negative tests
    public ErrorDTO getClientProductCodesRequestErrorDTO(String clientId, String issuanceState) {

        Map<String, String> pathParamsMap = new HashMap<>();
        Map<String, String> queryParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);
        if (issuanceState != null) queryParamsMap.put("state-of-issuance", issuanceState);

        requestSpecification.addPathParams(pathParamsMap);
        requestSpecification.addQueryParams(queryParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorDTO.class);
    }

}
