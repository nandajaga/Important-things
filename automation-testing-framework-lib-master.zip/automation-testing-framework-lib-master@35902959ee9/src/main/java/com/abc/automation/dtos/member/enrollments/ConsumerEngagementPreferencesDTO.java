package com.abc.automation.dtos.member.enrollments;

public class ConsumerEngagementPreferencesDTO {
    private String preferenceCode;
    private String categoryCode;
    private String methodCode;
    private Boolean primaryFlag;

    public String getPreferenceCode() {
        return preferenceCode;
    }

    public void setPreferenceCode(String preferenceCode) {
        this.preferenceCode = preferenceCode;
    }

    public String getCategoryCode() {
        return categoryCode;
    }

    public void setCategoryCode(String categoryCode) {
        this.categoryCode = categoryCode;
    }

    public String getMethodCode() {
        return methodCode;
    }

    public void setMethodCode(String methodCode) {
        this.methodCode = methodCode;
    }

    public Boolean getPrimaryFlag() {
        return primaryFlag;
    }

    public void setPrimaryFlag(Boolean primaryFlag) {
        this.primaryFlag = primaryFlag;
    }
}
