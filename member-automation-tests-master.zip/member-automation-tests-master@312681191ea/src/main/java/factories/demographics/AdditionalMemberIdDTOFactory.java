package factories.demographics;

import dtos.demographics.AdditionalMemberIdDTO;

import java.util.ArrayList;
import java.util.List;

import static helpers.constants.Constants.*;

public class AdditionalMemberIdDTOFactory {

    public List<AdditionalMemberIdDTO> createAdditionalMemberIdsDTO() {
        List<AdditionalMemberIdDTO> list = new ArrayList<>();

        AdditionalMemberIdDTO additionalMemberIdMedicareDTO = new AdditionalMemberIdDTO();
        additionalMemberIdMedicareDTO.setName(MEDICARE_ID_NAME);
        additionalMemberIdMedicareDTO.setValue(MEDICARE_ID_VALUE);

        AdditionalMemberIdDTO additionalMemberIdMedicaidDTO = new AdditionalMemberIdDTO();
        additionalMemberIdMedicaidDTO.setName(MEDICAID_ID_NAME);
        additionalMemberIdMedicaidDTO.setValue(MEDICAID_ID_VALUE);

        list.add(additionalMemberIdMedicareDTO);
        list.add(additionalMemberIdMedicaidDTO);

        return list;
    }
}
