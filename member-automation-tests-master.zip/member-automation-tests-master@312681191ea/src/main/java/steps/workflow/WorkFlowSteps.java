package steps.workflow;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.workflow.WorkFlowResponseDTO;
import factories.workflow.WorkFlowFactory;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import static helpers.constants.BasePathConstants.BASE_PATH_ENROLLMENT_ENSURE_WORKFLOW;
import static helpers.constants.Constants.SUBCLIENT_CODE;

//     * Updated by sbioi on 25/02/2021

public class WorkFlowSteps {
    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public WorkFlowSteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BASE_PATH_ENROLLMENT_ENSURE_WORKFLOW);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    public WorkFlowResponseDTO[] postWorkFlowSteps(String subClientCode) {
        Object payLoad = new WorkFlowFactory().createWorkFlowDTO(SUBCLIENT_CODE);
        requestSpecification.addBodyToRequest(payLoad);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_OK);

        return result.as(WorkFlowResponseDTO[].class);
    }
}
