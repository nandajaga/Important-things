package com.abc.automation.factories.member.enrollments;

import com.abc.automation.dtos.member.enrollments.SolutionDTO;
import com.abc.automation.helpers.constants.MemberConstants;

import java.util.ArrayList;

/**
 * Created by PPetarcheva on 4/17/2019.
 */
public class SolutionDTOFactory {

    public ArrayList<SolutionDTO> createSolutionDTO() {
        ArrayList<SolutionDTO> solutions = new ArrayList<>();
        SolutionDTO solution = new SolutionDTO();
        solution.setProgramType(MemberConstants.SOLUTION_PROGRAM_TYPE);
        solution.setSolutionId(MemberConstants.SOLUTION_PAYLOAD);

        solutions.add(solution);
        return solutions;
    }
}
