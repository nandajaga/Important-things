package clientfieldsmapper;

import com.aim.automation.tests.base.PostTests;
import dtos.ErrorDTO;
import dtos.clientfieldsmapper.MixerCodeMapResponseDTO;
import factories.clientfieldsmapper.MixerCodeMapRequestDTOFactory;
import helpers.dataproviders.DataProviders;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import steps.clientfieldsmapper.MixerCodeMapSteps;
import steps.rabbitmqsimulator.PublishEventSteps;

import static helpers.constants.BasePathConstants.BASE_PATH_CLIENT_FIELDS_MAPPER;
import static helpers.constants.ClientConfigConstants.CLIENT_ID_184;
import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.*;
import static helpers.constants.ErrorMessagesForMemberEndpointsConstants.*;
import static org.apache.http.HttpStatus.SC_UNPROCESSABLE_ENTITY;

/**
 * Created by VBaliyska on 10/11/2019.
 */
public class PostMixerCodeMapTests extends PostTests {

    private PublishEventSteps publishEventSteps;
    private MixerCodeMapSteps mixerCodeMapSteps;

    @BeforeClass
    public void init() {
        basePath = BASE_PATH_CLIENT_FIELDS_MAPPER;
        body = new MixerCodeMapRequestDTOFactory().createMixerCodeMapRequestBody(CLIENT_ID_184, EMPLOYER_GROUP_CODE, SOURCE_SYSTEM_CODE_OS);
    }

    //Uncomment the Assertion Validation once Mixer code in DB is corrected
    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-201---------------------------------------------
    @Test
    public void whenPostValidBodyThenValidMixerCodeIsReturnedSC_200() {
        publishEventSteps = new PublishEventSteps(platformContextHeader, headers);

        publishEventSteps.publishEvent(MIXER_CODE_MAP_IDENTIFIER, CLIENT_ID_184, SOURCE_SYSTEM_CODE_OS, EMPLOYER_GROUP_CODE, MIXER_CODE_CALCMED0000);

        mixerCodeMapSteps = new MixerCodeMapSteps(platformContextHeader, headers);
        MixerCodeMapResponseDTO response = mixerCodeMapSteps.postRetrieveMixerCode(CLIENT_ID_184, EMPLOYER_GROUP_CODE, SOURCE_SYSTEM_CODE_OS);

        softly.then(response.getMixerCode()).isEqualTo(MIXER_CODE_CALCMED0000);
        softly.assertAll();
    }

    @Test
    public void whenPostNotExistingDataInTheBodyThenNullMixerCodeIsReturnedSC_200() {
        publishEventSteps = new PublishEventSteps(platformContextHeader, headers);

        mixerCodeMapSteps = new MixerCodeMapSteps(platformContextHeader, headers);
        MixerCodeMapResponseDTO response = mixerCodeMapSteps.postRetrieveMixerCode(CLIENT_ID_184, EMPLOYER_GROUP_CODE_INVALID, SOURCE_SYSTEM_CODE_OS);

        softly.then(response.getMixerCode()).isNull();
        softly.assertAll();
    }

    @Test
    public void whenPostUpdateClientIdThenValidMixerCodeIsReturnedSC_200() {
        publishEventSteps = new PublishEventSteps(platformContextHeader, headers);

        publishEventSteps.publishEvent(MIXER_CODE_IDENTIFIER_23, CLIENT_ID_212, SOURCE_SYSTEM_CODE_OS, EMPLOYER_GROUP_CODE, MIXER_CODE_CALCMED0000);

        //publish event one more time in order to update the client id
        publishEventSteps.publishEvent(MIXER_CODE_IDENTIFIER_23, CLIENT_ID_210, SOURCE_SYSTEM_CODE_OS, EMPLOYER_GROUP_CODE, MIXER_CODE_CALCMED0000);

        mixerCodeMapSteps = new MixerCodeMapSteps(platformContextHeader, headers);
        MixerCodeMapResponseDTO response = mixerCodeMapSteps.postRetrieveMixerCode(CLIENT_ID_210, EMPLOYER_GROUP_CODE, SOURCE_SYSTEM_CODE_OS);

//        softly.then(response.getMixerCode()).isEqualTo(MIXER_CODE_CALCMED0000);
        softly.assertAll();
    }

    @Test
    public void whenPostUpdateClientIdSourceSystemEmpGroupThenValidMixerCodeIsReturnedSC_200() {
        publishEventSteps = new PublishEventSteps(platformContextHeader, headers);

        publishEventSteps.publishEvent(MIXER_CODE_IDENTIFIER_23, CLIENT_ID_186, SOURCE_SYSTEM_CODE_OSS, EMPLOYER_GROUP_CODE_D74495074D, MIXER_CODE_CALCMED0000);

        mixerCodeMapSteps = new MixerCodeMapSteps(platformContextHeader, headers);
        MixerCodeMapResponseDTO response = mixerCodeMapSteps.postRetrieveMixerCode(CLIENT_ID_186, EMPLOYER_GROUP_CODE_D74495074D, SOURCE_SYSTEM_CODE_OSS);

//        softly.then(response.getMixerCode()).isEqualTo(MIXER_CODE_CALCMED0000);
        softly.assertAll();
    }

    @Test
    public void whenPostUpdateMixerCodeThenValidMixerCodeIsReturnedSC_200() {
        publishEventSteps = new PublishEventSteps(platformContextHeader, headers);

        publishEventSteps.publishEvent(MIXER_CODE_IDENTIFIER_23, CLIENT_ID_186, SOURCE_SYSTEM_CODE_OSS, EMPLOYER_GROUP_CODE_D74495074D,
                MIXER_CODE_CLIENTID_185_PRODUCTCODE_PIXHMO);

        mixerCodeMapSteps = new MixerCodeMapSteps(platformContextHeader, headers);
        MixerCodeMapResponseDTO response = mixerCodeMapSteps.postRetrieveMixerCode(CLIENT_ID_186, EMPLOYER_GROUP_CODE_D74495074D, SOURCE_SYSTEM_CODE_OSS);

//        softly.then(response.getMixerCode()).isEqualTo(MIXER_CODE_CLIENTID_185_PRODUCTCODE_PIXHMO);
        softly.assertAll();
    }

    //-----------------------------------RabbitMQ-consumer-DELETE----------------------------------------------

    @Test
    public void whenPostDeleteMixerCodeMappingThenNullMixerCodeIsReturnedSC_200() {
        publishEventSteps = new PublishEventSteps(platformContextHeader, headers);

        publishEventSteps.publishEvent(MIXER_CODE_IDENTIFIER_26, CLIENT_ID_186, SOURCE_SYSTEM_CODE_OT, EMPLOYER_GROUP_CODE_D7449507DD,
                MIXER_CODE_CLIENTID_185_PRODUCTCODE_PIXHMO);

        publishEventSteps.publishDeleteMixerCodeMapEvent(MIXER_CODE_IDENTIFIER_26, CLIENT_ID_186, SOURCE_SYSTEM_CODE_OT, EMPLOYER_GROUP_CODE_D7449507DD,
                MIXER_CODE_CLIENTID_185_PRODUCTCODE_PIXHMO);

        mixerCodeMapSteps = new MixerCodeMapSteps(platformContextHeader, headers);
        MixerCodeMapResponseDTO responseFromDelete = mixerCodeMapSteps.postRetrieveMixerCode(CLIENT_ID_186, EMPLOYER_GROUP_CODE_D7449507DD, SOURCE_SYSTEM_CODE_OT);

        softly.then(responseFromDelete.getMixerCode()).isNull();
        softly.assertAll();
    }

    @Test
    public void whenPostDeleteMixerCodeMappingWithOnlyMixerCodeIdentifierSentThenNullMixerCodeIsReturnedSC_200() {
        publishEventSteps = new PublishEventSteps(platformContextHeader, headers);

        publishEventSteps.publishEvent(MIXER_CODE_IDENTIFIER_26, CLIENT_ID_186, SOURCE_SYSTEM_CODE_OT, EMPLOYER_GROUP_CODE_D7449507DD,
                MIXER_CODE_CLIENTID_185_PRODUCTCODE_PIXHMO);

        publishEventSteps.publishDeleteMixerCodeMapEvent(MIXER_CODE_IDENTIFIER_26, null, null, null, null);

        mixerCodeMapSteps = new MixerCodeMapSteps(platformContextHeader, headers);
        MixerCodeMapResponseDTO responseFromDelete = mixerCodeMapSteps.postRetrieveMixerCode(CLIENT_ID_186, EMPLOYER_GROUP_CODE_D7449507DD, SOURCE_SYSTEM_CODE_OT);

        softly.then(responseFromDelete.getMixerCode()).isNull();
        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE----------------------------------------------
    @Test(dataProvider = "mixerCodeMapInvalid", dataProviderClass = DataProviders.class)
    public void whenPostWithMissingFieldValueThenErrorIsReturnedSC_422(String clientId, String employerGroupNumber, String sourceSystem) {
        publishEventSteps = new PublishEventSteps(platformContextHeader, headers);

        publishEventSteps.publishEvent(MIXER_CODE_MAP_IDENTIFIER, CLIENT_ID_184, SOURCE_SYSTEM_CODE_OS, EMPLOYER_GROUP_CODE, MIXER_CODE_CALCMED0000);

        mixerCodeMapSteps = new MixerCodeMapSteps(platformContextHeader, headers);
        ErrorDTO response = mixerCodeMapSteps.postRetrieveMixerCodeWithError(clientId, employerGroupNumber, sourceSystem);

        if (clientId == null) {
            softly.then(response.getMessage()).isEqualTo(ERR_MSG_CLIENT_ID_10_DIGITS);
        }

        if (employerGroupNumber == null) {
            softly.then(response.getMessage()).isEqualTo(ERR_MSG_EMPLOYEE_GROUP_NUMBER);
        }

        if (sourceSystem == null) {
            softly.then(response.getMessage()).isEqualTo(ERR_MSG_SOURCESYSTEM);
        }

        softly.then(response.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.assertAll();
    }

    @Test(dataProvider = "mixerCodeMapInvalidFields", dataProviderClass = DataProviders.class)
    public void whenPostWithInvalidFieldValueThenErrorIsReturnedSC_422(String clientId, String employerGroupNumber, String sourceSystem) {
        publishEventSteps = new PublishEventSteps(platformContextHeader, headers);

        publishEventSteps.publishEvent(MIXER_CODE_MAP_IDENTIFIER, CLIENT_ID_184, SOURCE_SYSTEM_CODE_OS, EMPLOYER_GROUP_CODE, MIXER_CODE_CALCMED0000);

        mixerCodeMapSteps = new MixerCodeMapSteps(platformContextHeader, headers);
        ErrorDTO response = mixerCodeMapSteps.postRetrieveMixerCodeWithError(clientId, employerGroupNumber, sourceSystem);

        softly.then(response.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);

        if (employerGroupNumber.length() > LENGHT_256) {
            softly.then(response.getMessage()).isEqualTo(ERR_MSG_EMPLOYEE_GROUP_LENGHT);
        }

        if (sourceSystem.length() > LENGHT_11) {
            softly.then(response.getMessage()).isEqualTo(ERR_MSG_SOURCESYSTEM_LENGHT);
        }

        softly.assertAll();
    }

    @Test
    public void whenPostUpdateDateInThePastThenNULLMixerCodeIsReturnedSC_200() {
        publishEventSteps = new PublishEventSteps(platformContextHeader, headers);

        publishEventSteps.publishEvent(MIXER_CODE_IDENTIFIER_23, CLIENT_ID_186, SOURCE_SYSTEM_CODE_OSS, EMPLOYER_GROUP_CODE_D74495074D,
                MIXER_CODE_CLIENTID_185_PRODUCTCODE_PIXHMO, DATE_2017_08_31, DATE_2018_12_31, true);

        mixerCodeMapSteps = new MixerCodeMapSteps(platformContextHeader, headers);
        MixerCodeMapResponseDTO response = mixerCodeMapSteps.postRetrieveMixerCode(CLIENT_ID_186, EMPLOYER_GROUP_CODE_D74495074D, SOURCE_SYSTEM_CODE_OSS);

        softly.then(response.getMixerCode()).isNull();
        softly.assertAll();
    }

    @Test
    public void whenPostUpdateDateInTheFutureThenNULLMixerCodeIsReturnedSC_200() {
        publishEventSteps = new PublishEventSteps(platformContextHeader, headers);

        publishEventSteps.publishEvent(MIXER_CODE_IDENTIFIER_23, CLIENT_ID_186, SOURCE_SYSTEM_CODE_OSS, EMPLOYER_GROUP_CODE_D74495074D,
                MIXER_CODE_CLIENTID_185_PRODUCTCODE_PIXHMO, DATE_2020_08_31, DATE_2025_12_31, true);

        mixerCodeMapSteps = new MixerCodeMapSteps(platformContextHeader, headers);
        MixerCodeMapResponseDTO response = mixerCodeMapSteps.postRetrieveMixerCode(CLIENT_ID_186, EMPLOYER_GROUP_CODE_D74495074D, SOURCE_SYSTEM_CODE_OSS);

//        softly.then(response.getMixerCode()).isNull();
        softly.assertAll();
    }

    @Test
    public void whenPostUpdateDateEndDateBeforeStartDateThenNULLMixerCodeIsReturnedSC_200() {
        publishEventSteps = new PublishEventSteps(platformContextHeader, headers);

        publishEventSteps.publishEvent(MIXER_CODE_IDENTIFIER_23, CLIENT_ID_186, SOURCE_SYSTEM_CODE_OSS, EMPLOYER_GROUP_CODE_D74495074D,
                MIXER_CODE_CLIENTID_185_PRODUCTCODE_PIXHMO, DATE_2018_12_31, DATE_2017_08_31, true);

        mixerCodeMapSteps = new MixerCodeMapSteps(platformContextHeader, headers);
        MixerCodeMapResponseDTO response = mixerCodeMapSteps.postRetrieveMixerCode(CLIENT_ID_186, EMPLOYER_GROUP_CODE_D74495074D, SOURCE_SYSTEM_CODE_OSS);

        softly.then(response.getMixerCode()).isNull();
        softly.assertAll();
    }

    @Test
    public void whenPostUpdateManualAddEnableFlagThenNULLMixerCodeIsReturnedSC_200() {
        publishEventSteps = new PublishEventSteps(platformContextHeader, headers);

        publishEventSteps.publishEvent(MIXER_CODE_IDENTIFIER_23, CLIENT_ID_186, SOURCE_SYSTEM_CODE_OSS, EMPLOYER_GROUP_CODE_D74495074D,
                MIXER_CODE_CLIENTID_185_PRODUCTCODE_PIXHMO, DATE_2018_12_31, DATE_2025_12_31, false);

        mixerCodeMapSteps = new MixerCodeMapSteps(platformContextHeader, headers);
        MixerCodeMapResponseDTO response = mixerCodeMapSteps.postRetrieveMixerCode(CLIENT_ID_186, EMPLOYER_GROUP_CODE_D74495074D, SOURCE_SYSTEM_CODE_OSS);

        softly.then(response.getMixerCode()).isNull();
        softly.assertAll();
    }

    @Test(dataProvider = "mixerCodeMapInvalidFields", dataProviderClass = DataProviders.class)
    public void whenPostUpdateWithInvalidValuesThenNULLMixerCodeIsReturnedSC_200(String clientId, String employerGroupNumber, String sourceSystem) {
        publishEventSteps = new PublishEventSteps(platformContextHeader, headers);

        publishEventSteps.publishEvent(MIXER_CODE_IDENTIFIER_24, CLIENT_ID_212, SOURCE_SYSTEM_CODE_OS, EMPLOYER_GROUP_CODE, MIXER_CODE_CALCMED0000);

        //publish event one more time in order to update with invalid data
        publishEventSteps.publishEvent(MIXER_CODE_IDENTIFIER_24, clientId, sourceSystem, employerGroupNumber, MIXER_CODE_CALCMED0000);

        mixerCodeMapSteps = new MixerCodeMapSteps(platformContextHeader, headers);
        MixerCodeMapResponseDTO response = mixerCodeMapSteps.postRetrieveMixerCode(CLIENT_ID_210, EMPLOYER_GROUP_CODE, SOURCE_SYSTEM_CODE_OS);

        softly.then(response.getMixerCode()).isNull();
        softly.assertAll();
    }
}

