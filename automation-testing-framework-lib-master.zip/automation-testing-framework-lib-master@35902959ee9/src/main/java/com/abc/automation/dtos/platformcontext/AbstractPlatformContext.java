package com.abc.automation.dtos.platformcontext;

import com.abc.automation.factories.platformcontext.IPlatformContextFactory;
import com.abc.automation.factories.platformcontext.PlatformContextDTOFactory;
import com.abc.automation.factories.platformcontext.version2.PlatformContextV2DTOFactory;
import com.abc.automation.helpers.convert.GenericConvertHelper;
import com.abc.automation.helpers.enums.platformcontext.PlatformContextVersionEnum;
import com.abc.servicemodel.domain.IPlatformContext;

/**
 * Created by PPetarcheva on 6/25/2019.
 */
public class AbstractPlatformContext<K extends IPlatformContext> {

    private K platformContext;
    private IPlatformContextFactory platformContextFactory;
    private PlatformContextVersionEnum platformContextVersion;

    public AbstractPlatformContext(PlatformContextVersionEnum version) {
        this.platformContextVersion = version;

        determinePlatformContext();
    }

    public K getPlatformContext() {
        platformContext = (K) platformContextFactory.createPlatformContextDTO();

        return platformContext;
    }

    public String getPlatformContextAsString() {
        platformContext = (K) platformContextFactory.createPlatformContextDTO();

        return new GenericConvertHelper().dtoToString(platformContext);
    }

    private void determinePlatformContext() {
        switch (platformContextVersion) {
            case PC_V1:
                platformContextFactory = new PlatformContextDTOFactory();
                break;
            case PC_V2:
                platformContextFactory = new PlatformContextV2DTOFactory();
                break;
        }
    }

}
