package com.abc.automation.factories.member.enrollments;

import com.abc.automation.dtos.member.enrollments.ClientSpecificEnrollmentsDTO;

/**
 * Created by PPetarcheva on 4/17/2019.
 */
public class ClientSpecificEnrollmentsDTOFactory {

    public ClientSpecificEnrollmentsDTO createClientSpecificEnrollDTO(String sourceSystem) {

        return createClientSpecificEnrollDTO(sourceSystem, null);
    }

    public ClientSpecificEnrollmentsDTO createClientSpecificEnrollDTO(String sourceSystem, String alternateBenefitPlanCode) {

        return createClientSpecificEnrollDTO(sourceSystem, alternateBenefitPlanCode, null);
    }

    public ClientSpecificEnrollmentsDTO createClientSpecificEnrollDTO(String sourceSystem, String alternateBenefitPlanCode, String erisaIndicator) {
        ClientSpecificEnrollmentsDTO clientSpecificEnrollDTO = new ClientSpecificEnrollmentsDTO();
        clientSpecificEnrollDTO.setSourceSystem(sourceSystem);
        clientSpecificEnrollDTO.setAlternateBenefitPlanCode(alternateBenefitPlanCode);
        clientSpecificEnrollDTO.setErisaIndicator(erisaIndicator);
        return clientSpecificEnrollDTO;
    }
}
