package com.abc.automation.factories.platformcontext.version2;

import com.abc.servicemodel.domainV2.provider.OrderingProviderV2;

import java.util.ArrayList;

import static com.abc.automation.helpers.constants.PlatformContextConstants.*;
import static com.abc.automation.helpers.constants.PlatformContextConstants.PC_PLACE_OF_SERVICE_CODE;

public class OrderingProviderV2DTOFactory {
    public OrderingProviderV2 createOrderingProviderDTO() {
        ArrayList<String> networkCodes = new ArrayList<>();
        networkCodes.add(PC_ENROLLMENT_NETWORK_CODE);
        ArrayList<String> specialtyCodes = new ArrayList<>();
        specialtyCodes.add(PC_SPECIALTY_CODE);

        return createOrderingProviderDTO(PC_MEMBER_CLIENT_ID, PC_ENROLLMENT_INSURANCE_STATE_CODE, PC_PLACE_OF_SERVICE_CODE, networkCodes, specialtyCodes);
    }

    public OrderingProviderV2 createOrderingProviderDTO(Integer clientId, String stateCode, String placeOfServiceCode, ArrayList<String> networkCodes, ArrayList<String> specialtyCodes) {
        OrderingProviderV2 ordering = new OrderingProviderV2();

        ordering.setClientId(clientId);
        ordering.setStateCode(stateCode);
        ordering.setPlaceOfServiceCode(placeOfServiceCode);
        ordering.setNetworkCodes(networkCodes);
        ordering.setSpecialtyCodes(specialtyCodes);

        return ordering;
    }
}
