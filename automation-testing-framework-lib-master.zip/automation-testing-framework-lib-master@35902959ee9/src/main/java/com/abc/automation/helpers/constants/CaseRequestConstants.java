package com.abc.automation.helpers.constants;

public class CaseRequestConstants {

    /**
     * Path parameters used for case request creation
     */
    public static final String CASE_REQUEST_IDENTIFIER_PATH_PARAM = "caseRequestIdentifier";
    public static final String CASE_REQUEST_ID_PATH_PARAM = "caseRequestId";
}
