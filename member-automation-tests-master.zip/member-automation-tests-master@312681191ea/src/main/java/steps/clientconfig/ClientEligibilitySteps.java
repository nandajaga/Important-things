package steps.clientconfig;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.ErrorSpringDTO;
import dtos.clientconfig.ClientEligibilitySystemDTO;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

import static helpers.constants.BasePathConstants.*;

/**
 * Created by RKondakova on 7/4/2019.
 */
public class ClientEligibilitySteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public ClientEligibilitySteps(String platformContextHeader, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BASE_PATH_GET_CLIENT_ELIGIBILITY);
        requestSpecification.addPlatformContextToRequest(platformContextHeader);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    public ClientEligibilitySystemDTO getClientEligibility(String clientId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        if (clientId != null) pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);
        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_OK);

        return result.as(ClientEligibilitySystemDTO.class);
    }

    public ErrorDTO getMemberEligibilityResponseNegativeErrorWithoutCheckForNull(String clientId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorDTO.class);
    }

    public ErrorSpringDTO getMemberEligibilityResponseNegativeErrorSpring(String clientId){
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorSpringDTO.class);
    }
}
