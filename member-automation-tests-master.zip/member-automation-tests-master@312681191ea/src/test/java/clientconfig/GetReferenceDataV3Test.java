package clientconfig;

import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.clientconfig.ReferenceDataV3DTO;
import helpers.constants.BasePathConstants;
import helpers.dataproviders.DataProviders;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import steps.clientconfig.ClientReferencesDataSteps;
import java.util.ArrayList;
import java.util.List;

import static helpers.constants.ClientConfigConstants.*;
import static helpers.constants.Constants.CLIENT_ID_85;
import static helpers.constants.Constants.SS_NASCO;
import static helpers.constants.ErrorMessagesForMemberEndpointsConstants.*;
import static org.apache.http.HttpStatus.SC_BAD_REQUEST;

/**
 * Created by VBaliyska on 8/19/2019.
 */
public class GetReferenceDataV3Test extends GetTests {

    private PlatformContextUtils platformContextUtils;

    @BeforeClass
    public void init() {
        basePath = BasePathConstants.BASE_PATH_REFERENCES_DATA_V3;
        pathParamsMap.clear();
        pathParamsMap.put("clientId", CLIENT_ID_85);
    }


    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test(dataProvider = "clientId-85-210-212-220", dataProviderClass = DataProviders.class)
    public void whenGetForValidClientIdThenServiceReturnsAllRelatedReferenceDataSC200(String clientId) {

        ReferenceDataV3DTO referenceDataV3DTO = new ClientReferencesDataSteps(platformContextHeader, headers).getReferenceDataWithClientIdTests(clientId);

        softly.then(referenceDataV3DTO.getAllowedBusinessIndicators()).isNotNull();

        softly.then(referenceDataV3DTO.getAllowedClientDependentRelationCodes().get(0).getKey()).isEqualTo("E");
        softly.then(referenceDataV3DTO.getAllowedClientDependentRelationCodes().get(1).getKey()).isEqualTo("S");
        softly.then(referenceDataV3DTO.getAllowedClientDependentRelationCodes().get(2).getKey()).isEqualTo("C");
        softly.then(referenceDataV3DTO.getAllowedClientDependentRelationCodes().get(3).getKey()).isEqualTo("O");
        softly.then(referenceDataV3DTO.getAllowedClientDependentRelationCodes().get(0).getValue()).isEqualTo(SUBSCRIBER);
        softly.then(referenceDataV3DTO.getAllowedClientDependentRelationCodes().get(1).getValue()).isEqualTo(SPOUSE);
        softly.then(referenceDataV3DTO.getAllowedClientDependentRelationCodes().get(2).getValue()).isEqualTo(CHILD);
        softly.then(referenceDataV3DTO.getAllowedClientDependentRelationCodes().get(3).getValue()).isEqualTo(OTHER);

        softly.then(referenceDataV3DTO.getAllowedFundingTypes()).isNotNull();
        softly.then(referenceDataV3DTO.getAllowedNetworkCodes()).isNotNull();
        softly.then(referenceDataV3DTO.getAllowedProgramTypes().get(0)).isEqualTo("UM");
        softly.then(referenceDataV3DTO.getAllowedSourceSystems()).isNotNull();
        softly.then(referenceDataV3DTO.getClientFundingType()).isNotNull();
        softly.then(referenceDataV3DTO.getClientBusinessMarketSegment()).isNotNull();


        if (clientId.equals(CLIENT_ID_85)) {
            softly.then(referenceDataV3DTO.getAllowedNetworkCodes().size()).isEqualTo(807);
            softly.then(referenceDataV3DTO.getAllowedSourceSystems().get(0)).isEqualTo(ALLOWED_SOURCE_SYSTEMS_FACETS);
            softly.then(referenceDataV3DTO.getAllowedSourceSystems().get(1)).isEqualTo(ALLOWED_SOURCE_SYSTEMS_ISG);
            softly.then(referenceDataV3DTO.getAllowedSourceSystems().get(2)).isEqualTo(ALLOWED_SOURCE_SYSTEMS_NASCO);
            softly.then(referenceDataV3DTO.getAllowedSourceSystems().get(3)).isEqualTo(ALLOWED_SOURCE_SYSTEMS_WGS);
        }

        if(clientId.equals(CLIENT_ID_220)){ 
            for(int i=0;i<clientFundingTypeCode.length;i++){
                softly.then(referenceDataV3DTO.getClientFundingType().get(i).getClientFundingTypeCode()).isEqualTo(clientFundingTypeCode[i]);
            }

            for(int i=0;i<clientFundType.length;i++) {
                softly.then(referenceDataV3DTO.getClientFundingType().get(i).getFundType()).isEqualTo(clientFundType[i]);
            }

            softly.then(referenceDataV3DTO.getClientBusinessMarketSegment().get(0)).isEqualTo(CLIENT_BUSINESS_MARKET_SEGMENT_LARGEGROUP);
            softly.then(referenceDataV3DTO.getClientBusinessMarketSegment().get(1)).isEqualTo(CLIENT_BUSINESS_MARKET_SEGMENT_MIDMARKET);
            softly.then(referenceDataV3DTO.getClientBusinessMarketSegment().get(2)).isEqualTo(CLIENT_BUSINESS_MARKET_SEGMENT_SMALLGROUP);
            softly.then(referenceDataV3DTO.getClientBusinessMarketSegment().get(3)).isEqualTo(CLIENT_BUSINESS_MARKET_SEGMENT_RETAIL);
            softly.then(referenceDataV3DTO.getClientBusinessMarketSegment().get(4)).isEqualTo(CLIENT_BUSINESS_MARKET_SEGMENT_NMCC);
            softly.then(referenceDataV3DTO.getAllowedNetworkCodes().get(0)).isEqualTo(CLIENT_220_NETWORK_CODE_BAV);
            softly.then(referenceDataV3DTO.getAllowedNetworkCodes().get(1)).isEqualTo(CLIENT_220_NETWORK_CODE_CNN);
            softly.then(referenceDataV3DTO.getAllowedNetworkCodes().get(2)).isEqualTo(CLIENT_220_NETWORK_CODE_EPN);
            softly.then(referenceDataV3DTO.getAllowedNetworkCodes().get(3)).isEqualTo(CLIENT_220_NETWORK_CODE_HMO);
            softly.then(referenceDataV3DTO.getAllowedNetworkCodes().get(4)).isEqualTo(CLIENT_220_NETWORK_CODE_HPN);
            softly.then(referenceDataV3DTO.getAllowedNetworkCodes().get(5)).isEqualTo(CLIENT_220_NETWORK_CODE_MCD);
            softly.then(referenceDataV3DTO.getAllowedNetworkCodes().get(6)).isEqualTo(CLIENT_220_NETWORK_CODE_NL1);
            softly.then(referenceDataV3DTO.getAllowedNetworkCodes().get(7)).isEqualTo(CLIENT_220_NETWORK_CODE_NL2);
            softly.then(referenceDataV3DTO.getAllowedNetworkCodes().get(8)).isEqualTo(CLIENT_220_NETWORK_CODE_PPO);
        }

        softly.then(referenceDataV3DTO.getAllowedStatesOfIssuance()).isNotNull();

        softly.assertAll();
    }

    @Test(dataProvider = "client-ids-client-config", dataProviderClass = DataProviders.class)
    public void whenGetClientId184And185And186ThenServiceReturnsMixerCodeEnabledTrue(String clientId) {
        ReferenceDataV3DTO referenceDataV3DTO = new ClientReferencesDataSteps(platformContextHeader, headers).getReferenceDataWithClientIdTests(clientId);

        softly.then(referenceDataV3DTO.getAllowedBusinessIndicators()).isNotNull();
        softly.then(referenceDataV3DTO.getAllowedFundingTypes()).isNotNull();
        softly.then(referenceDataV3DTO.getAllowedNetworkCodes()).isNotNull();

        switch (clientId) {
            case CLIENT_ID_184:
            case CLIENT_ID_185:
            case CLIENT_ID_186:
                softly.then(referenceDataV3DTO.getMixerCodeEnabled()).isTrue();
                break;
            default:
                softly.then(referenceDataV3DTO.getMixerCodeEnabled()).isFalse();
                break;
        }
        softly.assertAll();
    }

    @Test(dataProvider = "solutionId", dataProviderClass = DataProviders.class)
    public void whenGetClientId184WithAnySolutionThenMixerCodeEnabledTrue(String solutionId) {
        platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeSolutionId(platformContextHeader, solutionId);

        ReferenceDataV3DTO referenceDataV3DTO = new ClientReferencesDataSteps(platformContextHeader, headers).getReferenceDataWithClientIdTests(CLIENT_ID_184);

        softly.then(referenceDataV3DTO.getAllowedBusinessIndicators()).isNotNull();
        softly.then(referenceDataV3DTO.getAllowedFundingTypes()).isNotNull();
        softly.then(referenceDataV3DTO.getAllowedNetworkCodes()).isNotNull();
        softly.then(referenceDataV3DTO.getMixerCodeEnabled()).isTrue();
        softly.assertAll();
    }

    @Test(dataProvider = "anthem-west-clients-184-185-186-mixer-code-change", dataProviderClass = DataProviders.class)
    public void whenGetClientIdAnthemWestThenNoNASCOIsNotAvailableInAllowedSourceSystemAndResponseSC200(String clientId) {

        ReferenceDataV3DTO referenceDataV3DTO = new ClientReferencesDataSteps(platformContextHeader, headers).getReferenceDataWithClientIdTests(clientId);

        softly.then(referenceDataV3DTO.getAllowedSourceSystems()).isNotNull().isNotEmpty();
        softly.then(referenceDataV3DTO.getAllowedSourceSystems()).doesNotContain(SS_NASCO);
        softly.assertAll();

    }

    @Test(dataProvider = "clientId-85-183-184-185-187-188-199-210", dataProviderClass = DataProviders.class)
    public void whenGetForValidClientIdThenServiceReturnsAllRelatedReferenceDataSC200_SOC(String clientId) {

        ReferenceDataV3DTO referenceDataV3DTO = new ClientReferencesDataSteps(platformContextHeader, headers).getReferenceDataWithClientIdTests(clientId);

        switch (clientId) {
            case CLIENT_ID_85:
            case CLIENT_ID_183:
            case CLIENT_ID_184:
            case CLIENT_ID_185:
            case CLIENT_ID_187:
            case CLIENT_ID_188:
                softly.then(referenceDataV3DTO.getAllowedReviewPrograms()).isNotNull();
                softly.then(referenceDataV3DTO.getAllowedReviewPrograms().get(0).getKey()).isEqualTo(REVIEW_PROGRAM_CODE);
                softly.then(referenceDataV3DTO.getAllowedReviewPrograms().get(0).getValue()).isEqualTo(SITE_OF_CARE);
                break;
            case CLIENT_ID_199:
            case CLIENT_ID_210:
                softly.then(referenceDataV3DTO.getAllowedReviewPrograms()).isEmpty();
                break;
        }
        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-400-----------------------------------------

    @Test(dataProvider = "clientIdSearch", dataProviderClass = DataProviders.class)
    public void whenGetAndInputInvalidClientIdThenReturnStatus400(String clientId) {

        ErrorDTO errorDTO = new ClientReferencesDataSteps(platformContextHeader, headers).getReferenceDataForNegativeTestsErrorDTO(clientId);

        softly.then(errorDTO.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.then(errorDTO.getMessage()).isEqualTo(ERR_MSG_LIST_POVIDE_VALID_FORMAT_CLIENT_ID);
        softly.assertAll();
    }

    @Test
    public void whenGetWithMissingChannelCodeThenReturnStatus400() {

        platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeChannelCode(platformContextHeader, null);

        ErrorDTO errorDTO = new ClientReferencesDataSteps(platformContextHeader, headers).getReferenceDataForNegativeTestsErrorDTO(CLIENT_ID_85);

        softly.then(errorDTO.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.then(errorDTO.getMessage()).isEqualTo(ERR_MSG_CHANNEL_CODE);
        softly.assertAll();
    }

    @Test
    public void whenGetWithMissingClientIdThenReturnStatus400() {

        platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, null);

        ErrorDTO errorDTO = new ClientReferencesDataSteps(platformContextHeader, headers).getReferenceDataForNegativeTestsErrorDTO(CLIENT_ID_85);

        softly.then(errorDTO.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.then(errorDTO.getMessage()).isEqualTo(ERR_MSG_CLIENT_ID);
        softly.assertAll();
    }
}
