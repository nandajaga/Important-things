package com.abc.automation.steps.member.datamanager;

import com.abc.automation.factories.member.MemberDTOFactory;
import com.abc.automation.helpers.CustomFilterableRequestSpecification;
import com.abc.automation.helpers.EnvironmentHelper;
import com.abc.automation.helpers.RequestOperationsHelper;
import com.abc.automation.helpers.constants.BasePathConstants;
import com.abc.automation.helpers.enums.DomainEnum;
import com.abc.automation.dtos.member.MemberResponseDTO;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by PPetarcheva on 4/17/2019.
 */
public class CreateMemberSteps {

    private RequestOperationsHelper requestOperationsHelper;

    private CustomFilterableRequestSpecification requestSpecification;

    public CreateMemberSteps(String platformContext, Headers headers) {
        requestSpecification = new CustomFilterableRequestSpecification();
        requestOperationsHelper = new RequestOperationsHelper();
        EnvironmentHelper environmentHelper = new EnvironmentHelper();

        requestSpecification.addBasePath(BasePathConstants.MEMBER_CREATE_BASE_PATH);
        requestSpecification.addPlatformContextToRequest(platformContext);

        requestSpecification.addBaseURI(environmentHelper.constructBaseURIForDomain(DomainEnum.MEMBER));
        requestSpecification.addHeaders(headers);
    }

    public CreateMemberSteps(CustomFilterableRequestSpecification requestSpecification) {
        this.requestSpecification = new CustomFilterableRequestSpecification();
        requestOperationsHelper = new RequestOperationsHelper();
        EnvironmentHelper environmentHelper = new EnvironmentHelper();

        Headers headers = requestSpecification.getFilterableRequestSpecification().getHeaders();

        this.requestSpecification.addHeaders(headers);
        this.requestSpecification.addBasePath(BasePathConstants.MEMBER_CREATE_BASE_PATH);
        this.requestSpecification.addBaseURI(environmentHelper.constructBaseURIForDomain(DomainEnum.MEMBER));
    }

    public Response createMemberResponse(String clientId) {

        return createMemberResponse(clientId, null);
    }

    public Response createMemberResponse(String clientId, String alternateBenefitPlanCode) {

        return createMemberResponse(clientId, alternateBenefitPlanCode, null, null);
    }

    public Response createMemberResponse(String clientId, String alternateBenefitPlanCode, String erisaIndicator, String caseFundType) {
        Map<String, String> pathParams = new HashMap<>();
        pathParams.put("clientId", clientId);

        MemberDTOFactory memberDTOFactory = new MemberDTOFactory();
        Object body = memberDTOFactory.createMemberDTO(clientId, alternateBenefitPlanCode, erisaIndicator, caseFundType);

        requestSpecification.addPathParams(pathParams);
        requestSpecification.addBodyToRequest(body);

        return requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());
    }

    public MemberResponseDTO createMember(String clientId) {

        return createMember(clientId, null);
    }

    public MemberResponseDTO createMember(String clientId, String alternateBenefitPlanCode) {

        return createMember(clientId, alternateBenefitPlanCode, null, null);
    }

    public MemberResponseDTO createMember(String clientId, String alternateBenefitPlanCode, String erisaIndicator, String caseFundType) {
        Response result = createMemberResponse(clientId, alternateBenefitPlanCode, erisaIndicator, caseFundType);

        result.then().statusCode(HttpStatus.SC_CREATED);

        return result.as(MemberResponseDTO.class);
    }
    public String createMemberAndGetId(String clientId) {

        return createMemberAndGetId(clientId, null);
    }

    public String createMemberAndGetId(String clientId, String alternateBenefitPlanCode) {

        return createMemberAndGetId(clientId, alternateBenefitPlanCode, null, null);
    }

    public String createMemberAndGetId(String clientId, String alternateBenefitPlanCode, String erisaIndicator, String caseFundType) {
        MemberResponseDTO memberResponseDTO = createMember(clientId, alternateBenefitPlanCode, erisaIndicator, caseFundType);

        return memberResponseDTO.getId();
    }
}
