package dtos;

public class RestrictedAccessResponseDTOV2 {
    private boolean isRestricted;
    private String restrictionType;

    public boolean getIsRestricted() {
        return isRestricted;
    }
    public void setIsRestricted(boolean isRestricted) {
        this.isRestricted = isRestricted;
    }

    public String getRestrictionType() {
        return restrictionType;
    }
    public void setRestrictionType(String restrictionType) {
        this.restrictionType = restrictionType;
    }
}
