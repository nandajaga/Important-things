package enrollments.snapshots;

import com.aim.automation.tests.base.PostTests;
import dtos.ErrorDTO;
import dtos.datamanager.MemberResponseDTO;
import dtos.enrollments.MemberEnrollmentsDTO;
import dtos.enrollments.SolutionDTO;
import dtos.enrollments.snapshots.MemberEnrollmentsSnapshotDTO;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.datamanager.MemberDataManagerSteps;
import steps.enrollments.MemberEnrollmentsSteps;
import steps.enrollments.snapshots.MemberEnrollmentSnapshotCreateSteps;

import java.util.ArrayList;

import static helpers.constants.BasePathConstants.BASE_PATH_CREATE_ENROLLMENT_SNAPSHOT;
import static helpers.constants.ClientConfigConstants.CLIENT_ID_184;
import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_186;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_85;
import static org.apache.http.HttpStatus.SC_NOT_FOUND;

/**
 * Created by RKondakova on 4/25/2019.
 */
public class PostMemberEnrollmentSnapshotTest extends PostTests {

    private MemberDataManagerSteps memberDataManagerSteps;
    private MemberEnrollmentsSteps memberEnrollmentsSteps;
    private MemberEnrollmentsSnapshotDTO memberEnrollmentsSnapshotDTO;
    private MemberEnrollmentSnapshotCreateSteps memberEnrollmentSnapshotCreateSteps;

    private static final String SOLUTION_ID_ONE = "1";
    private static final String SOLUTION_ID_TWO = "2";
    private String CLIENT_MEMBER_ID;

    @BeforeMethod
    public void initMethod() {
        CLIENT_MEMBER_ID = RandomStringUtils.randomNumeric(10) + RandomStringUtils.randomAlphabetic(5).toUpperCase();
    }

    @BeforeClass
    public void init() {
        basePath = BASE_PATH_CREATE_ENROLLMENT_SNAPSHOT;

        pathParamsMap.clear();
        pathParamsMap.put("clientId", CLIENT_ID_85);
        pathParamsMap.put("memberId", MEMBER_ID_REAL);
        pathParamsMap.put("enrollmentId", ENROLLMENT_ID_REAL);
        body = "";
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test
    public void whenPostAndValidClientIdAndMemberIdAndEnrollmentIdSentThenServiceCreateEnrollmentSnapshot() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        memberEnrollmentsSnapshotDTO = new MemberEnrollmentsSnapshotDTO();
        memberEnrollmentSnapshotCreateSteps = new MemberEnrollmentSnapshotCreateSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_85, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_85, memberId);

        String enrollmentId = memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId();

        memberEnrollmentsSnapshotDTO = memberEnrollmentSnapshotCreateSteps.createMemberEnrollmentSnapshot(CLIENT_ID_85, memberId, enrollmentId);

        String snapshotId = memberEnrollmentsSnapshotDTO.getSnapshotId();
        softly.then(snapshotId).isNotEmpty().isNotBlank().isNotNull();

        softly.then(memberEnrollmentsSnapshotDTO.getSnapshotId()).isEqualTo(snapshotId);
        softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getEnrollmentId()).isEqualTo(enrollmentId);
        softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getClientId()).isEqualTo(CLIENT_ID_85);
        softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getHealthPlan()).isEqualTo(HEALTHPLAN_AUTHEM_CR);

        ArrayList<SolutionDTO> solutions = memberEnrollmentsSnapshotDTO.getMemberEnrollment().getSolutions();

        for (SolutionDTO solution : solutions) {
            if (solution.isLevelOfCare() && solution.getProgramType().equals(SOLUTION_PROGRAM_TYPE)) {
                softly.then(solution.getSolutionId()).isIn(SOLUTION_ID_ONE, SOLUTION_ID_TWO);
            }
        }

        softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getClientMemberProductCode()).isEqualTo(CLIENT_MEMBER_PRODUCT_CODE);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientMemberProductCode()).isEqualTo(CLIENT_MEMBER_PRODUCT_CODE);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getErisaIndicator()).isNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMarketSegmentCode()).isNull();


        softly.assertAll();
    }

    @Test
    public void whenPostAndValidClientIdAndMemberIdAndMixerCodeAndClientMPCSentThenServiceCreateEnrollmentSnapshotClient_184() {

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        memberEnrollmentsSnapshotDTO = new MemberEnrollmentsSnapshotDTO();
        memberEnrollmentSnapshotCreateSteps = new MemberEnrollmentSnapshotCreateSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_184, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_184, memberId);

        String enrollmentId = memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId();

        memberEnrollmentsSnapshotDTO = memberEnrollmentSnapshotCreateSteps.createMemberEnrollmentSnapshot(CLIENT_ID_184, memberId, enrollmentId);

        String snapshotId = memberEnrollmentsSnapshotDTO.getSnapshotId();
        softly.then(snapshotId).isNotEmpty().isNotBlank().isNotNull();

        softly.then(memberEnrollmentsSnapshotDTO.getSnapshotId()).isEqualTo(snapshotId);
        softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getEnrollmentId()).isEqualTo(enrollmentId);
        softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getClientId()).isEqualTo(CLIENT_ID_184);
        softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getClientMemberProductCode()).isEqualTo(CLIENT_MEMBER_PRODUCT_CODE);
        softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getClientSpecificEnrollments().getMixerCode()).isEqualTo(MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAGHMO);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isEqualTo(MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAGHMO);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientMemberProductCode()).isEqualTo(CLIENT_MEMBER_PRODUCT_CODE);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getErisaIndicator()).isNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMarketSegmentCode()).isNull();
        softly.assertAll();
    }

    /* https://dbg-jira.antheminc.com/browse/OSPP-10841
     * ClientId - 186
     * HCSC - Implement snapshot changes for enrollments
     * Updated by Rkohli on 02/12/2020
     */
    @Test
    public void whenGetAndClientId186AndAdditionalFiledSentThenSC200() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        memberEnrollmentSnapshotCreateSteps = new MemberEnrollmentSnapshotCreateSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMemberWithSpecificClientIdAndAdditionalFields(CLIENT_ID_186, ADDITIONAL_FIELD_SUB_GROUP_CODE, ADDITIONAL_FIELD_CLIENT_ACCOUNT_NUMBER, ADDITIONAL_FIELD_CLIENT_LINE_OF_BUSINESS_CODE, ADDITIONAL_FIELD_BUSINESS_MARKET_SEGMENT_NAME, ADDITIONAL_FIELD_ALTERNATE_BENEFIT_PLAN_CODE, true, ADDITIONAL_FIELD_CLIENT_ACCOUNT_NAME, ADDITIONAL_FIELD_CLIENT_FUNDING_TYPE_CODE, CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_186, memberId);

        String enrollmentId = memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId();

        memberEnrollmentsSnapshotDTO = memberEnrollmentSnapshotCreateSteps.createMemberEnrollmentSnapshot(CLIENT_ID_186, memberId, enrollmentId);

        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getAdditionalFields().get(0).getKey()).isNotEmpty();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getAdditionalFields().get(0).getValue()).isNotNull();
        softly.assertAll();
    }
    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-404---------------------------------------------

    @Test
    public void whenPostAndValidClientId85AndInvalidMemberIdSentThenServiceReturnsErrorOnSnapshotEnrollments() {
        memberEnrollmentSnapshotCreateSteps = new MemberEnrollmentSnapshotCreateSteps(platformContextHeader, headers);


        ErrorDTO error = memberEnrollmentSnapshotCreateSteps.createSnapshotEnrollmentErrors(CLIENT_ID_85, MEMBER_ID_TEST, ENROLLMENT_ID_REAL);

        softly.then(error.getCode()).isEqualTo(SC_NOT_FOUND);
        softly.then(error.getMessage()).contains(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }

    @Test
    public void whenPostAndValidClientId85AndMemberIdAndInvalidEnrollmentIdSentThenServiceReturnsErrorOnSnapshotEnrollments() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        memberEnrollmentSnapshotCreateSteps = new MemberEnrollmentSnapshotCreateSteps(platformContextHeader, headers);


        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_85, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_85, memberId);

        ErrorDTO error = memberEnrollmentSnapshotCreateSteps.createSnapshotEnrollmentErrors(CLIENT_ID_85, memberId, ENROLLMENT_ID_TEST);

        softly.then(error.getCode()).isEqualTo(SC_NOT_FOUND);
        softly.then(error.getMessage()).contains(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }

    @Override
    public void whenPostWithNoBodyThenServiceReturnsBadRequest() {
        // No need to do anything here
        // This endpoint does not have body
    }
}
