package com.abc.automation.helpers.constants;

public class ClinicalPreClinicalConstants {

    //Clinical PreClinical constants
    public static final String REQUEST_TYPE = "Initial";
    public static final String REQUEST_TYPE_ZERO = "Zero";
    public static final String INITIAL_BASE_VISITS = "2";
    public static final String SECOND_TOOL_INITIAL_BASE_VISITS = "6";
    public static final String IMPROVEMENT_PERCENTAGE = "10";
    public static final String VERSION = "1";
    public static final String FIRST_TOOL_ID = "1";
    public static final String FIRST_TOOL_NAME = "2MWT - 2 Minute walk test";
    public static final String SCORE = "10";
    public static final String FIRST_TOOL_CLINICAL_CATEGORY = "Cardio";
    public static final String SECOND_TOOL_ID = "4";
    public static final String SECOND_TOOL_NAME = "Bayley Scales of Infant and Toddler Development-III (ed 3) (Bayley-III)";
    public static final String SECOND_TOOL_CLINICAL_CATEGORY = "EarlyIntv";
    public static final String PRECLINICAL_EVALUATION_DATE = "2019-04-17T07:48:42.108Z";
    public static final String PRECLINICAL_SNAPSHOT_ID = "1a8209eb-154e-4afc-91d1-6f98331e7c9a";

    //Clinical Decision constants
    public static final String CLINICAL_DECISION_APPROVE = "approve";
    public static final String CLINICAL_DECISION_REVIEW = "review";
    public static final String CLINICAL_DECISION_ID = "11";
    public static final String TYPE_OF_SERVICE = "Pain";
    public static final String ADDITIONAL_INFORMATION_REASON = "valid reason";
    public static final String ADDITIONAL_INFORMATION_REASON_LOI = "LOI";
}