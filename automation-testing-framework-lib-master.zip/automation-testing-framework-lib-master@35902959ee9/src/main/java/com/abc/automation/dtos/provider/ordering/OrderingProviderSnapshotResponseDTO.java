package com.abc.automation.dtos.provider.ordering;

import com.abc.automation.dtos.provider.ClientSpecificAttributesDTO;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderingProviderSnapshotResponseDTO {

    private AddressSearchDTO address;
    private Integer clientId;
    private String clientName;
    private String clientPhysicianId;
    private String clientPhysicianNumber;
    private String email;
    private String fax;
    private String firstName;
    private Date fromDate;
    private List<IdentifierDTO> identifier;
    private boolean isManual;
    private Boolean isSanctioned;
    private boolean isServicingProvider;
    private String lastName;
    private String networkStatus;
    private String ngProviderId;
    private List<NpiDTO> npi;
    private String orderingProvLocID;
    private String phone;
    private String providerGroupId;
    private Boolean sanctionLookupCompletedFlag;
    private boolean sanctionLookupRequiredFlag;
    private String sanctionReviewAnswerSnapshotId;
    private boolean sanctionedThroughReviewFlag;
    private String snapshotId;
    private Integer specialtyCode;
    private Date thruDate;
    private List<String> tin;
    private int providerClientId;
    private List<ClientSpecificAttributesDTO> clientSpecificAttributes;


    public List<ClientSpecificAttributesDTO> getClientSpecificAttributes() {
        return clientSpecificAttributes;
    }

    public void setClientSpecificAttributes(List<ClientSpecificAttributesDTO> clientSpecificAttributes) {
        this.clientSpecificAttributes = clientSpecificAttributes;
    }

    public AddressSearchDTO getAddress() {
        return address;
    }

    public void setAddress(AddressSearchDTO address) {
        this.address = address;
    }

    public Integer getClientId() {
        return clientId;
    }

    public void setClientId(Integer clientId) {
        this.clientId = clientId;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getClientPhysicianId() {
        return clientPhysicianId;
    }

    public void setClientPhysicianId(String clientPhysicianId) {
        this.clientPhysicianId = clientPhysicianId;
    }

    public String getClientPhysicianNumber() {
        return clientPhysicianNumber;
    }

    public void setClientPhysicianNumber(String clientPhysicianNumber) {
        this.clientPhysicianNumber = clientPhysicianNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public Date getFromDate() {
        return new Date(fromDate.getTime());
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = new Date(fromDate.getTime());
    }

    public List<IdentifierDTO> getIdentifier() {
        if (identifier != null) {
            return new ArrayList<>(identifier);
        } else {
            return null;
        }
    }

    public void setIdentifier(List<IdentifierDTO> identifier) {
        if (identifier != null) {
            this.identifier = new ArrayList<>(identifier);
        } else {
            this.identifier = null;
        }
    }

    public boolean getIsManual() {
        return isManual;
    }

    public void setIsManual(boolean manual) {
        isManual = manual;
    }

    public Boolean getIsSanctioned() {
        return isSanctioned;
    }

    public void setIsSanctioned(Boolean sanctioned) {
        isSanctioned = sanctioned;
    }

    public boolean getIsServicingProvider() {
        return isServicingProvider;
    }

    public void setIsServicingProvider(boolean servicingProvider) {
        isServicingProvider = servicingProvider;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getNetworkStatus() {
        return networkStatus;
    }

    public void setNetworkStatus(String networkStatus) {
        this.networkStatus = networkStatus;
    }

    public String getNgProviderId() {
        return ngProviderId;
    }

    public void setNgProviderId(String ngProviderId) {
        this.ngProviderId = ngProviderId;
    }

    public Integer getProviderClientId() {
        return providerClientId;
    }

    public void setProviderClientId(Integer providerClientId) {
        this.providerClientId = providerClientId;
    }

    public List<NpiDTO> getNpi() {
        if (npi != null) {
            return new ArrayList<>(npi);
        } else {
            return null;
        }
    }

    public void setNpi(List<NpiDTO> npi) {
        if (npi != null) {
            this.npi = new ArrayList<>(npi);
        } else {
            this.npi = null;
        }
    }

    public String getOrderingProvLocID() {
        return orderingProvLocID;
    }

    public void setOrderingProvLocID(String orderingProvLocID) {
        this.orderingProvLocID = orderingProvLocID;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getProviderGroupId() {
        return providerGroupId;
    }

    public void setProviderGroupId(String providerGroupId) {
        this.providerGroupId = providerGroupId;
    }

    public Boolean getSanctionLookupCompletedFlag() {
        return sanctionLookupCompletedFlag;
    }

    public void setSanctionLookupCompletedFlag(Boolean sanctionLookupCompletedFlag) {
        this.sanctionLookupCompletedFlag = sanctionLookupCompletedFlag;
    }

    public boolean getSanctionLookupRequiredFlag() {
        return sanctionLookupRequiredFlag;
    }

    public void setSanctionLookupRequiredFlag(boolean sanctionLookupRequiredFlag) {
        this.sanctionLookupRequiredFlag = sanctionLookupRequiredFlag;
    }

    public String getSanctionReviewAnswerSnapshotId() {
        return sanctionReviewAnswerSnapshotId;
    }

    public void setSanctionReviewAnswerSnapshotId(String sanctionReviewAnswerSnapshotId) {
        this.sanctionReviewAnswerSnapshotId = sanctionReviewAnswerSnapshotId;
    }

    public boolean getSanctionedThroughReviewFlag() {
        return sanctionedThroughReviewFlag;
    }

    public void setSanctionedThroughReviewFlag(boolean sanctionedThroughReviewFlag) {
        this.sanctionedThroughReviewFlag = sanctionedThroughReviewFlag;
    }

    public String getSnapshotId() {
        return snapshotId;
    }

    public void setSnapshotId(String snapshotId) {
        this.snapshotId = snapshotId;
    }

    public Integer getSpecialtyCode() {
        return specialtyCode;
    }

    public void setSpecialtyCode(Integer specialtyCode) {
        this.specialtyCode = specialtyCode;
    }

    public Date getThruDate() {
        if (thruDate != null) {
            return new Date(thruDate.getTime());
        } else {
            return null;
        }
    }

    public void setThruDate(Date thruDate) {
        if (thruDate != null) {
            this.thruDate = new Date(thruDate.getTime());
        } else {
            this.thruDate = null;
        }
    }

    public List<String> getTin() {
        if (tin != null) {
            return new ArrayList<>(tin);
        } else {
            return null;
        }
    }

    public void setTin(List<String> tin) {
        if (tin != null) {
            this.tin = new ArrayList<>(tin);
        } else {
            this.tin = null;
        }
    }
}
