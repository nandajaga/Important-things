package dtos.clientconfig;

public class AgeBasedHardStopRequestDTOV3 {

    private int memberAge;

    public int getMemberAge() {
        return memberAge;
    }

    public void setMemberAge(int memberAge) {
        this.memberAge = memberAge;
    }
}
