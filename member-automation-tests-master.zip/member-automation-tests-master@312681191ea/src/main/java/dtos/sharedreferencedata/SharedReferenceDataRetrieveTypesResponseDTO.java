package dtos.sharedreferencedata;

import java.util.HashMap;

/**
 * Created by RKohli on 15/09/2020..
 */
public class SharedReferenceDataRetrieveTypesResponseDTO {

    private Integer displayOrder;
    private HashMap<String, Object> referenceData;
    private String[] clientProductCode;


    public HashMap<String, Object> getReferenceData() {
        return referenceData;
    }

    public void setReferenceData(HashMap<String, Object> referenceData) {
        this.referenceData = referenceData;
    }


    public Integer getDisplayOrder() {
        return displayOrder;
    }

    public void setDisplayOrder(Integer displayOrder) {
        this.displayOrder = displayOrder;
    }

    public String[] getClientProductCode() {
        return clientProductCode;
    }

    public void setClientProductCode(String[] clientProductCode) {
        this.clientProductCode = clientProductCode;
    }
}
