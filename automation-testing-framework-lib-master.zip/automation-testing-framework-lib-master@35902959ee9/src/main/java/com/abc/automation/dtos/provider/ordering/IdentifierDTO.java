package com.abc.automation.dtos.provider.ordering;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
public class IdentifierDTO {

    @JsonProperty(value = "Type")
    private String Type;

    @JsonProperty(value = "Value")
    private String value;

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        this.Type = type;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
