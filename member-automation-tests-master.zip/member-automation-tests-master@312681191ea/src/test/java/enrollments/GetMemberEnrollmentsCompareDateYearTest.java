package enrollments;

import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.datamanager.MemberResponseDTO;
import dtos.enrollments.MemberEnrollmentsDTO;
import helpers.dataproviders.DataProviders;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.datamanager.MemberDataManagerSteps;
import steps.enrollments.MemberEnrollmentsCompareDateYearSteps;

import static helpers.constants.BasePathConstants.BASE_PATH_ENROLLMENTS_COMPARE_YEAR;
import static helpers.constants.ClientConfigConstants.CLIENT_ID_184;
import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_186;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_210;
import static org.apache.http.HttpStatus.SC_BAD_REQUEST;
import static org.apache.http.HttpStatus.SC_NOT_FOUND;

/**
 * Created by RKondakova on 5/14/2019.
 * Modified by IAntonova on 8/1/2019
 */
public class GetMemberEnrollmentsCompareDateYearTest extends GetTests {

    private static final String BASE_ID_THREE = "3";
    private static final String BASE_ID_TWO = "2";
    private static final String BASE_ID_ONE = "1";
    private static final String ERROR_JAVA_LANG_EXCEPTION = "Failed to convert value of type 'java.lang.String' to required type 'java.lang.Integer'; nested exception is java.lang.NumberFormatException: For input string: \"0.1234656789\"";
    private static final String ERROR_JAVA_LANG_EXCEPTION_2 = "Failed to convert value of type 'java.lang.String' to required type 'java.util.Date'; nested exception is org.springframework.core.convert.ConversionFailedException: Failed to convert from type [java.lang.String] to type [@org.springframework.web.bind.annotation.RequestParam @org.springframework.format.annotation.DateTimeFormat java.util.Date] for value '1234-13-100'; nested exception is java.lang.IllegalArgumentException: Parse attempt failed for value [1234-13-100]";
    private MemberDataManagerSteps memberDataManagerSteps;
    private MemberEnrollmentsCompareDateYearSteps memberEnrollmentsCompareDateYearSteps;
    private String CLIENT_MEMBER_ID;

    @BeforeMethod
    public void initMethod() {
        CLIENT_MEMBER_ID = RandomStringUtils.randomNumeric(10) + RandomStringUtils.randomAlphabetic(5).toUpperCase();
    }

    @BeforeClass
    public void init() {
        basePath = BASE_PATH_ENROLLMENTS_COMPARE_YEAR;

        pathParamsMap.clear();
        pathParamsMap.put("clientId", CLIENT_ID_85);
        pathParamsMap.put("memberId", MEMBER_ID_REAL);
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test(dataProvider = "clientId-85-184", dataProviderClass = DataProviders.class)
    public void whenGetAndValidClientId85AndMemberIdAndCompareYearAndCompareDateSentThenServiceReturnsEnrollments(String clientId) {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsCompareDateYearSteps = new MemberEnrollmentsCompareDateYearSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(clientId, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsCompareDateYearSteps.getMemberEnrollmentsCompareYearDate(clientId, memberId, COMPARE_DATE, COMPARE_YEAR);

        if (clientId.equals(CLIENT_ID_184)) {
            softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isEqualTo(MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAGHMO);
            softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientMemberProductCode()).isEqualTo(CLIENT_MEMBER_PRODUCT_CODE);
        } else {
            softly.then(memberEnrollmentsDTO.getId()).contains(memberId);
            softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId()).isNotEmpty().isNotBlank().isNotNull();
            softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).contains(clientId);
            softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getHealthPlan()).contains(HEALTHPLAN_AUTHEM_CR);
            softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientMemberProductCode()).isEqualTo(CLIENT_MEMBER_PRODUCT_CODE);
        }

        softly.assertAll();
    }

    @Test
    public void whenGetAndValidClientId186AndBaseIdOneAndMemberIdAndCompareYearAndCompareDateSentThenServiceReturnsEnrollments() {

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsCompareDateYearSteps = new MemberEnrollmentsCompareDateYearSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_186, ISSUANCE_STATE_CA, SS_ISG, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsCompareDateYearSteps.getMemberEnrollmentsCompareYearDate(CLIENT_ID_186, memberId, COMPARE_DATE, COMPARE_YEAR);

        softly.then(memberEnrollmentsDTO.getId()).contains(memberId);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId()).isNotEmpty().isNotBlank().isNotNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).contains(CLIENT_ID_186);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getBaseId()).contains(BASE_ID_TWO);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getHealthPlan()).contains(HEALTHPLAN_AUTHEM_BC);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getIssuanceState()).contains(ISSUANCE_STATE_CA);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMedicalManagementSystem()).contains(MMS_WMDS);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getSourceSystem()).contains(SS_ISG);

        softly.assertAll();
    }

    @Test
    public void whenGetAndValidClientId186AndBaseIdTwoAndMemberIdAndCompareYearAndCompareDateSentThenServiceReturnsEnrollments() {

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsCompareDateYearSteps = new MemberEnrollmentsCompareDateYearSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_186, ISSUANCE_STATE_CA, SS_WGS, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsCompareDateYearSteps.getMemberEnrollmentsCompareYearDate(CLIENT_ID_186, memberId, COMPARE_DATE, COMPARE_YEAR);

        softly.then(memberEnrollmentsDTO.getId()).contains(memberId);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId()).isNotEmpty().isNotBlank().isNotNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).contains(CLIENT_ID_186);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getBaseId()).contains(BASE_ID_ONE);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getHealthPlan()).contains(HEALTHPLAN_AUTHEM_BC);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getIssuanceState()).contains(ISSUANCE_STATE_CA);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMedicalManagementSystem()).contains(MMS_WMDS);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getSourceSystem()).contains(SS_WGS);

        softly.assertAll();
    }

    @Test
    public void whenGetAndValidClientId186AndBaseIdThreeAndMemberIdAndCompareYearAndCompareDateSentThenServiceReturnsEnrollments() {

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsCompareDateYearSteps = new MemberEnrollmentsCompareDateYearSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_186, ISSUANCE_STATE_CA, SS_NASCO, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsCompareDateYearSteps.getMemberEnrollmentsCompareYearDate(CLIENT_ID_186, memberId, COMPARE_DATE, COMPARE_YEAR);

        softly.then(memberEnrollmentsDTO.getId()).contains(memberId);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId()).isNotEmpty().isNotBlank().isNotNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).contains(CLIENT_ID_186);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getBaseId()).contains(BASE_ID_THREE);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getHealthPlan()).contains(HEALTHPLAN_AUTHEM_BC);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getIssuanceState()).contains(ISSUANCE_STATE_CA);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMedicalManagementSystem()).contains(MMS_WMDS);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getSourceSystem()).contains(SS_NASCO);

        softly.assertAll();
    }

    @Test
    public void whenGetAndValidClientId210AndBaseIdOneAndMemberIdAndCompareYearAndCompareDateSentThenServiceReturnsEnrollments() {

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsCompareDateYearSteps = new MemberEnrollmentsCompareDateYearSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_210, ISSUANCE_STATE_CA, SS_NULL, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();
        softly.then(memberId).isNotEmpty().isNotBlank().isNotNull();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsCompareDateYearSteps.getMemberEnrollmentsCompareYearDate(CLIENT_ID_210, memberId, COMPARE_DATE, COMPARE_YEAR);

        softly.then(memberEnrollmentsDTO.getId()).contains(memberId);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId()).isNotEmpty().isNotBlank().isNotNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).contains(CLIENT_ID_210);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getBaseId()).contains(BASE_ID_ONE);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getIssuanceState()).contains(ISSUANCE_STATE_CA);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMedicalManagementSystem()).contains(MMS_FACET);

        softly.assertAll();
    }

    @Test()
    public void whenGetAndValidClientId210AndMemberIdWithMoreEnrollmentsWithoutCaseReviewCategoryThenReturnListOfEnrollments() {
        int numberOfEnrollments = 2;
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsCompareDateYearSteps = new MemberEnrollmentsCompareDateYearSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_210, EMPLOYER_GROUP_NUMBER, numberOfEnrollments, null, null, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();
        MemberEnrollmentsDTO memberEnrollmentsDTO = new MemberEnrollmentsCompareDateYearSteps(platformContextHeader, headers).getMemberEnrollmentsCompareYearDate(CLIENT_ID_210, memberId, COMPARE_DATE_2019, COMPARE_YEAR_3);

        softly.then(memberEnrollmentsDTO.getEnrollments().size()).isEqualTo(numberOfEnrollments);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId()).isNotEmpty().isNotBlank().isNotNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(1).getEnrollmentId()).isNotEmpty().isNotBlank().isNotNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId()).isNotSameAs(memberEnrollmentsDTO.getEnrollments().get(1).getEnrollmentId());
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getErisaIndicator()).isNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMarketSegmentCode()).isNull();
        softly.assertAll();
    }

    @Test(dataProvider = "contextModeValue", dataProviderClass = DataProviders.class)
    public void whenGetValidClientIdBaseIdOneAndMemberIdAndCompareYearAndCompareDateWithTestContextModeThenServiceReturnsEnrollments(String contextMode) {
        PlatformContextUtils platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeContextMode(platformContextHeader, contextMode);

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        //get enrollments from the same DB
        memberEnrollmentsCompareDateYearSteps = new MemberEnrollmentsCompareDateYearSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_210, ISSUANCE_STATE_CA, SS_NULL, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();
        softly.then(memberId).isNotEmpty().isNotBlank().isNotNull();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsCompareDateYearSteps.getMemberEnrollmentsCompareYearDate(CLIENT_ID_210, memberId, COMPARE_DATE, COMPARE_YEAR);

        softly.then(memberEnrollmentsDTO.getId()).contains(memberId);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId()).isNotEmpty().isNotBlank().isNotNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).contains(CLIENT_ID_210);
        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-404---------------------------------------------
    @Test(dataProvider = "contextModeInDataBase", dataProviderClass = DataProviders.class)
    public void whenGetValidCompareDateSentWithReversedContextModeThenServiceReturnsSC404(String contextMode, String dataBaseMode) {
        PlatformContextUtils platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeContextMode(platformContextHeader, contextMode);
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        //get enrollments from different DB
        platformContextHeader = platformContextUtils.changeContextMode(platformContextHeader, dataBaseMode);
        memberEnrollmentsCompareDateYearSteps = new MemberEnrollmentsCompareDateYearSteps(platformContextHeader, headers);
        ErrorDTO error = memberEnrollmentsCompareDateYearSteps.getMemberEnrollmentsCompareYearDateError(CLIENT_ID_85, MEMBER_ID_TEST, COMPARE_DATE, COMPARE_YEAR);

        softly.then(error.getCode()).isEqualTo(SC_NOT_FOUND);
        softly.then(error.getMessage()).contains(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }

    //TODO The next 2 tests should be adjusted when BUG NCP-21673. Currently they are added to cover the Negative test scenarios, but the DEV team should adjust the the Global Exception Handler, so we can remove the hardcoded status and message
//TODO BUG NCP-21678 is also related, Not enough validations of the Compare Year and Date is provided.
//    @Test
    public void whenGetAndNotValidCompareDateSentThenServiceReturnsNotFoundResponseSC404() {

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsCompareDateYearSteps = new MemberEnrollmentsCompareDateYearSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_210, ISSUANCE_STATE_CA, SS_NULL, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        ErrorDTO error = memberEnrollmentsCompareDateYearSteps.getMemberEnrollmentsCompareYearDateError(CLIENT_ID_210, memberId, COMPARE_DATE_INVALID, COMPARE_YEAR);

        softly.then(error.getStatus()).isEqualTo(SC_BAD_REQUEST);
        softly.then(error.getMessage()).contains(ERROR_JAVA_LANG_EXCEPTION_2);
        softly.assertAll();
    }

    //    @Test
    public void whenGetAndNotValidCompareYearSentThenServiceReturnsNotFoundResponseSC400() {

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsCompareDateYearSteps = new MemberEnrollmentsCompareDateYearSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_210, ISSUANCE_STATE_CA, SS_NULL, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();
        softly.then(memberId).isNotEmpty().isNotBlank().isNotNull();

        pathParamsMap.put("memberId", memberId);
        pathParamsMap.put("compareDate", COMPARE_DATE);
        pathParamsMap.put("compareYear", COMPARE_YEAR_TEST);
        ErrorDTO error = memberEnrollmentsCompareDateYearSteps.getMemberEnrollmentsCompareYearDateError(CLIENT_ID_210, memberId, COMPARE_DATE, COMPARE_YEAR_TEST);

        softly.then(error.getStatus()).isEqualTo(SC_BAD_REQUEST);
        softly.then(error.getMessage()).contains(ERROR_JAVA_LANG_EXCEPTION);
        softly.assertAll();
    }

    @Test
    public void whenGetAndNotValidMemberIdSentThenServiceReturnsNotFoundResponseSC404() {

        memberEnrollmentsCompareDateYearSteps = new MemberEnrollmentsCompareDateYearSteps(platformContextHeader, headers);
        ErrorDTO error = memberEnrollmentsCompareDateYearSteps.getMemberEnrollmentsCompareYearDateError(CLIENT_ID_85, MEMBER_ID_TEST, COMPARE_DATE, COMPARE_YEAR);

        softly.then(error.getCode()).isEqualTo(SC_NOT_FOUND);
        softly.then(error.getMessage()).contains(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }
}
