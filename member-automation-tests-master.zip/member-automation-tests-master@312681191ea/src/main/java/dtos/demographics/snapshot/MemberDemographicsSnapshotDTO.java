package dtos.demographics.snapshot;

import dtos.demographics.MemberDemographicsDTO;

/**
 * Created by VBaliyska on 5/9/2019.
 */
public class MemberDemographicsSnapshotDTO {

    private MemberDemographicsDTO memberDemographics;
    private String snapshotId;
    private String caseRequestId;
    private String caseId;

    public MemberDemographicsDTO getMemberDemographics() {
        return memberDemographics;
    }

    public void setMemberDemographics(MemberDemographicsDTO memberDemographics) {
        this.memberDemographics = memberDemographics;
    }

    public String getSnapshotId() {
        return snapshotId;
    }

    public void setSnapshotId(String snapshotId) {
        this.snapshotId = snapshotId;
    }

    public String getCaseRequestId() {
        return caseRequestId;
    }

    public void setCaseRequestId(String caseRequestId) {
        this.caseRequestId = caseRequestId;
    }

    public String getCaseId() {
        return caseId;
    }

    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }
}
