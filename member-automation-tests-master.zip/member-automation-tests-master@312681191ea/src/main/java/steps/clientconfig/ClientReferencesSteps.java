package steps.clientconfig;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.clientconfig.ClientConfigReferencesResponseDTO;
import helpers.constants.BasePathConstants;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by IAntonova on 7/3/2019.
 */

public class ClientReferencesSteps {
    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public ClientReferencesSteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();
        requestSpecification.addBasePath(BasePathConstants.BASE_PATH_CLIENT_REFERENCES);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    public ClientConfigReferencesResponseDTO getClientReferences(String clientId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);

        Response response = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());
        return response.as(ClientConfigReferencesResponseDTO.class);
    }

}
