package com.abc.automation.dtos.provider.servicing;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
public class CreateServicingProviderSnapshotDTO {

    private String ngProviderId;
    private Integer providerClientId;
    private PlaceOfServiceDTO placeOfService;
    private Boolean benefitExceptionRequested;
    private Boolean isBillingEntity;
    private BenefitExceptionPackageDTO benefitExceptionPackage;
    private boolean isOrderingProvider;
    private String order;
    private String labelType;
    private String networkStatus;
    private Boolean sanctionLookupCompletedFlag;
    private Boolean optOutLookupCompletedFlag;
    private String sanctionReviewAnswerSnapshotId;
    private String optOutReviewAnswerSnapshotId;
    private boolean isInNetworkRedirectProvider;
    private Boolean isSanctioned;
    private Boolean isOptedOut;
    private ReviewCategoryCodeDefinitionsDTO reviewCategoryCodeDefinitions;

    public PlaceOfServiceDTO getPlaceOfService() {
        return placeOfService;
    }

    public void setPlaceOfService(PlaceOfServiceDTO placeOfService) {
        this.placeOfService = placeOfService;
    }

    public Boolean getBenefitExceptionRequested() {
        return benefitExceptionRequested;
    }

    public void setBenefitExceptionRequested(Boolean benefitExceptionRequested) {
        this.benefitExceptionRequested = benefitExceptionRequested;
    }

    public String getNgProviderId() {
        return ngProviderId;
    }

    public void setNgProviderId(String ngProviderId) {
        this.ngProviderId = ngProviderId;
    }

    public Integer getProviderClientId() {
        return providerClientId;
    }

    public void setProviderClientId(Integer providerClientId) {
        this.providerClientId = providerClientId;
    }

    public BenefitExceptionPackageDTO getBenefitExceptionPackage() {
        return benefitExceptionPackage;
    }

    public void setBenefitExceptionPackage(BenefitExceptionPackageDTO benefitExceptionPackage) {
        this.benefitExceptionPackage = benefitExceptionPackage;
    }

    public Boolean getIsBillingEntity() {
        return isBillingEntity;
    }

    public void setIsBillingEntity(Boolean billingEntity) {
        this.isBillingEntity = billingEntity;
    }

    public boolean getIsOrderingProvider() {
        return isOrderingProvider;
    }

    public void setIsOrderingProvider(boolean isOrderingProvider) {
        this.isOrderingProvider = isOrderingProvider;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public String getLabelType() {
        return labelType;
    }

    public void setLabelType(String labelType) {
        this.labelType = labelType;
    }

    public String getNetworkStatus() {
        return networkStatus;
    }

    public void setNetworkStatus(String networkStatus) {
        this.networkStatus = networkStatus;
    }

    public Boolean getSanctionLookupCompletedFlag() {
        return sanctionLookupCompletedFlag;
    }

    public void setSanctionLookupCompletedFlag(Boolean sanctionLookupCompletedFlag) {
        this.sanctionLookupCompletedFlag = sanctionLookupCompletedFlag;
    }

    public Boolean getOptOutLookupCompletedFlag() {
        return optOutLookupCompletedFlag;
    }

    public void setOptOutLookupCompletedFlag(Boolean optOutLookupCompletedFlag) {
        this.optOutLookupCompletedFlag = optOutLookupCompletedFlag;
    }

    public String getSanctionReviewAnswerSnapshotId() {
        return sanctionReviewAnswerSnapshotId;
    }

    public void setSanctionReviewAnswerSnapshotId(String sanctionReviewAnswerSnapshotId) {
        this.sanctionReviewAnswerSnapshotId = sanctionReviewAnswerSnapshotId;
    }

    public String getOptOutReviewAnswerSnapshotId() {
        return optOutReviewAnswerSnapshotId;
    }

    public void setOptOutReviewAnswerSnapshotId(String optOutReviewAnswerSnapshotId) {
        this.optOutReviewAnswerSnapshotId = optOutReviewAnswerSnapshotId;
    }

    public boolean getIsInNetworkRedirectProvider() {
        return isInNetworkRedirectProvider;
    }

    public void setIsInNetworkRedirectProvider(boolean inNetworkRedirectProvider) {
        isInNetworkRedirectProvider = inNetworkRedirectProvider;
    }

    public Boolean getIsSanctioned() {
        return isSanctioned;
    }

    public void setIsSanctioned(Boolean sanctioned) {
        isSanctioned = sanctioned;
    }

    public Boolean getIsOptedOut() {
        return isOptedOut;
    }

    public void setIsOptedOut(Boolean optedOut) {
        isOptedOut = optedOut;
    }

    public ReviewCategoryCodeDefinitionsDTO getReviewCategoryCodeDefinitions() {
        return reviewCategoryCodeDefinitions;
    }

    public void setReviewCategoryCodeDefinitions(ReviewCategoryCodeDefinitionsDTO reviewCategoryCodeDefinitions) {
        this.reviewCategoryCodeDefinitions = reviewCategoryCodeDefinitions;
    }
}
