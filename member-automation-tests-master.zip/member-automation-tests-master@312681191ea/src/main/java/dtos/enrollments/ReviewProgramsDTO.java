package dtos.enrollments;

public class ReviewProgramsDTO {
    private String reviewProgramCode;

    public String getReviewProgramCode() {
        return reviewProgramCode;
    }

    public void setReviewProgramCode(String reviewProgramCode) {
        this.reviewProgramCode = reviewProgramCode;
    }
}