package com.abc.automation.helpers.enums.cases.caserequest;

/**
 * Created by HKirazyan on 4/23/2019
 */
public enum LockTypeEnum {
    LOCK("LOCK"),
    UNLOCK("UNLOCK"),
    ACQUIRELOCK("ACQUIRELOCK"),
    INVALID_LOCK_TYPE("SDFGHJKL");

    private String lockType;

    LockTypeEnum(String programType) {
        this.lockType = programType;
    }

    public String getLockType() {
        return lockType;
    }
}
