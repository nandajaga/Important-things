package com.abc.automation.dtos.provider.servicing;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class ReviewCategoryCodeDefinitionsDTO {

    private List<String> bodySystemCodes;
    @JsonProperty("displayInitialDisplay")
    private String displayInitialDisplay;
    @JsonProperty("displayJustificationQuestion")
    private String displayJustificationQuestion;
    private List<String> posCodes;
    @JsonProperty("reviewCategoryCode")
    private String reviewCategoryCode;
    private String reviewProgramCode;

    public List<String> getBodySystemCodes() {
        return bodySystemCodes;
    }

    public void setBodySystemCodes(List<String> bodySystemCodes) {
        this.bodySystemCodes = bodySystemCodes;
    }

    public String getDisplayInitialDisplay() {
        return displayInitialDisplay;
    }

    public void setDisplayInitialDisplay(String displayInitialDisplay) {
        this.displayInitialDisplay = displayInitialDisplay;
    }

    public String getDisplayJustificationQuestion() {
        return displayJustificationQuestion;
    }

    public void setDisplayJustificationQuestion(String displayJustificationQuestion) {
        this.displayJustificationQuestion = displayJustificationQuestion;
    }

    public List<String> getPosCodes() {
        return posCodes;
    }

    public void setPosCodes(List<String> posCodes) {
        this.posCodes = posCodes;
    }

    public String getReviewCategoryCode() {
        return reviewCategoryCode;
    }

    public void setReviewCategoryCode(String reviewCategoryCode) {
        this.reviewCategoryCode = reviewCategoryCode;
    }

    public String getReviewProgramCode() {
        return reviewProgramCode;
    }

    public void setReviewProgramCode(String reviewProgramCode) {
        this.reviewProgramCode = reviewProgramCode;
    }
}
