package com.abc.automation.factories.platformcontext;

import com.abc.automation.helpers.constants.PlatformContextConstants;
import com.abc.servicemodel.domain.Solution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class SolutionDTOFactory {
    private final static Logger LOGGER = LoggerFactory.getLogger(SolutionDTOFactory.class);

    public Solution createSolutionPCDTO() {
        DateFormat date = new SimpleDateFormat("yyyy-mm-dd");
        String timeStamp = PlatformContextConstants.PC_SOLUTION_START_DATE;
        Solution solution = new Solution();
        solution.setId(PlatformContextConstants.PC_SOLUTION_ID);
        try {
            solution.setDateOfService(date.parse(timeStamp));
        } catch (ParseException e) {
            LOGGER.error("An error occurred while parsing the time stamp {} \n", timeStamp, e);
        }

        return solution;
    }

    public Solution createSolutionPCDTO(int id, String timeStamp, DateFormat date) {
        Solution solution = new Solution();
        solution.setId(id);
        try {
            solution.setDateOfService(date.parse(timeStamp));
        } catch (ParseException e) {
            LOGGER.error("An error occurred while parsing the time stamp {} \n", timeStamp, e);
        }

        return solution;
    }
}
