package com.abc.automation.steps.base;

import com.abc.automation.helpers.CustomFilterableRequestSpecification;
import com.abc.automation.helpers.GeneralFunctionality;
import com.abc.automation.helpers.enums.RequestHeadersEnum;
import com.abc.automation.helpers.enums.platformcontext.PlatformContextVersionEnum;
import com.abc.automation.dtos.platformcontext.AbstractPlatformContext;
import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.http.Headers;

import java.util.ArrayList;

/**
 * Created by PPetarcheva on 3/19/2019.
 */
public class BasePreparationSteps {
    private GeneralFunctionality generalFunctionality;

    public BasePreparationSteps() {
        this.generalFunctionality = new GeneralFunctionality();
    }

    public Headers prepareHeadersWithMissingHeader(RequestHeadersEnum requestHeader, int length) {
        ArrayList<Header> headerList = new ArrayList<>();

        for (RequestHeadersEnum r : RequestHeadersEnum.values()) {
            if (r != requestHeader) {
                headerList.add(new Header(r.getName(), generalFunctionality.generateRandomString(length)));
            }
        }
        Headers headers = new Headers(headerList);
        return headers;
    }

    public Headers prepareHeadersWithMissingHeader(RequestHeadersEnum requestHeader) {
        return prepareHeadersWithMissingHeader(requestHeader, 3);
    }

    public String preparePlatformContext(PlatformContextVersionEnum platformContextVersion) {
        AbstractPlatformContext platformContext = new AbstractPlatformContext(platformContextVersion);

        return platformContext.getPlatformContextAsString();
    }

    /**
     * Here we set values to the mandatory headers described in RequestHeadersEnum file
     * Please note that as platform context has a more complex structure, a new validation was added so that a valid PC is added
     * Also we set content type to json
     *
     * @return returns the object that the mandatory headers were set to
     */
    public CustomFilterableRequestSpecification initializeRequestSpecification(Headers headers, String platformContext) {
        CustomFilterableRequestSpecification customFilterableRequestSpecification = new CustomFilterableRequestSpecification();

        customFilterableRequestSpecification.addHeaders(headers);
        customFilterableRequestSpecification.addPlatformContextToRequest(platformContext);
        customFilterableRequestSpecification.setContentType(ContentType.JSON);
        customFilterableRequestSpecification.setRelaxedHttpsValidation();

        return customFilterableRequestSpecification;
    }

    /*
    This method takes a PlatformContextVersionEnum of the PC version you want to use and returns a Request Specification with
    all of the required headers, including PC, Content type set to Json and relaxed Https validation.
     */
    public CustomFilterableRequestSpecification initializeRequestSpecification(PlatformContextVersionEnum platformContextVersion, boolean generateRandomHeader) {
        AbstractPlatformContext abstractPlatformContext = new AbstractPlatformContext(platformContextVersion);
        String platformContextHeader = abstractPlatformContext.getPlatformContextAsString();
        Headers headers = prepareHeadersWithMissingHeader(RequestHeadersEnum.PLATFORM_CONTEXT, 10);

        return initializeRequestSpecification(headers, platformContextHeader);
    }


}
