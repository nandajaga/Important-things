package steps.clientconfig;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.clientconfig.MemberRestrictionRequestDTO;
import dtos.clientconfig.RestrictionTypeResponseDTO;
import factories.clientconfig.MemberRestrictionDTOFactory;
import helpers.constants.BasePathConstants;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static helpers.constants.Constants.USER_LOC_CODE;

/**
 * created by sbioi 06/28/2021
 */
public class MemberSearchRestrictionV4Steps {

        private RequestOperationsHelper requestOperationsHelper;
        private CustomFilterableRequestSpecification requestSpecification;

        public MemberSearchRestrictionV4Steps(String platformContext, Headers headers){
            requestOperationsHelper = new RequestOperationsHelper();
            requestSpecification = new CustomFilterableRequestSpecification();

            requestSpecification.addBasePath(BasePathConstants.BASE_PATH_V4_MEMBER_SEARCH_RESTRICTION);
            requestSpecification.addPlatformContextToRequest(platformContext);
            requestSpecification.setContentType(ContentType.JSON);
            requestSpecification.addHeaders(headers);
        }

        public RestrictionTypeResponseDTO[] postMemberRestrictionRequest(String clientId, String employerGroupNumber, String dependentRelationCode, String restrictionType, String memberId,String issuanceStateCode, String lineOfBusinessCode,String userLocCode){
            Map<String,String> queryParam=new HashMap<>();
            queryParam.put(USER_LOC_CODE, userLocCode);
            requestSpecification.addQueryParams(queryParam);
            List<MemberRestrictionRequestDTO> requestBody = new MemberRestrictionDTOFactory().createSearchRestrictionRequestMemberDTO(clientId, employerGroupNumber, dependentRelationCode, restrictionType, memberId,issuanceStateCode,lineOfBusinessCode);
            requestSpecification.addBodyToRequest(requestBody);
            Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

            result.then().statusCode(HttpStatus.SC_OK);

            return result.as(RestrictionTypeResponseDTO[].class);
        }

        public ErrorDTO postMemberRestrictionRequestError(String clientId, String employerGroupNumber, String dependentRelationCode, String restrictionType, String memberId,String issuanceStateCode, String lineOfBusinessCode,String userLocCode) {
            Map<String,String> queryParam=new HashMap<>();
            queryParam.put(USER_LOC_CODE, userLocCode);
            requestSpecification.addQueryParams(queryParam);
            List<MemberRestrictionRequestDTO> requestBody = new MemberRestrictionDTOFactory().createSearchRestrictionRequestMemberDTO(clientId, employerGroupNumber, dependentRelationCode, restrictionType, memberId,issuanceStateCode,lineOfBusinessCode);
            requestSpecification.addBodyToRequest(requestBody);
            Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

            return result.as(ErrorDTO.class);
        }
    }

