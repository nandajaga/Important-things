package dtos.sharedreferencedata;

import java.util.HashMap;

/**
 * Created by RKohli on 15/09/2020.
 */
public class SharedReferenceDataDTO {


    private String effectiveStartDate;
    private HashMap<String, Object> searchCriteria;


    public HashMap<String, Object> getSearchCriteria() {
        return this.searchCriteria;
    }

    public void setSearchCriteria(HashMap<String, Object> searchCriteria) {
        this.searchCriteria = searchCriteria;
    }

    public String getEffectiveDate() {
        return effectiveStartDate;
    }

    public void setEffectiveDate(String effectiveStartDate) {
        this.effectiveStartDate = effectiveStartDate;
    }



}
