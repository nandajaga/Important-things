package factories.enrollments;


import dtos.enrollments.MemberEnrollmentDTO;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import static helpers.constants.Constants.*;

public class MemberEnrollmentDTOFactory {

    public List<MemberEnrollmentDTO> createMemberEnrollmentDTO(String clientId, String sourceCode, String employerGroupNumber, String mixerCode) {
        return createMemberEnrollmentDTO(1, clientId, sourceCode, employerGroupNumber, mixerCode, ISSUANCE_STATE, null, PRODUCT_CODE_VAGHMO);
    }

    public List<MemberEnrollmentDTO> createMemberEnrollmentDTO(String clientId) {
        return createMemberEnrollmentDTO(1, clientId, SS_ISG, EMPLOYER_GROUP_NUMBER, MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAGHMO, ISSUANCE_STATE, CLIENT_MEMBER_PRODUCT_CODE, PRODUCT_CODE_VAGHMO);
    }

    public List<MemberEnrollmentDTO> createMemberEnrollmentSourceSystemDTO(String clientId, String issuanceState, String sourceSystem) {
        return createMemberEnrollmentDTO(1, clientId, sourceSystem, EMPLOYER_GROUP_NUMBER, MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAGHMO, issuanceState, null, PRODUCT_CODE_VAGHMO);
    }

    public List<MemberEnrollmentDTO> createMemberEnrollmentDTO(String clientId, String issuanceState, String clientrLineOfBusinessCode) {
        return createMemberEnrollmentDTO(1,clientId, issuanceState,clientrLineOfBusinessCode);
    }

    public List<MemberEnrollmentDTO> createMemberEnrollmentDTOWithSpecificProductCode(String clientId, String productCode) {
        return createMemberEnrollmentDTO(1, clientId, SS_ISG, EMPLOYER_GROUP_NUMBER, MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAGHMO, ISSUANCE_STATE, null, productCode);
    }

    public List<MemberEnrollmentDTO> createMemberEnrollmentDTO(String clientId, String employerGroupNumber, int numberOfEnrollments, String mixerCode, String clientMemberProductCode) {
        return createMemberEnrollmentDTO(numberOfEnrollments, clientId, SS_ISG, employerGroupNumber, mixerCode, ISSUANCE_STATE, clientMemberProductCode, PRODUCT_CODE);
    }

    private List<MemberEnrollmentDTO> createMemberEnrollmentDTO(int numberOfEnrollments, String clientId, String sourceCode, String employerGroupNumber, String mixerCode, String issuanceStateCode, String clientMemberProductCode, String productCode) {
        DateFormat date = new SimpleDateFormat("yyyy-MM-dd");
        List<MemberEnrollmentDTO> list = new ArrayList<>();

        for (int i = 0; i < numberOfEnrollments; i++) {
            MemberEnrollmentDTO memberEnrollment = new MemberEnrollmentDTO();

            memberEnrollment.setClientId(clientId);
            memberEnrollment.setEmployerGroupNumber(employerGroupNumber);
            memberEnrollment.setClientSpecificEnrollments(new ClientSpecificEnrollmentsDTOFactory().createClientSpecificEnrollmentDTOWithMixerCode(sourceCode, mixerCode));
            memberEnrollment.setCovered(COVERED);

            try {
                memberEnrollment.setEffectiveEndDate(date.parse(EFFECTIVE_END_DATE));
                memberEnrollment.setEffectiveStartDate(date.parse(EFFECTIVE_START_DATE));
                memberEnrollment.setOriginalEffectiveEndDate(date.parse(ORIGINAL_EFFECTIVE_END_DATE));
            } catch (ParseException e) {
                System.out.println("Can't parse the date!");
            }

            memberEnrollment.setEnrollmentPrefix(ENROLLMENT_PREFIX);
            memberEnrollment.setFundType(FUND_TYPE);
            memberEnrollment.setIssuanceState(issuanceStateCode);
            memberEnrollment.setLineOfBusiness(LINE_OF_BUSINESS);
            memberEnrollment.setLineOfBusinessId(LINE_OF_BUSINESS_ID);
            memberEnrollment.setManuallyEntered(MANUALLY_ENTERED);
            memberEnrollment.setNationalFlag(NATIONAL_FLAG);
            memberEnrollment.setPractitionerCode(PRACTITIONER_CODE);
            memberEnrollment.setPrimaryCarePhysicianNumber(PRIMARY_CARE_PHYSICIAN_NUMBER);
            memberEnrollment.setProductCode(productCode);
            memberEnrollment.setProductCodeId(PRODUCT_CODE_ID);
            memberEnrollment.setProgramCoverageIndicator(PROGRAM_COVERAGE_INDICATOR);
            memberEnrollment.setSolutions(new SolutionDTOFactory().createSolutionDTO());
            memberEnrollment.setClientMemberProductCode(clientMemberProductCode);

            list.add(memberEnrollment);
        }

        return list;
    }
    public List<MemberEnrollmentDTO> createMemberEnrollmentDTO( String clientId,  String issuanceStateCode, String clientMemberProductCode, String productCode,String employerGroupNumber, String subGroupCode, String clientAccountNumber, String clientLineOfBusinessCode,String businessMarketSegmentName, String alternateBenefitPlanCode, Boolean preAcaHonorContractFlag, String clientAccountName, String clientFundingTypeCode) {

        DateFormat date = new SimpleDateFormat("yyyy-MM-dd");
        List<MemberEnrollmentDTO> list = new ArrayList<>();

            MemberEnrollmentDTO memberEnrollment = new MemberEnrollmentDTO();

            memberEnrollment.setClientId(clientId);
        memberEnrollment.setEmployerGroupNumber(employerGroupNumber);
            memberEnrollment.setClientSpecificEnrollments(new ClientSpecificEnrollmentsDTOFactory().createClientSpecificEnrollmentDTOWithAdditionalFields(subGroupCode,clientAccountNumber,clientLineOfBusinessCode,businessMarketSegmentName,alternateBenefitPlanCode,preAcaHonorContractFlag, clientAccountName, clientFundingTypeCode));
            memberEnrollment.setCovered(COVERED);

            try {
                memberEnrollment.setEffectiveEndDate(date.parse(EFFECTIVE_END_DATE));
                memberEnrollment.setEffectiveStartDate(date.parse(EFFECTIVE_START_DATE));
                memberEnrollment.setOriginalEffectiveEndDate(date.parse(ORIGINAL_EFFECTIVE_END_DATE));
            } catch (ParseException e) {
                System.out.println("Can't parse the date!");
            }

            memberEnrollment.setEnrollmentPrefix(ENROLLMENT_PREFIX);
            memberEnrollment.setFundType(FUND_TYPE);
            memberEnrollment.setIssuanceState(issuanceStateCode);
            memberEnrollment.setLineOfBusiness(LINE_OF_BUSINESS);
            memberEnrollment.setLineOfBusinessId(LINE_OF_BUSINESS_ID);
            memberEnrollment.setManuallyEntered(MANUALLY_ENTERED);
            memberEnrollment.setNationalFlag(NATIONAL_FLAG);
            memberEnrollment.setPractitionerCode(PRACTITIONER_CODE);
            memberEnrollment.setPrimaryCarePhysicianNumber(PRIMARY_CARE_PHYSICIAN_NUMBER);
            memberEnrollment.setProductCode(productCode);
            memberEnrollment.setProductCodeId(PRODUCT_CODE_ID);
            memberEnrollment.setProgramCoverageIndicator(PROGRAM_COVERAGE_INDICATOR);
            memberEnrollment.setSolutions(new SolutionDTOFactory().createSolutionDTO());
            memberEnrollment.setClientMemberProductCode(clientMemberProductCode);

            list.add(memberEnrollment);


        return list;
    }

    private List<MemberEnrollmentDTO> createMemberEnrollmentDTO(int numberOfEnrollments, String clientId,String issuanceStateCode, String clientLineOfBusinessCode) {
        DateFormat date = new SimpleDateFormat("yyyy-MM-dd");
        List<MemberEnrollmentDTO> list = new ArrayList<>();

        for (int i = 0; i < numberOfEnrollments; i++) {
            MemberEnrollmentDTO memberEnrollment = new MemberEnrollmentDTO();

            memberEnrollment.setClientId(clientId);
            memberEnrollment.setEmployerGroupNumber(EMPLOYER_GROUP_NUMBER);
            memberEnrollment.setClientSpecificEnrollments(new ClientSpecificEnrollmentsDTOFactory().createClientSpecificEnrollmentDTOWithMixerCode(SS_ISG, MIXER_CODE_CALCMED0000));
            memberEnrollment.setCovered(COVERED);

            try {
                memberEnrollment.setEffectiveEndDate(date.parse(EFFECTIVE_END_DATE));
                memberEnrollment.setEffectiveStartDate(date.parse(EFFECTIVE_START_DATE));
                memberEnrollment.setOriginalEffectiveEndDate(date.parse(ORIGINAL_EFFECTIVE_END_DATE));
            } catch (ParseException e) {
                System.out.println("Can't parse the date!");
            }

            memberEnrollment.setEnrollmentPrefix(ENROLLMENT_PREFIX);
            memberEnrollment.setFundType(FUND_TYPE);
            memberEnrollment.setIssuanceState(issuanceStateCode);
            memberEnrollment.setLineOfBusiness(clientLineOfBusinessCode);
            memberEnrollment.setLineOfBusinessId(LINE_OF_BUSINESS_ID);
            memberEnrollment.setManuallyEntered(MANUALLY_ENTERED);
            memberEnrollment.setNationalFlag(NATIONAL_FLAG);
            memberEnrollment.setPractitionerCode(PRACTITIONER_CODE);
            memberEnrollment.setPrimaryCarePhysicianNumber(PRIMARY_CARE_PHYSICIAN_NUMBER);
            memberEnrollment.setProductCode(PRODUCT_CODE_HIAC_85);
            memberEnrollment.setProductCodeId(PRODUCT_CODE_ID);
            memberEnrollment.setProgramCoverageIndicator(PROGRAM_COVERAGE_INDICATOR);
            memberEnrollment.setSolutions(new SolutionDTOFactory().createSolutionDTO());
            memberEnrollment.setClientMemberProductCode(null);

            list.add(memberEnrollment);
        }

        return list;
    }
}

