package dtos.clientconfig;

/**
 * Created by RKondakova on 7/22/2019.
 */
public class ClientResponseDTO {

    private String fieldName;
    private boolean value;

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public boolean isValue() {
        return value;
    }

    public void setValue(boolean value) {
        this.value = value;
    }
}
