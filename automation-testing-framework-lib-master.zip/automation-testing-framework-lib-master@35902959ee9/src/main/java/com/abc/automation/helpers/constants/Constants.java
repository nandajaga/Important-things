package com.abc.automation.helpers.constants;

import java.time.*;
import java.time.format.DateTimeFormatter;

/**
 * Created by PPetarcheva on 3/15/2019.
 */
public class Constants {

    public static final String TIMEZONE_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    public static final String SAMPLE_DATE_FORMAT = "yyyy-MM-dd";

    public static final String INTERACTION_ID = "testinteractionid";

    public static final String CHANNEL_CODE = "channelCode";

    public static final String CASE_REQUEST = "caseRequestId";

    public static final String TEST_PDF_FILE = "Attachment/test_pdf.pdf";

    public static final String PDF_DOCUMENT_ATTACHMENT_TYPE = "application/pdf";

    public static final String TODAYS_DATE = LocalDateTime.now().format(DateTimeFormatter.ofPattern(TIMEZONE_DATE_FORMAT));
    public static final String DATE_AFTER_ONE_MONTH = LocalDateTime.now().plusMonths(1).format(DateTimeFormatter.ofPattern(TIMEZONE_DATE_FORMAT));

    public static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern(SAMPLE_DATE_FORMAT);
    public static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern(TIMEZONE_DATE_FORMAT);
    public static final ZonedDateTime ZONED_DATE_TIME = ZonedDateTime.ofInstant(Instant.now(), ZoneId.of(ZoneOffset.UTC.toString()));
    public static final String USER_HOUSE_ACCOUNT = "A9526723-C3BC-4A36-ADF8-9AC7CBDCEE52";

    // Site Of Care Constants
    public static final String REVIEW_PROGRAM_CODE = "SOC";
    public static final String DISPLAY_JUSTIFICATION_QUESTION = "Include";

}
