package factories.workflow;


import dtos.workflow.DisasterDTO;

public class WorkFlowFactory {
    public DisasterDTO createWorkFlowDTO(String subClientCode) {
        DisasterDTO disasterDTO = new DisasterDTO();
        disasterDTO.setSubClientCode(subClientCode);
        return disasterDTO;
    }
}
