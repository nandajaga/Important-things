package clientconfig;

import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.clientconfig.ClientResponseDTO;
import helpers.dataproviders.DataProviders;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import steps.clientconfig.ClientsV3Steps;

import static helpers.constants.BasePathConstants.BASE_PATH_GET_V3_CLIENTS;
import static helpers.constants.ClientConfigConstants.CLIENT_ID_210;
import static helpers.constants.Constants.*;
import static helpers.constants.ErrorMessagesForMemberEndpointsConstants.ERR_MSG_CONFIGURATION_LIST_IS_EMPTY;
import static helpers.constants.ErrorMessagesForMemberEndpointsConstants.ERR_MSG_INVALID_FIELDS;
import static org.apache.http.HttpStatus.SC_INTERNAL_SERVER_ERROR;
import static org.apache.http.HttpStatus.SC_UNPROCESSABLE_ENTITY;

/**
 * Created by RKondakova on 7/22/2019.
 */
public class GetClientV3Tests extends GetTests {

    @BeforeClass
    public void init() {
        basePath = BASE_PATH_GET_V3_CLIENTS;
        pathParamsMap.clear();
        pathParamsMap.put("clientId", CLIENT_ID_210);
        queryParamsMap.put("fields", ALLOWS_ELIGIBILITY_OVERRIDE);
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test(dataProvider = "clientId-85-186-187-210", dataProviderClass = DataProviders.class)
    public void whenGetClientV3FieldsWithValidClientIdThenResponseIs200(String clientId) {
        ClientsV3Steps clientsV3Steps = new ClientsV3Steps();
        ClientResponseDTO[] clientV2ResponseDTO = clientsV3Steps.getClientV3PositiveDTO(clientId, DISPLAY_PCP_INFORMATION, platformContextHeader, headers);

        if (CLIENT_ID_210.equals(clientId)) {
            softly.then(clientV2ResponseDTO[0].isValue()).isEqualTo(true);
        } else {
            softly.then(clientV2ResponseDTO[0].isValue()).isEqualTo(false);
        }

        softly.then(clientV2ResponseDTO[0].getFieldName()).contains(DISPLAY_PCP_INFORMATION);
        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-422-500-----------------------------------------

    //TODO opened a bug for not checking for valid ClientId - Response status is 200 with invalid credentials NCP-24420
//    @Test(dataProvider = "clientIdNegative", dataProviderClass = DataProviders.class)
    public void whenGetClientV3FieldsWithNegativeClientIdThenResponseStatus422(String clientId) {
        ErrorDTO error = new ClientsV3Steps().getClientRequestErrorDTO(clientId, DISPLAY_PCP_INFORMATION, platformContextHeader, headers);

        softly.then(error.getMessage()).isEqualTo(ERR_MSG_INVALID_FIELDS);
        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.assertAll();
    }

    @Test(dataProvider = "solutionIdNegative", dataProviderClass = DataProviders.class)
    public void
    whenGetClientV3FieldsWithNegativeFieldsThenResponseStatus422(String fields) {
        ErrorDTO error = new ClientsV3Steps().getClientRequestErrorDTO(CLIENT_ID_85, fields, platformContextHeader, headers);

        if (fields == null || fields.isEmpty()) {
            softly.then(error.getMessage()).isEqualTo(ERR_MSG_CONFIGURATION_LIST_IS_EMPTY);
            softly.then(error.getCode()).isEqualTo(SC_INTERNAL_SERVER_ERROR);
        } else {
            softly.then(error.getMessage()).isEqualTo(ERR_MSG_INVALID_FIELDS);
            softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        }

        softly.assertAll();
    }
}
