package com.abc.automation.dtos.provider.servicing;

import com.abc.automation.dtos.provider.ordering.AddressSearchDTO;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
public class CreateServicingProviderDTO {

    @JsonProperty("SpecialtyCodes")
    private List<Integer> specialtyCodes;
    private AddressSearchDTO address;
    private String caseRequestId;
    private Integer clientId;
    private String facilityName;
    private String fax;
    private boolean isNationalMember;
    private boolean manual;
    private String phone;
    private String physicianFirstName;
    private String physicianLastName;

    public List<Integer> getSpecialtyCodes() {
        if (specialtyCodes != null) {
            return new ArrayList<>(specialtyCodes);
        } else {
            return null;
        }
    }

    public void setSpecialtyCodes(List<Integer> specialtyCodes) {
        if (specialtyCodes != null) {
            this.specialtyCodes = new ArrayList<>(specialtyCodes);
        } else {
            this.specialtyCodes = null;
        }
    }

    public AddressSearchDTO getAddress() {
        return address;
    }

    public void setAddress(AddressSearchDTO address) {
        this.address = address;
    }

    public String getCaseRequestId() {
        return caseRequestId;
    }

    public void setCaseRequestId(String caseRequestId) {
        this.caseRequestId = caseRequestId;
    }

    public Integer getClientId() {
        return clientId;
    }

    public void setClientId(Integer clientId) {
        this.clientId = clientId;
    }

    public String getFacilityName() {
        return facilityName;
    }

    public void setFacilityName(String facilityName) {
        this.facilityName = facilityName;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public boolean getIsNationalMember() {
        return isNationalMember;
    }

    public void setIsNationalMember(boolean nationalMember) {
        isNationalMember = nationalMember;
    }

    public boolean getManual() {
        return manual;
    }

    public void setManual(boolean manual) {
        this.manual = manual;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPhysicianFirstName() {
        return physicianFirstName;
    }

    public void setPhysicianFirstName(String physicianFirstName) {
        this.physicianFirstName = physicianFirstName;
    }

    public String getPhysicianLastName() {
        return physicianLastName;
    }

    public void setPhysicianLastName(String physicianLastName) {
        this.physicianLastName = physicianLastName;
    }
}
