package com.abc.automation.helpers.constants;

/**
 * Created by PPetarcheva on 7/2/2019.
 */
public class ErrorMessagesConstants {

    public static final String METHOD_NOT_ALLOWED_MESSAGE = "Request method '%s' not supported";

    public static final String BAD_REQUEST_ERROR = "Bad Request";
    public static final String BAD_REQUEST_MESSAGE = "Missing request header '%s' for method parameter of type String";
    public static final String BAD_REQUEST_MESSAGE_START = "Missing request header";
    public static final String BAD_REQUEST_MESSAGE_END = "for method parameter of type String";
}
