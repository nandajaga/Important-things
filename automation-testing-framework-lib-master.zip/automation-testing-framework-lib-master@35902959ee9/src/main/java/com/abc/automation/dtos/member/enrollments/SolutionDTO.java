package com.abc.automation.dtos.member.enrollments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

/**
 * Created by PPetarcheva on 4/17/2019.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SolutionDTO {
    private boolean levelOfCare;
    private String programType;
    private String solutionId;
    private String solutionName;
    private List<ReviewProgramsDTO> reviewPrograms;
    private ConsumerEngagementProgramDTO consumerEngagementProgram;

    public boolean getLevelOfCare() {
        return levelOfCare;
    }

    public void setLevelOfCare(boolean levelOfCare) {
        this.levelOfCare = levelOfCare;
    }

    public String getSolutionName() {
        return solutionName;
    }

    public void setSolutionName(String solutionName) {
        this.solutionName = solutionName;
    }

    public String getProgramType() {
        return programType;
    }

    public void setProgramType(String programType) {
        this.programType = programType;
    }

    public String getSolutionId() {
        return solutionId;
    }

    public void setSolutionId(String solutionId) {
        this.solutionId = solutionId;
    }

    public List<ReviewProgramsDTO> getReviewPrograms() {
        return reviewPrograms;
    }

    public void setReviewPrograms(List<ReviewProgramsDTO> reviewPrograms) {
        this.reviewPrograms = reviewPrograms;
    }

    public ConsumerEngagementProgramDTO getConsumerEngagementProgram() {
        return consumerEngagementProgram;
    }

    public void setConsumerEngagementProgram(ConsumerEngagementProgramDTO consumerEngagementProgram) {
        this.consumerEngagementProgram = consumerEngagementProgram;
    }
}
