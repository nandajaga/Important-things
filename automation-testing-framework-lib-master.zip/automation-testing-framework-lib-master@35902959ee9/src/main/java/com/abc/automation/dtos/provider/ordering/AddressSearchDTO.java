package com.abc.automation.dtos.provider.ordering;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
public class AddressSearchDTO {
    private String city;
    private String line1;
    private String line2;
    private String stateCode;
    private String zipCode;
    private String zipCodeExtension;

    public String getLine1() {
        return line1;
    }

    public void setLine1(String line1) {
        this.line1 = line1;
    }

    public String getLine2() {
        return line2;
    }

    public void setLine2(String line2) {
        this.line2 = line2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getZipCodeExtension() {
        return zipCodeExtension;
    }

    public void setZipCodeExtension(String zipCodeExtension) {
        this.zipCodeExtension = zipCodeExtension;
    }
}
