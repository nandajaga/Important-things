package com.abc.automation.helpers.constants;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
public class ProviderConstants {

    // AddressDTO
    public static final String ADDRESS_LINE_2 = "8600 W Bryn Mawr Ave";
    public static final String CITY_NAME = "Chicago";
    public static final String STATE_CODE = "IL";
    public static final String ZIP_CODE = "60505";


    // CreateOrderingProviderDTO
    public static final Integer SPECIALTY_CODE = 100;
    public static final String PHONE = "1234567890";
    // TODO: Check for a concept for FAX and EMAILS so that downstream systems don't really send something
    public static final String FAX = "1234567890";
    public static final String EMAIL = "automation@abcspecialtyhealth.com";
    public static final Integer CLIENT_ID = 186;

    // CreateServicingProviderDTO
    public static final String FACILITY_NAME = "UMBALSM N.I.PIROGOV";
    public static final String PHY_FIRST_NAME = "Dr. Dre";
    public static final String PHY_LAST_NAME = "Verma";

    //PlaceOfServiceDTO
    public static final String PLACE_OF_SERVICE_CODE = "PlaceOfServiceCode";
    public static final String PLACE_OF_SERVICE_NAME = "PlaceOfServiceName";

    // PlaceOfService
    public static final String PLACE_OF_SERVICE_CODE_OP = "22";
    public static final String PLACE_OF_SERVICE_NAME_OP = "22";

    // CreateServicingProviderSnapshotDTO
    public static final String LABEL_TYPE = "Facility";
    public static final String ORDER = "someOrder";
}
