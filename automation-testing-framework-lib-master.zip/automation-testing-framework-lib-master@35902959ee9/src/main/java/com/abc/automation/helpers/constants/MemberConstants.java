package com.abc.automation.helpers.constants;

/**
 * Created by PPetarcheva on 4/17/2019.
 */
public class MemberConstants {

    // Data Manager
    public static final String CLIENT_ID_85 = "85";
    public static final String DOB = "1967-06-30";

    // MemberDTOFactory
    public static final String CASE_REQUEST_ID = "12345678901";

    // MemberEnrollmentDTO

    // SolutionDTOFactory
    public static final String SOLUTION_PROGRAM_TYPE = "UM";
    public static final String SOLUTION_PAYLOAD = "15";

    // MemberEnrollmentDTOFactory
    public static final String EFFECTIVE_END_DATE = "2018-05-29";
    public static final String EFFECTIVE_START_DATE = "1999-07-20";
    public static final String EMPLOYER_GROUP_NUMBER = "00218643";
    public static final String ENROLLMENT_PREFIX = "TYH";
    public static final String FUND_TYPE = "QY";
    public static final String ISSUANCE_STATE = "CA";
    public static final String LINE_OF_BUSINESS = "MEDICARE";
    public static final String LINE_OF_BUSINESS_ID = "1234";
    public static final String ORIGINAL_EFFECTIVE_END_DATE = "2007-02-05";
    public static final String PRACTITIONER_CODE = "S";
    public static final String PRIMARY_CARE_PHYSICIAN_NUMBER = "312";
    public static final String PRODUCT_CODE = "Z";
    public static final String PRODUCT_CODE_ID = "1234";
    public static final String PROGRAM_COVERAGE_INDICATOR = "12";

    // SS=SOURCE_SYSTEM
    public static final String SS_ISG = "ISG";

    // MemberDemographics

    // MemberDemographicsDTOFactory
    public static final String FIRST_NAME_STARTS_WITH = "Auto-";
    public static final String LAST_NAME_STARTS_WITH = "Test-";
    public static final String CLIENT_DEPENDENT_RELATION_CODE = "S";
    public static final String CLIENT_MEMBER_ID = "9931231423ABC";
    public static final String DEPENDENT_CODE = "CV";
    public static final String GENDER = "M";
    public static final String LEGACY_MEMBER_ID = "12345678";
    public static final String MEMBER_PREFIX = "ABC";

    // ClientSpecificDemographicsDTOFactory
    public static final String LANG_PREFERENCE_CODE = "AB";
    public static final String LANG_PREFERENCE_ORIGINAL_CODE = "ABC";
    public static final String RESTRICTED_ACCESS_CODE = "ADS";
    public static final String SUB_CLIENT_CODE = "123C";

    // AddressesDTOFactory
    public static final String ADDRESS_1 = "8600 W Bryn Mawr Ave";
    public static final String CITY_NAME = "Chicago";
    public static final String STATE_CODE = "IL";
    public static final String ZIP_CODE = "60631";
    public static final String ZIP_EXTENSION = "060";

    // AdditionalMemberIdsMediaCareIdDTOFactory
    public static final String MEDICARE_ID_NAME = "medicareId";
    public static final String MEDICARE_ID_VALUE = "9931231423ABC";
    public static final String MEDICAID_ID_NAME = "medicaidId";
    public static final String MEDICAID_ID_VALUE = "999987978978";

    //MemberEmailDTOFactory
    public static final String EMAIL_ID ="string";
    public static final String EMAIL_TYPE="string";

    //MemberPhoneDTOFactory
    public static final String PHONE_NUMBER ="string";
    public static final String PHONE_TYPE="string";
}
