package com.abc.automation.factories.user;

import com.abc.automation.dtos.user.UserStateLicenseDTO;
import com.abc.automation.helpers.constants.Constants;
import com.abc.automation.helpers.enums.user.UserStateLicenseEnum;

import java.util.ArrayList;

public class UserStateLicenseDTOFactory {

    private UserStateLicenseDTO createStateLicenseDTO(UserStateLicenseEnum license) {
        UserStateLicenseDTO licenseDTO = new UserStateLicenseDTO();
        licenseDTO.setStateLicenseCode(license.getCode());
        licenseDTO.setStateLicenseNumber(license.getNumber());
        licenseDTO.setStateLicenseNumberExpiryDate(Constants.DATE_AFTER_ONE_MONTH);
        licenseDTO.setStateLicenseNumberIssueDate(Constants.TODAYS_DATE);

        return licenseDTO;
    }

    public ArrayList<UserStateLicenseDTO> createStateLicensesDTO(UserStateLicenseEnum license) {
        ArrayList<UserStateLicenseDTO> stateLicensesDTO = new ArrayList<>();
        UserStateLicenseDTO licenseDTO = createStateLicenseDTO(license);
        stateLicensesDTO.add(licenseDTO);

        return stateLicensesDTO;
    }

    public ArrayList<UserStateLicenseDTO> createStateLicensesDTO() {
        ArrayList<UserStateLicenseDTO> stateLicensesDTO = new ArrayList<>();
        UserStateLicenseDTO licenseDTO = createStateLicenseDTO(UserStateLicenseEnum.ALASKA_STATE_LICENSE);
        stateLicensesDTO.add(licenseDTO);

        return stateLicensesDTO;
    }
}
