package helpers.dataproviders;

import com.aim.automation.helpers.enums.ContextModeEnum;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.ITestContext;
import org.testng.annotations.DataProvider;

import static helpers.constants.ClientConfigConstants.*;
import static helpers.constants.ClientConfigConstants.CLIENT_ID_212;
import static helpers.constants.ClientConfigConstants.CLIENT_ID_220;
import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_186;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_187;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_210;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_85;
import static helpers.constants.ConstantsClientIds.*;

/**
 * Created by RKondakova on 6/17/2019.
 */
public class DataProviders {

    private static final String NULL = null;
    private static final String DOT_SIGN = ".";
    private static final String DOLLAR_SIGN = "$";
    private static final String SINGLE_CHAR = "A";
    private static final String MORE_THAN_TWO_CHARS = "ABC";
    private static final String TOTAL_3_NUM = "999";
    private static final String TOTAL_11_NUM = "12345678901";
    private static final String TOTAL_16_NUM = "1234567890123456";
    private static final String TOTAL_21_NUM = "123456789012345678901";
    private static final String TOTAL_31_NUM = "1234567890123456789012345678901";
    private static final String EMPTY_STRING = " ";
    private static final String INVALID_SORT = "Invalid.MustBeACSoDESC";
    private static final String INVALID_SORT_0_DOT_ASC = "0.ASC";
    private static final String INVALID_DATE = "00-00-00";
    private static final String INVALID_DATE_MONTH = "1985-13-25";
    private static final String INVALID_DATE_DATE = "1967-12-32";
    private static final String INVALID_DATE_YEAR = "2025-01-01";
    private static final String EMPTY_STRING_WITH_NO_SPACE = "";
    private static final String SPECIAL_CHARACTERS = "@!#$%^&*())";
    private static final String SPECIAL_CHARS_LENGHT_4 = "@!#$";
    private static final String ALPHANUMERIC_10CHARS = "15963hgyft";
    private static final String INVALID_STATE_CODE_LOWER_CASE = "in";
    private static final String INVALID_STATE_CODE_3_ALPHABETIC = "GTF";
    private static final String SOLUTION_ID_TEST = "3314462";
    private static final String NULL_VALUE = "null";
    private static final String CLIENT_PARAM = "client-id";

    //The two data providers are commented out due to bug NCP-23099
    @DataProvider(name = "sortNegative")
    public Object[][] dataProviderMethodSort() {
        return new Object[][]{{EMPTY_STRING}, {INVALID_SORT}, /*{INVALID_SORT_FIRST_NAME_WITH_DOT},*/ {INVALID_SORT_0_DOT_ASC}};
    }

    @DataProvider(name = "data-provider-clientId")
    public Object[][] provideClientId(ITestContext context) {
        if (context.getCurrentXmlTest().getAllParameters().size() != 0) {
            return new Object[][]{{context.getCurrentXmlTest().getParameter(CLIENT_PARAM)}};
        } else {
            return new Object[][]{{CLIENT_ID_186}, {CLIENT_ID_85},{CLIENT_ID_210}};
        }
    }

    @DataProvider(name = "data-provider-issuanceState")
    public Object[][] provideIssuanceState() {
        return new Object[][]{{ISSUANCE_STATE_WI}, {ISSUANCE_STATE_FL}};
    }

    @DataProvider(name = "reviewType")
    public Object[][] provideReviewType() {
        return new Object[][]{{REVIEW_TYPE_PCCA}, {""}, {REVIEW_TYPE_PROSPECTIVE}, {REVIEW_TYPE_RETROSPECTIVE}};
    }

    @DataProvider(name = "clientMemberId")
    public Object[][] provideMethodClientMemberId() {
        return new Object[][]{{NULL}, {DOLLAR_SIGN}, {TOTAL_3_NUM}, {TOTAL_31_NUM}};
    }

    @DataProvider(name = "FirstName")
    public Object[][] provideFirstName() {
        return new Object[][]{{NULL}, {DOLLAR_SIGN}, {EMPTY_STRING}, {TOTAL_16_NUM}};
    }

    @DataProvider(name = "LastName")
    public Object[][] provideLastName() {
        return new Object[][]{{NULL}, {DOLLAR_SIGN}, {EMPTY_STRING}, {TOTAL_21_NUM}};
    }

    @DataProvider(name = "clientIdSearch")
    public Object[][] dataProviderMethodClientId() {
        return new Object[][]{{NULL}, {DOLLAR_SIGN}, {TOTAL_11_NUM}, {EMPTY_STRING}};
    }

    @DataProvider(name = "invalidDate")
    public Object[][] provideDateOfBirth() {
        return new Object[][]{{INVALID_DATE}, {INVALID_DATE_YEAR}, {INVALID_DATE_MONTH}, {INVALID_DATE_DATE}, {DOB_150Plus}};
    }

    @DataProvider(name = "clientMemberIdPositive")
    public Object[][] dataProviderMethodClientMemberIdPositive(ITestContext context) {
        if (context.getCurrentXmlTest().getAllParameters().size() != 0) {
            return new Object[][]{{context.getCurrentXmlTest().getParameter("client-id-search")}};
        } else {
            return new Object[][]{{CLIENT_MEMBER_ID}, {MEDICAID_ID_VALUE}, {PREFIX_CLIENT_MEMBER_ID}, {PREFIX_CLIENT_MEMBER_ID_DEPENDENT_CODE}, {CLIENT_MEMBER_ID_DEPENDENT_CODE}};
        }
    }

    @DataProvider(name = "clientIdAll")
    public Object[][] provideClientIdAll(ITestContext context) {
        if (context.getCurrentXmlTest().getAllParameters().size() != 0) {
            return new Object[][]{{context.getCurrentXmlTest().getParameter(CLIENT_PARAM)}};
        } else {
            return new Object[][]{{CLIENT_ID_40}, {CLIENT_ID_55}, {CLIENT_ID_85}, {CLIENT_ID_183}, {CLIENT_ID_184}, {CLIENT_ID_185}, {CLIENT_ID_186},
                    {CLIENT_ID_187}, {CLIENT_ID_188}, {CLIENT_ID_189}, {CLIENT_ID_199}, {CLIENT_ID_210}, {DEFAULT_CLIENT_ID}};
        }
    }

    @DataProvider(name = "clientIdWithoutDefaultValue")
    public Object[][] provideClientIdNoDefaultValue(ITestContext context) {
        if (context.getCurrentXmlTest().getAllParameters().size() != 0) {
            return new Object[][]{{context.getCurrentXmlTest().getParameter(CLIENT_PARAM)}};
        } else {
            return new Object[][]{{CLIENT_ID_40}, {CLIENT_ID_55}, {CLIENT_ID_85}, {CLIENT_ID_86}, {CLIENT_ID_183}, {CLIENT_ID_184}, {CLIENT_ID_185}, {CLIENT_ID_186},
                    {CLIENT_ID_187}, {CLIENT_ID_188}, {CLIENT_ID_189}, {CLIENT_ID_199}, {CLIENT_ID_210}, {CLIENT_ID_212}, {CLIENT_ID_220}};
        }
    }

    @DataProvider(name = "overrideSolutionIdNullForEligibleClientId")
    public Object[][] provideClientIdNullSolutionId(ITestContext context) {
        if (context.getCurrentXmlTest().getAllParameters().size() != 0) {
            return new Object[][]{{context.getCurrentXmlTest().getParameter(CLIENT_PARAM)}};
        } else {
            return new Object[][]{{CLIENT_ID_85}, {CLIENT_ID_183}, {CLIENT_ID_184}, {CLIENT_ID_185}, {CLIENT_ID_186},
                    {CLIENT_ID_187}, {CLIENT_ID_188}, {CLIENT_ID_189}, {CLIENT_ID_199}, {CLIENT_ID_210}, {CLIENT_ID_212}, {CLIENT_ID_220}};
        }
    }

    @DataProvider(name = "types")
    public Object[][] provideTypesOptions(ITestContext context) {
        if (context.getCurrentXmlTest().getAllParameters().size() != 0) {
            return new Object[][]{{context.getCurrentXmlTest().getParameter("types")}};
        } else {
            return new Object[][]{{CLIENT_TYPE_QUERY_PARAM}, {EMAIL_TYPE_QUERY_PARAM}, {REFERENCE_TYPE_GENDER}, {LANGUAGE_PREFERENCE_CODE_TYPE_QUERY_PARAM},
                    {PHONE_TYPE_QUERY_PARAM}, {PROGRAM_TYPE_QUERY_PARAM}, {SUB_DIVISION_STATE_TYPE_QUERY_PARAM}};
        }
    }

    @DataProvider(name = "clientId")
    public Object[][] clientIdOptions(ITestContext context) {
        if (context.getCurrentXmlTest().getAllParameters().size() != 0) {
            return new Object[][]{{context.getCurrentXmlTest().getParameter("client-id-85")}};
        } else {
            return new Object[][]{{CLIENT_ID_85}, {CLIENT_ID_183}, {CLIENT_ID_184}, {CLIENT_ID_185}, {CLIENT_ID_186}, {CLIENT_ID_187}, {CLIENT_ID_188}, {CLIENT_ID_189}, {CLIENT_ID_199}, {CLIENT_ID_202}, {CLIENT_ID_210}, {CLIENT_ID_212}, {CLIENT_ID_55}, {CLIENT_ID_160}, {CLIENT_ID_218}, {CLIENT_ID_219}, {CLIENT_ID_220}};
        }
    }

    @DataProvider(name = "clientIdEmployerCodeRestriction")
    public Object[][] clientIdEmployerCodeRestriction(ITestContext context) {
        return new Object[][]{{CLIENT_ID_183, EMPLOYER_GROUP_NUMBER_CLID183}, {CLIENT_ID_184, EMPLOYER_GROUP_NUMBER_CLID_184}, {CLIENT_ID_185, EMPLOYER_GROUP_NUMBER_CLID_185},
                {CLIENT_ID_186, EMPLOYER_GROUP_NUMBER_CLID_186}, {CLIENT_ID_187, EMPLOYER_GROUP_NUMBER_CLID_187}, {CLIENT_ID_188, EMPLOYER_GROUP_NUMBER_CL1ID_188},
                {CLIENT_ID_189, EMPLOYER_GROUP_NUMBER_CLID_189}};
    }

    @DataProvider(name = "clientIdEmployerCodeRestrictionV4")
    public Object[][] clientIdEmployerCodeRestrictionV4(ITestContext context) {
        return new Object[][]{{CLIENT_ID_183, EMPLOYER_GROUP_NUMBER_CLID183}, {CLIENT_ID_184, EMPLOYER_GROUP_NUMBER_CLID_184}, {CLIENT_ID_185, EMPLOYER_GROUP_NUMBER_CLID_185},
                {CLIENT_ID_186, EMPLOYER_GROUP_NUMBER_CLID_186}, {CLIENT_ID_187, EMPLOYER_GROUP_NUMBER_CLID_187}, {CLIENT_ID_188, EMPLOYER_GROUP_NUMBER_CL1ID_188}, {CLIENT_ID_189, EMPLOYER_GROUP_NUMBER_CLID_189}, {CLIENT_ID_210, EMPLOYER_GROUP_NUMBER_CLID_210}, {CLIENT_ID_212, EMPLOYER_GROUP_NUMBER_CLID_212}, {CLIENT_ID_55, EMPLOYER_GROUP_NUMBER_CLID_55}
                , {CLIENT_ID_160, EMPLOYER_GROUP_NUMBER_CLID_160}, {CLIENT_ID_218, EMPLOYER_GROUP_NUMBER_CLID_218}, {CLIENT_ID_219, EMPLOYER_GROUP_NUMBER_CLID_219}, {CLIENT_ID_220, EMPLOYER_GROUP_NUMBER_CLID_220}};
    }

    @DataProvider(name = "sortPositive")
    public Object[][] dataProviderMethodSizePositive(ITestContext context) {
        if (context.getCurrentXmlTest().getAllParameters().size() != 0) {
            return new Object[][]{{context.getCurrentXmlTest().getParameter("sortPositive")}};
        } else {
            return new Object[][]{{SORT_VALID_CLIENT_MEMBER_ID}, {SORT_VALID_MEMBER_PREFIX}, {SORT_VALID_CLIENT_MEMBER_IDENTIFIER}, {SORT_VALID_DEPENDENT_CODE},
                    {SORT_VALID_FIRST_NAME}, {SORT_VALID_HEALTH_PLAN}, {SORT_VALID_LAST_NAME}, {SORT_VALID_GENDER}, {SORT_VALID_STATE}};
        }
    }

    @DataProvider(name = "clientMemberIdNegative")
    public Object[][] dataProviderMethodClientMemberIdNegative() {
        return new Object[][]{{NULL}, {DOLLAR_SIGN}, {TOTAL_3_NUM}, {TOTAL_31_NUM}};
    }

    @DataProvider(name = "ClientIdNegative")
    public Object[][] dataProviderMethodClientIdNegative() {
        return new Object[][]{{NULL}, {DOLLAR_SIGN}, {TOTAL_11_NUM}};
    }

    @DataProvider(name = "DependentCode")
    public Object[][] dataProviderMethodDependentCode() {
        return new Object[][]{{NULL}, {DOLLAR_SIGN}, {SINGLE_CHAR}, {MORE_THAN_TWO_CHARS}};
    }

    @DataProvider(name = "size")
    public Object[][] dataProviderMethodSize() {
        return new Object[][]{{NULL}, {DOLLAR_SIGN}, {INVALID_DATE}, {INVALID_DATE_YEAR}, {INVALID_DATE_MONTH}, {INVALID_DATE_DATE}, {DOB_150Plus}};
    }

    @DataProvider(name = "clientId-85-186-187-210-233-234")
    public Object[][] dataProviderNewClientId(ITestContext context) {
        if (context.getCurrentXmlTest().getAllParameters().size() != 0) {
            return new Object[][]{{context.getCurrentXmlTest().getParameter("client-id-85")}};
        } else {
            return new Object[][]{{CLIENT_ID_85}, {CLIENT_ID_186}, {CLIENT_ID_187}, {CLIENT_ID_210}, {CLIENT_ID_233}, {CLIENT_ID_234}};
        }
    }

    @DataProvider(name = "clientId-85-186-187-210")
    public Object[][] dataProviderClientId(ITestContext context) {
        if (context.getCurrentXmlTest().getAllParameters().size() != 0) {
            return new Object[][]{{context.getCurrentXmlTest().getParameter("client-id-85")}};
        } else {
            return new Object[][]{{CLIENT_ID_85}, {CLIENT_ID_186}, {CLIENT_ID_187}, {CLIENT_ID_210}};
        }
    }

    @DataProvider(name = "memberIdNegative")
    public Object[][] dataProviderMemberIdNegative() {
        return new Object[][]{{NULL}, {DOLLAR_SIGN}, {SINGLE_CHAR}, {EMPTY_STRING}, {EMPTY_STRING_WITH_NO_SPACE}};
    }

    @DataProvider(name = "clientId-210-212")
    public Object[][] dataProviderClientIdPositive(ITestContext context) {
        if (context.getCurrentXmlTest().getAllParameters().size() != 0) {
            return new Object[][]{{context.getCurrentXmlTest().getParameter("clientId-210")}};
        } else {
            return new Object[][]{{CLIENT_ID_210}, {CLIENT_ID_212}};
        }
    }

    @DataProvider(name = "clientIdNegative")
    public Object[][] dataProviderClientIdNegative() {
        return new Object[][]{{NULL}, {DOLLAR_SIGN}, {SINGLE_CHAR}, {EMPTY_STRING}};
    }

    @DataProvider(name = "validClientIdAndValidAgeAge")
    public Object[][] dataProviderValidClientIdAndValidAgeWithoutMessaging(ITestContext context) {
        if (context.getCurrentXmlTest().getAllParameters().size() != 0) {
            return new Object[][]{{context.getCurrentXmlTest().getParameter(CLIENT_PARAM), Integer.valueOf(context.getCurrentXmlTest().getParameter("member-age"))}};
        } else {
            return new Object[][]{{CLIENT_ID_85, MEMBER_AGE_3}, {CLIENT_ID_184, MEMBER_AGE_6}, {CLIENT_ID_189, MEMBER_AGE_3},
                    {CLIENT_ID_186, MEMBER_AGE_10}, {CLIENT_ID_185, MEMBER_AGE_10}, {CLIENT_ID_188, MEMBER_AGE_3},
                    {CLIENT_ID_199, MEMBER_AGE_10}, {CLIENT_ID_187, MEMBER_AGE_3}, {CLIENT_ID_183, MEMBER_AGE_10}};
        }
    }

    @DataProvider(name = "IsClientSOCEligible")
    public Object[][] IsClientSOCEligible(ITestContext context) {
        return new Object[][]{{CLIENT_ID_85, ISSUANCE_STATE_CODE_IN, COMMERCIAL_NAME}, {CLIENT_ID_183, ISSUANCE_STATE_CODE_IN, COMMERCIAL_NAME}, {CLIENT_ID_184, ISSUANCE_STATE_CODE_IN, COMMERCIAL_NAME}, {CLIENT_ID_185, ISSUANCE_STATE_CODE_IN, COMMERCIAL_NAME}, {CLIENT_ID_186, ISSUANCE_STATE_CODE_IN, COMMERCIAL_NAME}, {CLIENT_ID_187, ISSUANCE_STATE_CODE_IN, COMMERCIAL_NAME}, {CLIENT_ID_188, ISSUANCE_STATE_CODE_IN, COMMERCIAL_NAME}, {CLIENT_ID_189, ISSUANCE_STATE_CODE_IN, COMMERCIAL_NAME}, {CLIENT_ID_210, ISUUANCE_STATE_CODE_NY, MEDICAID_NAME}, {CLIENT_ID_220, ISSUANCE_STATE_CODE_IN, COMMERCIAL_NAME}, {CLIENT_ID_300, ISSUANCE_STATE_CODE_IN, MEDICAID_NAME}};
    }

    @DataProvider(name = "emptyStringAndDot")
    public Object[][] dataProviderClientNegativeNullDot() {
        return new Object[][]{{EMPTY_STRING_WITH_NO_SPACE}, {DOT_SIGN}};
    }

    @DataProvider(name = "clientId-85-186-187")
    public Object[][] dataProviderClientIdPositiveEligibility(ITestContext context) {
        return new Object[][]{{CLIENT_ID_85}, {CLIENT_ID_186}, {CLIENT_ID_187}};
    }

    @DataProvider(name = "clientId-85-183-184-186-187-188-189-199")
    public Object[][] dataProviderClientIdProductCodes(ITestContext context) {
        return new Object[][]{{CLIENT_ID_85}, {CLIENT_ID_183}, {CLIENT_ID_184}, {CLIENT_ID_186}, {CLIENT_ID_187}, {CLIENT_ID_188}, {CLIENT_ID_189}, {CLIENT_ID_199}};
    }

    @DataProvider(name = "validClientIdAndValidAgeAgeBoundaryValueAnalysis")
    public Object[][] provideValidClientIdAndValidAgeBoundaryValueAnalysis() {
        return new Object[][]{{CLIENT_ID_85, MEMBER_AGE_4}, {CLIENT_ID_184, MEMBER_AGE_7}, {CLIENT_ID_189, MEMBER_AGE_4}, {CLIENT_ID_188, MEMBER_AGE_4}, {CLIENT_ID_187, MEMBER_AGE_4},
                {CLIENT_ID_85, MEMBER_AGE_0}, {CLIENT_ID_184, MEMBER_AGE_0}, {CLIENT_ID_189, MEMBER_AGE_0}, {CLIENT_ID_188, MEMBER_AGE_0}, {CLIENT_ID_187, MEMBER_AGE_0}};
    }

    @DataProvider(name = "validClientIdAndInvalidMemberAge")
    public Object[][] provideValidClientIdAndValidClientIdAndInvalidMemberAge() {
        return new Object[][]{{CLIENT_ID_85, MEMBER_AGE_MINUS_ONE}, {CLIENT_ID_184, MEMBER_AGE_151}, {CLIENT_ID_189, Integer.valueOf(RandomStringUtils.random(3, false, true))},
                {CLIENT_ID_187, MEMBER_AGE_151}, {CLIENT_ID_188, MEMBER_AGE_151}};
    }

    @DataProvider(name = "validMemberAgeForClient210boundaryValueAnalysis")
    public Object[][] provideValidMemberAgeForClient210boundaryValueAnalysis() {
        return new Object[][]{{MEMBER_AGE_3}, {MEMBER_AGE_2}, {MEMBER_AGE_4}, {MEMBER_AGE_0}};
    }

    @DataProvider(name = "solutionId")
    public Object[][] providerValidSolutionId(ITestContext context) {
        if (context.getCurrentXmlTest().getAllParameters().size() != 0) {
            return new Object[][]{{context.getCurrentXmlTest().getParameter("solutionId")}};
        } else {
            return new Object[][]{{SOLUTION_ID_12}, {SOLUTION_ID_15}, {SOLUTION_ID_16}, {SOLUTION_ID_17}};
        }
    }

    @DataProvider(name = "solutionIdIsClientEligible")
    public Object[][] memberValidSolutionIdForIsClientEligible(ITestContext context) {
        return new Object[][]{{SOLUTION_ID_15}, {SOLUTION_ID_16}, {SOLUTION_ID_17},
        };
    }

    @DataProvider(name = "solutionIdTerminatedInConfig")
    public Object[][] memberValidSolutionIdAndClientIdForClientNotEligible(ITestContext context) {
        return new Object[][]{{SOLUTION_ID_2, CLIENT_ID_85}, {SOLUTION_ID_11, CLIENT_ID_184}, {SOLUTION_ID_2, CLIENT_ID_187}, {SOLUTION_ID_11, CLIENT_ID_199}, {SOLUTION_ID_2, CLIENT_ID_210}, {SOLUTION_ID_11, CLIENT_ID_212}, {null, CLIENT_ID_220}, {null, CLIENT_ID_233}, {null, CLIENT_ID_234}
        };
    }

    @DataProvider(name = "solutionIdIssuanceStateCodeLobEligible")
    public Object[][] solutionIdIssuanceStateCodeLob(ITestContext context) {
        return new Object[][]{{SOLUTION_ID_15, CLIENT_ID_85, STATE_CODE_IN, COMMERCIAL_CODE}, {SOLUTION_ID_15, CLIENT_ID_183, STATE_CODE_IN, COMMERCIAL_CODE}, {SOLUTION_ID_15, CLIENT_ID_184, STATE_CODE_IN, COMMERCIAL_CODE},
                {SOLUTION_ID_15, CLIENT_ID_185, STATE_CODE_IN, COMMERCIAL_CODE}, {SOLUTION_ID_15, CLIENT_ID_186, STATE_CODE_CA, COMMERCIAL_CODE}, {SOLUTION_ID_15, CLIENT_ID_187, STATE_CODE_IN, COMMERCIAL_CODE},
                {SOLUTION_ID_15, CLIENT_ID_188, STATE_CODE_IN, COMMERCIAL_CODE}, {SOLUTION_ID_15, CLIENT_ID_189, STATE_CODE_IN, COMMERCIAL_CODE}, {SOLUTION_ID_15, CLIENT_ID_199, STATE_CODE_IN, COMMERCIAL_CODE},
                {SOLUTION_ID_15, CLIENT_ID_210, ISUUANCE_STATE_CODE_NY, MEDICAID_CODE}, {SOLUTION_ID_15, CLIENT_ID_212, ISUUANCE_STATE_CODE_NY, MEDICARE_CODE}, {SOLUTION_ID_15, CLIENT_ID_233, STATE_CODE_NE, MEDICAID_CODE},
                {SOLUTION_ID_15, CLIENT_ID_234, STATE_CODE_MO, MEDICAID_CODE}, {SOLUTION_ID_15, CLIENT_ID_220, STATE_CODE_NM, MEDICAID_CODE}
        };
    }

    @DataProvider(name = "noSolutionEligibleClientId")
    public Object[][] memberSolutionAgnosticForIsClientEligible(ITestContext context) {
        return new Object[][]{{CLIENT_ID_85}, {CLIENT_ID_183}, {CLIENT_ID_184}, {CLIENT_ID_185}, {CLIENT_ID_186}, {CLIENT_ID_187}, {CLIENT_ID_188}, {CLIENT_ID_189},
                {CLIENT_ID_199}, {CLIENT_ID_210}, {CLIENT_ID_212}, {CLIENT_ID_233}, {CLIENT_ID_234}, {CLIENT_ID_220}
        };
    }

    @DataProvider(name = "SolutionEligibleClientId")
    public Object[][] memberSolutionForIsClientEligible(ITestContext context) {
        return new Object[][]{{SOLUTION_ID_15}, {SOLUTION_ID_16}, {SOLUTION_ID_17}};
    }

    @DataProvider(name = "channelCodeIsClientEligible")
    public Object[][] providerValidChannelCodeForIsClientEligible(ITestContext context) {
        return new Object[][]{{PC_CHANNEL_CODE_CC}, {PC_CHANNEL_CODE_P}};
    }

    @DataProvider(name = "solutionIdNegative")
    public Object[][] dataProviderSolutionIdNegative() {
        return new Object[][]{{NULL}, {DOLLAR_SIGN}, {SINGLE_CHAR}, {EMPTY_STRING}, {EMPTY_STRING_WITH_NO_SPACE}};
    }

    @DataProvider(name = "solutionIdNegativeIsClientEligible")
    public Object[][] dataProviderSolutionIdNegativeForIsClientEligible() {
        return new Object[][]{{DOLLAR_SIGN}, {SINGLE_CHAR}};
    }

    @DataProvider(name = "screenValid")
    public Object[][] dataProviderScreenValidInput() {
        return new Object[][]{{DISPLAY_PARAMETER_MANUAL_ADD}, {DISPLAY_PARAMETER_ENROLLMENTS}, {DISPLAY_PARAMETER_DEMOGRAPHICS}};
    }

    @DataProvider(name = "clientId-220-233-234-and-ValidScreen")
    public Object[][] dataProviderClientIdAndValidScreenInput() {
        return new Object[][]{{CLIENT_ID_220, DISPLAY_PARAMETER_MANUAL_ADD}, {CLIENT_ID_220, DISPLAY_PARAMETER_ENROLLMENTS}, {CLIENT_ID_220, DISPLAY_PARAMETER_DEMOGRAPHICS},
                {CLIENT_ID_233, DISPLAY_PARAMETER_MANUAL_ADD}, {CLIENT_ID_233, DISPLAY_PARAMETER_ENROLLMENTS}, {CLIENT_ID_233, DISPLAY_PARAMETER_DEMOGRAPHICS},
                {CLIENT_ID_234, DISPLAY_PARAMETER_MANUAL_ADD}, {CLIENT_ID_234, DISPLAY_PARAMETER_ENROLLMENTS}, {CLIENT_ID_234, DISPLAY_PARAMETER_DEMOGRAPHICS}};
    }

    @DataProvider(name = "screenNegative")
    public Object[][] dataProviderScreenInvalidInput() {
        return new Object[][]{{NULL}, {DISPLAY_PARAMETER_NEGATIVE}, {DOLLAR_SIGN}, {SINGLE_CHAR}, {EMPTY_STRING}};
    }

    @DataProvider(name = "pageInvalid")
    public Object[][] dataProviderSearchClientMemberUnique() {
        return new Object[][]{{DOLLAR_SIGN}, {EMPTY_STRING}, {TOTAL_31_NUM}, {DOT_SIGN}};
    }

    @DataProvider(name = "state-of-issuance")
    public Object[][] dataProviderStateOfIssuance() {
        return new Object[][]{{CLIENT_ID_210, ISUUANCE_STATE_CODE_NM}, {CLIENT_ID_210, ISUUANCE_STATE_CODE_TX}, {CLIENT_ID_210, ISUUANCE_STATE_CODE_WA}, {CLIENT_ID_210, ISUUANCE_STATE_CODE_NJ},
                {CLIENT_ID_212, ISSUANCE_STATE_CA}, {CLIENT_ID_212, ISSUANCE_STATE_CO}, {CLIENT_ID_212, ISUUANCE_STATE_CODE_CT}, {CLIENT_ID_212, ISUUANCE_STATE_CODE_GA},
                {CLIENT_ID_212, ISSUANCE_STATE_CODE_IN}, {CLIENT_ID_212, ISUUANCE_STATE_CODE_KY}, {CLIENT_ID_212, ISUUANCE_STATE_CODE_ME}, {CLIENT_ID_212, ISUUANCE_STATE_CODE_MO},
                {CLIENT_ID_212, ISUUANCE_STATE_CODE_NH}, {CLIENT_ID_212, ISUUANCE_STATE_CODE_NY}, {CLIENT_ID_212, ISUUANCE_STATE_CODE_OH}, {CLIENT_ID_212, ISUUANCE_STATE_CODE_VA}, {CLIENT_ID_212, ISSUANCE_STATE_WI}};
    }

    @DataProvider(name = "clientId212-and-issuance-state-code")
    public Object[][] dataProviderStateOfIssuanceForClientId212() {
        return new Object[][]{{CLIENT_ID_212, ISSUANCE_STATE_CA}};
    }

    @DataProvider(name = "clientId210-and-issuance-state-code")
    public Object[][] dataProviderStateOfIssuanceForClientId210() {
        return new Object[][]{{CLIENT_ID_210, ISUUANCE_STATE_CODE_NY}};
    }

    @DataProvider(name = "clientId220-and-issuance-state-code")
    public Object[][] dataProviderStateOfIssuanceForClientId220() {
        return new Object[][]{{CLIENT_ID_220, ISUUANCE_STATE_CODE_NM}};
    }

    @DataProvider(name = "clientId233-and-issuance-state-code")
    public Object[][] dataProviderStateOfIssuanceForClientId233() {
        return new Object[][]{{CLIENT_ID_233, ISUUANCE_STATE_CODE_NE}};
    }

    @DataProvider(name = "clientId234-and-issuance-state-code")
    public Object[][] dataProviderStateOfIssuanceForClientId234() {
        return new Object[][]{{CLIENT_ID_234, ISUUANCE_STATE_CODE_MO}};
    }

    @DataProvider(name = "fieldsPositive")
    public Object[][] dataProviderFieldsPositive() {
        return new Object[][]{{ALLOWS_ELIGIBILITY_OVERRIDE}, {ALLOWS_CONTACT_EDIT}, {CONFIRM_CONTACT_INFORMATION_PROMPT}, {PROVIDE_PHONE_INFORMATION_PROMPT}, {PROVIDE_EMAIL_INFORMATION_PROMPT}};
    }

    @DataProvider(name = "genderNegative")
    public Object[][] dataProviderGenderNegative() {
        return new Object[][]{{NULL}, {DOLLAR_SIGN}, {SINGLE_CHAR}, {EMPTY_STRING}, {EMPTY_STRING_WITH_NO_SPACE}};
    }

    @DataProvider(name = "validClientMemberProductCodeAndMixerCode")
    public Object[][] providerValidClientMemberProductCodeAndMixerCode() {
        return new Object[][]{{null, CLIENT_MEMBER_PRODUCT_CODE}, {MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAGHMO, null}};
    }

    @DataProvider(name = "invalidClientMemberProductCodeAndMixerCode")
    public Object[][] provideInvalidClientMemberCodeAndMixerCode() {
        return new Object[][]{{EMPTY_STRING_WITH_NO_SPACE, EMPTY_STRING_WITH_NO_SPACE}, {SPECIAL_CHARS_LENGHT_4, SPECIAL_CHARACTERS},
                {SPECIAL_CHARS_LENGHT_4, RandomStringUtils.random(11, true, true)},
                {EMPTY_STRING_WITH_NO_SPACE, RandomStringUtils.random(11, true, true)},
                {SPECIAL_CHARACTERS, RandomStringUtils.random(4, true, true)},
                {EMPTY_STRING_WITH_NO_SPACE, RandomStringUtils.random(4, true, true)}};
    }

    @DataProvider(name = "clientId-85-184")
    public Object[][] dataProviderClientIds(ITestContext context) {
        return new Object[][]{{CLIENT_ID_85}, {CLIENT_ID_184}};
    }

    @DataProvider(name = "validClientIdAndProductCodesForReceivingValidMixerCode")
    public Object[][] dataProviderGenerateValidMixerCodes() {
        return new Object[][]{{CLIENT_ID_184, PRODUCT_CODE_VAFHMO, MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAFHMO}, {CLIENT_ID_184, PRODUCT_CODE_VAGHMO, MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAGHMO}, {CLIENT_ID_185, PRODUCT_CODE_PIHMO, MIXER_CODE_CLIENTID_185_PRODUCTCODE_PIHMO},
                {CLIENT_ID_185, PRODUCT_CODE_PIXHMO, MIXER_CODE_CLIENTID_185_PRODUCTCODE_PIXHMO}};
    }

    @DataProvider(name = "clientId-85-210-212-220")
    public Object[][] dataProviderClientIdsForReferenceData(ITestContext context) {
        if (context.getCurrentXmlTest().getAllParameters().size() != 0) {
            return new Object[][]{{context.getCurrentXmlTest().getParameter("client-210")}};
        } else {
            return new Object[][]{{CLIENT_ID_85}, {CLIENT_ID_210}, {CLIENT_ID_212}, {CLIENT_ID_220}};
        }
    }

    @DataProvider(name = "clientId-85-183-184-185-187-188-199-210")
    public Object[][] dataProviderSOCClientIdsForReferenceData() {
        return new Object[][]{{CLIENT_ID_85}, {CLIENT_ID_183}, {CLIENT_ID_184}, {CLIENT_ID_185}, {CLIENT_ID_187}, {CLIENT_ID_188}, {CLIENT_ID_199}, {CLIENT_ID_210}};
    }

    @DataProvider(name = "clientId-and-issuance-state-code")
    public Object[][] dataProvideClientIdAndIssuanceStateCode(ITestContext context) {
        if (context.getCurrentXmlTest().getAllParameters().size() != 0) {
            return new Object[][]{{context.getCurrentXmlTest().getParameter(CLIENT_PARAM), context.getCurrentXmlTest().getParameter("issuance-state-code")}};
        } else {
            return new Object[][]{{CLIENT_ID_85, ISSUANCE_STATE_CODE_IN}, {CLIENT_ID_85, ISUUANCE_STATE_CODE_KY}, {CLIENT_ID_85, ISSUANCE_STATE_WI},
                    {CLIENT_ID_210, ISUUANCE_STATE_CODE_NM}, {CLIENT_ID_210, ISUUANCE_STATE_CODE_TX}, {CLIENT_ID_210, ISUUANCE_STATE_CODE_WA},
                    {CLIENT_ID_210, ISSUANCE_STATE_WI}, {CLIENT_ID_210, ISUUANCE_STATE_CODE_NY}, {CLIENT_ID_212, ISSUANCE_STATE_CA},
                    {CLIENT_ID_212, ISSUANCE_STATE_WI}, {CLIENT_ID_212, ISUUANCE_STATE_CODE_CT}, {CLIENT_ID_220, ISUUANCE_STATE_CODE_NM},
                    {CLIENT_ID_233, ISUUANCE_STATE_CODE_NE}, {CLIENT_ID_234, ISUUANCE_STATE_CODE_MO}};
        }
    }

    @DataProvider(name = "client-ids-client-config")
    public Object[][] dataProviderClientIdsForClientConfig() {
        return new Object[][]{{CLIENT_ID_199}, {CLIENT_ID_189}, {CLIENT_ID_188}, {CLIENT_ID_187}, {CLIENT_ID_186}, {CLIENT_ID_185}, {CLIENT_ID_184}};
    }

    @DataProvider(name = "invalid-id-client-config")
    public Object[][] dataProviderInvalidIdScenariosClientConfig() {
        return new Object[][]{{SPECIAL_CHARACTERS}, {EMPTY_STRING}, {RandomStringUtils.random(10, true, true)}, {RandomStringUtils.random(10, true, false)}, {null}};
    }

    @DataProvider(name = "invalid-issuance-state-code-client-config")
    public Object[][] dataProviderInvalidIssuanceStateCodeConfig() {
        return new Object[][]{{"GTF"}, {EMPTY_STRING}, {INVALID_STATE_CODE_LOWER_CASE}, {RandomStringUtils.random(3, true, false)}, {RandomStringUtils.random(3, false, true)}, {SPECIAL_CHARS_LENGHT_4}};
    }

    @DataProvider(name = "invalid-client-id-and-invalid-issuance-state-code-client-config")
    public Object[][] dataProviderInvalidIssuanceStateCodeAndInvalidClientIdConfig() {
        return new Object[][]{{SPECIAL_CHARACTERS, INVALID_STATE_CODE_3_ALPHABETIC}, {EMPTY_STRING, EMPTY_STRING}, {ALPHANUMERIC_10CHARS, INVALID_STATE_CODE_LOWER_CASE}, {EMPTY_STRING, SPECIAL_CHARS_LENGHT_4}};
    }

    @DataProvider(name = "invalidMemberIdAndClientMemberId")
    public Object[][] dataProviderInvalidMemberAndClientMemberId() {
        return new Object[][]{{NULL, DOLLAR_SIGN}, {DOLLAR_SIGN, TOTAL_3_NUM}, {TOTAL_3_NUM, TOTAL_31_NUM}, {TOTAL_31_NUM, NULL}, {NULL, NULL}};
    }

    @DataProvider(name = "clientId-and-issuance-state-code-line-of-business")
    public Object[][] dataProvideClientIdAndIssuanceStateCodeAndLineOfBusiness(ITestContext context) {
        if (context.getCurrentXmlTest().getAllParameters().size() != 0) {
            return new Object[][]{{context.getCurrentXmlTest().getParameter("clientId-210"), context.getCurrentXmlTest().getParameter("issuance-state-code"), context.getCurrentXmlTest().getParameter("line-of-business-code")}};
        } else {
            return new Object[][]{{CLIENT_ID_85, ISSUANCE_STATE_CODE_IN, COMMERCIAL_CODE}, {CLIENT_ID_85, ISUUANCE_STATE_CODE_KY, COMMERCIAL_CODE}, {CLIENT_ID_85, ISSUANCE_STATE_WI, COMMERCIAL_CODE},
                    {CLIENT_ID_210, ISUUANCE_STATE_CODE_GA, MEDICAID_CODE}, {CLIENT_ID_210, ISSUANCE_STATE_CODE_IN, MEDICAID_CODE}, {CLIENT_ID_210, ISUUANCE_STATE_CODE_NY, MEDICAID_CODE},
                    {CLIENT_ID_212, ISSUANCE_STATE_CA, MEDICARE_CODE}, {CLIENT_ID_212, ISUUANCE_STATE_CODE_KY, MEDICARE_CODE}, {CLIENT_ID_212, ISUUANCE_STATE_CODE_NH, MEDICARE_CODE}, {CLIENT_ID_233, ISUUANCE_STATE_CODE_NE, MEDICAID_CODE}, {CLIENT_ID_234, ISUUANCE_STATE_CODE_MO, MEDICAID_CODE}, {CLIENT_ID_220, ISUUANCE_STATE_CODE_NM, MEDICAID_CODE}};
        }
    }

    @DataProvider(name = "invalid-line-of-business-client-config")
    public Object[][] dataProviderInvalidLineOfBusiness() {
        return new Object[][]{{INVALID_LINE_OF_BUSINESS_ALPHABETIC}, {EMPTY_STRING}, {INVALID_LINE_OF_BUSINESS_NUMERIC},
                {INVALID_LINE_OF_BUSINESS_NUMERIC_16_CHARS}, {SPECIAL_CHARACTERS}};
    }

    @DataProvider(name = "valid-client-id-line-of-business-default-config")
    public Object[][] dataProviderValidClientIdLineOfBusinessIssuanceStateCodeDefaultConfig() {
        return new Object[][]{{CLIENT_ID_186, ISSUANCE_STATE_CA}, {CLIENT_ID_185, ISSUANCE_STATE_CO},
                {CLIENT_ID_187, ISUUANCE_STATE_CODE_CT}, {CLIENT_ID_188, ISUUANCE_STATE_CODE_NH}};
    }

    @DataProvider(name = "anthem-west-clients-184-185-186-mixer-code-change")
    public Object[][] dataProviderAnthemWestClient() {
        return new Object[][]{{CLIENT_ID_186}, {CLIENT_ID_185}, {CLIENT_ID_184}};
    }

    @DataProvider(name = "mixerCodeMapInvalid")
    public Object[][] dataProviderMixerCodeMapInvalid() {
        return new Object[][]{{null, EMPLOYER_GROUP_CODE, SOURCE_SYSTEM_CODE_OS},
                {CLIENT_ID_184, null, SOURCE_SYSTEM_CODE_OS}, {CLIENT_ID_184, EMPLOYER_GROUP_CODE, null}};
    }

    @DataProvider(name = "mixerCodeMapInvalidFields")
    public Object[][] dataProviderMixerCodeMapInvalidFields() {
        return new Object[][]{{CLIENT_ID_184, RandomStringUtils.random(257, true, true), SOURCE_SYSTEM_CODE_OS}, {CLIENT_ID_184, EMPLOYER_GROUP_CODE, TOTAL_11_NUM}};
    }

    @DataProvider(name = "invalid-mixer-codes")
    public Object[][] dataProviderInvalidMixerCodes() {
        return new Object[][]{{INVALID_MIXERCODE_1}, {INVALID_MIXERCODE_2}, {INVALID_MIXERCODE_3}, {INVALID_MIXERCODE_4}, {INVALID_MIXERCODE_5}, {INVALID_MIXERCODE_6}, {INVALID_MIXERCODE_7}};
    }

    @DataProvider(name = "contextModeValue")
    public Object[][] setContextModeInPlatformContext() {
        return new Object[][]{{ContextModeEnum.TEST.toString()}, {ContextModeEnum.PROD.toString()}, {CONTEXT_MODE_DEFAULT}};
    }

    @DataProvider(name = "contextModeInDataBase")
    public Object[][] setReverseContextModeInPlatformContext() {
        return new Object[][]{{(ContextModeEnum.TEST.toString()), (ContextModeEnum.PROD.toString())}, {ContextModeEnum.PROD.toString(), ContextModeEnum.TEST.toString()}, {CONTEXT_MODE_DEFAULT, ContextModeEnum.TEST.toString()}};
    }

    @DataProvider(name = "solutionIdOneAndEmptyForEligibilityCheck")
    public Object[][] solutionIdOneAndEmptyEligibility() {
        return new Object[][]{{SOLUTION_ID_1}, {EMPTY_STRING_WITH_NO_SPACE}, {EMPTY_STRING}};
    }

    @DataProvider(name = "invalidSolutionIdForEligibility")
    public Object[][] invalidSolutionIdForEligibility() {
        return new Object[][]{{SOLUTION_ID_TEST}, {NULL_VALUE}};
    }

    @DataProvider(name = "validZipCodeForClient210DisasterDeclaration")
    public Object[][] provideValidZipCodeForClient210DisasterDeclaration() {
        return new Object[][]{{ZIP_CODE_75001, ""}, {ZIP_CODE_75001, "  "}, {ZIP_CODE_75001, null}, {ZIP_CODE_75001, SUBCLIENT_CODE}, {ZIP_CODE_75006, ""}, {ZIP_CODE_75006, "  "}, {ZIP_CODE_75006, null}, {ZIP_CODE_75006, SUBCLIENT_CODE}};
    }

    @DataProvider(name = "validZipCodeForClient85DisasterDeclaration")
    public Object[][] provideValidZipCodeForClient85DisasterDeclaration() {
        return new Object[][]{{ZIP_CODE_46403, STATE_CODE_IN}, {ZIP_CODE_60423, STATE_CODE_KY}};
    }

    @DataProvider(name = "validZipCodeForClientDisasterDeclaration")
    public Object[][] provideValidZipCodeForClientDisasterDeclaration() {
        return new Object[][]{{ZIP_CODE_46403, STATE_CODE_IN, CLIENT_ID_85}, {ZIP_CODE_60423, STATE_CODE_KY, CLIENT_ID_85}, {ZIP_CODE_89002, STATE_CODE_NV, CLIENT_ID_185},
                {ZIP_CODE_30030, ISUUANCE_STATE_CODE_GA, CLIENT_ID_183}, {ZIP_CODE_12084, STATE_CODE_NY, CLIENT_ID_199}, {ZIP_CODE_80538, "", CLIENT_ID_184}, {ZIP_CODE_30080, "", CLIENT_ID_183}

        };
    }

    @DataProvider(name = "employerGroupCode32BJ")
    public Object[][] employerGroupCode32BJ() {
        return new Object[][]{{EMPLOYER_GROUP_CODE_720902}, {EMPLOYER_GROUP_CODE_720903}, {EMPLOYER_GROUP_CODE_720904}, {EMPLOYER_GROUP_CODE_720905}, {EMPLOYER_GROUP_CODE_720906}
        };
    }

    @DataProvider(name = "getProviderDescriptionClientIdAndProductCode")
    public Object[][] getProviderDescription() {
        return new Object[][]{{CLIENT_ID_85, PRODUCT_CODE_HIAC_85, COMMERCIAL_CODE, STATE_CODE_WA},
                {CLIENT_ID_183, PRODUCT_CODE_IND_183, COMMERCIAL_CODE, STATE_CODE_WA},
                {CLIENT_ID_184, PRODUCT_CODE_VAGHMO_184, COMMERCIAL_CODE, STATE_CODE_WA},
                {CLIENT_ID_185, PRODUCT_CODE_HMO_185, COMMERCIAL_CODE, STATE_CODE_WA},
                {CLIENT_ID_186, PRODUCT_CODE_MEDADV_186, COMMERCIAL_CODE, STATE_CODE_WA},
                {CLIENT_ID_187, PRODUCT_CODE_HMO_187, COMMERCIAL_CODE, STATE_CODE_WA},
                {CLIENT_ID_188, PRODUCT_CODE_4703_188, COMMERCIAL_CODE, STATE_CODE_WA},
                {CLIENT_ID_189, PRODUCT_CODE_PPO_189, COMMERCIAL_CODE, STATE_CODE_WA},
                {CLIENT_ID_199, PRODUCT_CODE_SHO_199, COMMERCIAL_CODE, STATE_CODE_WA},
                {CLIENT_ID_210, PRODUCT_CODE_189401_210_MEDICARE, MEDICARE_CODE, STATE_CODE_WA},
                {CLIENT_ID_210, PRODUCT_CODE_IACHP1_210_MEDICAID, MEDICAID_CODE, STATE_CODE_IA},
                {CLIENT_ID_212, PRODUCT_CODE_ECLPR0_212_MEDICARE, MEDICARE_CODE, STATE_CODE_CA}};
    }

    @DataProvider(name = "restrictedAccessEmployerGroupCode")
    public Object[][] restrictedAccessEmployerGroupCode() {
        return new Object[][]{{EMPLOYERGROUPCODE_220_1}, {EMPLOYERGROUPCODE_220_2}, {EMPLOYERGROUPCODE_220_3}, {EMPLOYERGROUPCODE_220_4}, {EMPLOYERGROUPCODE_220_5}, {EMPLOYERGROUPCODE_220_6}, {EMPLOYERGROUPCODE_220_7}};
    }

    @DataProvider(name = "ensureWorkFlowEmployerGroupCode")
    public Object[][] ensureWorkFlowEmployerGroupCode() {
        return new Object[][]{
                {EMPLOYER_GROUP_CODE_720902}, {EMPLOYER_GROUP_CODE_720903}, {EMPLOYER_GROUP_CODE_720904}, {EMPLOYER_GROUP_CODE_720905}, {EMPLOYER_GROUP_CODE_720906}};
    }

    @DataProvider(name = "ensureWorkFlowClientIdZipcodeState")
    public Object[][] ensureWorkFlowClientIdZipcodeState() {
        return new Object[][]{
                {CLIENT_ID_85, STATE_CODE_IN, ZIP_CODE_46403}, {CLIENT_ID_85, STATE_CODE_KY, ZIP_CODE_60423}, {CLIENT_ID_185, STATE_CODE_NV, ZIP_CODE_89002}, {CLIENT_ID_183, ISUUANCE_STATE_CODE_GA, ZIP_CODE_30030}, {CLIENT_ID_199, STATE_CODE_NY, ZIP_CODE_12084}, {CLIENT_ID_184, "", ZIP_CODE_80538}, {CLIENT_ID_183, "", ZIP_CODE_30080}};
    }

    @DataProvider(name = "restrictedClientId")
    public Object[][] restrictedClientId() {
        return new Object[][]{
                {CLIENT_ID_183}, {CLIENT_ID_184}, {CLIENT_ID_185}, {CLIENT_ID_186}, {CLIENT_ID_187}, {CLIENT_ID_188},
                {CLIENT_ID_188}, {CLIENT_ID_189}, {CLIENT_ID_199}, {CLIENT_ID_210}, {CLIENT_ID_212}
        };
    }
}