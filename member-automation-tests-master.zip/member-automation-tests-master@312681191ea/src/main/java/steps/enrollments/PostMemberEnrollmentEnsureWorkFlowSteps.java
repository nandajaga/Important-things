package steps.enrollments;

import com.aim.automation.dtos.ErrorDTO;
import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.workflow.MemberDemographicWorkflowResDTO;
import dtos.workflow.WorkFlowResponseDTO;
import factories.workflow.DemographicEnsureWorkflowDTOFactory;
import factories.workflow.WorkFlowFactory;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import static helpers.constants.BasePathConstants.*;
import static helpers.constants.Constants.SUBCLIENT_CODE;


/**
 * Created by @sbioi on 05/15/2020
 */
public class PostMemberEnrollmentEnsureWorkFlowSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public PostMemberEnrollmentEnsureWorkFlowSteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BASE_PATH_POST_ENROLLMENT_ENSUREWORKFLOW);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    public Response postWorkFlowResponse(String subClientCode) {
        Object payLoad = new WorkFlowFactory().createWorkFlowDTO(SUBCLIENT_CODE);
        requestSpecification.addBodyToRequest(payLoad);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        return result;
    }
    public WorkFlowResponseDTO[] postEnrollmentEnsureWorkFlowSteps(String subClientCode) {
        Response response = postWorkFlowResponse(subClientCode);
        response.then().statusCode(HttpStatus.SC_OK);

        return response.as(WorkFlowResponseDTO[].class);
    }

    public ErrorDTO whenCaseRequestIdIsNullSendError(String subClientCode) {
        Response response = postWorkFlowResponse(subClientCode);
        response.then().statusCode(HttpStatus.SC_INTERNAL_SERVER_ERROR);

        return response.as(ErrorDTO.class);
    }

    public Response whenCaseIdIsNotNullSendError(String subClientCode) {
        requestSpecification.setContentType(ContentType.JSON);

        return postWorkFlowResponse(subClientCode);
    }
}
