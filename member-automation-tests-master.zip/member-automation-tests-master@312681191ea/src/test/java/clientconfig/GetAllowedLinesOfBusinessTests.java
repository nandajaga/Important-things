package clientconfig;

import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.clientconfig.AllowedLineOfBusinessResponseDTO;
import helpers.dataproviders.DataProviders;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import steps.clientconfig.AllowedLinesOfBusinessSteps;

import java.util.List;

import static helpers.constants.BasePathConstants.BASE_PATH_GET_V1_ALLOWED_LINES_OF_BUSINESS;
import static helpers.constants.Constants.*;
import static helpers.constants.Constants.CLIENT_ID_85;
import static helpers.constants.ConstantsClientIds.*;

public class GetAllowedLinesOfBusinessTests extends GetTests {

    private AllowedLinesOfBusinessSteps allowedLinesOfBusinessSteps;

    @BeforeClass
    public void init() {
        basePath = BASE_PATH_GET_V1_ALLOWED_LINES_OF_BUSINESS;
        pathParamsMap.clear();
        pathParamsMap.put("clientId", CLIENT_ID_85);
    }

    //-----------------------------------------------POSITIVE-TESTS--------------------------------------------------------

    /* https://jira.aimspecialtyhealth.com/browse/OSPP-9064
     * Updated the test for NEMO, HSCSC(clientId's 220, 233 & 234)
     */
    @Test(dataProvider = "clientId-and-issuance-state-code", dataProviderClass = DataProviders.class)
    public void whenGetAllowedLinesOfBusinessWithValidClientIdAndWithOptionalIssuanceStateCodeThenResponseSC200(String clientId, String issuanceStateCode) {

        allowedLinesOfBusinessSteps = new AllowedLinesOfBusinessSteps(platformContextHeader, headers);
        List<AllowedLineOfBusinessResponseDTO> allowedLinesOfBusiness = allowedLinesOfBusinessSteps.getAllowedLinesOfBusiness(clientId, issuanceStateCode);

        for (AllowedLineOfBusinessResponseDTO allowedLineOfBusinessResponseDTO : allowedLinesOfBusiness) {
            switch (clientId) {
                case CLIENT_ID_85:
                    softly.then(allowedLineOfBusinessResponseDTO.getId()).isEqualTo(COMMERCIAL_ID);
                    softly.then(allowedLineOfBusinessResponseDTO.getCode()).isEqualTo(COMMERCIAL_CODE);
                    softly.then(allowedLineOfBusinessResponseDTO.getName()).isEqualTo(COMMERCIAL_NAME);
                    break;
                case CLIENT_ID_210:
                    if (allowedLineOfBusinessResponseDTO.getId().equals(MEDICAID_ID)) {
                        softly.then(allowedLineOfBusinessResponseDTO.getId()).isEqualTo(MEDICAID_ID);
                        softly.then(allowedLineOfBusinessResponseDTO.getCode()).isEqualTo(MEDICAID_CODE);
                        softly.then(allowedLineOfBusinessResponseDTO.getName()).isEqualTo(MEDICAID_NAME);
                    } else if (allowedLineOfBusinessResponseDTO.getId().equals(MEDICARE_ID)) {
                        softly.then(allowedLineOfBusinessResponseDTO.getId()).isEqualTo(MEDICARE_ID);
                        softly.then(allowedLineOfBusinessResponseDTO.getCode()).isEqualTo(MEDICARE_CODE);
                        softly.then(allowedLineOfBusinessResponseDTO.getName()).isEqualTo(MEDICARE_NAME);
                    }
                    break;
                case CLIENT_ID_212:
                    softly.then(allowedLineOfBusinessResponseDTO.getId()).isEqualTo(MEDICARE_ID);
                    softly.then(allowedLineOfBusinessResponseDTO.getCode()).isEqualTo(MEDICARE_CODE);
                    softly.then(allowedLineOfBusinessResponseDTO.getName()).isEqualTo(MEDICARE_NAME);
                    break;
                case CLIENT_ID_220:
                case CLIENT_ID_233:
                case CLIENT_ID_234:
                    softly.then(allowedLineOfBusinessResponseDTO.getId()).isEqualTo(MEDICAID_ID);
                    softly.then(allowedLineOfBusinessResponseDTO.getCode()).isEqualTo(MEDICAID_CODE);
                    softly.then(allowedLineOfBusinessResponseDTO.getName()).isEqualTo(MEDICAID_NAME);
                    break;
                default:
                    softly.then(allowedLineOfBusinessResponseDTO.getId()).isNotEmpty().isNotBlank().isNotNull();
                    softly.then(allowedLineOfBusinessResponseDTO.getCode()).isNotEmpty().isNotBlank().isNotNull();
                    softly.then(allowedLineOfBusinessResponseDTO.getName()).isNotNull().isNotBlank().isNotEmpty();
                    break;
            }
        }
        softly.assertAll();
    }

    @Test(dataProvider = "client-ids-client-config", dataProviderClass = DataProviders.class)
    public void whenGetAllowedLinesOfBusinessWithValidClientIdAndWithoutOptionalIssuanceStateCodeThenResponseSC200(String clientId) {

        allowedLinesOfBusinessSteps = new AllowedLinesOfBusinessSteps(platformContextHeader, headers);
        List<AllowedLineOfBusinessResponseDTO> allowedLinesOfBusiness = allowedLinesOfBusinessSteps.getAllowedLinesOfBusiness(clientId, null);

        for (AllowedLineOfBusinessResponseDTO allowedLineOfBusinessResponseDTO : allowedLinesOfBusiness) {
            softly.then(allowedLineOfBusinessResponseDTO.getId()).isEqualTo(COMMERCIAL_ID);
            softly.then(allowedLineOfBusinessResponseDTO.getCode()).isEqualTo(COMMERCIAL_CODE);
            softly.then(allowedLineOfBusinessResponseDTO.getName()).isEqualTo(COMMERCIAL_NAME);
        }

        softly.assertAll();
    }

//-----------------------------------------------------------------NEGATIVE-TESTS-------------------------------------------------------------------------------------------------

    @Test(dataProvider = "invalid-id-client-config", dataProviderClass = DataProviders.class)
    public void whenGetAllowedLinesOfBusinessWithInvalidClientIdThenResponseSC400(String clientId) {

        allowedLinesOfBusinessSteps = new AllowedLinesOfBusinessSteps(platformContextHeader, headers);
        ErrorDTO allowedLinesOfBusinessErrorDTO = allowedLinesOfBusinessSteps.getAllowedLinesOfBusinessWithError(clientId, null);

        softly.then(allowedLinesOfBusinessErrorDTO.getCode()).isEqualTo(HttpStatus.SC_BAD_REQUEST);
        softly.then(allowedLinesOfBusinessErrorDTO.getMessage()).isEqualTo(ERROR_MESSAGE_CLIENT_ID_VALIDATION);
        softly.assertAll();
    }

    @Test(dataProvider = "invalid-issuance-state-code-client-config", dataProviderClass = DataProviders.class)
    public void whenGetAllowedLinesOfBusinessWithInvalidIssuanceStateCodeThenResponseSC400(String issuanceStateCode) {

        allowedLinesOfBusinessSteps = new AllowedLinesOfBusinessSteps(platformContextHeader, headers);
        ErrorDTO allowedLinesOfBusinessErrorDTO = allowedLinesOfBusinessSteps.getAllowedLinesOfBusinessWithError(CLIENT_ID_186, issuanceStateCode);

        softly.then(allowedLinesOfBusinessErrorDTO.getCode()).isEqualTo(HttpStatus.SC_BAD_REQUEST);
        softly.then(allowedLinesOfBusinessErrorDTO.getMessage()).isEqualTo(ALLOWED_LINES_OF_BUSINESS_ISSUANCE_STATE_CODE_VALIDATION);
        softly.assertAll();
    }

    @Test(dataProvider = "invalid-client-id-and-invalid-issuance-state-code-client-config", dataProviderClass = DataProviders.class)
    public void whenGetAllowedLinesOfBusinessWithInvalidIssuanceStateCodeAndInvalidClientIdThenResponseSC400(String clientId, String issuanceStateCode) {

        allowedLinesOfBusinessSteps = new AllowedLinesOfBusinessSteps(platformContextHeader, headers);
        ErrorDTO allowedLinesOfBusinessErrorDTO = allowedLinesOfBusinessSteps.getAllowedLinesOfBusinessWithError(clientId, issuanceStateCode);

        softly.then(allowedLinesOfBusinessErrorDTO.getCode()).isEqualTo(HttpStatus.SC_BAD_REQUEST);
        softly.then(allowedLinesOfBusinessErrorDTO.getMessage()).contains(ALLOWED_LINES_OF_BUSINESS_CLIENT_ID_ISSUANCE_STATE_CODE_VALIDATION_PARTIAL_MESSAGE);
        softly.assertAll();
    }
}
