package clientconfig;

import com.aim.automation.tests.base.GetTests;
import dtos.ErrorSpringDTO;
import dtos.clientconfig.IsManualAddAllowedResponseDTO;
import helpers.dataproviders.DataProviders;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import steps.clientconfig.ManualAddAllowedSteps;

import static helpers.constants.BasePathConstants.BASE_PATH_IS_MANUAL_ADD_ALLOWED;
import static helpers.constants.ClientConfigConstants.*;
import static helpers.constants.Constants.CLIENT_ID_85;
import static helpers.constants.Constants.*;
import static org.apache.http.HttpStatus.SC_BAD_REQUEST;

public class GetIsManualAddAllowedTests extends GetTests {

    private ManualAddAllowedSteps isManualAddAllowedSteps;


    @BeforeClass
    public void init() {
        basePath = BASE_PATH_IS_MANUAL_ADD_ALLOWED;
        pathParamsMap.clear();
        pathParamsMap.put("clientId", CLIENT_ID_85);
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test(dataProvider = "clientIdAll", dataProviderClass = DataProviders.class)
    public void whenAllowedMemberIsManuallyAddedThenServiceResponseIs200WithMessageAndScript(String clientId) {
        isManualAddAllowedSteps = new ManualAddAllowedSteps(platformContextHeader, headers);
        IsManualAddAllowedResponseDTO isManualAddAllowed = isManualAddAllowedSteps.getIsManualAddAllowed(clientId);

        switch (clientId) {
            case CLIENT_ID_40:
                softly.then(isManualAddAllowed.getIsManualAddAllowed()).isTrue();
                softly.then(isManualAddAllowed.getMessage()).isNull();
                softly.then(isManualAddAllowed.getScript()).isNull();
                softly.then(isManualAddAllowed.getScriptLabel()).isNull();
                break;
            case CLIENT_ID_55:
                softly.then(isManualAddAllowed.getIsManualAddAllowed()).isFalse();
                softly.then(isManualAddAllowed.getMessage()).isNull();
                softly.then(isManualAddAllowed.getScript()).isNull();
                softly.then(isManualAddAllowed.getScriptLabel()).isNull();
                break;
            case CLIENT_ID_210:
                softly.then(isManualAddAllowed.getIsManualAddAllowed()).isTrue();
                softly.then(isManualAddAllowed.getMessage()).isEqualTo(MESSAGE_NOT_ELIGIBLE);
                softly.then(isManualAddAllowed.getScript()).isEqualTo(SCRIPT);
                softly.then(isManualAddAllowed.getScriptLabel()).isEqualTo(SCRIPT_LABEL);
                break;
            case DEFAULT_CLIENT_ID:
                softly.then(isManualAddAllowed.getIsManualAddAllowed()).isFalse();
                softly.then(isManualAddAllowed.getMessage()).isEqualTo(MESSAGE_ADD_NOT_ALLOWED);
                softly.then(isManualAddAllowed.getScript()).isNull();
                softly.then(isManualAddAllowed.getScriptLabel()).isNull();
                break;
            default:
                softly.then(isManualAddAllowed.getIsManualAddAllowed()).isTrue();
                softly.then(isManualAddAllowed.getMessage()).isEqualTo(MESSAGE_ELIGIBLE);
                softly.then(isManualAddAllowed.getScript()).isEqualTo(SCRIPT);
                softly.then(isManualAddAllowed.getScriptLabel()).isEqualTo(SCRIPT_LABEL);
        }

        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-400---------------------------------------------
    @Test
    public void whenSentInvalidClientIdThenSC400() {
        String invalidClientId = "";
        isManualAddAllowedSteps = new ManualAddAllowedSteps(platformContextHeader, headers);
        ErrorSpringDTO error = isManualAddAllowedSteps.getIsManualAddAllowedWithError(invalidClientId);

        softly.then(error.getStatus()).isEqualTo(SC_BAD_REQUEST);
        softly.then(error.getError()).isEqualTo(ERROR_BAD_REQUEST);
        softly.then(error.getMessage()).isEqualTo(ERROR_MESSAGE_SC400);
        softly.assertAll();
    }
}

