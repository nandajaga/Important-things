package com.abc.automation.factories.member.demographics;

import com.abc.automation.dtos.member.demographics.EmailsDTO;
import com.abc.automation.dtos.member.demographics.MemberDemographicsDTO;
import com.abc.automation.dtos.member.demographics.PhonesDTO;
import com.abc.automation.helpers.constants.MemberConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created by PPetarcheva on 4/17/2019.
 */
public class MemberDemographicsDTOFactory {

    private static final Logger LOGGER = LoggerFactory.getLogger(MemberDemographicsDTOFactory.class);

    public MemberDemographicsDTO createMemberDemographicsDTO(String clientId, String firstName, String lastName, ArrayList<EmailsDTO> emails, ArrayList<PhonesDTO> phones) {
        MemberDemographicsDTO memberDemographicsDTO = new MemberDemographicsDTO();
        DateFormat date = new SimpleDateFormat("yyyy-MM-dd");
        Date dob = new Date();

        try {
            dob = date.parse(MemberConstants.DOB);
        } catch (ParseException e) {
            LOGGER.error("Could not parse the dates!");
        }

        memberDemographicsDTO.setAdditionalMemberIds(new AdditionalMemberIdDTOFactory().createAdditionalMemberIdsDTO());
        memberDemographicsDTO.setAddresses(new AddressesDTOFactory().createAddressesDTO());
        memberDemographicsDTO.setClientDependentRelationCode(MemberConstants.CLIENT_DEPENDENT_RELATION_CODE);
        memberDemographicsDTO.setClientId(clientId);
        memberDemographicsDTO.setClientMemberId(MemberConstants.CLIENT_MEMBER_ID);
        memberDemographicsDTO.setClientSpecificDemographics(new ClientSpecificDemographicsDTOFactory().createClientSpecificDemographicsDTO());
        memberDemographicsDTO.setDateOfBirth(dob);
        memberDemographicsDTO.setDependentCode(MemberConstants.DEPENDENT_CODE);
        memberDemographicsDTO.setFirstName(firstName);
        memberDemographicsDTO.setGender(MemberConstants.GENDER);
        memberDemographicsDTO.setLastName(lastName);
        memberDemographicsDTO.setLegacyMemberId(MemberConstants.LEGACY_MEMBER_ID);
        memberDemographicsDTO.setManuallyCreated(Boolean.TRUE);
        memberDemographicsDTO.setManuallyUpdated(Boolean.TRUE);
        memberDemographicsDTO.setMemberPrefix(MemberConstants.MEMBER_PREFIX);

        if (phones != null) {
            memberDemographicsDTO.setPhones(phones);
        }

        if (emails != null) {
            memberDemographicsDTO.setEmails(emails);
        }

        return memberDemographicsDTO;
    }
}
