package com.abc.automation.helpers;

import org.apache.commons.lang3.RandomStringUtils;

/**
 * Created by PPetarcheva on 3/19/2019.
 */
public class GeneralFunctionality {

    public String generateRandomString(int count) {
        return RandomStringUtils.random(count, true, true);
    }

    public String generateRandomString() {
        return generateRandomString(10);
    }

    public String generateRandomIntAsString(int length) {
        return RandomStringUtils.randomNumeric(length);
    }

    public int generateRandomInt(int length) {
        return Integer.parseInt(generateRandomIntAsString(length));
    }
}
