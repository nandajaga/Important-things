package enrollments;

import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.datamanager.MemberResponseDTO;
import dtos.enrollments.MemberEnrollmentDTO;
import dtos.enrollments.MemberEnrollmentsDTO;
import dtos.enrollments.SolutionDTO;
import helpers.constants.BasePathConstants;
import helpers.dataproviders.DataProviders;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.datamanager.MemberDataManagerSteps;
import steps.enrollments.MemberEnrollmentIdSteps;
import steps.enrollments.MemberEnrollmentsSteps;

import java.util.ArrayList;

import static helpers.constants.ClientConfigConstants.CLIENT_ID_186;
import static helpers.constants.ClientConfigConstants.CLIENT_ID_85;
import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_210;

/**
 * Created by RKondakova on 4/16/2019.
 */
public class GetClientIdMemberEnrollmentIdTest extends GetTests {

    private MemberDataManagerSteps memberDataManagerSteps;
    private MemberEnrollmentsSteps memberEnrollmentsSteps;
    private MemberEnrollmentIdSteps memberEnrollmentIdSteps;
    private String CLIENT_MEMBER_ID;

    @BeforeMethod
    public void initMethod() {
        CLIENT_MEMBER_ID = RandomStringUtils.randomNumeric(10) + RandomStringUtils.randomAlphabetic(5).toUpperCase();
    }

    @BeforeClass
    public void init() {
        basePath = BasePathConstants.BASE_PATH_ENROLLMENTS_ID;

        pathParamsMap.clear();
        pathParamsMap.put("clientId", CLIENT_ID_85);
        pathParamsMap.put("memberId", MEMBER_ID_REAL);
        pathParamsMap.put("enrollmentId", ENROLLMENT_ID_REAL);
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test
    public void whenGetAndValidClientId85AndMemberIdSentThenServiceReturnsEnrollmentsAndEnrollmentsId() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        memberEnrollmentIdSteps = new MemberEnrollmentIdSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_85, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_85, memberId);

        String enrollmentId = memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId();
        softly.then(enrollmentId).isNotEmpty().isNotBlank().isNotNull();

        MemberEnrollmentDTO memberEnrollmentDTO = memberEnrollmentIdSteps.getMemberEnrollment(CLIENT_ID_85, memberId, enrollmentId);

        softly.then(memberEnrollmentsDTO.getId()).contains(memberId);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).contains(CLIENT_ID_85);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientMemberProductCode()).isEqualTo(CLIENT_MEMBER_PRODUCT_CODE);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isEqualTo(MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAGHMO);
        softly.then(memberEnrollmentDTO.getEnrollmentId()).contains(enrollmentId);
        softly.then(memberEnrollmentDTO.getHealthPlan()).contains(HEALTHPLAN_AUTHEM_CR);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getErisaIndicator()).isNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMarketSegmentCode()).isNull();


        ArrayList<SolutionDTO> solutions = memberEnrollmentDTO.getSolutions();
        for (SolutionDTO solution : solutions) {
            if (solution.isLevelOfCare() && solution.getProgramType().equals(SOLUTION_PROGRAM_TYPE)) {
                softly.then(solution.getSolutionId()).isIn(SOLUTION_ID_ONE, SOLUTION_ID_TWO);
            }
        }
        softly.assertAll();
    }

    @Test
    public void whenGetAndValidClientId186AndMemberIdSentThenServiceReturnsEnrollmentsAndEnrollmentsId() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        memberEnrollmentIdSteps = new MemberEnrollmentIdSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_186, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_186, memberId);

        String enrollmentId = memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId();
        softly.then(enrollmentId).isNotEmpty().isNotBlank().isNotNull();

        MemberEnrollmentDTO memberEnrollmentDTO = memberEnrollmentIdSteps.getMemberEnrollment(CLIENT_ID_186, memberId, enrollmentId);

        softly.then(memberEnrollmentsDTO.getId()).contains(memberId);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).contains(CLIENT_ID_186);
        softly.then(memberEnrollmentDTO.getEnrollmentId()).contains(enrollmentId);
        softly.then(memberEnrollmentDTO.getHealthPlan()).contains(HEALTHPLAN_AUTHEM_BC);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientMemberProductCode()).isEqualTo(CLIENT_MEMBER_PRODUCT_CODE);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isNotEmpty().isNotNull();

        ArrayList<SolutionDTO> solutions = memberEnrollmentDTO.getSolutions();
        for (SolutionDTO solution : solutions) {
            if (solution.isLevelOfCare() && solution.getProgramType().equals(SOLUTION_PROGRAM_TYPE)) {
                softly.then(solution.getSolutionId()).isIn(SOLUTION_ID_ONE, SOLUTION_ID_TWO);
            }
        }

        softly.assertAll();
    }

    @Test
    public void whenGetAndValidClientId210AndMemberIdSentThenServiceReturnsEnrollmentsAndEnrollmentsId() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        memberEnrollmentIdSteps = new MemberEnrollmentIdSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_210, ISSUANCE_STATE_WI, SS_WGS, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_210, memberId);
        String enrollmentId = memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId();
        softly.then(enrollmentId).isNotEmpty().isNotBlank().isNotNull();

        MemberEnrollmentDTO memberEnrollmentDTO = memberEnrollmentIdSteps.getMemberEnrollment(CLIENT_ID_210, memberId, enrollmentId);

        softly.then(memberEnrollmentsDTO.getId()).contains(memberId);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).contains(CLIENT_ID_210);
        softly.then(memberEnrollmentDTO.getEnrollmentId()).contains(enrollmentId);
        softly.then(memberEnrollmentDTO.getHealthPlan()).contains(HEALTHPLAN_ANTHEM_BCBS_WI);
        ArrayList<SolutionDTO> solutions = memberEnrollmentDTO.getSolutions();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientMemberProductCode()).isNullOrEmpty();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isNotEmpty().isNotNull();

        for (SolutionDTO solution : solutions) {
            if (solution.isLevelOfCare() && solution.getProgramType().equals(SOLUTION_PROGRAM_TYPE)) {
                softly.then(solution.getSolutionId()).isIn(SOLUTION_ID_ONE, SOLUTION_ID_TWO);
            }
        }
        softly.assertAll();
    }

    @Test
    public void whenGetAndValidClientId210FLAndMemberIdSentThenServiceReturnsEnrollmentsAndEnrollmentsId() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        memberEnrollmentIdSteps = new MemberEnrollmentIdSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_210, ISSUANCE_STATE_FL, SS_WGS, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_210, memberId);

        String enrollmentId = memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId();
        softly.then(enrollmentId).isNotEmpty().isNotBlank().isNotNull();

        MemberEnrollmentDTO memberEnrollmentDTO = memberEnrollmentIdSteps.getMemberEnrollment(CLIENT_ID_210, memberId, enrollmentId);

        softly.then(memberEnrollmentsDTO.getId()).contains(memberId);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).contains(CLIENT_ID_210);
        softly.then(memberEnrollmentDTO.getEnrollmentId().contains(enrollmentId));
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getHealthPlan()).contains(HEALTHPLAN_AMERIGROUP_FL);
        ArrayList<SolutionDTO> solutions = memberEnrollmentDTO.getSolutions();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientMemberProductCode()).isNullOrEmpty();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isNotEmpty().isNotNull();

        for (SolutionDTO solution : solutions) {
            if (solution.isLevelOfCare() && solution.getProgramType().equals(SOLUTION_PROGRAM_TYPE_QI)) {
                softly.then(solution.getSolutionId()).isIn(SOLUTION_ID_ONE, SOLUTION_ID_TWO);
            }
        }

        softly.assertAll();
    }

    @Test
    public void whenGetClientId85AndMemberIdSentThenServiceReturnsEnrollmentsAndMixerCodeWithSpaceOn4ThPosition() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        memberEnrollmentIdSteps = new MemberEnrollmentIdSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_186, EMPLOYER_GROUP_NUMBER, 1, MIXER_CODE_SPACE_ON_4TH_POSITION, null, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_186, memberId);

        String enrollmentId = memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId();
        softly.then(enrollmentId).isNotEmpty().isNotBlank().isNotNull();

        MemberEnrollmentDTO memberEnrollmentDTO = memberEnrollmentIdSteps.getMemberEnrollment(CLIENT_ID_186, memberId, enrollmentId);

        softly.then(memberEnrollmentsDTO.getId()).contains(memberId);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).isEqualTo(CLIENT_ID_186);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isEqualTo(MIXER_CODE_SPACE_ON_4TH_POSITION);
        softly.then(memberEnrollmentDTO.getEnrollmentId()).contains(enrollmentId);
        softly.assertAll();
    }

    @Test(dataProvider = "clientId-85-183-184-186-187-188-189-199", dataProviderClass = DataProviders.class)
    public void whenGetAndValidClientIdsAndMemberIdSentThenServiceReturnsEnrollmentsAndEnrollmentsIdForRehabSolutionIdsToFetchReviewProgramCodes(String clientId) {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        memberEnrollmentIdSteps = new MemberEnrollmentIdSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(clientId, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(clientId, memberId);

        String enrollmentId = memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId();
        softly.then(enrollmentId).isNotEmpty().isNotBlank().isNotNull();

        MemberEnrollmentDTO memberEnrollmentDTO = memberEnrollmentIdSteps.getMemberEnrollment(clientId, memberId, enrollmentId);

        softly.then(memberEnrollmentsDTO.getId()).contains(memberId);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).contains(clientId);
        softly.then(memberEnrollmentDTO.getEnrollmentId()).contains(enrollmentId);

        ArrayList<SolutionDTO> solutions = memberEnrollmentDTO.getSolutions();
        for (SolutionDTO solution : solutions) {

            switch (solution.getSolutionId()) {
                case SOLUTION_ID_15:
                case SOLUTION_ID_16:
                case SOLUTION_ID_17:
                    softly.then(solution.getReviewPrograms().get(0).getReviewProgramCode()).isEqualTo(REVIEW_PROGRAM_CODE_SOC);
                    break;

                case SOLUTION_ID_ONE:
                case SOLUTION_ID_TWO:
                case SOLUTION_ID_3:
                case SOLUTION_ID_11:
                case SOLUTION_ID_12:
                case SOLUTION_ID_6:
                case SOLUTION_ID_7:
                case SOLUTION_ID_8:
                case SOLUTION_ID_9:
                    softly.then(solution.getReviewPrograms()).isNull();
                    break;
            }
        }
        softly.assertAll();
    }


    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-404---------------------------------------------

    @Test
    public void whenGetAndValidClientId85FLAndMemberIdNotValidSentThenServiceReturnsEnrollmentsAndEnrollmentsId() {
        memberEnrollmentIdSteps = new MemberEnrollmentIdSteps(platformContextHeader, headers);

        ErrorDTO error = memberEnrollmentIdSteps.getMemberEnrollmentErrors(CLIENT_ID_85, MEMBER_ID_TEST, ENROLLMENT_ID_REAL);

        softly.then(error.getCode()).isEqualTo(HttpStatus.SC_NOT_FOUND);
        softly.then(error.getMessage()).contains(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }

    @Test
    public void whenGetAndValidClientId186AndMemberIdSentThenServiceReturnsEnrollmentsAndInvalidEnrollmentsId() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        memberEnrollmentIdSteps = new MemberEnrollmentIdSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_186, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();
        softly.then(memberId).isNotEmpty().isNotBlank().isNotNull();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_186, memberId);

        ErrorDTO error = memberEnrollmentIdSteps.getMemberEnrollmentErrors(CLIENT_ID_186, memberId, ENROLLMENT_ID_TEST);

        softly.then(error.getCode()).isEqualTo(HttpStatus.SC_NOT_FOUND);
        softly.then(error.getMessage()).contains(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }

    @Test(dataProvider = "contextModeValue", dataProviderClass = DataProviders.class)
    public void whenGetValidClientIdMemberIdAndSolutionIdSentWithTestContextModeThenServiceReturnsEnrollmentId(String contextMode) {
        PlatformContextUtils platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeContextMode(platformContextHeader, contextMode);

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_85, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        //get enrollmentId from the same DB
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        memberEnrollmentIdSteps = new MemberEnrollmentIdSteps(platformContextHeader, headers);

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_85, memberId);

        String enrollmentId = memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId();
        softly.then(enrollmentId).isNotEmpty().isNotBlank().isNotNull();

        MemberEnrollmentDTO memberEnrollmentDTO = memberEnrollmentIdSteps.getMemberEnrollment(CLIENT_ID_85, memberId, enrollmentId);

        softly.then(memberEnrollmentsDTO.getId()).contains(memberId);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientId()).contains(CLIENT_ID_85);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientMemberProductCode()).isEqualTo(CLIENT_MEMBER_PRODUCT_CODE);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isEqualTo(MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAGHMO);
        softly.then(memberEnrollmentDTO.getEnrollmentId()).contains(enrollmentId);
        softly.assertAll();
    }

    @Test(dataProvider = "contextModeInDataBase", dataProviderClass = DataProviders.class)
    public void whenGetValidClientIdMemberIdAndSolutionIdSentWithReversedContextModeThenServiceReturnsSC404(String contextMode, String dataBaseMode) {
        PlatformContextUtils platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeContextMode(platformContextHeader, contextMode);
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_85, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        //get enrollments from different DB
        platformContextHeader = platformContextUtils.changeContextMode(platformContextHeader, dataBaseMode);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);

        ErrorDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollmentsErrors(CLIENT_ID_85, memberId);

        softly.then(memberEnrollmentsDTO.getCode()).isEqualTo(HttpStatus.SC_NOT_FOUND);
        softly.then(memberEnrollmentsDTO.getMessage()).contains(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }
}
