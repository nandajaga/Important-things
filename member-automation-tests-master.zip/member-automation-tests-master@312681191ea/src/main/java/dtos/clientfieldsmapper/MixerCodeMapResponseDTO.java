package dtos.clientfieldsmapper;

/**
 * Created by VBaliyska on 10/11/2019.
 */
public class MixerCodeMapResponseDTO {

    private String mixerCode;

    public String getMixerCode() {
        return mixerCode;
    }

    public void setMixerCode(String mixerCode) {
        this.mixerCode = mixerCode;
    }
}
