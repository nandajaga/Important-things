package com.abc.automation.factories.provider.snapshot;

import com.abc.automation.dtos.provider.servicing.CreateServicingProviderSnapshotDTO;
import com.abc.automation.helpers.constants.ProviderConstants;

import java.util.Collections;
import java.util.Map;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
public class CreateServicingProviderSnapshotDTOFactory {

    public CreateServicingProviderSnapshotDTO createServicingProviderSnapshotDTO(int providerClientId, String ngProviderId) {

        return createServicingProviderSnapshotDTO(providerClientId,ngProviderId, Collections.emptyMap());
    }

    public CreateServicingProviderSnapshotDTO createServicingProviderSnapshotDTO(int providerClientId, String ngProviderId, Map<String,String> servicingProvider) {

        CreateServicingProviderSnapshotDTO payload = new CreateServicingProviderSnapshotDTO();
        payload.setBenefitExceptionRequested(Boolean.TRUE);
        payload.setProviderClientId(providerClientId);
        payload.setNgProviderId(ngProviderId);
        payload.setSanctionLookupCompletedFlag(Boolean.FALSE);
        payload.setOptOutLookupCompletedFlag(Boolean.FALSE);
        payload.setLabelType(ProviderConstants.LABEL_TYPE);
        payload.setOrder(ProviderConstants.ORDER);
        payload.setPlaceOfService(new PlaceOfServiceDTOFactory().createPlaceOfServiceDTO());
        payload.setNetworkStatus(servicingProvider.get("networkStatus"));

        return payload;
    }
}
