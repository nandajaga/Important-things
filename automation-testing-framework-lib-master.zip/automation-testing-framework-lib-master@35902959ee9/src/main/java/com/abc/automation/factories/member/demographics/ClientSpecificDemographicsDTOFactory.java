package com.abc.automation.factories.member.demographics;

import com.abc.automation.dtos.member.demographics.ClientSpecificDemographicsDTO;
import com.abc.automation.helpers.constants.MemberConstants;

/**
 * Created by PPetarcheva on 4/17/2019.
 */
public class ClientSpecificDemographicsDTOFactory {

    public ClientSpecificDemographicsDTO createClientSpecificDemographicsDTO() {

        ClientSpecificDemographicsDTO clientSpecificDemographicsDTO = new ClientSpecificDemographicsDTO();

        clientSpecificDemographicsDTO.setEstimatedDateOfBirthFlag(Boolean.TRUE);
        clientSpecificDemographicsDTO.setLangPreferenceCode(MemberConstants.LANG_PREFERENCE_CODE);
        clientSpecificDemographicsDTO.setLangPreferenceOriginalCode(MemberConstants.LANG_PREFERENCE_ORIGINAL_CODE);
        clientSpecificDemographicsDTO.setRestrictedAccessCode(MemberConstants.RESTRICTED_ACCESS_CODE);
        clientSpecificDemographicsDTO.setSubClientCode(MemberConstants.SUB_CLIENT_CODE);
        clientSpecificDemographicsDTO.setUpdateFlag(Boolean.TRUE);

        return clientSpecificDemographicsDTO;
    }
}
