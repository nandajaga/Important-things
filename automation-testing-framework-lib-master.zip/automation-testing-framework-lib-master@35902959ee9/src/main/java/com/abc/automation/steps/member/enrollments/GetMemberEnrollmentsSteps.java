package com.abc.automation.steps.member.enrollments;

import com.abc.automation.helpers.CustomFilterableRequestSpecification;
import com.abc.automation.helpers.EnvironmentHelper;
import com.abc.automation.helpers.RequestOperationsHelper;
import com.abc.automation.helpers.constants.BasePathConstants;
import com.abc.automation.helpers.enums.DomainEnum;
import com.abc.automation.dtos.member.enrollments.MemberEnrollmentsResponseDTO;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by PPetarcheva on 4/24/2019.
 */
public class GetMemberEnrollmentsSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public GetMemberEnrollmentsSteps(String platformContext, Headers headers) {
        requestSpecification = new CustomFilterableRequestSpecification();
        requestOperationsHelper = new RequestOperationsHelper();
        EnvironmentHelper environmentHelper = new EnvironmentHelper();

        requestSpecification.addBasePath(BasePathConstants.MEMBER_GET_ENROLLMENTS_BASE_PATH);
        requestSpecification.addPlatformContextToRequest(platformContext);

        requestSpecification.addBaseURI(environmentHelper.constructBaseURIForDomain(DomainEnum.MEMBER));
        requestSpecification.addHeaders(headers);
    }

    public GetMemberEnrollmentsSteps(CustomFilterableRequestSpecification requestSpecification) {
        this.requestSpecification = new CustomFilterableRequestSpecification();
        requestOperationsHelper = new RequestOperationsHelper();
        EnvironmentHelper environmentHelper = new EnvironmentHelper();

        Headers headers = requestSpecification.getFilterableRequestSpecification().getHeaders();

        this.requestSpecification.addHeaders(headers);
        this.requestSpecification.addBasePath(BasePathConstants.MEMBER_GET_ENROLLMENTS_BASE_PATH);
        this.requestSpecification.addBaseURI(environmentHelper.constructBaseURIForDomain(DomainEnum.MEMBER));
    }

    public Response getMemberEnrollmentsResponse(String clientId, String memberId) {
        Map<String, String> pathParams = new HashMap<>();
        pathParams.put("clientId", clientId);
        pathParams.put("memberId", memberId);

        requestSpecification.addPathParams(pathParams);

        return requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());
    }

    public MemberEnrollmentsResponseDTO getMemberEnrollments(String clientId, String memberId) {
        Response result = getMemberEnrollmentsResponse(clientId, memberId);

        result.then().statusCode(HttpStatus.SC_OK);

        return result.as(MemberEnrollmentsResponseDTO.class);
    }

    public String getMemberEnrollmentsId(String clientId, String memberId) {
        MemberEnrollmentsResponseDTO memberEnrollmentsResponseDTO = getMemberEnrollments(clientId, memberId);

        return memberEnrollmentsResponseDTO.getEnrollments().get(0).getEnrollmentId();
    }
}
