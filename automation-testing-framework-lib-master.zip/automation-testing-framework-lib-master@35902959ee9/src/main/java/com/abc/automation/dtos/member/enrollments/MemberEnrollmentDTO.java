package com.abc.automation.dtos.member.enrollments;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by PPetarcheva on 4/17/2019.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MemberEnrollmentDTO {
    private String baseId;
    private String clientId;
    private String clientPrimaryCarePhysician;
    private ClientSpecificEnrollmentsDTO clientSpecificEnrollments;
    private Boolean covered;
    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = "yyyy-MM-dd"
    )
    private Date effectiveEndDate;
    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = "yyyy-MM-dd"
    )
    @JsonIgnore
    private Date updateDate;
    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = "yyyy-MM-dd"
    )
    private Date effectiveStartDate;
    @JsonIgnore
    private String healthPlan;
    private String employerGroupNumber;
    private String enrollmentId;
    private String enrollmentPrefix;
    private String fundType;
    private String issuanceState;
    private String lineOfBusiness;
    private String lineOfBusinessId;
    private Boolean manuallyEntered;
    private Boolean nationalFlag;
    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = "yyyy-MM-dd"
    )
    private Date originalEffectiveEndDate;
    private String actionCode;
    private String practitionerCode;
    private String primaryCarePhysicianNumber;
    private String productCode;
    private String productCodeId;
    private String programCoverageIndicator;
    private ArrayList<SolutionDTO> solutions;
    private String clientMemberProductCode;
    private Integer reviewPackageId;
    private Integer consumerEngagementId;
    private List<ConsumerEngagementPreferencesDTO> consumerEngagementPreferences;

    public String getBaseId() {
        return baseId;
    }

    public void setBaseId(String baseId) {
        this.baseId = baseId;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientPrimaryCarePhysician() {
        return clientPrimaryCarePhysician;
    }

    public void setClientPrimaryCarePhysician(String clientPrimaryCarePhysician) {
        this.clientPrimaryCarePhysician = clientPrimaryCarePhysician;
    }

    public ClientSpecificEnrollmentsDTO getClientSpecificEnrollments() {
        return clientSpecificEnrollments;
    }

    public void setClientSpecificEnrollments(ClientSpecificEnrollmentsDTO clientSpecificEnrollments) {
        this.clientSpecificEnrollments = clientSpecificEnrollments;
    }

    public Boolean getCovered() {
        return covered;
    }

    public void setCovered(Boolean covered) {
        this.covered = covered;
    }

    public Date getEffectiveEndDate() {
        if (effectiveEndDate != null) {
            return new Date(effectiveEndDate.getTime());
        } else {
            return null;
        }
    }

    public void setEffectiveEndDate(Date effectiveEndDate) {
        if (effectiveEndDate != null) {
            this.effectiveEndDate = new Date(effectiveEndDate.getTime());
        } else {
            this.effectiveEndDate = null;
        }
    }

    public Date getUpdateDate() {
        if (updateDate != null) {
            return new Date(updateDate.getTime());
        } else {
            return null;
        }
    }

    public void setUpdateDate(Date updateDate) {
        if (updateDate != null) {
            this.updateDate = new Date(updateDate.getTime());
        } else {
            this.updateDate = null;
        }
    }

    public Date getEffectiveStartDate() {
        if (effectiveStartDate != null) {
            return new Date(effectiveStartDate.getTime());
        } else {
            return null;
        }
    }

    public void setEffectiveStartDate(Date effectiveStartDate) {
        if (effectiveStartDate != null) {
            this.effectiveStartDate = new Date(effectiveStartDate.getTime());
        } else {
            this.effectiveStartDate = null;
        }
    }

    public String getHealthPlan() {
        return healthPlan;
    }

    public void setHealthPlan(String healthPlan) {
        this.healthPlan = healthPlan;
    }

    public String getEmployerGroupNumber() {
        return employerGroupNumber;
    }

    public void setEmployerGroupNumber(String employerGroupNumber) {
        this.employerGroupNumber = employerGroupNumber;
    }

    public String getEnrollmentId() {
        return enrollmentId;
    }

    public void setEnrollmentId(String enrollmentId) {
        this.enrollmentId = enrollmentId;
    }

    public String getEnrollmentPrefix() {
        return enrollmentPrefix;
    }

    public void setEnrollmentPrefix(String enrollmentPrefix) {
        this.enrollmentPrefix = enrollmentPrefix;
    }

    public String getFundType() {
        return fundType;
    }

    public void setFundType(String fundType) {
        this.fundType = fundType;
    }

    public String getIssuanceState() {
        return issuanceState;
    }

    public void setIssuanceState(String issuanceState) {
        this.issuanceState = issuanceState;
    }

    public Boolean getManuallyEntered() {
        return manuallyEntered;
    }

    public void setManuallyEntered(Boolean manuallyEntered) {
        this.manuallyEntered = manuallyEntered;
    }

    public Boolean getNationalFlag() {
        return nationalFlag;
    }

    public void setNationalFlag(Boolean nationalFlag) {
        this.nationalFlag = nationalFlag;
    }

    public Date getOriginalEffectiveEndDate() {
        if (originalEffectiveEndDate != null) {
            return new Date(originalEffectiveEndDate.getTime());
        } else {
            return null;
        }
    }

    public void setOriginalEffectiveEndDate(Date originalEffectiveEndDate) {
        if (originalEffectiveEndDate != null) {
            this.originalEffectiveEndDate = new Date(originalEffectiveEndDate.getTime());
        } else {
            this.originalEffectiveEndDate = null;
        }
    }

    public String getActionCode() {
        return actionCode;
    }

    public void setActionCode(String actionCode) {
        this.actionCode = actionCode;
    }

    public String getPractitionerCode() {
        return practitionerCode;
    }

    public void setPractitionerCode(String practitionerCode) {
        this.practitionerCode = practitionerCode;
    }

    public String getPrimaryCarePhysicianNumber() {
        return primaryCarePhysicianNumber;
    }

    public void setPrimaryCarePhysicianNumber(String primaryCarePhysicianNumber) {
        this.primaryCarePhysicianNumber = primaryCarePhysicianNumber;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductCodeId() {
        return productCodeId;
    }

    public void setProductCodeId(String productCodeId) {
        this.productCodeId = productCodeId;
    }

    public String getProgramCoverageIndicator() {
        return programCoverageIndicator;
    }

    public void setProgramCoverageIndicator(String programCoverageIndicator) {
        this.programCoverageIndicator = programCoverageIndicator;
    }

    public String getLineOfBusinessId() {
        return lineOfBusinessId;
    }

    public void setLineOfBusinessId(String lineOfBusinessId) {
        this.lineOfBusinessId = lineOfBusinessId;
    }

    public String getLineOfBusiness() {
        return lineOfBusiness;
    }

    public void setLineOfBusiness(String lineOfBusiness) {
        this.lineOfBusiness = lineOfBusiness;
    }

    public ArrayList<SolutionDTO> getSolutions() {
        if (this.solutions != null) {
            return new ArrayList<>(solutions);
        } else {
            return null;
        }
    }

    public void setSolutions(ArrayList<SolutionDTO> solutions) {
        if (solutions != null) {
            this.solutions = new ArrayList<>(solutions);
        } else {
            this.solutions = null;
        }
    }

    public String getClientMemberProductCode() {
        return clientMemberProductCode;
    }

    public void setClientMemberProductCode(String clientMemberProductCode) {
        this.clientMemberProductCode = clientMemberProductCode;
    }

    public Integer getReviewPackageId() {
        return reviewPackageId;
    }

    public void setReviewPackageId(Integer reviewPackageId) {
        this.reviewPackageId = reviewPackageId;
    }

    public Integer getConsumerEngagementId() {
        return consumerEngagementId;
    }

    public void setConsumerEngagementId(Integer consumerEngagementId) {
        this.consumerEngagementId = consumerEngagementId;
    }

    public List<ConsumerEngagementPreferencesDTO> getConsumerEngagementPreferences() {
        return consumerEngagementPreferences;
    }

    public void setConsumerEngagementPreferences(List<ConsumerEngagementPreferencesDTO> consumerEngagementPreferences) {
        this.consumerEngagementPreferences = consumerEngagementPreferences;
    }
}
