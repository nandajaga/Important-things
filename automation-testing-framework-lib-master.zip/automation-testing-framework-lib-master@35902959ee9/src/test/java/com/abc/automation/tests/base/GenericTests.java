package com.abc.automation.tests.base;

import com.abc.automation.dtos.GenericErrorDTO;
import com.abc.automation.helpers.CustomFilterableRequestSpecification;
import com.abc.automation.helpers.constants.ErrorMessagesConstants;
import com.abc.automation.helpers.dataproviders.DataProviders;
import com.abc.automation.helpers.enums.RequestHeadersEnum;
import com.abc.automation.steps.ErrorsSteps;
import io.restassured.http.ContentType;
import io.restassured.http.Method;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class GenericTests extends BaseTest {

    private CustomFilterableRequestSpecification specification;

    @BeforeMethod (alwaysRun = true)
    public void initGenericTests() {
        specification = new CustomFilterableRequestSpecification();
        specification.addBasePath(basePath);
        specification.addPathParams(pathParamsMap);
        specification.addQueryParams(queryParamsMap);
        specification.setContentType(ContentType.JSON);
        specification.addHeaders(headers);
        specification.addHeaders(additionalHeaders);
        specification.addPlatformContextToRequest(platformContextHeader);
        if (endpointHttpMethod.equals(Method.POST) || endpointHttpMethod.equals(Method.PUT)) {
            specification.addBodyToRequest(body);
        }
    }

    @DataProvider(name = "notAllowedMethods")
    public Object[][] createDataProviderForNotAllowedMethods() {
        if (notAllowedMethodsList.contains(endpointHttpMethod)) {
            notAllowedMethodsList.remove(endpointHttpMethod);
        }
        Object[][] notAllowedMethodsDataProvider = new Object[this.notAllowedMethodsList.size()][1];

        for (int i = 0; i < this.notAllowedMethodsList.size(); i++) {
            notAllowedMethodsDataProvider[i][0] = this.notAllowedMethodsList.get(i);

        }
        return notAllowedMethodsDataProvider;
    }

    @Test(dataProvider = "notAllowedMethods")
    public void whenNotAllowedHttpMethodSendThenServiceReturnsMethodNotAllowedResponse(Method notAllowedMethod) {
        ErrorsSteps errorsSteps = new ErrorsSteps();
        GenericErrorDTO errorDTO = errorsSteps.sendRequestWithGenericError(specification, notAllowedMethod);
        softNG.assertEquals(errorDTO.getStatus(), HttpStatus.SC_METHOD_NOT_ALLOWED, "Status code is not correct!");
        softNG.assertEquals(errorDTO.getMessage(), String.format(ErrorMessagesConstants.METHOD_NOT_ALLOWED_MESSAGE, notAllowedMethod), "Error message is not correct!");

        softNG.assertAll();
    }

    @Test
    public void whenNoBodyThenServiceReturnsBadRequest() {
        if (endpointHttpMethod.equals(Method.POST) || endpointHttpMethod.equals(Method.PUT)) {

            specification.addHeaders(requestSpecification.getFilterableRequestSpecification().getHeaders());
            specification.addBodyToRequest("");
            ErrorsSteps errorsSteps = new ErrorsSteps();
            GenericErrorDTO errorDTO = errorsSteps.sendRequestWithGenericError(specification, endpointHttpMethod);

            softNG.assertEquals(errorDTO.getStatus(), HttpStatus.SC_BAD_REQUEST, "Status code is not correct!");
            softNG.assertTrue(ErrorMessagesConstants.BAD_REQUEST_ERROR.equals(errorDTO.getError()) || ErrorMessagesConstants.BAD_REQUEST_ERROR.equals(errorDTO.getMessage())
                    || errorDTO.getMessage().startsWith("Required request body is missing"), "Error message is not correct!");

        }
        softNG.assertAll();
    }

    @Test
    public void whenNoRequestHeaderSentThenServiceReturnsBadRequest() {
        ErrorsSteps errorsSteps = new ErrorsSteps();
        specification.getFilterableRequestSpecification().removeHeaders();
        specification.setContentType(ContentType.JSON);
        GenericErrorDTO errorDTO = errorsSteps.sendRequestWithGenericError(specification, endpointHttpMethod);

        softNG.assertEquals(errorDTO.getStatus(), HttpStatus.SC_BAD_REQUEST, "Status code is not correct!");
        softNG.assertTrue(errorDTO.getMessage().startsWith(ErrorMessagesConstants.BAD_REQUEST_MESSAGE_START), "Error message is not correct!");
        softNG.assertTrue(errorDTO.getMessage().endsWith(ErrorMessagesConstants.BAD_REQUEST_MESSAGE_END), "Error message is not correct!");
        softNG.assertAll();
    }

    @Test(dataProvider = "Headers", dataProviderClass = DataProviders.class)
    public void whenMissingHeaderThenServiceReturnsBadRequest(RequestHeadersEnum missingHeader) {
        specification.removeHeader(missingHeader.getName());
        ErrorsSteps errorsSteps = new ErrorsSteps();
        GenericErrorDTO errorDTO = errorsSteps.sendRequestWithGenericError(specification, endpointHttpMethod);

        softNG.assertEquals(errorDTO.getStatus(), HttpStatus.SC_BAD_REQUEST, "Status code is not correct!");
        softNG.assertEquals(errorDTO.getMessage(), String.format(ErrorMessagesConstants.BAD_REQUEST_MESSAGE, missingHeader.getName()), "Error message is not correct!");
        softNG.assertAll();
    }
}
