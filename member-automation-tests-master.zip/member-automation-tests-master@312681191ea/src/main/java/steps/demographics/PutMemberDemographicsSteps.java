package steps.demographics;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.datamanager.MemberResponseDTO;
import dtos.demographics.EmailsDTO;
import dtos.demographics.PhonesDTO;
import factories.demographics.MemberUpdateDTOFactory;
import helpers.constants.BasePathConstants;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by PPetarcheva on 5/20/2019.
 */
public class PutMemberDemographicsSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public PutMemberDemographicsSteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BasePathConstants.BASE_PATH_PUT_DEMOGRAPHICS);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    public Response updateMember(Object bodyDTO, String clientId, String memberId) {
        requestSpecification.addBodyToRequest(bodyDTO);

        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("memberId", memberId);
        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);

        Response response = requestOperationsHelper.sendPutRequest(requestSpecification.getFilterableRequestSpecification());

        return response;
    }

    public MemberResponseDTO updateMemberContacts(String memberId, String clientId, ArrayList<EmailsDTO> emails, ArrayList<PhonesDTO> phones, boolean isPhoneInformationConfirmed, boolean isEmailInformationConfirmed, boolean noEmailInformationProvided, boolean noPhoneInformationProvided) {
        MemberUpdateDTOFactory memberUpdateDTOFactory = new MemberUpdateDTOFactory();
        Object updateBody = memberUpdateDTOFactory.createMemberUpdateDTO(clientId, memberId, emails, phones, isEmailInformationConfirmed, isPhoneInformationConfirmed, noEmailInformationProvided, noPhoneInformationProvided);

        Response response = updateMember(updateBody, clientId, memberId);

        response.then().statusCode(HttpStatus.SC_OK);

        return response.as(MemberResponseDTO.class);
    }

    public ErrorDTO updateMemberContactsWithError(int statusCode, String memberId, String clientId, ArrayList<EmailsDTO> emails, ArrayList<PhonesDTO> phones, boolean isPhoneInformationConfirmed, boolean isEmailInformationConfirmed, boolean noEmailInformationProvided, boolean noPhoneInformationProvided) {
        MemberUpdateDTOFactory memberUpdateDTOFactory = new MemberUpdateDTOFactory();
        Object updateBody = memberUpdateDTOFactory.createMemberUpdateDTO(clientId, memberId, emails, phones, isEmailInformationConfirmed, isPhoneInformationConfirmed, noEmailInformationProvided, noPhoneInformationProvided);

        Response response = updateMember(updateBody, clientId, memberId);

        response.then().statusCode(statusCode);

        return response.as(ErrorDTO.class);
    }
}
