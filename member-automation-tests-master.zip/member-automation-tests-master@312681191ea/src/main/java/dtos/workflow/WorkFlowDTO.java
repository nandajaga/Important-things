package dtos.workflow;

/**
 * Created by RKohli on 04/28/2020
 */
public class WorkFlowDTO {

    private String businessKey;
    private String workFlowType;
    private String workFlowReason;
    private String workFlowMessaging;

    public String getBusinessKey() {
        return businessKey;
    }

    public void setBusinessKey(String businessKey) {
        this.businessKey = businessKey;
    }

    public String getWorkFlowType() {
        return workFlowType;
    }

    public void setWorkFlowType(String workFlowType) {
        this.workFlowType = workFlowType;
    }

    public String getWorkFlowReason() {
        return workFlowReason;
    }

    public void setWorkFlowReason(String workFlowReason) {
        this.workFlowReason = workFlowReason;
    }
    public String getWorkFlowMessaging() {
        return workFlowMessaging;
    }

    public void setWorkFlowMessaging(String workFlowMessaging) {
        this.workFlowMessaging = workFlowMessaging;
    }
}


