package com.abc.automation.factories.provider.ordering;

import com.abc.automation.dtos.provider.ordering.CreateOrderingProviderDTO;
import com.abc.automation.helpers.constants.ProviderConstants;
import org.apache.commons.lang3.RandomStringUtils;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
public class CreateOrderingProviderDTOFactory {

    public CreateOrderingProviderDTO createOrderingProviderDTO() {
        return createOrderingProviderDTO(ProviderConstants.CLIENT_ID);
    }

    public CreateOrderingProviderDTO createOrderingProviderDTO(int clientId) {

        CreateOrderingProviderDTO payload = new CreateOrderingProviderDTO();

        payload.setAddressDTO(new ProviderAddressDTOFactory().createAddressV3AddDTO());
        payload.setFirstName("Test." + RandomStringUtils.random(10, true, true));
        payload.setLastName("Automation." + RandomStringUtils.random(10, true, true));
        payload.setClientId(clientId);
        payload.setSpecialtyCode(ProviderConstants.SPECIALTY_CODE);
        payload.setPhone(ProviderConstants.PHONE);
        payload.setFax(ProviderConstants.FAX);
        payload.setEmail(ProviderConstants.EMAIL);

        return payload;
    }
}
