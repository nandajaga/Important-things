package factories.clientconfig;

import dtos.clientconfig.RestrictedAccessDTO;

public class RestrictedAccessDTOFactory {

    public RestrictedAccessDTO setRestrictedAccessDTO(String memberId, String dependentRelationCode, String restrictionType, String clientId, String employerGroupNumber) {
        RestrictedAccessDTO restrictedAccessDTO = new RestrictedAccessDTO();

        restrictedAccessDTO.setMemberId(memberId);
        restrictedAccessDTO.setDependentRelationCode(dependentRelationCode);
        restrictedAccessDTO.setRestrictionType(restrictionType);
        restrictedAccessDTO.setClientId(clientId);
        restrictedAccessDTO.setEmployerGroupNumber(employerGroupNumber);
        return restrictedAccessDTO;
    }
}
