package com.abc.automation.dtos.provider.providerQuestionAnswer;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class VisibilityDTO {

    private Boolean visible;
    private String questionId;
    private String questionOptionIds;

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getQuestionOptionIds() {
        return questionOptionIds;
    }

    public void setQuestionOptionIds(String questionOptionIds) {
        this.questionOptionIds = questionOptionIds;
    }

    public Boolean getVisible() {
        return visible;
    }

    public void setVisible(Boolean visible) {
        this.visible = visible;
    }
}
