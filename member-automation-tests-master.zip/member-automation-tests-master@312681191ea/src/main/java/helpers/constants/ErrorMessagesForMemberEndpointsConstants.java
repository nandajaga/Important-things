package helpers.constants;

public class ErrorMessagesForMemberEndpointsConstants {

    public static final String ERR_MSG_CLIENT_MEMBER_ID_NOT_PRESENT = "Required String parameter 'client-member-id' is not present";
    public static final String ERR_MSG_CLIENT_MEMBER_ID_NOT_LENGTH = "client-member-id should not contain special characters and should be 4 to 30 length.";
    public static final String ERR_MSG_SIZE_VALUE = "Page size must not be less than one!";
    public static final String ERR_MSG_INDEX_VALUE = "[from] parameter cannot be negative";
    public static final String ERR_MSG_DOB_NOT_PRESENT = "Required Date parameter 'date-of-birth' is not present";
    public static final String ERR_MSG_DOB_NOT_MET_FOR_ACTUAL_PARAMETERS = "Parameter conditions \"date-of-birth!=\" not met for actual request parameters";
    public static final String ERR_MSG_DOB_VALID_PERIOD = "date-of-birth could not be a date in the future or more than 150 years overdue.";
    public static final String ERR_MSG_DOB_FORMAT = "Failed to convert value of type 'java.lang.String' to required type 'java.util.Date'; nested exception is org.springframework.core.convert.ConversionFailedException: Failed to convert from type [java.lang.String] to type [@io.swagger.annotations.ApiParam @org.springframework.web.bind.annotation.RequestParam @org.springframework.format.annotation.DateTimeFormat java.util.Date] for value '$'; nested exception is java.lang.IllegalArgumentException: Invalid format: \"$\"";
    public static final String ERR_MSG_DOB_YEAR_FORMAT = "for monthOfYear must be in the range [1,12]";
    public static final String ERR_MSG_DOB_DAY_FORMAT = "for dayOfMonth must be in the range [1,31]";
    public static final String ERR_MSG_DOB_MONTH_FORMAT = "for monthOfYear must be in the range [1,12]";
    public static final String ERR_MSG_SORT_FORMAT_INCORRECT = "Incorrect sort persistedField added = ";
    public static final String ERR_MSG_SORT_PROPERTY = "Property must not null or empty!";
    public static final String ERR_MSG_FIRST_LAST_NAME = "At least one character is required for first-name/last-name parameters which can be alpha with space, hyphen and apostrophe.";
    public static final String ERR_MSG_FIRST_NAME_NOT_PRESENT = "Required String parameter 'first-name' is not present";
    public static final String ERR_MSG_CLIENT_LAST_NAME_NOT_PRESENT = "Required String parameter 'last-name' is not present";
    public static final String ERR_MSG_CLIENT_ID_LENGTH = "client-id should contain at most 10 digits and should not start with 0.";
    public static final String ERR_MSG_DEPENDENT_CODE_FORMAT = "dependent-code should contain exactly 2 characters and should be alphanumeric.";
    public static final String ERR_MSG_CLIENT_ID_NOT_PRESENT = "Required String parameter 'client-id' is not present";
    public static final String ERR_MSG_DEPENDENT_CODE_NOT_PRESENT = "Required String parameter 'dependent-code' is not present";
    public static final String ERR_MSG_DEMOGRAPHIC_NOT_FOUND_FOR_CLIENT_ID = "Demographics not found for client id: ";
    public static final String ERR_MSG_DEMOGRAPHIC_NOT_FOUND_FOR_CLIENT_ID_ADDITION = " and member id: ";
    public static final String ERR_MSG_MEMBER_ID_NOT_PRESENT = "Required String parameter 'memberId' is not present";
    public static final String ERR_MSG_ENTRY_NOT_FOUND = "Entity not found!";
    public static final String ERR_MSG_LIST_PARAMETER_NOT_PRESENT = "Required List parameter 'fields' is not present";
    public static final String ERR_MSG_LIST_POVIDE_VALID_FORMAT_CLIENT_ID = "Please provide valid format of clientId with up to 10 digits. Should not be null, empty or contain special characters.";
    public static final String ERR_MSG_VALIDATION_FAILED_NOT_NULL = "Validation failed. [must not be null]";
    public static final String ERR_MSG_INVALID_FIELDS = "There are invalid fields entered";
    public static final String ERR_MSG_CONFIGURATION_LIST_IS_EMPTY = "Request configurations list is empty.";
    public static final String ERR_MSG_CHANNEL_CODE = "PlatformContext channelCode cannot be null or empty";
    public static final String ERR_MSG_CLIENT_ID = "PlatformContext Member clientId cannot be null";
    public static final String ERR_MSG_ID = "Please provide valid UUID format of %s";
    public static final String ERR_MSG_CLIENT_ID_10_DIGITS = "Validation failed. [Please provide valid format of clientId with up to 10 digits";
    public static final String ERR_MSG_SOURCESYSTEM = "Validation failed. [Please provide sourceSystem";
    public static final String ERR_MSG_EMPLOYEE_GROUP_NUMBER = "Validation failed. [Please provide employerGroupNumber";
    public static final String ERR_MSG_EMPLOYEE_GROUP_LENGHT = "Validation failed. [Please provide valid employerGroupNumber with up to 256 symbols";
    public static final String ERR_MSG_SOURCESYSTEM_LENGHT = "Validation failed. [Please provide valid sourceSystem with up to 10 symbols";
    public static final String ERR_MSG_JSON_PARSE_INT = "Cannot deserialize value of type `java.lang.Integer` from String";
    public static final String ERR_MSG_NO_MESSAGE_FOUND = "No message available";
    public static final String ERR_MSG_NO_DEMOGRAPHICS_FOUND = "Demographics not found for client id: 85 and member id: %s";
    public static final String ERR_MSG_CASEREQUESTID_CANNOT_NULL="caseRequestId cannot be null or empty";
}