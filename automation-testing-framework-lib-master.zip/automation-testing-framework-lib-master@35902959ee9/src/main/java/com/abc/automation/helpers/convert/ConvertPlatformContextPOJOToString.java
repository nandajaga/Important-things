package com.abc.automation.helpers.convert;

import com.abc.automation.factories.platformcontext.PlatformContextDTOFactory;
import com.abc.servicemodel.domain.PlatformContext;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Deprecated
public class ConvertPlatformContextPOJOToString {
    private final static Logger LOGGER = LoggerFactory.getLogger(ConvertPlatformContextPOJOToString.class);

    public static String convertPlatformContextPOJOToString() {
        PlatformContext platformContextPOJO = new PlatformContextDTOFactory().createPlatformContextDTO();

        return convertPlatformContextToString(platformContextPOJO);
    }

    public static String convertPlatformContextToString(PlatformContext platformContext) {
        ObjectMapper mapper = new ObjectMapper();
        String platformContextString = null;

        try {
            platformContextString = mapper.writeValueAsString(platformContext);
        } catch (JsonProcessingException e) {
            LOGGER.error("An error has occurred while converting PlatformContext {} to string", platformContext, e);
        }

        return platformContextString;
    }

}
