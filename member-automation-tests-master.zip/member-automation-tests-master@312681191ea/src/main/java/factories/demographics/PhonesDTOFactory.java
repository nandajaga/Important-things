package factories.demographics;

import dtos.demographics.PhonesDTO;

import java.util.ArrayList;

import static helpers.constants.Constants.*;

public class PhonesDTOFactory {

    public ArrayList<PhonesDTO> createPhonesDTO(boolean clientSource, String phoneType, String phoneValue) {
        ArrayList<PhonesDTO> list = new ArrayList<>();
        PhonesDTO phone = new PhonesDTO();
        phone.setClientSource(clientSource);
        phone.setType(phoneType);
        phone.setValue(phoneValue);
        list.add(phone);

        return list;
    }

    public ArrayList<PhonesDTO> createPhonesDTO() {
        return createPhonesDTO(PHONE_CLIENT_SOURCE, PHONE_TYPE, PHONE_VALUE);
    }
}
