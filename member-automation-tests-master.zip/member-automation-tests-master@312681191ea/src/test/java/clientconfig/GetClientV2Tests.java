package clientconfig;

import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.clientconfig.ClientResponseDTO;
import helpers.dataproviders.DataProviders;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import steps.clientconfig.ClientsV2Steps;

import static helpers.constants.BasePathConstants.BASE_PATH_GET_V2_CLIENTS;
import static helpers.constants.ClientConfigConstants.CLIENT_ID_210;
import static helpers.constants.Constants.*;
import static helpers.constants.ErrorMessagesForMemberEndpointsConstants.ERR_MSG_CONFIGURATION_LIST_IS_EMPTY;
import static helpers.constants.ErrorMessagesForMemberEndpointsConstants.ERR_MSG_INVALID_FIELDS;
import static org.apache.http.HttpStatus.SC_INTERNAL_SERVER_ERROR;
import static org.apache.http.HttpStatus.SC_UNPROCESSABLE_ENTITY;

/**
 * Created by RKondakova on 7/22/2019.
 */
public class GetClientV2Tests extends GetTests {

    private ClientsV2Steps clientsV2Steps;

    @BeforeClass
    public void init() {
        basePath = BASE_PATH_GET_V2_CLIENTS;
        pathParamsMap.clear();
        pathParamsMap.put("clientId", CLIENT_ID_210);
        queryParamsMap.put("fields", ALLOWS_ELIGIBILITY_OVERRIDE);
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test(dataProvider = "clientId-85-186-187-210", dataProviderClass = DataProviders.class)
    public void whenGetClientV2FieldsWithValidClientIdThenResponseIs200(String clientId) {
        clientsV2Steps = new ClientsV2Steps();
        ClientResponseDTO[] clientV2ResponseDTO = clientsV2Steps.getClientV2PositiveDTO(clientId, ALLOWS_ELIGIBILITY_OVERRIDE, platformContextHeader, headers);

        softly.then(clientV2ResponseDTO[0].getFieldName()).contains(ALLOWS_ELIGIBILITY_OVERRIDE);
        softly.then(clientV2ResponseDTO[0].isValue()).isEqualTo(true);
        softly.assertAll();
    }

    @Test(dataProvider = "fieldsPositive", dataProviderClass = DataProviders.class)
    public void whenGetClientV2FieldsWithPositiveFieldsThenResponseIs200(String fields) {
        clientsV2Steps = new ClientsV2Steps();
        ClientResponseDTO[] clientV2ResponseDTO = clientsV2Steps.getClientV2PositiveDTO(CLIENT_ID_85, fields, platformContextHeader, headers);

        switch (fields) {
            case ALLOWS_ELIGIBILITY_OVERRIDE:
            case ALLOWS_CONTACT_EDIT:
                softly.then(clientV2ResponseDTO[0].isValue()).isEqualTo(true);
                break;
            default:
                softly.then(clientV2ResponseDTO[0].isValue()).isEqualTo(false);
        }
        softly.then(clientV2ResponseDTO[0].getFieldName()).contains(fields);
        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-422-500-----------------------------------------

    //TODO opened a bug for not checking for valid ClientId - Response status is 200 with invalid credentials NCP-24418
//    @Test(dataProvider = "clientIdNegative", dataProviderClass = DataProviders.class)
    public void whenGetClientV2FieldsWithNegativeClientIdThenResponseStatus422(String clientId) {
        ErrorDTO error = new ClientsV2Steps().getClientRequestErrorDTO(clientId, ALLOWS_ELIGIBILITY_OVERRIDE, platformContextHeader, headers);

        softly.then(error.getMessage()).isEqualTo(""/*TODO proper response message*/);
        softly.then(error.getStatus()).isEqualTo(""/*TODO proper response status*/);
        softly.assertAll();
    }

    @Test(dataProvider = "solutionIdNegative", dataProviderClass = DataProviders.class)
    public void
    whenGetClientV2FieldsWithNegativeFieldsThenResponseStatus422(String fields) {
        ErrorDTO error = new ClientsV2Steps().getClientRequestErrorDTO(CLIENT_ID_85, fields, platformContextHeader, headers);
        if (fields == null || fields.isEmpty()) {
            softly.then(error.getMessage()).isEqualTo(ERR_MSG_CONFIGURATION_LIST_IS_EMPTY);
            softly.then(error.getCode()).isEqualTo(SC_INTERNAL_SERVER_ERROR);
        } else {
            softly.then(error.getMessage()).isEqualTo(ERR_MSG_INVALID_FIELDS);
            softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        }
        softly.assertAll();
    }
}