package dtos;

public class ErrorDTO {

    private int code;
    //TODO This is added due to BUG NCP-21673. Once the bug is resolved this should be removed.
    private int status;
    private String message;

    public int getCode() {
        return code;
    }
    public void setCode(int code) {
        this.code = code;
    }

    public int getStatus() { return status; }
    public void setStatus(int status) { this.status = status; }

    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
}
//AREA 51
