package com.abc.automation.dtos.member;

/**
 * Created by PPetarcheva on 4/17/2019.
 */
public class MemberResponseDTO {

    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
