package dtos.clientconfig;

import java.util.List;

/**
 * Created by VBaliyska on 8/21/2019.
 */
public class ReferenceDataV3DTO {

    private List<AllowedConfigurationsResponseDTO> allowedBusinessIndicators;

    private List<AllowedConfigurationsResponseDTO> allowedClientDependentRelationCodes;

    private List<AllowedConfigurationsResponseDTO> allowedFundingTypes;

    private List<AllowedConfigurationsResponseDTO> allowedStatesOfIssuance;

    private List<AllowedConfigurationsResponseDTO> allowedReviewPrograms;

    private List<String> allowedNetworkCodes;

    private List<String> allowedProgramTypes;

    private List<String> allowedSourceSystems;

    private boolean mixerCodeEnabled;

    private List<String> clientBusinessMarketSegment;

    private List<ClientFundingTypeResponseDTO> clientFundingType;

    public List<AllowedConfigurationsResponseDTO> getAllowedBusinessIndicators() {
        return allowedBusinessIndicators;
    }

    public void setAllowedBusinessIndicators(List<AllowedConfigurationsResponseDTO> allowedBusinessIndicators) {
        this.allowedBusinessIndicators = allowedBusinessIndicators;
    }

    public List<AllowedConfigurationsResponseDTO> getAllowedClientDependentRelationCodes() {
        return allowedClientDependentRelationCodes;
    }

    public void setAllowedClientDependentRelationCodes(List<AllowedConfigurationsResponseDTO> allowedClientDependentRelationCodes) {
        this.allowedClientDependentRelationCodes = allowedClientDependentRelationCodes;
    }

    public List<AllowedConfigurationsResponseDTO> getAllowedFundingTypes() {
        return allowedFundingTypes;
    }

    public void setAllowedFundingTypes(List<AllowedConfigurationsResponseDTO> allowedFundingTypes) {
        this.allowedFundingTypes = allowedFundingTypes;
    }

    public List<AllowedConfigurationsResponseDTO> getAllowedStatesOfIssuance() {
        return allowedStatesOfIssuance;
    }

    public void setAllowedStatesOfIssuance(List<AllowedConfigurationsResponseDTO> allowedStatesOfIssuance) {
        this.allowedStatesOfIssuance = allowedStatesOfIssuance;
    }

    public List<String> getAllowedNetworkCodes() {
        return allowedNetworkCodes;
    }

    public void setAllowedNetworkCodes(List<String> allowedNetworkCodes) {
        this.allowedNetworkCodes = allowedNetworkCodes;
    }

    public List<String> getAllowedProgramTypes() {
        return allowedProgramTypes;
    }

    public void setAllowedProgramTypes(List<String> allowedProgramTypes) {
        this.allowedProgramTypes = allowedProgramTypes;
    }

    public List<String> getAllowedSourceSystems() {
        return allowedSourceSystems;
    }

    public void setAllowedSourceSystems(List<String> allowedSourceSystems) {
        this.allowedSourceSystems = allowedSourceSystems;
    }

    public boolean getMixerCodeEnabled() {
        return mixerCodeEnabled;
    }

    public void setMixerCodeEnabled(boolean mixerCodeEnabled) {
        this.mixerCodeEnabled = mixerCodeEnabled;
    }


    public List<String> getClientBusinessMarketSegment() {
        return clientBusinessMarketSegment;
    }

    public void setClientBusinessMarketSegment(List<String> clientBusinessMarketSegment) {
        this.clientBusinessMarketSegment = clientBusinessMarketSegment;
    }

    public List<ClientFundingTypeResponseDTO> getClientFundingType() {
        return clientFundingType;
    }

    public void setClientFundingType(List<ClientFundingTypeResponseDTO> clientFundingType) {
        this.clientFundingType = clientFundingType;
    }

    public List<AllowedConfigurationsResponseDTO> getAllowedReviewPrograms() {
        return allowedReviewPrograms;
    }

    public void setAllowedReviewPrograms(List<AllowedConfigurationsResponseDTO> allowedReviewPrograms) {
        this.allowedReviewPrograms = allowedReviewPrograms;
    }


}
