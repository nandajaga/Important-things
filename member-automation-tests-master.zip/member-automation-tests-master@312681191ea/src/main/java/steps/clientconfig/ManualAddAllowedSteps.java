package steps.clientconfig;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorSpringDTO;
import dtos.clientconfig.IsManualAddAllowedResponseDTO;
import helpers.constants.BasePathConstants;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;

import java.util.HashMap;
import java.util.Map;

public class ManualAddAllowedSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public ManualAddAllowedSteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();
        requestSpecification.addBasePath(BasePathConstants.BASE_PATH_IS_MANUAL_ADD_ALLOWED);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    public IsManualAddAllowedResponseDTO getIsManualAddAllowed(String clientId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);

        Response response = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return response.as(IsManualAddAllowedResponseDTO.class);
    }

    public ErrorSpringDTO getIsManualAddAllowedWithError(String clientId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);
        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorSpringDTO.class);
    }

}
