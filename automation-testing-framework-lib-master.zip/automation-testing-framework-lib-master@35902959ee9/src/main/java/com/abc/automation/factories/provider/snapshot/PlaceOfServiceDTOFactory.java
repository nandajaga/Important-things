package com.abc.automation.factories.provider.snapshot;

import com.abc.automation.dtos.provider.servicing.PlaceOfServiceDTO;
import com.abc.automation.helpers.constants.ProviderConstants;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
public class PlaceOfServiceDTOFactory {

    public PlaceOfServiceDTO createPlaceOfServiceDTO(String code, String name) {

        PlaceOfServiceDTO payload = new PlaceOfServiceDTO();
        payload.setCode(code);
        payload.setName(name);

        return payload;
    }

    public PlaceOfServiceDTO createPlaceOfServiceDTO() {
        return createPlaceOfServiceDTO(ProviderConstants.PLACE_OF_SERVICE_CODE, ProviderConstants.PLACE_OF_SERVICE_NAME);
    }
}
