package com.abc.automation.factories.member.demographics;

import com.abc.automation.dtos.member.demographics.AdditionalMemberIdDTO;
import com.abc.automation.helpers.constants.MemberConstants;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by PPetarcheva on 4/17/2019.
 */
public class AdditionalMemberIdDTOFactory {

    public List<AdditionalMemberIdDTO> createAdditionalMemberIdsDTO() {
        List<AdditionalMemberIdDTO> list = new ArrayList<>();

        AdditionalMemberIdDTO additionalMemberIdMedicareDTO = new AdditionalMemberIdDTO();
        additionalMemberIdMedicareDTO.setName(MemberConstants.MEDICARE_ID_NAME);
        additionalMemberIdMedicareDTO.setValue(MemberConstants.MEDICARE_ID_VALUE);

        AdditionalMemberIdDTO additionalMemberIdMedicaidDTO = new AdditionalMemberIdDTO();
        additionalMemberIdMedicaidDTO.setName(MemberConstants.MEDICAID_ID_NAME);
        additionalMemberIdMedicaidDTO.setValue(MemberConstants.MEDICAID_ID_VALUE);

        list.add(additionalMemberIdMedicareDTO);
        list.add(additionalMemberIdMedicaidDTO);

        return list;
    }
}
