package dtos.clientconfig;

/**
 * Created by VBaliyska on 6/25/2019.
 */
public class RestrictedAccessTypeResponseDTO {

    private boolean isRestrictionAllowed;
    private String restrictionType;

    public boolean getIsRestrictionAllowed() {
        return isRestrictionAllowed;
    }

    public void setRestrictionAllowed(boolean restrictionAllowed) {
        isRestrictionAllowed = restrictionAllowed;
    }

    public String getRestrictionType() {
        return restrictionType;
    }

    public void setRestrictionType(String restrictionType) {
        this.restrictionType = restrictionType;
    }
}
