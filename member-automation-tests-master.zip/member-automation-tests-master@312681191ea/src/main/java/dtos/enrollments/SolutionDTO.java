package dtos.enrollments;

import java.util.ArrayList;

public class SolutionDTO {
    private boolean levelOfCare;
    private String programType;
    private String solutionId;
    private String solutionName;
    private ArrayList<ReviewProgramsDTO> reviewPrograms;
    private ConsumerEngagementProgramDTO consumerEngagementProgram;

    public boolean isLevelOfCare() {
        return levelOfCare;
    }

    public void setLevelOfCare(boolean levelOfCare) {
        this.levelOfCare = levelOfCare;
    }

    public String getSolutionName() {
        return solutionName;
    }

    public void setSolutionName(String solutionName) {
        this.solutionName = solutionName;
    }

    public String getProgramType() {
        return programType;
    }

    public void setProgramType(String programType) {
        this.programType = programType;
    }

    public String getSolutionId() {
        return solutionId;
    }

    public void setSolutionId(String solutionId) {
        this.solutionId = solutionId;
    }

    public ArrayList<ReviewProgramsDTO> getReviewPrograms() {
        return reviewPrograms;
    }

    public void setReviewPrograms(ArrayList<ReviewProgramsDTO> reviewPrograms) {
        this.reviewPrograms = reviewPrograms;
    }

    public ConsumerEngagementProgramDTO getConsumerEngagementProgram() {
        return consumerEngagementProgram;
    }

    public void setConsumerEngagementProgram(ConsumerEngagementProgramDTO consumerEngagementProgram) {
        this.consumerEngagementProgram = consumerEngagementProgram;
    }
}
//AREA 51
