package dtos.enrollments.snapshots;

import dtos.enrollments.MemberEnrollmentDTO;
/**
 * Created by RKondakova on 4/25/2019.
 */
public class MemberEnrollmentsSnapshotDTO {

    private MemberEnrollmentDTO memberEnrollment;
    private String snapshotId;

    public MemberEnrollmentDTO getMemberEnrollment() {
        return memberEnrollment;
    }

    public void setMemberEnrollment(MemberEnrollmentDTO memberEnrollment) {
        this.memberEnrollment = memberEnrollment;
    }

    public String getSnapshotId() {
        return snapshotId;
    }
}