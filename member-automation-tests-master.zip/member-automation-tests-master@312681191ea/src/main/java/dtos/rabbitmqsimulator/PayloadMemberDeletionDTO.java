package dtos.rabbitmqsimulator;

import dtos.demographics.MemberDemographicsDTO;

/**
 * Created by VBaliyska on 12/3/2019.
 */
public class PayloadMemberDeletionDTO {

    private MemberDemographicsDTO memberDemographics;

    public MemberDemographicsDTO getMemberDemographics() {
        return memberDemographics;
    }

    public void setMemberDemographics(MemberDemographicsDTO memberDemographics) {
        this.memberDemographics = memberDemographics;
    }
}
