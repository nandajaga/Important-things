package dtos.search;

import dtos.demographics.AdditionalMemberIdDTO;
import dtos.demographics.RestrictedAccessesDTO;

import java.util.Date;
import java.util.List;

public class MemberSearchDTO {

    private String id;
    private Date createdOn;
    private String memberPrefix;
    private String clientMemberId;
    private String firstName;
    private String healthPlan;
    private String lastName;
    private String dependentCode;
    private String gender;
    private Date dateOfBirth;
    private String state;
    private String clientId;
    private Boolean manuallyCreated;
    private List<AdditionalMemberIdDTO> additionalMemberIds;
    private List<RestrictedAccessesDTO> restrictedAccesses;
    private EnrollmentsDTO[] enrollments;

    public EnrollmentsDTO[] getEnrollments() {
        return enrollments;
    }

    public void setEnrollments(EnrollmentsDTO[] enrollments) {
        this.enrollments = enrollments;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    public String getMemberPrefix() {
        return memberPrefix;
    }

    public void setMemberPrefix(String memberPrefix) {
        this.memberPrefix = memberPrefix;
    }

    public String getClientMemberId() {
        return clientMemberId;
    }

    public void setClientMemberId(String clientMemberId) {
        this.clientMemberId = clientMemberId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getHealthPlan() {
        return healthPlan;
    }

    public void setHealthPlan(String healthPlan) {
        this.healthPlan = healthPlan;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getDependentCode() {
        return dependentCode;
    }

    public void setDependentCode(String dependentCode) {
        this.dependentCode = dependentCode;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public Boolean getManuallyCreated() {
        return manuallyCreated;
    }

    public void setManuallyCreated(Boolean manuallyCreated) {
        this.manuallyCreated = manuallyCreated;
    }

    public List<AdditionalMemberIdDTO> getAdditionalMemberIds() {
        return additionalMemberIds;
    }

    public void setAdditionalMemberIds(List<AdditionalMemberIdDTO> additionalMemberIds) {
        this.additionalMemberIds = additionalMemberIds;
    }

    public List<RestrictedAccessesDTO> getRestrictedAccesses() {
        return restrictedAccesses;
    }

    public void setRestrictedAccesses(List<RestrictedAccessesDTO> restrictedAccesses) {
        this.restrictedAccesses = restrictedAccesses;
    }
}
