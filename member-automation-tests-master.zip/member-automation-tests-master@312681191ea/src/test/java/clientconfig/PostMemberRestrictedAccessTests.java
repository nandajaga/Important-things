package clientconfig;

import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.tests.base.PostTests;
import dtos.ErrorDTO;
import dtos.clientconfig.RestrictedAcessResponseDTOV4;
import dtos.datamanager.MemberResponseDTO;
import factories.clientconfig.RestrictedAccessDTOFactory;
import helpers.dataproviders.DataProviders;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.clientconfig.RestrictedAccessSteps;
import steps.datamanager.MemberDataManagerSteps;

import static helpers.constants.BasePathConstants.BASE_PATH_RESTRICTED_ACCESSS_V4;
import static helpers.constants.ClientConfigConstants.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_212;

public class PostMemberRestrictedAccessTests extends PostTests {
    private MemberDataManagerSteps memberDataManagerSteps;
    private PlatformContextUtils platformContextUtils;
    private String CLIENT_MEMBER_ID;

    @BeforeClass
    public void init() {
        basePath = BASE_PATH_RESTRICTED_ACCESSS_V4;
        body = new RestrictedAccessDTOFactory().setRestrictedAccessDTO(null, null, null, null, null);
    }

    @BeforeMethod
    public void initMethod() {
        platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeChannelCode(platformContextHeader, CHANNEL_CODE_P);
        CLIENT_MEMBER_ID = RandomStringUtils.randomNumeric(10) + RandomStringUtils.randomAlphabetic(5).toUpperCase();
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    /* https://dbg-jira.antheminc.com/browse/OSPP-11417
     * Updated the test for client 220 and dataProvider for employergroupcode
     * Updated by sbioi on 06/04/2020
     * updated the scripts in accordance with changes by sthummalapudi as part of the story OSPP-10381
     */

    @Test(dataProvider = "restrictedAccessEmployerGroupCode", dataProviderClass = DataProviders.class)
    public void whenPostClientIdAndEmployerGroupCodeSGEMPLOYEEOVERRIDEThenServiceReturnsRestrictedHealthPlanTrue(String employerGroupCode) {
        platformContextHeader = platformContextUtils.changeUserId(platformContextHeader, UUID_220_SG_EMPLOYEE);

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_220, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        RestrictedAcessResponseDTOV4 restrictedAcessResponseDTOV4 = new RestrictedAccessSteps(platformContextHeader, headers).postRestrictedAccessResponse(memberId, null, null, CLIENT_ID_220, employerGroupCode);

        if (employerGroupCode.equalsIgnoreCase(EMPLOYERGROUPCODE_220_2)) {
            softly.then(restrictedAcessResponseDTOV4.isRestricted()).isTrue();
            softly.then(restrictedAcessResponseDTOV4.getRestrictionType()).isEqualTo(RESTRICTION_HEALTH_PLAN);
            softly.then(restrictedAcessResponseDTOV4.getMessage()).isNull();
            softly.then(restrictedAcessResponseDTOV4.getScript()).isNull();
        } else {
            softly.then(restrictedAcessResponseDTOV4.isRestricted()).isFalse();
            softly.then(restrictedAcessResponseDTOV4.getRestrictionType()).isEqualTo(NONE_VALUE);
            softly.then(restrictedAcessResponseDTOV4.getMessage()).isNull();
            softly.then(restrictedAcessResponseDTOV4.getScript()).isNull();
        }

        softly.assertAll();
    }

    @Test(dataProvider = "clientIdEmployerCodeRestrictionV4", dataProviderClass = DataProviders.class)
    public void whenPostClientIdAndEmployerGroupCodeThenServiceReturnsRestrictedHealthPlanTrue(String clientId, String employerGroupCode) {
        platformContextHeader = platformContextUtils.changeUserId(platformContextHeader, employerGroupCode);

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_220, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        RestrictedAcessResponseDTOV4 restrictedAcessResponseDTOV4 = new RestrictedAccessSteps(platformContextHeader, headers).postRestrictedAccessResponse(memberId, null, null, clientId, employerGroupCode);

        if (clientId != CLIENT_ID_210 && clientId != CLIENT_ID_212) {
            softly.then(restrictedAcessResponseDTOV4.isRestricted()).isTrue();
            softly.then(restrictedAcessResponseDTOV4.getRestrictionType()).isEqualTo(RESTRICTION_HEALTH_PLAN);
            softly.then(restrictedAcessResponseDTOV4.getMessage()).isNull();
            softly.then(restrictedAcessResponseDTOV4.getScript()).isNull();
        } else {
            softly.then(restrictedAcessResponseDTOV4.isRestricted()).isFalse();
            softly.then(restrictedAcessResponseDTOV4.getRestrictionType()).isEqualTo(NONE_VALUE);
            softly.then(restrictedAcessResponseDTOV4.getMessage()).isNull();
            softly.then(restrictedAcessResponseDTOV4.getScript()).isNull();
        }

        softly.assertAll();
    }

    @Test(dataProvider = "restrictedAccessEmployerGroupCode", dataProviderClass = DataProviders.class)
    public void whenPostClientIdAndEmployerGroupCodeSGFEPOVERRIDEThenServiceReturnsRestrictedHealthPlanTrue(String employerGroupCode) {
        platformContextHeader = platformContextUtils.changeUserId(platformContextHeader, UUID_220_SG_FEP);

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_220, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        RestrictedAcessResponseDTOV4 restrictedAcessResponseDTOV4 = new RestrictedAccessSteps(platformContextHeader, headers).postRestrictedAccessResponse(memberId, null, null, CLIENT_ID_220, employerGroupCode);

        if (employerGroupCode.equalsIgnoreCase(EMPLOYERGROUPCODE_220_1)) {
            softly.then(restrictedAcessResponseDTOV4.isRestricted()).isTrue();
            softly.then(restrictedAcessResponseDTOV4.getRestrictionType()).isEqualTo(RESTRICTION_HEALTH_PLAN);
            softly.then(restrictedAcessResponseDTOV4.getMessage()).isNull();
            softly.then(restrictedAcessResponseDTOV4.getScript()).isNull();
        } else {
            softly.then(restrictedAcessResponseDTOV4.isRestricted()).isFalse();
            softly.then(restrictedAcessResponseDTOV4.getRestrictionType()).isEqualTo(NONE_VALUE);
            softly.then(restrictedAcessResponseDTOV4.getMessage()).isNull();
            softly.then(restrictedAcessResponseDTOV4.getScript()).isNull();
        }
        softly.assertAll();
    }

    @Test(dataProvider = "restrictedAccessEmployerGroupCode", dataProviderClass = DataProviders.class)
    public void whenPostClientIdAndEmployerGroupCodeAIMOFFSHOREUSEREXCLUSIONThenServiceReturnsRestrictedHealthPlanTrue(String employerGroupCode) {
        platformContextHeader = platformContextUtils.changeUserId(platformContextHeader, UUID_220_AIM_OFFSHORE_USER);

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_220, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        RestrictedAcessResponseDTOV4 restrictedAcessResponseDTOV4 = new RestrictedAccessSteps(platformContextHeader, headers).postRestrictedAccessResponse(memberId, null, null, CLIENT_ID_220, employerGroupCode);

        softly.then(restrictedAcessResponseDTOV4.isRestricted()).isTrue();
        softly.then(restrictedAcessResponseDTOV4.getRestrictionType()).isEqualTo(RESTRICTION_HEALTH_PLAN);
        softly.then(restrictedAcessResponseDTOV4.getMessage()).isNull();
        softly.then(restrictedAcessResponseDTOV4.getScript()).isNull();

        softly.assertAll();
    }


    //------------------------------------------------------------------------NEGATIVE-TESTS--------------------------------------------------------------------


    @Test()
    public void whenPostClientIdAndEmployerGroupCodeAndInvalidMemberId() {

        ErrorDTO errorDTO = new RestrictedAccessSteps(platformContextHeader, headers).postRestrictedAccessErrorResponse(INVALID_MEMMBER_ID, null, null, CLIENT_ID_220, EMPLOYERGROUPCODE_220_1);

        softly.then(errorDTO.getCode()).isEqualTo(HttpStatus.SC_UNPROCESSABLE_ENTITY);
        softly.then(errorDTO.getMessage()).isEqualTo(RESTRICTED_ACCESS_INVALID_MEMBERID_ERROR_MSG);
        softly.assertAll();
    }

    @Test
    public void whenPostClientIdAndEmployerGroupCodeAndInvalidDependentCode() {

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_220, CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();

        ErrorDTO errorDTO = new RestrictedAccessSteps(platformContextHeader, headers).postRestrictedAccessErrorResponse(memberId, "PPP", null, CLIENT_ID_220, EMPLOYERGROUPCODE_220_1);

        softly.then(errorDTO.getCode()).isEqualTo(HttpStatus.SC_UNPROCESSABLE_ENTITY);
        softly.then(errorDTO.getMessage()).isEqualTo(RESTRICTED_ACCESS_INVALID_DEPENDENTCODE_ERROR_MSG);
        softly.assertAll();
    }


    @Test
    public void whenPostClientIdAndEmployerGroupCodeAndInvalidRestrictionType() {

        ErrorDTO errorDTO = new RestrictedAccessSteps(platformContextHeader, headers).postRestrictedAccessErrorResponse(null, null, null, CLIENT_ID_220, EMPLOYERGROUPCODE_220_1);

        softly.then(errorDTO.getCode()).isEqualTo(HttpStatus.SC_UNPROCESSABLE_ENTITY);
        softly.then(errorDTO.getMessage()).isEqualTo(RESTRICTED_ACCESS_INVALID_RESTRCITIONTYPE_ERROR_MSG);
        softly.assertAll();
    }

    @Test(dataProvider = "restrictedAccessEmployerGroupCode", dataProviderClass = DataProviders.class)
    public void whenPostClientIdAndEmployerGroupCodeAndInvalidUserIdThenServiceReturnsDefaultRestrictedHealthPlanTrue(String employerGroupCode) {
        platformContextHeader = platformContextUtils.changeUserId(platformContextHeader, UUID_220_AIM_INVALID_USER);

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_220, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        RestrictedAcessResponseDTOV4 restrictedAcessResponseDTOV4 = new RestrictedAccessSteps(platformContextHeader, headers).postRestrictedAccessResponse(memberId, null, null, CLIENT_ID_220, employerGroupCode);

        softly.then(restrictedAcessResponseDTOV4.isRestricted()).isTrue();
        softly.then(restrictedAcessResponseDTOV4.getRestrictionType()).isEqualTo(RESTRICTION_HEALTH_PLAN);
        softly.then(restrictedAcessResponseDTOV4.getMessage()).isNull();
        softly.then(restrictedAcessResponseDTOV4.getScript()).isNull();

        softly.assertAll();
    }

    @Test(dataProvider = "restrictedAccessEmployerGroupCode", dataProviderClass = DataProviders.class)
    public void whenPostClientIdAndEmployerGroupCodeAndUserIdWithoutEntitlementThenServiceReturnsDefaultRestrictedHealthPlanTrue(String employerGroupCode) {
        platformContextHeader = platformContextUtils.changeUserId(platformContextHeader, UUID_220_AIM_NO_ENTITLEMENT);

        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_220, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        RestrictedAcessResponseDTOV4 restrictedAcessResponseDTOV4 = new RestrictedAccessSteps(platformContextHeader, headers).postRestrictedAccessResponse(memberId, null, null, CLIENT_ID_220, employerGroupCode);

        softly.then(restrictedAcessResponseDTOV4.isRestricted()).isTrue();
        softly.then(restrictedAcessResponseDTOV4.getRestrictionType()).isEqualTo(RESTRICTION_HEALTH_PLAN);
        softly.then(restrictedAcessResponseDTOV4.getMessage()).isNull();
        softly.then(restrictedAcessResponseDTOV4.getScript()).isNull();

        softly.assertAll();
    }

    @Test()
    public void whenPostNullClientIdAndEmployerGroupCodeAndValidMemberId() {

        ErrorDTO errorDTO = new RestrictedAccessSteps(platformContextHeader, headers).postRestrictedAccessErrorResponse(null, null, null, null, null);

        softly.then(errorDTO.getCode()).isEqualTo(HttpStatus.SC_UNPROCESSABLE_ENTITY);
        softly.then(errorDTO.getMessage()).isEqualTo(RESTRICTED_ACCESS_INVALID_CLIENT_ID_ERROR_MSG);
        softly.assertAll();
    }
}
