# Automation testing framework lib

This project contains the shared functionality for the domain automation projects for testing the backend REST services.

>**src/main/java**

**dtos package** - containing dtos classes
- `ErrorDTO` - dto representing the error object returned from the services
- `ActionLogDTO` - all dto objects needed for getting action log messages 
- *Domain dtos* - all the needed domain dtos that will be used in the *steps*

**factories package** - containing factories classes representing the dto object
- *Platform context* - contains factories for the platform context header object
  - *Case* part of the header
  - *Enrollment* part of the header
  - *Location* part of the header
  - *Member* part of the header
  - *Services* part of the header
  - *Solution* part of the header
  - *User* part of the header
- *Domain factories* - all the needed domain factories that will be used in the *steps*

**helpers package** - containing the common helper functionality needed for the tests and steps across the whole framework
- *constants* 
  - *Constants* - stores common constants
  - `PlatformContextConstants` - stores all constants needed for the platform context header
  - `BasePathConstants` - stores all base paths
  - `<Domain>Constants` - stores all domain relevant constants
- *enums* - containing enums with the common functionality
  - `RequestHeadersEnum` - stores names of all mandatory headers needed for the requests 
  - `DomainEnum` - stores the names of all available domains
  - `PlatformContextVersionEnum` - stores the values of platform context versions
- *convert* - stores all the classes related to conversion of the objects
- *testng*
  - `RetryAnalyzer` - functionality for retrying of failing tests
  - `StatusTestListener` - additional logging of the tests execution
  - `TestNGRunnerForXMLSuitesInJar` - helper functionality for running the test on higher environments 
  - `ExtentRepotSetup` - functionality for extent report instance creation and htmlReport configuration
  - `ExtentTestReport` - functionality to start,end,get test while running and can hooked to testng 
  - `ExtentTestListener` - functionality which hook testng and extent report , and can be called on domain level suite to create extent report
  - `ConsoleOutputStream` - functionality to customize the console and capture the log in String format 
- `RequestSpecification` - helper methods for working with Rest-assured RequestSpecification object
- `PropertiesUtils` - helper functionality for loading and working with Properties file
- `ReadContentResourceFiles` - functionality for reading of content from file
- `RequestOperationHelper` - functionality for sending Rest-assured style requests
- `EditDTOHelper` - used to change the value of a specific field of an object
- `PlatformContextUtils` - contains methods that change defined field in the platform context header

**steps package** - containing all functions for the allowed operations for given endpoint
- *Steps for working with action log* - for getting action log messages
- *Steps for working with errors*
- *Steps for creating case* - all the needed steps for creating a case - crating user, member, provider and case request

**config package** – containing common functionality needed for configuring and preparing the test execution
- to be added

>**src/test/java**

**tests package** - containing classes with the tests
- *Base test* - containing common fields and initialization of mandatory headers for all the tests
- *Common tests* checking the error response when headers are not provided or wrong verb is used 

**suites package** - containing the tests grouped in a suite for execution
- to be added

>**src/test/resources**
- *config properties* - this properties file should be part of every domain project so it can be used to control the functionality. These options could also be provided as runtime parameters.
  - `isLogEnabled` - boolean parameter that is used to turn on/off logging of the request and response. Default - `false`
  - `baseURI` - String parameter providing the baseuri to be used (environment specific). Example: `"https://member.xformdevpoc.com/"`
  - `isProxyNeeded` - boolean parameter to define if using proxy configuration is needed. Default - `false`
  - `proxyHost` - String parameter to define the proxy host. (Needed if `isProxyNeeded` is set to `true`)
  - `proxyPort` - int parameter to define the proxy port. (Needed if `isProxyNeeded` is set to `true`)
  - `contextMode` - String parameter providing the value for *contextMode* field in *PlatformContext* header. (Possible values: `PROD` and `TEST`)
  
## Integration with the shared lib 
The following dependencies need to be added to *build.gradle*
    
    compile 'shared-tool-chain:automation-testing-framework-lib:<version>'
    compile 'shared-tool-chain:automation-testing-framework-lib:<version>:test'
    
The integrated project could benefit from the following features:
* `RequestOperationHelper`: The steps are using this class to send the rest-assured requests and to convert the response to the needed DTO class for better usage
* `CustomFilterableRequestSpecification`: Used in the steps for preparation of the request elements such as basePath, headers, body
* TestNG listeners and runner for better reporting and running of the fatJar in UCD
* `base tests`: common classes used for setup of the tests, the shared elements, test configuration and tests that executes additional checks for properly handling of the errors such as method not allowed, missing headers

## How to use the shared lib functionality
Here is a description how the benefits from the shared testing lib could be used
* *base tests* - to use the tests from the lib, the test class needs to extend the relevant class from the base package - <method>Tests (or <method>WithPlatformContextTests to get additional tests for the PC header) and to set `basePath`, `queryParams`, `pathParams` and `body` in `@BeforeClass` method
* *helper functionality* - just import the helper class where needed
* *dtos, factories and steps* - use the available

## How to use the base tests in shared lib
To use the base tests they need to be extended and all needed parameters for the request need to be provided:
* `basePath` needs to be provided for all endpoints
* `body` needs to be provided for all endpoints that requires valid one (POST, PUT)
* `pathParamsMap` needs to be provided if the endpoint has pathParams
* `queryParamsMap` needs to be provided if the endpoint has queryParams

### GenericTests
If `GenericTests` is extended then additional parameter need to be provided:
* `endpointHttpMethod` - the method of the endpoint under test (ex. `Method.POST`)

If there are two endpoints with the same and `GenericTests` is extended then the list with not allowed methods needs to be updated properly:
* `notAllowedMethodsList` - list with all methods that are not allowed for the endpoint under test

### <Method>Tests
The needed class need to be extended depending of the method of the endpoint.

If there are two endpoints with the same and `<Method>Tests` is extended then the not relevant test need to be overridden and the `@Test` annotation needs to be removed

## How to edit dto
A DTO could be changed using `EditDTOHelper` in the following way:
- pass the object (e.g. user), the field that you want changed (e.g. *"firstName"*) and the value that you want (e.g. *"Manoela"*) 
- `changeSpecificFieldValueInDTO(user, "lastName", "Georigeva")` it will change the lastName of your user. 
- used in a loop and in each iteration pass in different fields and values. `changeSpecificFieldValueInDTO(user, field, value)` where `field` is a list containing: *firstName, lastName, username* and `value` is *"testValue"*. If you loop through the field list, you will have: first iteration: *user with firstName of testValue*, second iteration: *user with lastName of testValue*, third iteration: *user with username of testValue*
- used to change the value of a field of a nested object. Eg: `User` has a `UserRoleDTO` role. `UserRoleDTO` has a `roleName`. You can use this method, pass in *user, "role.roleName", "Manager"* and it will set the role name in the role of your user to Manager.

*Note*: you can not use this method to change values of fields in `Collections` of objects (e.g. if your user has a `List<UserRoleDTO>` you can not change the values in that list. )

## Smokesuite and @DataProvider
When using  `@DataProvider` annotation to provide multiple data to a single test and this test needs to be added to `smokesuite.xml` additional modifications needs to be added to the data provider method in order to have only single execution of the test in the suite.
* `ITestContext` needs to be used in this case to get the needed parameters from the xml file 
* `<parameter name="<name>" value="<value>" />` needs to be added to the xml file under `<test>`  tag
* The parameter needs to be get from the xml file if provided `context.getCurrentXmlTest().getParameter("<name>)`