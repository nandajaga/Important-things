package dtos.workflow;

public class DemographicEnsureWorkflowReqDTO {
    private String subClientCode;

    public String getSubClientCode() {
        return subClientCode;
    }

    public void setSubClientCode(String subClientCode) {
        this.subClientCode = subClientCode;
    }

}
