package dtos.clientconfig;

import java.util.ArrayList;

/**
 * Created by RKondakova on 7/4/2019.
 */
public class ClientEligibilitySystemDTO extends ArrayList<String> {
    //TODO The DTO appears to be an array of Strings, therefor no getters and setters are needed
}

