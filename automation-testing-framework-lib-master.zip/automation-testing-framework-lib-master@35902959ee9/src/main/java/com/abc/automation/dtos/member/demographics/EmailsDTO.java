package com.abc.automation.dtos.member.demographics;

/**
 * Created by PPetarcheva on 4/17/2019.
 */
public class EmailsDTO {

    private boolean clientSource;
    private String type;
    private String value;

    public boolean getClientSource() {
        return clientSource;
    }

    public void setClientSource(boolean clientSource) {
        this.clientSource = clientSource;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
