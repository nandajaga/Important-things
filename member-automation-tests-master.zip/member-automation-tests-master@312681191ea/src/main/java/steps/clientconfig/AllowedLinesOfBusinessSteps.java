package steps.clientconfig;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.clientconfig.AllowedLineOfBusinessResponseDTO;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static helpers.constants.BasePathConstants.BASE_PATH_GET_V1_ALLOWED_LINES_OF_BUSINESS;

public class AllowedLinesOfBusinessSteps {

    private CustomFilterableRequestSpecification requestSpecification;
    private RequestOperationsHelper requestOperationsHelper;

    public AllowedLinesOfBusinessSteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addBasePath(BASE_PATH_GET_V1_ALLOWED_LINES_OF_BUSINESS);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.addHeaders(headers);
    }

    //for the positive tests
    public List<AllowedLineOfBusinessResponseDTO> getAllowedLinesOfBusiness(String clientId, String issuanceStateCode) {

        HashMap<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);
        HashMap<String, String> queryParamsMap = new HashMap<>();
        queryParamsMap.put("issuance-state-code", issuanceStateCode);
        requestSpecification.addPathParams(pathParamsMap);

        if (issuanceStateCode != null) {
            requestSpecification.addQueryParams(queryParamsMap);
        }

        Response response = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());
        List<AllowedLineOfBusinessResponseDTO> allowedLineOfBusinessResponseDTOList = Arrays.asList(response.getBody().as(AllowedLineOfBusinessResponseDTO[].class));
        response.then().statusCode(HttpStatus.SC_OK);

        return allowedLineOfBusinessResponseDTOList;
    }

    //for the negative tests
    public ErrorDTO getAllowedLinesOfBusinessWithError(String clientId, String issuanceStateCode) {

        HashMap<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);
        HashMap<String, String> queryParamsMap = new HashMap<>();
        queryParamsMap.put("issuance-state-code", issuanceStateCode);

        requestSpecification.addPathParams(pathParamsMap);
        if (issuanceStateCode != null) {
            requestSpecification.addQueryParams(queryParamsMap);
        }

        Response response = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return response.as(ErrorDTO.class);
    }
}
