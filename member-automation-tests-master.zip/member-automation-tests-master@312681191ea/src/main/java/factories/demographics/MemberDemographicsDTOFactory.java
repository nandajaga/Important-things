package factories.demographics;

import dtos.demographics.EmailsDTO;
import dtos.demographics.MemberDemographicsDTO;
import dtos.demographics.PhonesDTO;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.BeforeMethod;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import static helpers.constants.Constants.*;

public class MemberDemographicsDTOFactory {

    private DateFormat date = new SimpleDateFormat("yyyy-MM-dd");
    ArrayList<EmailsDTO> emails = new EmailsDTOFactory().createEmailsDTO(true, EMAIL_TYPE, EMAIL_VALUE);
    ArrayList<PhonesDTO> phones = new PhonesDTOFactory().createPhonesDTO(true, PHONE_TYPE, PHONE_VALUE);


    public MemberDemographicsDTO createMemberDemographicsDTOFactory(String clientId,String clientMemberId) {
        return createMemberDemographicsDTO(clientId, clientMemberId);
    }

    public MemberDemographicsDTO createMemberDemographicsDTO(String clientId, String clientMemberId) {
        MemberDemographicsDTO memberDemographicsDTO = new MemberDemographicsDTO();

        memberDemographicsDTO.setClientId(clientId);
        memberDemographicsDTO.setAdditionalMemberIds(new AdditionalMemberIdDTOFactory().createAdditionalMemberIdsDTO());
        memberDemographicsDTO.setAddresses(new AddressesDTOFactory().createAddressesDTO());
        memberDemographicsDTO.setClientDependentRelationCode(CLIENT_DEPENDENT_RELATION_CODE);
        memberDemographicsDTO.setClientMemberId(clientMemberId);
        memberDemographicsDTO.setClientSpecificDemographics(new ClientSpecificDemographicsDTOFactory().createClientSpecificDemographicsDTO());
        try {
            memberDemographicsDTO.setDateOfBirth(date.parse(DOB));
        } catch (ParseException e) {
            System.out.println("Can't parse the date!");
        }
        memberDemographicsDTO.setDependentCode(DEPENDENT_CODE);
        memberDemographicsDTO.setEmails(new EmailsDTOFactory().createEmailsDTO());
        memberDemographicsDTO.setFirstName(FIRST_NAME_STARTS_WITH + RandomStringUtils.random(10, true, false));
        memberDemographicsDTO.setGender(GENDER);
        memberDemographicsDTO.setLastName(LAST_NAME_STARTS_WITH + RandomStringUtils.random(10, true, false));
        memberDemographicsDTO.setLegacyMemberId(LEGACY_MEMBER_ID);
        memberDemographicsDTO.setManuallyCreated(MANUALLY_CREATED);
        memberDemographicsDTO.setManuallyUpdated(MANUALLY_UPDATED);
        memberDemographicsDTO.setMemberPrefix(MEMBER_PREFIX);
        memberDemographicsDTO.setPhones(new PhonesDTOFactory().createPhonesDTO());

        return memberDemographicsDTO;
    }

    public MemberDemographicsDTO createMemberDemographicsDTO(String clientId, String firstName, String lastName, ArrayList<EmailsDTO> emails, ArrayList<PhonesDTO> phones,String clientMemberId) {
        MemberDemographicsDTO memberDemographicsDTO = new MemberDemographicsDTO();

        memberDemographicsDTO.setAdditionalMemberIds(new AdditionalMemberIdDTOFactory().createAdditionalMemberIdsDTO());
        memberDemographicsDTO.setAddresses(new AddressesDTOFactory().createAddressesDTO());
        memberDemographicsDTO.setClientDependentRelationCode(CLIENT_DEPENDENT_RELATION_CODE);
        memberDemographicsDTO.setClientId(clientId);
        memberDemographicsDTO.setClientMemberId(clientMemberId);
        memberDemographicsDTO.setClientSpecificDemographics(new ClientSpecificDemographicsDTOFactory().createClientSpecificDemographicsDTO());
        try {
            memberDemographicsDTO.setDateOfBirth(date.parse(DOB));
        } catch (ParseException e) {
            System.out.println("Can't parse the date!");
        }
        memberDemographicsDTO.setDependentCode(DEPENDENT_CODE);
        memberDemographicsDTO.setFirstName(firstName);
        memberDemographicsDTO.setGender(GENDER);
        memberDemographicsDTO.setLastName(lastName);
        memberDemographicsDTO.setLegacyMemberId(LEGACY_MEMBER_ID);
        memberDemographicsDTO.setManuallyCreated(MANUALLY_CREATED);
        memberDemographicsDTO.setManuallyUpdated(MANUALLY_UPDATED);
        memberDemographicsDTO.setMemberPrefix(MEMBER_PREFIX);

        if (phones != null) {
            memberDemographicsDTO.setPhones(phones);
        }

        if (emails != null) {
            memberDemographicsDTO.setEmails(emails);
        }

        return memberDemographicsDTO;
    }
    public MemberDemographicsDTO createMemberDemographicsDTO(String clientId, String firstName, String lastName, String dob, String clientMemberId) throws ParseException {
        MemberDemographicsDTO memberDemographicsDTO = new MemberDemographicsDTO();

        memberDemographicsDTO.setAdditionalMemberIds(new AdditionalMemberIdDTOFactory().createAdditionalMemberIdsDTO());
        memberDemographicsDTO.setAddresses(new AddressesDTOFactory().createAddressesDTO());
        memberDemographicsDTO.setClientDependentRelationCode(CLIENT_DEPENDENT_RELATION_CODE);
        memberDemographicsDTO.setClientId(clientId);
        memberDemographicsDTO.setClientMemberId(clientMemberId);
        memberDemographicsDTO.setClientSpecificDemographics(new ClientSpecificDemographicsDTOFactory().createClientSpecificDemographicsDTO());
        memberDemographicsDTO.setDateOfBirth(date.parse(dob));
        memberDemographicsDTO.setDependentCode(DEPENDENT_CODE);
        memberDemographicsDTO.setFirstName(firstName);
        memberDemographicsDTO.setGender(GENDER);
        memberDemographicsDTO.setLastName(lastName);
        memberDemographicsDTO.setLegacyMemberId(LEGACY_MEMBER_ID);
        memberDemographicsDTO.setManuallyCreated(MANUALLY_CREATED);
        memberDemographicsDTO.setManuallyUpdated(MANUALLY_UPDATED);
        memberDemographicsDTO.setMemberPrefix(MEMBER_PREFIX);
         memberDemographicsDTO.setPhones(phones);
        memberDemographicsDTO.setEmails(emails);

        return memberDemographicsDTO;
    }

    public MemberDemographicsDTO createMemberDemographicsForDeletionViaRabbitMQDTO(String clientId, String id) {
        MemberDemographicsDTO memberDemographicsDTO = new MemberDemographicsDTO();
        memberDemographicsDTO.setClientId(clientId);
        memberDemographicsDTO.setId(id);

        return memberDemographicsDTO;
    }
}
//AREA 51
