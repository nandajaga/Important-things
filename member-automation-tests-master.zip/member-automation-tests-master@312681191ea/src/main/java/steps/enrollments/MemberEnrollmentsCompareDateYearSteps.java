package steps.enrollments;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.enrollments.MemberEnrollmentsDTO;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

import static helpers.constants.BasePathConstants.BASE_PATH_ENROLLMENTS_COMPARE_YEAR;

/**
 * Created by RKondakova on 5/14/2019.
 */
public class MemberEnrollmentsCompareDateYearSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;


    public MemberEnrollmentsCompareDateYearSteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BASE_PATH_ENROLLMENTS_COMPARE_YEAR);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    public MemberEnrollmentsDTO getMemberEnrollmentsCompareYearDate(String clientId, String memberId, String compareDate, String compareYear) {

        Response result = getMemberEnrollmentsCompareYearDateResponse(clientId, memberId, compareDate, compareYear, null);

        result.then().statusCode(HttpStatus.SC_OK);

        return result.as(MemberEnrollmentsDTO.class);
    }

    public ErrorDTO getMemberEnrollmentsCompareYearDateError(String clientId, String memberId, String compareDate, String compareYear) {
        Response result = getMemberEnrollmentsCompareYearDateResponse(clientId, memberId, compareDate, compareYear, null);

        return result.as(ErrorDTO.class);
    }

    private Response getMemberEnrollmentsCompareYearDateResponse(String clientId, String memberId, String compareDate, String compareYear, String reviewType) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);
        pathParamsMap.put("memberId", memberId);

        requestSpecification.addPathParams(pathParamsMap);

        Map<String, String> queryParamsMap = new HashMap<>();
        queryParamsMap.put("compareDate", compareDate);
        queryParamsMap.put("compareYear", compareYear);
        if (reviewType != null) {
            queryParamsMap.put("reviewType", reviewType);
        }

        requestSpecification.addQueryParams(queryParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return result;
    }
}
