package factories.datamanager;

import dtos.datamanager.MemberDTO;
import dtos.demographics.EmailsDTO;
import dtos.demographics.PhonesDTO;
import dtos.enrollments.MemberEnrollmentDTO;
import factories.demographics.MemberDemographicsDTOFactory;
import factories.enrollments.MemberEnrollmentDTOFactory;
import factories.enrollments.ReviewProgramsDTOFactory;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static helpers.constants.Constants.*;

public class MemberDTOFactory {

    private List<MemberEnrollmentDTO> enrollmentWithSpecificProductCode;

    private List<MemberEnrollmentDTO> enrollmentWithProductCode(String clientId, String productCode) {

        enrollmentWithSpecificProductCode = new MemberEnrollmentDTOFactory().createMemberEnrollmentDTOWithSpecificProductCode(clientId, productCode);

        return enrollmentWithSpecificProductCode;
    }

    private List<MemberEnrollmentDTO> enrollmentSourceSystem(String clientId, String issuanceState, String sourceSystem) {
        enrollmentWithSpecificProductCode = new MemberEnrollmentDTOFactory().createMemberEnrollmentSourceSystemDTO(clientId, issuanceState, sourceSystem);
        return enrollmentWithSpecificProductCode;
    }

    private List<MemberEnrollmentDTO> enrollmentsWithNumberEnrollments(String clientId, String employerGroupNumber, int numberOfEnrollments, String mixerCode, String clientMemberProductCode) {
        enrollmentWithSpecificProductCode = new MemberEnrollmentDTOFactory().createMemberEnrollmentDTO(clientId, employerGroupNumber, numberOfEnrollments, mixerCode, clientMemberProductCode);
        return enrollmentWithSpecificProductCode;
    }

    public MemberDTO createMemberDTO(String clientId, List<MemberEnrollmentDTO> enrollment, String clientMemberId) {
        MemberDTO memberDTO = new MemberDTO();
        memberDTO.setCaseRequestId(CASE_REQUEST_ID);
        memberDTO.setLevelOfCare(LEVEL_OF_CARE);
        memberDTO.setMemberDemographics(new MemberDemographicsDTOFactory().createMemberDemographicsDTO(clientId, clientMemberId));
        memberDTO.setMemberEnrollments(enrollment);
        memberDTO.setReviewProgramCodes(new ReviewProgramsDTOFactory().reviewProgramCodes());

        return memberDTO;
    }

    public MemberDTO createMemberDTO(String clientId, String clientMemberId) {
        MemberDTO memberDTO = new MemberDTO();
        memberDTO.setCaseRequestId(CASE_REQUEST_ID);
        memberDTO.setLevelOfCare(LEVEL_OF_CARE);
        memberDTO.setMemberDemographics(new MemberDemographicsDTOFactory().createMemberDemographicsDTO(clientId, clientMemberId));
        memberDTO.setMemberEnrollments(new MemberEnrollmentDTOFactory().createMemberEnrollmentDTO(clientId));
        memberDTO.setReviewProgramCodes(new ReviewProgramsDTOFactory().reviewProgramCodes());

        return memberDTO;
    }

    public MemberDTO createMemberSourceSystemDTO(String clientId, String issuanceState, String sourceSystem, String clientMemberId) {
        return createMemberDTO(clientId, enrollmentSourceSystem(clientId, issuanceState, sourceSystem), clientMemberId);
    }

    public MemberDTO createMemberSpecificClientIdEmployerGroupNumberDTO(String clientId, String employerGroupNumber, int numberOfEnrollments, String mixerCode, String clientMemberProductCode, String clientMemberId) {
        return createMemberDTO(clientId, enrollmentsWithNumberEnrollments(clientId, employerGroupNumber, numberOfEnrollments, mixerCode, clientMemberProductCode), clientMemberId);
    }

    public MemberDTO createMemberDTO(String clientId, String firstName, String lastName, ArrayList<EmailsDTO> emails, ArrayList<PhonesDTO> phones, String clientMemberId) {
        MemberDTO memberDTO = new MemberDTO();
        memberDTO.setCaseRequestId(CASE_REQUEST_ID);
        memberDTO.setLevelOfCare(LEVEL_OF_CARE);
        memberDTO.setMemberDemographics(new MemberDemographicsDTOFactory().createMemberDemographicsDTO(clientId, firstName, lastName, emails, phones, clientMemberId));
        memberDTO.setMemberEnrollments(new MemberEnrollmentDTOFactory().createMemberEnrollmentDTO(clientId));

        return memberDTO;
    }
    public MemberDTO createMemberDTO(String clientId, String firstName, String lastName, String dob, String clientMemberId) throws ParseException {
        MemberDTO memberDTO = new MemberDTO();
        memberDTO.setCaseRequestId(CASE_REQUEST_ID);
        memberDTO.setLevelOfCare(LEVEL_OF_CARE);
        memberDTO.setMemberDemographics(new MemberDemographicsDTOFactory().createMemberDemographicsDTO(clientId, firstName, lastName, dob, clientMemberId));
        memberDTO.setMemberEnrollments(new MemberEnrollmentDTOFactory().createMemberEnrollmentDTO(clientId));

        return memberDTO;
    }

    public MemberDTO createMemberClientMemberId(String clientId, String clientMemberId) {
        MemberDTO memberDTO = new MemberDTO();
        memberDTO.setCaseRequestId(CASE_REQUEST_ID);
        memberDTO.setLevelOfCare(LEVEL_OF_CARE);
        memberDTO.setMemberDemographics(new MemberDemographicsDTOFactory().createMemberDemographicsDTO(clientId, clientMemberId));
        memberDTO.setMemberEnrollments(new MemberEnrollmentDTOFactory().createMemberEnrollmentDTO(clientId));

        return memberDTO;
    }

    public MemberDTO createMemberWithSpecificProductCodeDTO(String clientId, String productCode, String clientMemberId) {
        return createMemberDTO(clientId, enrollmentWithProductCode(clientId, productCode), clientMemberId);
    }

    public MemberDTO createMemberWithSpecificClientIdEmployerGroupNumberAndSourceSystemCode(String clientId, String employerGroupNumber, String systemSourceCode, String mixerCode, String clientMemberId) {

        MemberDTO payload = new MemberDTO();

        payload.setCaseRequestId(CASE_REQUEST_ID);
        payload.setLevelOfCare(LEVEL_OF_CARE);
        payload.setMemberDemographics(new MemberDemographicsDTOFactory().createMemberDemographicsDTO(clientId, clientMemberId));
        payload.setMemberEnrollments(new MemberEnrollmentDTOFactory().createMemberEnrollmentDTO(clientId, systemSourceCode, employerGroupNumber, mixerCode));
        return payload;
    }

    public MemberDTO createMemberWithSpecificClientIdAndAdditionalFields(String clientId, String subGroupCode, String clientAccountNumber, String clientLineOfBusinessCode, String businessMarketSegmentName, String alternateBenefitPlanCode, Boolean preAcaHonorContractFlag, String clientAccountName, String clientFundingTypeCode, String clientMemberId) {

        MemberDTO payload = new MemberDTO();

        payload.setCaseRequestId(CASE_REQUEST_ID);
        payload.setLevelOfCare(LEVEL_OF_CARE);
        payload.setMemberDemographics(new MemberDemographicsDTOFactory().createMemberDemographicsDTO(clientId, clientMemberId));
        payload.setMemberEnrollments(new MemberEnrollmentDTOFactory().createMemberEnrollmentDTO(clientId, ISSUANCE_STATE_CODE_IN, CLIENT_MEMBER_PRODUCT_CODE, PRODUCT_CODE, EMPLOYER_GROUP_NUMBER, subGroupCode, clientAccountNumber, clientLineOfBusinessCode, businessMarketSegmentName, alternateBenefitPlanCode, preAcaHonorContractFlag, clientAccountName, clientFundingTypeCode));
        return payload;
    }

    public MemberDTO createMemberWithSpecificClientIdAndLOBAndIssuanceStateCode(String clientId, String issuanceStateCode, String clientLineOfBusinessCode, String clientMemberId) {

        MemberDTO payload = new MemberDTO();

        payload.setCaseRequestId(CASE_REQUEST_ID);
        payload.setLevelOfCare(LEVEL_OF_CARE);
        payload.setMemberDemographics(new MemberDemographicsDTOFactory().createMemberDemographicsDTO(clientId, clientMemberId));
        payload.setMemberEnrollments(new MemberEnrollmentDTOFactory().createMemberEnrollmentDTO(clientId, issuanceStateCode, clientLineOfBusinessCode));
        return payload;
    }
}
