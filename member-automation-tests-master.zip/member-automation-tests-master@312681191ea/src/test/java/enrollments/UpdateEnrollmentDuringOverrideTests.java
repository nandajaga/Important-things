package enrollments;

import com.aim.automation.tests.base.PostTests;
import dtos.ErrorDTO;
import dtos.datamanager.MemberResponseDTO;
import dtos.enrollments.MemberEnrollmentMixerCodeResponseDTO;
import dtos.enrollments.MemberEnrollmentsDTO;
import helpers.constants.BasePathConstants;
import helpers.dataproviders.DataProviders;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.datamanager.MemberDataManagerSteps;
import steps.enrollments.MemberEnrollmentsSteps;
import steps.enrollments.UpdateMemberEnrollmentsDuringOverrideSteps;
import steps.rabbitmqsimulator.PublishEventSteps;

import static helpers.constants.ClientConfigConstants.*;
import static helpers.constants.Constants.*;
import static helpers.constants.ErrorMessagesForMemberEndpointsConstants.ERR_MSG_ENTRY_NOT_FOUND;
import static helpers.constants.ErrorMessagesForMemberEndpointsConstants.ERR_MSG_ID;

public class UpdateEnrollmentDuringOverrideTests extends PostTests {

    private PublishEventSteps publishEventSteps;
    private MemberDataManagerSteps memberDataManagerSteps;
    private MemberEnrollmentsSteps memberEnrollmentsSteps;
    private UpdateMemberEnrollmentsDuringOverrideSteps updateMemberEnrollmentsDuringOverrideSteps;
    private String CLIENT_MEMBER_ID;

    @BeforeMethod
    public void initMethod() {
        CLIENT_MEMBER_ID = RandomStringUtils.randomNumeric(10) + RandomStringUtils.randomAlphabetic(5).toUpperCase();
    }

    @BeforeClass
    public void init() {
        basePath = BasePathConstants.BASE_PATH_ENROLLMENTS_UPDATE_ENROLLMENT_DURING_OVERRIDE;
        pathParamsMap.clear();
        pathParamsMap.put("clientId", CLIENT_ID_184);
        pathParamsMap.put("memberId", MEMBER_ID_REAL);
        pathParamsMap.put("enrollmentId", ENROLLMENT_ID_REAL);
        body = "";
    }

    //-----------------------------------------------------------POSITIVE-TESTS--------------------------------------------------------------------------------------------------

    @Test
    public void whenCreateMemberAndUpdateEnrollmentDuringOverrideThenResponseSC200() {

        //Publish event through RabbitMQ
        publishEventSteps = new PublishEventSteps(platformContextHeader, headers);
        publishEventSteps.publishEvent(13, CLIENT_ID_184, SS_NASCO, EMPLOYER_GROUP_NUMBER_CLID85, MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAGHMO);

        //Create member with specific data in the enrollment from the event in RabbitMQ
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMemberWithSpecificEmployerGroupNumberAndSystemSourceCode(CLIENT_ID_184, EMPLOYER_GROUP_NUMBER_CLID85, SS_NASCO, null, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        //Get the enrollment
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_184, memberId);
        String enrollmentId = memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId();

        //Check if the mixerCode is updated
        updateMemberEnrollmentsDuringOverrideSteps = new UpdateMemberEnrollmentsDuringOverrideSteps(platformContextHeader, headers);
        MemberEnrollmentMixerCodeResponseDTO updateMemberEnrollmentsResponseDTO = updateMemberEnrollmentsDuringOverrideSteps.updateMemberEnrollmentsDuringOverride(CLIENT_ID_184, memberId, enrollmentId);

        softly.then(memberEnrollmentsDTO).isNotNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isNull();
        softly.then(updateMemberEnrollmentsResponseDTO).isNotNull();
        softly.then(memberEnrollmentsDTO.getEnrollments()).isNotEmpty().isNotNull();
        softly.then(updateMemberEnrollmentsResponseDTO.getMemberEnrollment().getClientSpecificEnrollments().getMixerCode()).isEqualTo(MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAGHMO);
        softly.then(updateMemberEnrollmentsResponseDTO.getMixerCodeEnabled()).isTrue();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getErisaIndicator()).isNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMarketSegmentCode()).isNull();
        softly.assertAll();
    }

    @Test
    public void whenCreateMemberAndUpdateEnrollmentDuringOverrideMixerCodeEnabledFalseThenResponseSC200() {

        //Publish event through RabbitMQ
        publishEventSteps = new PublishEventSteps(platformContextHeader, headers);
        publishEventSteps.publishEvent(MIXER_CODE_IDENTIFIER_14, CLIENT_ID_210, SS_ISG, EMPLOYER_GROUP_CODE_D74495074D, MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAFHMO);

        //Create member with specific data in the enrollment from the event in RabbitMQ
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMemberWithSpecificEmployerGroupNumberAndSystemSourceCode(CLIENT_ID_210, EMPLOYER_GROUP_CODE_D74495074D, SS_ISG, null, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        //Get the enrollment
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_184, memberId);
        String enrollmentId = memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId();

        //Check if the mixerCode is updated
        updateMemberEnrollmentsDuringOverrideSteps = new UpdateMemberEnrollmentsDuringOverrideSteps(platformContextHeader, headers);
        MemberEnrollmentMixerCodeResponseDTO updateMemberEnrollmentsResponseDTO = updateMemberEnrollmentsDuringOverrideSteps.updateMemberEnrollmentsDuringOverride(CLIENT_ID_210, memberId, enrollmentId);

        softly.then(memberEnrollmentsDTO).isNotNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isNull();
        softly.then(updateMemberEnrollmentsResponseDTO).isNotNull();
        softly.then(memberEnrollmentsDTO.getEnrollments()).isNotEmpty().isNotNull();
        softly.then(updateMemberEnrollmentsResponseDTO.getMemberEnrollment().getClientSpecificEnrollments().getMixerCode()).isNull();
        softly.then(updateMemberEnrollmentsResponseDTO.getMixerCodeEnabled()).isFalse();
        softly.assertAll();
    }

    //----------------------------------------------------------------------------------------------------NEGATIVE-TESTS---------------------------------------------------------------------------------------------------------------------------------------

    @Test(dataProvider = "invalid-id-client-config", dataProviderClass = DataProviders.class)
    public void whenSettingInvalidClientIdThenServiceReturns422(String clientId) {

        //Create member with specific data in the enrollment from the event in RabbitMQ
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMemberWithSpecificEmployerGroupNumberAndSystemSourceCode(CLIENT_ID_210, EMPLOYER_GROUP_CODE_D74495074D, SS_ISG, null, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        //Get the enrollment
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_184, memberId);
        String enrollmentId = memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId();

        updateMemberEnrollmentsDuringOverrideSteps = new UpdateMemberEnrollmentsDuringOverrideSteps(platformContextHeader, headers);
        ErrorDTO updateMemberEnrollmentsResponseDTO = updateMemberEnrollmentsDuringOverrideSteps.updateMemberEnrollmentsDuringOverrideWithError(clientId, memberId, enrollmentId);

        softly.then(updateMemberEnrollmentsResponseDTO.getCode()).isEqualTo(HttpStatus.SC_BAD_REQUEST);
        softly.then(updateMemberEnrollmentsResponseDTO.getMessage()).isEqualTo(ERROR_MESSAGE_CLIENT_ID_VALIDATION);
        softly.assertAll();
    }

    @Test(dataProvider = "invalid-id-client-config", dataProviderClass = DataProviders.class)
    public void whenSettingInvalidMemberIdThenServiceReturns422(String memberId) {

        String memberIdMessage = "memberId";

        updateMemberEnrollmentsDuringOverrideSteps = new UpdateMemberEnrollmentsDuringOverrideSteps(platformContextHeader, headers);
        ErrorDTO updateMemberEnrollmentsResponseDTO = updateMemberEnrollmentsDuringOverrideSteps.updateMemberEnrollmentsDuringOverrideWithError(CLIENT_ID_184, memberId, ENROLLMENT_ID_REAL);

        softly.then(updateMemberEnrollmentsResponseDTO.getCode()).isEqualTo(HttpStatus.SC_BAD_REQUEST);
        softly.then(updateMemberEnrollmentsResponseDTO.getMessage()).isEqualTo(String.format(ERR_MSG_ID, memberIdMessage));
        softly.assertAll();
    }

    @Test(dataProvider = "invalid-id-client-config", dataProviderClass = DataProviders.class)
    public void whenSettingInvalidEnrollmentIdThenServiceReturns422(String enrollmentId) {

        //Create member with specific data in the enrollment from the event in RabbitMQ
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMemberWithSpecificEmployerGroupNumberAndSystemSourceCode(CLIENT_ID_184, EMPLOYER_GROUP_NUMBER_CLID85, SS_NASCO, null, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        updateMemberEnrollmentsDuringOverrideSteps = new UpdateMemberEnrollmentsDuringOverrideSteps(platformContextHeader, headers);
        ErrorDTO updateMemberEnrollmentsResponseDTO = updateMemberEnrollmentsDuringOverrideSteps.updateMemberEnrollmentsDuringOverrideWithError(CLIENT_ID_184, memberId, enrollmentId);

        softly.then(updateMemberEnrollmentsResponseDTO.getCode()).isEqualTo(HttpStatus.SC_NOT_FOUND);
        softly.then(updateMemberEnrollmentsResponseDTO.getMessage()).isEqualTo(ERR_MSG_ENTRY_NOT_FOUND);
        softly.assertAll();
    }

    //Here the method is overridden, because otherwise the test fails, due to no body sent. In this endpoint no body is sent, just pathParams
    @Override
    public void whenPostWithNoBodyThenServiceReturnsBadRequest() {

    }

}
