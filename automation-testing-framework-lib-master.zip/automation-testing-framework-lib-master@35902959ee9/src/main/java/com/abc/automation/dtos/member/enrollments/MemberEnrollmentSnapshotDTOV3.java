package com.abc.automation.dtos.member.enrollments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Created by Bharath Kumar on 04/05/2021
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MemberEnrollmentSnapshotDTOV3 {

    private String caseId;
    private String caseRequestId;
    private String pcpSnapshotId;
    private MemberEnrollmentDTO memberEnrollment;
    private String snapshotId;

    public MemberEnrollmentDTO getMemberEnrollment() {
        return memberEnrollment;
    }

    public void setMemberEnrollment(MemberEnrollmentDTO memberEnrollment) {
        this.memberEnrollment = memberEnrollment;
    }

    public String getSnapshotId() {
        return snapshotId;
    }

    public void setSnapshotId(String snapshotId) {
        this.snapshotId = snapshotId;
    }


    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    public String getCaseId() {
        return caseId;
    }

    public void setCaseRequestId(String caseRequestId) {
        this.caseRequestId = caseRequestId;
    }

    public String getCaseRequestId() {
        return caseRequestId;
    }

    public void setPcpSnapshotId(String pcpSnapshotId) {
        this.pcpSnapshotId = pcpSnapshotId;
    }

    public String getPcpSnapshotId() {
        return pcpSnapshotId;
    }
}
