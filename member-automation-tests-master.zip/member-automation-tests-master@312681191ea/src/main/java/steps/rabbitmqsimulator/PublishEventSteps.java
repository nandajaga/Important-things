package steps.rabbitmqsimulator;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.rabbitmqsimulator.PublishEventRequestDTO;
import factories.rabbitmqsimulator.PublishEventRequestDTOFactory;
import helpers.constants.BasePathConstants;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import static helpers.constants.Constants.*;

/**
 * Created by VBaliyska on 10/2/2019.
 */
public class PublishEventSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public PublishEventSteps(String platformContextHeaders, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BasePathConstants.BASE_PATH_PUBLISH_EVENT);
        requestSpecification.addPlatformContextToRequest(platformContextHeaders);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    public Response  publishEvent(int mixerCodeMapIdentifier, String clientId, String sourceSystemCode, String employerGroupCode, String mixerCode) {
        PublishEventRequestDTOFactory publishEvent = new PublishEventRequestDTOFactory();
        PublishEventRequestDTO body = publishEvent.createMixerCodeMappingEvent(mixerCodeMapIdentifier, clientId, sourceSystemCode, employerGroupCode, mixerCode);

        return publishMixerCodeMapEvent(body);
    }

    public Response publishEvent(int mixerCodeMapIdentifier, String clientId, String sourceSystemCode, String employerGroupCode, String mixerCode, String effectiveStartDate, String effectiveEndDate, boolean manualAddEnableFlag) {
        PublishEventRequestDTOFactory publishEvent = new PublishEventRequestDTOFactory();
        PublishEventRequestDTO body = publishEvent.createMixerCodeMappingEvent(mixerCodeMapIdentifier, clientId, sourceSystemCode, employerGroupCode, mixerCode, effectiveStartDate, effectiveEndDate, manualAddEnableFlag);

        return publishMixerCodeMapEvent(body);
    }

    public Response publishEventMemberManualAdd(String clientId, String clientMemberId) {
        PublishEventRequestDTOFactory publishEvent = new PublishEventRequestDTOFactory();
        PublishEventRequestDTO body = publishEvent.createMemberManual(clientId, clientMemberId);

        return publishEventMember(body);
    }

    public Response publishEventMember(PublishEventRequestDTO body) {
        requestSpecification.addCustomHeader(EXCHANGE_TYPE_HEADER, RIVER_EXCHANGE_TYPE);
        requestSpecification.addCustomHeader(ROUTING_KEY_HEADER, RIVER_ROUTING_KEY);
        requestSpecification.addCustomHeader(MESSAGE_TYPE_HEADER, MANUAL_ADD_MESSAGE_TYPE);

        requestSpecification.addBodyToRequest(body);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());
        result.then().statusCode(HttpStatus.SC_ACCEPTED);

        return result;
    }

    public Response publishMixerCodeMapEvent(PublishEventRequestDTO body) {
        requestSpecification.addCustomHeader(EXCHANGE_TYPE_HEADER, STREAM_EXCHANGE_TYPE);
        requestSpecification.addCustomHeader(ROUTING_KEY_HEADER, MIXERCODEMAP_ROUTING_KEY);
        requestSpecification.addCustomHeader(MESSAGE_TYPE_HEADER, MIXERCODEMAP_MESSAGE_TYPE);

        requestSpecification.addBodyToRequest(body);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());
        result.then().statusCode(HttpStatus.SC_ACCEPTED);

        return result;
    }

    public Response publishDeleteMixerCodeMapEvent(int mixerCodeMapIdentifier, String clientId, String sourceSystemCode, String employerGroupCode, String mixerCode) {
        PublishEventRequestDTOFactory publishEvent = new PublishEventRequestDTOFactory();
        PublishEventRequestDTO body = publishEvent.createMixerCodeMappingDeleteEvent(mixerCodeMapIdentifier, clientId, sourceSystemCode, employerGroupCode, mixerCode);

        return publishMixerCodeMapEvent(body);
    }

    public Response publishDeleteMemberEvent(String clientId, String id) {
        PublishEventRequestDTOFactory publishEvent = new PublishEventRequestDTOFactory();
        PublishEventRequestDTO body = publishEvent.createMemberDeleteEvent(clientId, id);

        return publishEventMember(body);
    }

    public Response publishInvalidDeleteMemberEvent(String clientId, String id) {
        PublishEventRequestDTOFactory publishEvent = new PublishEventRequestDTOFactory();
        PublishEventRequestDTO body = publishEvent.createMemberInvalidDeleteEvent(clientId, id);

        return publishEventMember(body);
    }
}
