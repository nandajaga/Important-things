package clientconfig;

import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.clientconfig.RestrictedAccessTypeResponseDTO;
import helpers.constants.ClientConfigConstants;
import helpers.dataproviders.DataProviders;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.clientconfig.RestrictedAccessTypeSteps;

import java.time.LocalDate;
import java.util.Date;

import static helpers.constants.BasePathConstants.BASE_PATH_MEMBER_RESTRICTED_ACCESS_TYPE_GET;
import static helpers.constants.ClientConfigConstants.*;
import static helpers.constants.ClientConfigConstants.CLIENT_ID_210;
import static helpers.constants.ClientConfigConstants.CLIENT_ID_212;
import static helpers.constants.Constants.CLIENT_ID_85;
import static helpers.constants.ConstantsClientIds.*;
import static org.apache.http.HttpStatus.SC_BAD_REQUEST;

/**
 * Created by VBaliyska on 6/25/2019.
 */
public class GetRestrictedAccessTypeTest extends GetTests {

    private PlatformContextUtils platformContextUtils;

    @BeforeClass
    public void init() {
        basePath = BASE_PATH_MEMBER_RESTRICTED_ACCESS_TYPE_GET;
        pathParamsMap.clear();
        pathParamsMap.put("clientId", CLIENT_ID_85);
    }

    @BeforeMethod
    public void initMethod() {
        platformContextUtils = new PlatformContextUtils();
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200-----------------------------------------

    @Test(dataProvider = "clientId", dataProviderClass = DataProviders.class)
    public void whenSendClientIdWithRestrictedAccessThenServiceReturnsIsRestrictionAllowedTrue(String clientId) {
        LocalDate lDate = LocalDate.now();
        Date date = java.sql.Date.valueOf(lDate.plusDays(0));
        platformContextHeader = platformContextUtils.changeDateOfServiceDate(platformContextHeader, date);
        platformContextHeader = platformContextUtils.changeRootLevelDateOfServiceDate(platformContextHeader, date);
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));
        if (clientId != CLIENT_ID_85) {
            platformContextHeader = platformContextUtils.changeChannelCode(platformContextHeader, CHANNEL_CODE_P);

        }
        RestrictedAccessTypeResponseDTO restrictedAccessTypeResponseDTO = new RestrictedAccessTypeSteps(platformContextHeader, headers).getMemberRestrictedAccessType(clientId);

        switch (clientId) {
            case CLIENT_ID_85:
                softly.then(restrictedAccessTypeResponseDTO.getIsRestrictionAllowed()).isTrue();
                softly.then(restrictedAccessTypeResponseDTO.getRestrictionType()).isEqualTo(RESTRICTION_HOUSE_ACCOUNT);
                break;
            case CLIENT_ID_202:
                softly.then(restrictedAccessTypeResponseDTO.getIsRestrictionAllowed()).isTrue();
                softly.then(restrictedAccessTypeResponseDTO.getRestrictionType()).isEqualTo(RESTRICTION_VIP_ACCOUNT);
                break;
            case CLIENT_ID_210:
                softly.then(restrictedAccessTypeResponseDTO.getIsRestrictionAllowed()).isFalse();
                softly.then(restrictedAccessTypeResponseDTO.getRestrictionType()).isEqualTo(NONE);
                break;
            case CLIENT_ID_212:
                softly.then(restrictedAccessTypeResponseDTO.getIsRestrictionAllowed()).isFalse();
                softly.then(restrictedAccessTypeResponseDTO.getRestrictionType()).isEqualTo(NONE);
                break;
        }
        if (clientId != CLIENT_ID_210 && clientId != CLIENT_ID_212 && clientId != CLIENT_ID_202 && clientId != CLIENT_ID_85) {
            softly.then(restrictedAccessTypeResponseDTO.getIsRestrictionAllowed()).isTrue();
            softly.then(restrictedAccessTypeResponseDTO.getRestrictionType()).isEqualTo(RESTRICTION_HEALTH_PLAN);
        }
        softly.assertAll();

    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-400---------------------------------------------

    @Test
    public void whenPostWithoutChannelCodeThenServiceReturnsSC400() {
        platformContextHeader = platformContextUtils.changeChannelCode(platformContextHeader, null);

        ErrorDTO error = new RestrictedAccessTypeSteps(platformContextHeader, headers).getMemberRestrictedAccessTypeWithError(CLIENT_ID_85);

        softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.then(error.getMessage()).contains(PLATFORM_CONTEXT_MISSING_FIELD_CC);
        softly.assertAll();
    }

    //TODO Bug for implement validations on the client Id field is logged. Uncomment once fixed - NCP-23670
    //@Test(dataProvider = "clientIdSearch", dataProviderClass = DataProviders.class)
    public void whenPostInvalidClientIdThenServiceReturnsSC400(String clientId) {

        ErrorDTO error = new RestrictedAccessTypeSteps(platformContextHeader, headers).getMemberRestrictedAccessTypeWithError(clientId);

        softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.then(error.getMessage()).contains(PLATFORM_CONTEXT_MISSING_FIELD_CC);
        softly.assertAll();
    }
}
