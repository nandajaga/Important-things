package factories.demographics;

import dtos.demographics.ClientSpecificDemographicsDTO;

import static helpers.constants.Constants.*;

public class ClientSpecificDemographicsDTOFactory {

    public ClientSpecificDemographicsDTO createClientSpecificDemographicsDTO() {

        ClientSpecificDemographicsDTO clientSpecificDemographicsDTO = new ClientSpecificDemographicsDTO();

        clientSpecificDemographicsDTO.setEstimatedDateOfBirthFlag(ESTIMATED_DOB_FLAG);
        clientSpecificDemographicsDTO.setLangPreferenceCode(LANG_PREFERENCE_CODE);
        clientSpecificDemographicsDTO.setLangPreferenceOriginalCode(LANG_PREFERENCE_ORIGINAL_CODE);
        clientSpecificDemographicsDTO.setRestrictedAccessCode(RESTRICTED_ACCESS_CODE);
        clientSpecificDemographicsDTO.setSubClientCode(SUB_CLIENT_CODE);
        clientSpecificDemographicsDTO.setUpdateFlag(UPDATE_FLAG);

        return clientSpecificDemographicsDTO;
    }
}
//AREA 51
