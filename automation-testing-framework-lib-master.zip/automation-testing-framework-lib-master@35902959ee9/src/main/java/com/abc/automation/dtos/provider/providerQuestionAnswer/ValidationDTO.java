package com.abc.automation.dtos.provider.providerQuestionAnswer;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ValidationDTO {

    private Boolean required;
    private String errorMessage;
    private String dataType;
    private String externalFieldName;
    private String operator;

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getExternalFieldName() {
        return externalFieldName;
    }

    public void setExternalFieldName(String externalFieldName) {
        this.externalFieldName = externalFieldName;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public Boolean getRequired() {
        return required;
    }

    public void setRequired(Boolean required) {
        this.required = required;
    }
}
