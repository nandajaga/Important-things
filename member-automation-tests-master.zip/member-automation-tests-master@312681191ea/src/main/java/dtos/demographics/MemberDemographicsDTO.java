package dtos.demographics;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by RKondakova on 7/24/2019.
 */
public class MemberDemographicsDTO {

    private String id;

    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
    )
    private Date createdOn;
    private List<AdditionalMemberIdDTO> additionalMemberIds;
    private List<AddressesDTO> addresses;
    private String clientDependentRelationCode;
    private String clientId;
    private String clientMemberCode;
    private String clientMemberId;
    private ClientSpecificDemographicsDTO clientSpecificDemographics;

    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = "yyyy-MM-dd"
    )

    private Date dateOfBirth;
    private String dependentCode;
    private String dependentRelationCode;
    private String dependentRelationName;
    private List<DoNotCallRecordDTO> doNotCallRecords;
    private List<EmailsDTO> emails;
    private String firstName;
    private String gender;
    private String healthPlan;
    private String lastName;
    private String legacyMemberId;
    private Boolean manuallyUpdated;
    private String memberPrefix;
    private Boolean manuallyCreated;
    private List<PhonesDTO> phones;
    private List<RestrictedAccessesDTO> restrictedAccesses;

    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
    )

    private Date updateDate;

    public List<AdditionalMemberIdDTO> getAdditionalMemberIds() {
        return this.additionalMemberIds != null ? new ArrayList(this.additionalMemberIds) : null;
    }

    public void setAdditionalMemberIds(List<AdditionalMemberIdDTO> additionalMemberIds) {
        if (additionalMemberIds != null) {
            this.additionalMemberIds = new ArrayList(additionalMemberIds);
        }

    }

    public List<AddressesDTO> getAddresses() {
        return this.addresses != null ? new ArrayList(this.addresses) : null;
    }

    public void setAddresses(ArrayList<AddressesDTO> addresses) {
        if (addresses != null) {
            this.addresses = new ArrayList(addresses);
        }

    }

    public String getClientDependentRelationCode() {
        return this.clientDependentRelationCode;
    }

    public void setClientDependentRelationCode(String clientDependentRelationCode) {
        this.clientDependentRelationCode = clientDependentRelationCode;
    }

    public String getClientId() {
        return this.clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientMemberCode() {
        return this.clientMemberCode;
    }

    public void setClientMemberCode(String clientMemberCode) {
        this.clientMemberCode = clientMemberCode;
    }

    public String getClientMemberId() {
        return this.clientMemberId;
    }

    public void setClientMemberId(String clientMemberId) {
        this.clientMemberId = clientMemberId;
    }

    public ClientSpecificDemographicsDTO getClientSpecificDemographics() {
        return this.clientSpecificDemographics;
    }

    public void setClientSpecificDemographics(ClientSpecificDemographicsDTO clientSpecificDemographics) {
        this.clientSpecificDemographics = clientSpecificDemographics;
    }

    public Date getCreatedOn() {
        return this.createdOn != null ? new Date(this.createdOn.getTime()) : null;
    }

    public void setCreatedOn(Date createdOn) {
        if (createdOn != null) {
            this.createdOn = new Date(createdOn.getTime());
        }

    }

    public Date getDateOfBirth() {
        return this.dateOfBirth != null ? new Date(this.dateOfBirth.getTime()) : null;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        if (dateOfBirth != null) {
            this.dateOfBirth = new Date(dateOfBirth.getTime());
        }

    }

    public String getDependentCode() {
        return this.dependentCode;
    }

    public void setDependentCode(String dependentCode) {
        this.dependentCode = dependentCode;
    }

    public String getDependentRelationCode() {
        return this.dependentRelationCode;
    }

    public void setDependentRelationCode(String dependentRelationCode) {
        this.dependentRelationCode = dependentRelationCode;
    }

    public String getDependentRelationName() {
        return this.dependentRelationName;
    }

    public void setDependentRelationName(String dependentRelationName) {
        this.dependentRelationName = dependentRelationName;
    }

    public List<DoNotCallRecordDTO> getDoNotCallRecords() {
        return this.doNotCallRecords != null ? new ArrayList(this.doNotCallRecords) : null;
    }

    public void setDoNotCallRecords(List<DoNotCallRecordDTO> doNotCallRecords) {
        if (doNotCallRecords != null) {
            this.doNotCallRecords = new ArrayList(doNotCallRecords);
        }

    }

    public List<EmailsDTO> getEmails() {
        return this.emails != null ? new ArrayList(this.emails) : null;
    }

    public void setEmails(ArrayList<EmailsDTO> emails) {
        if (emails != null) {
            this.emails = new ArrayList(emails);
        }

    }

    public String getFirstName() {
        return this.firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getGender() {
        return this.gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getHealthPlan() {
        return this.healthPlan;
    }

    public void setHealthPlan(String healthPlan) {
        this.healthPlan = healthPlan;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLastName() {
        return this.lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLegacyMemberId() {
        return this.legacyMemberId;
    }

    public void setLegacyMemberId(String legacyMemberId) {
        this.legacyMemberId = legacyMemberId;
    }

    public Boolean getManuallyUpdated() {
        return this.manuallyUpdated;
    }

    public void setManuallyUpdated(Boolean manuallyUpdated) {
        this.manuallyUpdated = manuallyUpdated;
    }

    public String getMemberPrefix() {
        return this.memberPrefix;
    }

    public void setMemberPrefix(String memberPrefix) {
        this.memberPrefix = memberPrefix;
    }

    public Boolean getManuallyCreated() {
        return this.manuallyCreated;
    }

    public void setManuallyCreated(Boolean manuallyCreated) {
        this.manuallyCreated = manuallyCreated;
    }

    public List<RestrictedAccessesDTO> getRestrictedAccesses() {
        return this.restrictedAccesses != null ? new ArrayList(this.restrictedAccesses) : null;
    }

    public void setRestrictedAccesses(List<RestrictedAccessesDTO> restrictedAccesses) {
        if (restrictedAccesses != null) {
            this.restrictedAccesses = new ArrayList(restrictedAccesses);
        }

    }

    public Date getUpdateDate() {
        return this.updateDate != null ? new Date(this.updateDate.getTime()) : null;
    }

    public void setUpdateDate(Date updateDate) {
        if (updateDate != null) {
            this.updateDate = new Date(updateDate.getTime());
        }

    }

    public List<PhonesDTO> getPhones() {
        return this.phones != null ? new ArrayList(this.phones) : null;
    }

    public void setPhones(ArrayList<PhonesDTO> phones) {
        if (phones != null) {
            this.phones = new ArrayList(phones);
        }

    }
}
