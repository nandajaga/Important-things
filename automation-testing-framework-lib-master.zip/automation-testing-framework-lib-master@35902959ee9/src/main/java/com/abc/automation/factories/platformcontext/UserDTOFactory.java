package com.abc.automation.factories.platformcontext;

import com.abc.servicemodel.domain.User;

import java.util.ArrayList;

import static com.abc.automation.helpers.constants.PlatformContextConstants.PC_USER_ID;

public class UserDTOFactory {

    public User createUserPCDTO() {
        ArrayList<String> roles = new ArrayList();
        User user = new User();

        roles.add("1");

        user.setId(PC_USER_ID);
        user.setRoles(roles);

        return user;
    }

    public User createUserPCDTO(String id, ArrayList<String> roles) {
        User user = new User();
        user.setId(id);
        user.setRoles(roles);

        return user;
    }
}
