package steps.demographics;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.demographics.MemberDemographicsDTO;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;

import java.util.HashMap;
import java.util.Map;

import static helpers.constants.BasePathConstants.BASE_PATH_V1_MEMBER_DEMOGRAPHICS;

/**
 * Created by RKondakova on 7/2/2019.
 */
public class GetV1MemberDemographicsSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public GetV1MemberDemographicsSteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BASE_PATH_V1_MEMBER_DEMOGRAPHICS);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    // for positive tests
    public MemberDemographicsDTO getMemberSearch(String clientId, String memberId) {

        Map<String, String> queryParamsMap = new HashMap<>();
        if (clientId != null) queryParamsMap.put("clientId", clientId);
        if (memberId != null) queryParamsMap.put("memberId", memberId);

        requestSpecification.addQueryParams(queryParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(MemberDemographicsDTO.class);
    }

    // for negative tests
    public ErrorDTO getMemberInvalidParamsSearch(String clientId, String memberId) {

        Map<String, String> queryParamsMap = new HashMap<>();
        if (clientId != null) queryParamsMap.put("clientId", clientId);
        if (memberId != null) queryParamsMap.put("memberId", memberId);

        requestSpecification.addQueryParams(queryParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorDTO.class);
    }

    public ErrorDTO getMemberInvalidParamsSearchWithoutCheckingForNull(String clientId, String memberId) {

        Map<String, String> queryParamsMap = new HashMap<>();
        queryParamsMap.put("clientId", clientId);
        queryParamsMap.put("memberId", memberId);

        requestSpecification.addQueryParams(queryParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorDTO.class);
    }
}
