package demographics;

import com.aim.automation.dtos.ErrorDTO;
import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.steps.cases.caserequest.CreateCaseRequestSteps;
import com.aim.automation.steps.cases.servicelock.CaseServiceLockSteps;
import com.aim.automation.tests.base.PostTests;
import dtos.workflow.MemberDemographicWorkflowResDTO;
import factories.workflow.DemographicEnsureWorkflowDTOFactory;
import helpers.constants.Constants;
import helpers.dataproviders.DataProviders;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.demographics.PostEnsureWorkFlowSteps;

import static helpers.constants.BasePathConstants.BASE_PATH_POST_ENSUREWORKFLOW;
import static helpers.constants.BasePathConstants.CASE_REQUEST_BASE_URI;
import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_210;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_212;
import static helpers.constants.ErrorMessagesForMemberEndpointsConstants.ERR_MSG_CASEREQUESTID_CANNOT_NULL;

/**
 * Created by @sbioi on 05/15/2020
 */

public class PostEnsureWorkFlowTests extends PostTests {

    private MemberDemographicWorkflowResDTO memberEnsureWorkFlowResponseDTO;
    private PostEnsureWorkFlowSteps postEnsureWorkFlowSteps;
    private PlatformContextUtils platformContextUtils;

    @BeforeClass
    public void initClass() {
        basePath = BASE_PATH_POST_ENSUREWORKFLOW;
        body = new DemographicEnsureWorkflowDTOFactory().createDisasterDTO(SUBCLIENT_CODE);
    }

    @BeforeMethod
    public void initMethod() {

        //Create caseRequestId and put a lock on it by changing baseURI to C&S
        requestSpecification.addBaseURI(CASE_REQUEST_BASE_URI);
        requestSpecification.addPlatformContextToRequest(new PlatformContextUtils().changeUserId(requestSpecification, USER_ID));
        CreateCaseRequestSteps createCaseRequestSteps = new CreateCaseRequestSteps(requestSpecification);
        String caseRequestId = createCaseRequestSteps.createCaseRequest();

        //Create caseRequestId and put a lock on it
        CaseServiceLockSteps caseServiceLockStep = new CaseServiceLockSteps(requestSpecification);
        caseServiceLockStep.lockCaseOrCaseRequest(caseRequestId, USER_ID);

        platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(CLIENT_ID_210));
        platformContextHeader = platformContextUtils.changeStateCode(platformContextHeader, ISUUANCE_STATE_CODE_TX);
        platformContextHeader = platformContextUtils.changeSolutionId(platformContextHeader, String.valueOf(PC_SOLUTION_ID));
        platformContextHeader = platformContextUtils.changeCaseId(platformContextHeader, null);
        platformContextHeader = platformContextUtils.changeUserId(platformContextHeader, USER_ID);
        platformContextHeader = platformContextUtils.changeCaseRequestId(platformContextHeader, caseRequestId);
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-201---------------------------------------------
    /* https://jira.aimspecialtyhealth.com/browse/OSPP-5787
     * ClientId - 210, Zipcode - 75006,75001 , solution id=15 and StateCode - TX
     * Validate Member is in Disaster area and Hard stop is provided
     * Updated by sbioi on 20/05/2020
     */
    @Test(dataProvider = "validZipCodeForClient210DisasterDeclaration", dataProviderClass = DataProviders.class)
    public void whenDisasterZipcodeAndClientIdAndStateCodeAndSolutionIdPassed(String zipCode, String subClientCode) {
        platformContextHeader = platformContextUtils.changeZipCode(platformContextHeader, zipCode);

        postEnsureWorkFlowSteps = new PostEnsureWorkFlowSteps(platformContextHeader, headers);
        memberEnsureWorkFlowResponseDTO = postEnsureWorkFlowSteps.postEnsureWorkFlowStep(subClientCode);

        softly.then(memberEnsureWorkFlowResponseDTO.getWorkFlow()).isNull();
        softly.then(memberEnsureWorkFlowResponseDTO.getFlow()).isNull();
        softly.assertAll();
    }

    /* https://jira.aimspecialtyhealth.com/browse/OSPP-5787
     * ClientId - 212, Zipcode - 75006,75001 , solution id=15 and StateCode - TX
     * Validate Member is NOT in Disaster area and Hard stop is provided
     * Updated by sbioi on 20/05/2020
     */
    @Test
    public void whenOption1ZipCodeAndClientIdAndStateCodeAndSolutionIdPassedInPlatformContext() {
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(CLIENT_ID_212));

        postEnsureWorkFlowSteps = new PostEnsureWorkFlowSteps(platformContextHeader, headers);
        memberEnsureWorkFlowResponseDTO = postEnsureWorkFlowSteps.postEnsureWorkFlowStep(SUBCLIENT_CODE);

        softly.then(memberEnsureWorkFlowResponseDTO).isNotNull();
        softly.then(memberEnsureWorkFlowResponseDTO.getFlow()).isNull();
        softly.then(memberEnsureWorkFlowResponseDTO.getWorkFlow()).isNull();
        softly.assertAll();
    }

    //Can be modified when we get new configuration , So don't remove

    /* https://jira.aimspecialtyhealth.com/browse/OSPP-5787
     * ClientId - 85, Zipcode - 46403, 60423
     * Validate Member is in Disaster area and Hard stop is provided
     * Updated by sbioi on 20/05/2020
     */
    @Test(dataProvider = "validZipCodeForClient85DisasterDeclaration", dataProviderClass = DataProviders.class)
    public void whenDisasterAndOption1ZipcodeAndClientIdAndStateCodeAndSolutionIdPassedInPlatformContext(String zipCode, String stateCode) {
        platformContextHeader = platformContextUtils.changeZipCode(platformContextHeader, zipCode);
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(Constants.CLIENT_ID_85));
        platformContextHeader = platformContextUtils.changeStateCode(platformContextHeader, stateCode);
        platformContextHeader = platformContextUtils.changeChannelCode(platformContextHeader, PC_CHANNEL_CODE_P);

        postEnsureWorkFlowSteps = new PostEnsureWorkFlowSteps(platformContextHeader, headers);
        memberEnsureWorkFlowResponseDTO = postEnsureWorkFlowSteps.postEnsureWorkFlowStep(SUBCLIENT_CODE);

        softly.then(memberEnsureWorkFlowResponseDTO.getFlow()).isNull();
        softly.then(memberEnsureWorkFlowResponseDTO.getWorkFlow()).isNull();

        softly.assertAll();
    }

    @Test(dataProvider = "validZipCodeForClient85DisasterDeclaration", dataProviderClass = DataProviders.class)
    public void whenDisasterAndOption1ZipcodeAndClientIdAndStateCodeAndSolutionIdAndChannelCodeCcPassedInPlatformContext(String zipCode, String stateCode) {
        platformContextHeader = platformContextUtils.changeZipCode(platformContextHeader, zipCode);
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(Constants.CLIENT_ID_85));
        platformContextHeader = platformContextUtils.changeStateCode(platformContextHeader, stateCode);
        platformContextHeader = platformContextUtils.changeChannelCode(platformContextHeader, PC_CHANNEL_CODE_CC);

        postEnsureWorkFlowSteps = new PostEnsureWorkFlowSteps(platformContextHeader, headers);
        memberEnsureWorkFlowResponseDTO = postEnsureWorkFlowSteps.postEnsureWorkFlowStep(SUBCLIENT_CODE);

        softly.then(memberEnsureWorkFlowResponseDTO.getFlow()).isNull();
        softly.then(memberEnsureWorkFlowResponseDTO.getWorkFlow()).isNull();

        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-404---------------------------------------------//
    @Test
    public void whenCaseIdIsPassedWithValueInPlatformContextThenEmptyBody() {
        platformContextHeader = platformContextUtils.changeCaseId(platformContextHeader, CASE_ID);

        postEnsureWorkFlowSteps = new PostEnsureWorkFlowSteps(platformContextHeader, headers);
        Response response = postEnsureWorkFlowSteps.whenCaseIdIsNotNullSendError(SUBCLIENT_CODE);

        softly.then(response.asString()).isEmpty();
        softly.then(response.asString()).isBlank();
        softly.assertAll();
    }

    @Test
    public void whenCaseRequestIdIsPassedEmptyInPlatformContextResponseIs500() {
        platformContextHeader = platformContextUtils.changeCaseRequestId(platformContextHeader, null);

        postEnsureWorkFlowSteps = new PostEnsureWorkFlowSteps(platformContextHeader, headers);
        ErrorDTO errorDTO = postEnsureWorkFlowSteps.whenCaseRequestIdIsNullSendError(SUBCLIENT_CODE);

        softly.then(errorDTO.getCode()).isEqualTo(HttpStatus.SC_INTERNAL_SERVER_ERROR);
        softly.then(errorDTO.getMessage()).isEqualTo(ERR_MSG_CASEREQUESTID_CANNOT_NULL);
        softly.assertAll();
    }

    @Test
    public void whenDisasterAndOption1ZipcodeAndInvalidChannelCodePassedInPlatformContextThenNullWorkFlowReturned() {
        platformContextHeader = platformContextUtils.changeZipCode(platformContextHeader, ZIP_CODE_46403);
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(Constants.CLIENT_ID_85));
        platformContextHeader = platformContextUtils.changeChannelCode(platformContextHeader, "TEST");
        platformContextHeader = platformContextUtils.changeIssuanceStateCode(platformContextHeader, STATE_CODE_IN);
        platformContextHeader = platformContextUtils.changeStateCode(platformContextHeader, STATE_CODE_IN);

        postEnsureWorkFlowSteps = new PostEnsureWorkFlowSteps(platformContextHeader, headers);
        memberEnsureWorkFlowResponseDTO = postEnsureWorkFlowSteps.postEnsureWorkFlowStep(null);

        softly.then(memberEnsureWorkFlowResponseDTO.getFlow()).isNull();
        softly.then(memberEnsureWorkFlowResponseDTO.getWorkFlow()).isNull();

        softly.assertAll();
    }
}
