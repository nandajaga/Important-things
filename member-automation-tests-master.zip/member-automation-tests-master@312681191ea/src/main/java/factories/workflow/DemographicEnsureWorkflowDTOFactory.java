package factories.workflow;

import dtos.workflow.DemographicEnsureWorkflowReqDTO;

public class DemographicEnsureWorkflowDTOFactory {
    public DemographicEnsureWorkflowReqDTO createDisasterDTO(String subClientCode) {
        DemographicEnsureWorkflowReqDTO demographicEnsureWorkflowReqDTO = new DemographicEnsureWorkflowReqDTO();
        demographicEnsureWorkflowReqDTO.setSubClientCode(subClientCode);
        return demographicEnsureWorkflowReqDTO;
    }
}
