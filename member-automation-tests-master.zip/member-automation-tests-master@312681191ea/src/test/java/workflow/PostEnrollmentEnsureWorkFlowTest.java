package workflow;

import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.tests.base.PostTests;
import dtos.workflow.WorkFlowResponseDTO;
import factories.workflow.WorkFlowFactory;
import helpers.constants.BasePathConstants;
import helpers.constants.Constants;
import helpers.dataproviders.DataProviders;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.workflow.WorkFlowSteps;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import static helpers.constants.ClientConfigConstants.*;
import static helpers.constants.Constants.*;

/**
 * Created by sbioi on 25/03/2021.
 */
public class PostEnrollmentEnsureWorkFlowTest extends PostTests {
    private WorkFlowResponseDTO[] enrollmentEnsureWorkFlowResponseDTO;
    private WorkFlowSteps workFlowSteps;
    private PlatformContextUtils platformContextUtils;
    String dateInString = "2021-03-27";


    @BeforeClass
    public void init() {
        basePath = BasePathConstants.BASE_PATH_ENROLLMENT_ENSURE_WORKFLOW;
        body = new WorkFlowFactory().createWorkFlowDTO(SUBCLIENT_CODE);
    }

    @BeforeMethod
    public void initMethod() {
        platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(CLIENT_ID_199));
        platformContextHeader = platformContextUtils.changeSolutionId(platformContextHeader, String.valueOf(PC_SOLUTION_ID));
    }
    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    /* https://dbg-jira.antheminc.com/browse/CAP-3628
     * ClientId - 199, employergroupcode -720902,720903,720904,720905,720906 ,Solution id-15
     * Validate Member hard stop is provided
     * created by sbioi on 25/02/2021
     */

    @Test(dataProvider = "ensureWorkFlowClientIdZipcodeState", dataProviderClass = DataProviders.class)
    public void whenPostDifferentClientIdZipCodeAndStateCodeResponseIs200(String clientId, String stateCode, String zipCode) {
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));
        platformContextHeader = platformContextUtils.changeStateCode(platformContextHeader, stateCode);
        platformContextHeader = platformContextUtils.changeZipCode(platformContextHeader, zipCode);

        workFlowSteps = new WorkFlowSteps(platformContextHeader, headers);

        enrollmentEnsureWorkFlowResponseDTO = workFlowSteps.postWorkFlowSteps(SUBCLIENT_CODE);

        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getFlow()).isNull();
        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getWorkFlow()).isNull();

        softly.assertAll();
    }

    /* https://dbg-jira.antheminc.com/browse/CAP-4607
     * ClientId - 199, employergroupcode -720902,720903,720904,720905,720906 ,Solution id-15
     * Validate Member hard stop is provided
     * created by sbioi on 03/26/2021
     * May change when Test config is deployed
     */

    @Test(dataProvider = "ensureWorkFlowEmployerGroupCode", dataProviderClass = DataProviders.class)
    public void whenPostClientIdSolutionIdAndEmployerCodeResponseIs200(String employerGroupCode) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);

        Date date = null;
        try {
            date = formatter.parse(dateInString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(CLIENT_ID_199));
        platformContextHeader = platformContextUtils.changeEmployerGroupCode(platformContextHeader, employerGroupCode);
        platformContextHeader = platformContextUtils.changeDateOfServiceDate(platformContextHeader, date);
        platformContextHeader = platformContextUtils.changeRootLevelDateOfServiceDate(platformContextHeader, date);

        workFlowSteps = new WorkFlowSteps(platformContextHeader, headers);

        enrollmentEnsureWorkFlowResponseDTO = workFlowSteps.postWorkFlowSteps(SUBCLIENT_CODE);

        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getFlow().getBusinessKey()).isEqualTo(BUSINESS_KEY_EMPLOYER_GROUP_RESTRICTION);
        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getFlow().getBusinessKeyCode()).isEqualTo(BUSINESS_KEY_CODE_32BJ);
        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getFlow().getBusinessKeyCodeDescription()).isEqualTo(BUSINESS_KEY_CODE_32BJ);
        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getWorkFlow().getWorkFlowType()).isEqualTo(WORK_FLOW_TYPE);
        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getWorkFlow().getBusinessKey()).isEqualTo(BUSINESS_KEY_EMPLOYER_GROUP_RESTRICTION);
        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getWorkFlow().getWorkFlowReason()).isEqualTo(WORK_FLOW_REASON_EMPLOYER_GROUP_HARD_STOP);
        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getWorkFlow().getWorkFlowMessaging()).isEqualTo(WORK_FLOW_MESSAGING_EMPLOYER_GROUP_CODE_32BJ);
        softly.assertAll();
    }

    //****************************************************Negetive scenario*****************************************************/

    @Test
    public void whenPostInvalidEmployerGroupCodeScenario() {
        platformContextHeader = platformContextUtils.changeEmployerGroupCode(platformContextHeader, WRONG_EMPLOYER_GROUP_CODE);

        workFlowSteps = new WorkFlowSteps(platformContextHeader, headers);

        enrollmentEnsureWorkFlowResponseDTO = workFlowSteps.postWorkFlowSteps(SUBCLIENT_CODE);

        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getFlow()).isNull();
        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getWorkFlow()).isNull();
        softly.assertAll();
    }

    @Test
    public void whenPostWrongZipcode() {
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(Constants.CLIENT_ID_85));
        platformContextHeader = platformContextUtils.changeStateCode(platformContextHeader, STATE_CODE_IN);
        platformContextHeader = platformContextUtils.changeZipCode(platformContextHeader, ZIP_CODE_12084);

        workFlowSteps = new WorkFlowSteps(platformContextHeader, headers);

        enrollmentEnsureWorkFlowResponseDTO = workFlowSteps.postWorkFlowSteps(SUBCLIENT_CODE);
        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getWorkFlow()).isNull();
        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getFlow()).isNull();
    }

    @Test
    public void whenPostWrongStateCode() {
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(CLIENT_ID_199));
        platformContextHeader = platformContextUtils.changeStateCode(platformContextHeader, STATE_CODE_IN);
        platformContextHeader = platformContextUtils.changeZipCode(platformContextHeader, ZIP_CODE_12084);

        workFlowSteps = new WorkFlowSteps(platformContextHeader, headers);

        enrollmentEnsureWorkFlowResponseDTO = workFlowSteps.postWorkFlowSteps(SUBCLIENT_CODE);
        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getWorkFlow()).isNull();
        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getFlow()).isNull();
    }

    /*
    Solution id =1 passed which is not valid according to the configuration, (correct solution id=15)
     */
    @Test
    public void whenPostInvalidSolutionIdScenario() {
        platformContextHeader = platformContextUtils.changeSolutionId(platformContextHeader, SOLUTION_ID_1);
        platformContextHeader = platformContextUtils.changeEmployerGroupCode(platformContextHeader, EMPLOYER_GROUP_CODE_720902);

        workFlowSteps = new WorkFlowSteps(platformContextHeader, headers);

        enrollmentEnsureWorkFlowResponseDTO = workFlowSteps.postWorkFlowSteps(SUBCLIENT_CODE);

        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getFlow()).isNull();
        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getWorkFlow()).isNull();
        softly.assertAll();
    }
}