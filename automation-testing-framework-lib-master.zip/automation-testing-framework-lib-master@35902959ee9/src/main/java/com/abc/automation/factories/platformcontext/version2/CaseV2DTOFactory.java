package com.abc.automation.factories.platformcontext.version2;

import com.abc.servicemodel.domainV2.CaseV2;
import com.abc.servicemodel.domainV2.ServiceV2;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import static com.abc.automation.helpers.constants.Constants.SAMPLE_DATE_FORMAT;
import static com.abc.automation.helpers.constants.Constants.TIMEZONE_DATE_FORMAT;
import static com.abc.automation.helpers.constants.PlatformContextConstants.*;

public class CaseV2DTOFactory {
    public CaseV2 createCasePCDTO(String pcCaseId) {
        CaseV2 casePC = new CaseV2();
        casePC.setId(pcCaseId);

        return casePC;
    }

    public CaseV2 createCaseDTO(LocalDateTime createdDate, LocalDate dateOfService, String id, Integer parentSolutionId,
                                LocalDateTime requestCreatedDate, String requestId, String reviewCategoryCode,
                                List<ServiceV2> services, Integer solutionId) {
        CaseV2 casePC = new CaseV2();

        casePC.setCreatedDate(createdDate);
        casePC.setDateOfService(dateOfService);
        casePC.setId(id);
        casePC.setParentSolutionId(parentSolutionId);
        casePC.setRequestCreatedDate(requestCreatedDate);
        casePC.setRequestId(requestId);
        casePC.setReviewCategoryCode(reviewCategoryCode);
        casePC.setServices(services);
        casePC.setSolutionId(solutionId);

        return casePC;
    }

    public CaseV2 createCaseDTO() {
        ArrayList<ServiceV2> services = new ArrayList<>();
        services.add(new ServiceV2DTOFactory().createServiceDTO());
        DateTimeFormatter formatterDateTime = DateTimeFormatter.ofPattern(TIMEZONE_DATE_FORMAT);

        LocalDateTime createdDate = LocalDateTime.parse(PC_CASE_CREATED_DATE, formatterDateTime);
        LocalDateTime requestCreatedDate = LocalDateTime.parse(PC_REQUEST_CREATED_DATE, formatterDateTime);
        DateTimeFormatter formatterDate = DateTimeFormatter.ofPattern(SAMPLE_DATE_FORMAT);
        LocalDate dateOfService = LocalDate.parse(PC_DATE_OF_SERVICE, formatterDate);

        return createCaseDTO(createdDate, dateOfService, PC_CASE_ID, PC_PARENT_SOLUTION_ID, requestCreatedDate,
                PC_REQUEST_ID, PC_REVIEW_CATEGORY_CODE, services, PC_SOLUTION_ID);
    }


}
