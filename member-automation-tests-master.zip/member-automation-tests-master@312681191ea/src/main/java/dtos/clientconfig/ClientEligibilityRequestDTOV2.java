package dtos.clientconfig;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * Created by RKondakova on 7/10/2019.
 */
public class ClientEligibilityRequestDTOV2 {

    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = "yyyy-MM-dd"
    )

    private String dateOfService;
    private String memberId;
    private String solutionId;
    private String subClientCode;

    public String getDateOfService() {
        return dateOfService;
    }

    public void setDateOfService(String dateOfService) {
        this.dateOfService = dateOfService;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getSolutionId() {
        return solutionId;
    }

    public void setSolutionId(String solutionId) {
        this.solutionId = solutionId;
    }

    public String getSubClientCode() {
        return subClientCode;
    }

    public void setSubClientCode(String subClientCode) {
        this.subClientCode = subClientCode;
    }
}
