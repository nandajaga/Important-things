package dtos.workflow;

public class WorkFlowResponseDTO {
    private FlowDTO flow;
    private WorkFlowDTO workFlow;

    public FlowDTO getFlow() {
        return flow;
    }

    public void setFlow(FlowDTO flow) {
        this.flow = flow;
    }

    public WorkFlowDTO getWorkFlow() {
        return workFlow;
    }

    public void setWorkFlow(WorkFlowDTO workFlow) {
        this.workFlow = workFlow;
    }
}
