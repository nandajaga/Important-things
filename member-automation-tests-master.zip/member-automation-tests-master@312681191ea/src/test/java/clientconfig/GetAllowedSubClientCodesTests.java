package clientconfig;

import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.clientconfig.AllowedSubClientCodesResponseDTO;
import helpers.dataproviders.DataProviders;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import steps.clientconfig.GetAllowedSubClientCodesSteps;

import static helpers.constants.BasePathConstants.BASE_PATH_GET_ALLOWED_SUB_CLIENT_CODES;
import static helpers.constants.ClientConfigConstants.CLIENT_ID_210;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_220;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_233;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_234;

import static helpers.constants.Constants.*;

/**
 * Created by SDoneva at 9/19/2019
 */

public class GetAllowedSubClientCodesTests extends GetTests {

    private GetAllowedSubClientCodesSteps getAllowedSubClientCodesSteps;

    @BeforeClass
    public void init() {
        basePath = BASE_PATH_GET_ALLOWED_SUB_CLIENT_CODES;
        pathParamsMap.clear();
        pathParamsMap.put("clientId", CLIENT_ID_210);
        queryParamsMap.put("issuance-state-code", "DC");
        queryParamsMap.put("line-of-business-code", LINE_OF_BUSINESS);
    }

    //--------------------------------------------------POSITIVE-TESTS--------------------------------------------------------------------------------

    @Test(dataProvider = "clientId-and-issuance-state-code-line-of-business", dataProviderClass = DataProviders.class)
    public void whenGetValidClientConfigThenResponseSC200(String clientId, String issuanceStateCode, String lineOfBusiness) {

        getAllowedSubClientCodesSteps = new GetAllowedSubClientCodesSteps(platformContextHeader, headers);

        AllowedSubClientCodesResponseDTO responseDTO = getAllowedSubClientCodesSteps.getAllowedSubClientCodes(clientId, issuanceStateCode, lineOfBusiness);

        softly.then(responseDTO.getAllowedSubClientCodes()).isNotNull().isNotEmpty();
        softly.then(responseDTO.getAllowedSubClientCodes().get(0)).isEqualTo(issuanceStateCode);

        if (clientId.equals(CLIENT_ID_210) && issuanceStateCode.equals(ISUUANCE_STATE_CODE_NY) && lineOfBusiness.equals(MEDICAID_CODE)) {
            softly.then(responseDTO.getAllowedSubClientCodes().get(1)).isEqualTo(SUBCLIENT_CODE);
        }

        softly.assertAll();
    }

    @Test(dataProvider = "valid-client-id-line-of-business-default-config", dataProviderClass = DataProviders.class)
    public void whenNotValidClientIdButInvalidLineOfBusinessThenDefaultConfigResponseSC200(String clientId, String issuanceStateCode) {

        getAllowedSubClientCodesSteps = new GetAllowedSubClientCodesSteps(platformContextHeader, headers);

        AllowedSubClientCodesResponseDTO responseDTO = getAllowedSubClientCodesSteps.getAllowedSubClientCodes(clientId, issuanceStateCode, COMMERCIAL_CODE);

        softly.then(responseDTO.getAllowedSubClientCodes()).isNull();
        softly.assertAll();
    }

    //-----------------------------------------------NEGATIVE-TESTS-SC-400----------------------------------------------------------------

    @Test(dataProvider = "invalid-id-client-config", dataProviderClass = DataProviders.class)
    public void whenGetInvalidClientIdThenResponseSC400(String clientId) {

        getAllowedSubClientCodesSteps = new GetAllowedSubClientCodesSteps(platformContextHeader, headers);

        ErrorDTO errorDTO = getAllowedSubClientCodesSteps.getAllowedSubClientCodesWithError(clientId, ISSUANCE_STATE_CODE_IN, MEDICARE_CODE);

        softly.then(errorDTO.getCode()).isEqualTo(HttpStatus.SC_BAD_REQUEST);
        softly.then(errorDTO.getMessage()).isEqualTo(ERROR_MESSAGE_CLIENT_ID_VALIDATION);
        softly.assertAll();
    }

    @Test(dataProvider = "invalid-issuance-state-code-client-config", dataProviderClass = DataProviders.class)
    public void whenGetInvalidIssuanceStateCodeThenResponseSC400(String issuanceStateCode) {

        getAllowedSubClientCodesSteps = new GetAllowedSubClientCodesSteps(platformContextHeader, headers);

        ErrorDTO errorDTO = getAllowedSubClientCodesSteps.getAllowedSubClientCodesWithError(CLIENT_ID_210, issuanceStateCode, MEDICARE_CODE);

        softly.then(errorDTO.getCode()).isEqualTo(HttpStatus.SC_BAD_REQUEST);
        softly.then(errorDTO.getMessage()).isEqualTo(ALLOWED_LINES_OF_BUSINESS_ISSUANCE_STATE_CODE_VALIDATION);
        softly.assertAll();
    }

    @Test(dataProvider = "invalid-line-of-business-client-config", dataProviderClass = DataProviders.class)
    public void whenGetInvalidLineOfBusinessThenResponseSC400(String lineOfBusiness) {

        getAllowedSubClientCodesSteps = new GetAllowedSubClientCodesSteps(platformContextHeader, headers);

        ErrorDTO errorDTO = getAllowedSubClientCodesSteps.getAllowedSubClientCodesWithError(CLIENT_ID_210, ISSUANCE_STATE_CODE_IN, lineOfBusiness);

        softly.then(errorDTO.getCode()).isEqualTo(HttpStatus.SC_BAD_REQUEST);

        if (INVALID_LINE_OF_BUSINESS_ALPHABETIC.equals(lineOfBusiness)) {
            softly.then(errorDTO.getMessage()).isEqualTo(ALLOWED_SUB_CLIENT_CODE_LINE_BUSINESS_VALIDATION_LENGHT);
        } else {
            softly.then(errorDTO.getMessage()).isEqualTo(ALLOWED_SUB_CLIENT_CODES_LINE_OF_BUSINESS_VALIDATION_MESSAGE);
        }
        softly.assertAll();
    }

    @Test(dataProvider = "invalid-issuance-state-code-client-config", dataProviderClass = DataProviders.class)
    public void whenGetInvalidIssuanceStateCodeThenResponseSC400HCSC(String issuanceStateCode) {

        getAllowedSubClientCodesSteps = new GetAllowedSubClientCodesSteps(platformContextHeader, headers);

        ErrorDTO errorDTO = getAllowedSubClientCodesSteps.getAllowedSubClientCodesWithError(CLIENT_ID_220, issuanceStateCode, MEDICAID_CODE);

        softly.then(errorDTO.getCode()).isEqualTo(HttpStatus.SC_BAD_REQUEST);
        softly.then(errorDTO.getMessage()).isEqualTo(ALLOWED_LINES_OF_BUSINESS_ISSUANCE_STATE_CODE_VALIDATION);
        softly.assertAll();
    }

    @Test(dataProvider = "invalid-issuance-state-code-client-config", dataProviderClass = DataProviders.class)
    public void whenGetInvalidIssuanceStateCodeThenResponseSC400NE(String issuanceStateCode) {

        getAllowedSubClientCodesSteps = new GetAllowedSubClientCodesSteps(platformContextHeader, headers);

        ErrorDTO errorDTO = getAllowedSubClientCodesSteps.getAllowedSubClientCodesWithError(CLIENT_ID_233, issuanceStateCode, MEDICAID_CODE);

        softly.then(errorDTO.getCode()).isEqualTo(HttpStatus.SC_BAD_REQUEST);
        softly.then(errorDTO.getMessage()).isEqualTo(ALLOWED_LINES_OF_BUSINESS_ISSUANCE_STATE_CODE_VALIDATION);
        softly.assertAll();
    }

    @Test(dataProvider = "invalid-issuance-state-code-client-config", dataProviderClass = DataProviders.class)
    public void whenGetInvalidIssuanceStateCodeThenResponseSC400MO(String issuanceStateCode) {

        getAllowedSubClientCodesSteps = new GetAllowedSubClientCodesSteps(platformContextHeader, headers);

        ErrorDTO errorDTO = getAllowedSubClientCodesSteps.getAllowedSubClientCodesWithError(CLIENT_ID_234, issuanceStateCode, MEDICAID_CODE);

        softly.then(errorDTO.getCode()).isEqualTo(HttpStatus.SC_BAD_REQUEST);
        softly.then(errorDTO.getMessage()).isEqualTo(ALLOWED_LINES_OF_BUSINESS_ISSUANCE_STATE_CODE_VALIDATION);
        softly.assertAll();
    }

    @Test(dataProvider = "invalid-line-of-business-client-config", dataProviderClass = DataProviders.class)
    public void whenGetInvalidLineOfBusinessThenResponseSC400HSCS(String lineOfBusiness) {

        getAllowedSubClientCodesSteps = new GetAllowedSubClientCodesSteps(platformContextHeader, headers);

        ErrorDTO errorDTO = getAllowedSubClientCodesSteps.getAllowedSubClientCodesWithError(CLIENT_ID_220, ISUUANCE_STATE_CODE_NM, lineOfBusiness);

        softly.then(errorDTO.getCode()).isEqualTo(HttpStatus.SC_BAD_REQUEST);

        if (INVALID_LINE_OF_BUSINESS_ALPHABETIC.equals(lineOfBusiness)) {
            softly.then(errorDTO.getMessage()).isEqualTo(ALLOWED_SUB_CLIENT_CODE_LINE_BUSINESS_VALIDATION_LENGHT);
        } else {
            softly.then(errorDTO.getMessage()).isEqualTo(ALLOWED_SUB_CLIENT_CODES_LINE_OF_BUSINESS_VALIDATION_MESSAGE);
        }
        softly.assertAll();
    }

    @Test(dataProvider = "invalid-line-of-business-client-config", dataProviderClass = DataProviders.class)
    public void whenGetInvalidLineOfBusinessThenResponseSC400NE(String lineOfBusiness) {

        getAllowedSubClientCodesSteps = new GetAllowedSubClientCodesSteps(platformContextHeader, headers);

        ErrorDTO errorDTO = getAllowedSubClientCodesSteps.getAllowedSubClientCodesWithError(CLIENT_ID_233, ISUUANCE_STATE_CODE_NE, lineOfBusiness);

        softly.then(errorDTO.getCode()).isEqualTo(HttpStatus.SC_BAD_REQUEST);

        if (INVALID_LINE_OF_BUSINESS_ALPHABETIC.equals(lineOfBusiness)) {
            softly.then(errorDTO.getMessage()).isEqualTo(ALLOWED_SUB_CLIENT_CODE_LINE_BUSINESS_VALIDATION_LENGHT);
        } else {
            softly.then(errorDTO.getMessage()).isEqualTo(ALLOWED_SUB_CLIENT_CODES_LINE_OF_BUSINESS_VALIDATION_MESSAGE);
        }
        softly.assertAll();
    }

    @Test(dataProvider = "invalid-line-of-business-client-config", dataProviderClass = DataProviders.class)
    public void whenGetInvalidLineOfBusinessThenResponseSC400MO(String lineOfBusiness) {

        getAllowedSubClientCodesSteps = new GetAllowedSubClientCodesSteps(platformContextHeader, headers);

        ErrorDTO errorDTO = getAllowedSubClientCodesSteps.getAllowedSubClientCodesWithError(CLIENT_ID_234, ISUUANCE_STATE_CODE_MO, lineOfBusiness);

        softly.then(errorDTO.getCode()).isEqualTo(HttpStatus.SC_BAD_REQUEST);

        if (INVALID_LINE_OF_BUSINESS_ALPHABETIC.equals(lineOfBusiness)) {
            softly.then(errorDTO.getMessage()).isEqualTo(ALLOWED_SUB_CLIENT_CODE_LINE_BUSINESS_VALIDATION_LENGHT);
        } else {
            softly.then(errorDTO.getMessage()).isEqualTo(ALLOWED_SUB_CLIENT_CODES_LINE_OF_BUSINESS_VALIDATION_MESSAGE);
        }
        softly.assertAll();
    }

}
