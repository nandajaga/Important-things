package clientconfig;

import com.aim.automation.dtos.ErrorDTO;
import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.tests.base.GetTests;
import dtos.clientconfig.EligibilityOverrideAllowedResponseDTO;
import helpers.constants.BasePathConstants;
import helpers.dataproviders.DataProviders;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import steps.clientconfig.EligibilityOverrideAllowedSteps;

import static helpers.constants.ClientConfigConstants.*;
import static helpers.constants.Constants.CLIENT_ID_85;
import static helpers.constants.Constants.*;
import static org.apache.http.HttpStatus.SC_BAD_REQUEST;

public class GetIsEligibilityOverrideAllowedTests extends GetTests {

    private EligibilityOverrideAllowedSteps eligibilityOverrideAllowedSteps;

    @BeforeClass
    public void init() {
        basePath = BasePathConstants.BASE_PATH_ALLOWED_ELIGIBILITY_OVERRIDE;
        pathParamsMap.clear();
        pathParamsMap.put("clientId", CLIENT_ID_85);
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------
    @Test(dataProvider = "clientIdWithoutDefaultValue", dataProviderClass = DataProviders.class)
    public void whenIsEligibilityOverrideAllowedThenServiceResponseIs200(String clientId) {
        eligibilityOverrideAllowedSteps = new EligibilityOverrideAllowedSteps(platformContextHeader, headers);
        EligibilityOverrideAllowedResponseDTO eligibilityOverrideAllowedResponse = eligibilityOverrideAllowedSteps.getIsEligibilityOverrideAllowed(clientId);

        softly.then(eligibilityOverrideAllowedResponse).isNotNull();
        softly.then(eligibilityOverrideAllowedResponse.getMessage()).isNull();
        softly.then(eligibilityOverrideAllowedResponse.getScriptLabel()).isNull();

        switch (clientId) {
            case CLIENT_ID_40:
            case CLIENT_ID_55:
            case CLIENT_ID_86:
                softly.then(eligibilityOverrideAllowedResponse.isEligibilityOverrideAllowed()).isFalse();
                softly.then(eligibilityOverrideAllowedResponse.getScript()).isNull();
                softly.then(eligibilityOverrideAllowedResponse.getNote()).isNull();
                softly.then(eligibilityOverrideAllowedResponse.getSecondNote()).isNull();
                break;
            case CLIENT_ID_220:
                softly.then(eligibilityOverrideAllowedResponse).isNotNull();
                softly.then(eligibilityOverrideAllowedResponse.getMessage()).isNull();
                softly.then(eligibilityOverrideAllowedResponse.getScriptLabel()).isNull();
                softly.then(eligibilityOverrideAllowedResponse.isEligibilityOverrideAllowed()).isTrue();
                softly.then(eligibilityOverrideAllowedResponse.getScript()).isEqualTo(ELIGIBILITY_SCRIPT_MESSAGE_220);
                softly.then(eligibilityOverrideAllowedResponse.getNote()).isNull();
                softly.then(eligibilityOverrideAllowedResponse.getSecondNote()).isNull();
                break;
            default:
                softly.then(eligibilityOverrideAllowedResponse.isEligibilityOverrideAllowed()).isTrue();
                softly.then(eligibilityOverrideAllowedResponse.getScript()).isEqualTo(ELIGIBILITY_SCRIPT_MESSAGE);
                softly.then(eligibilityOverrideAllowedResponse.getNote()).isEqualTo(NOTE_MESSAGE);
                softly.then(eligibilityOverrideAllowedResponse.getSecondNote()).isNull();
                break;
        }

        softly.assertAll();
    }

    @Test(dataProvider = "overrideSolutionIdNullForEligibleClientId", dataProviderClass = DataProviders.class)
    public void whenSolutionIsOverrideSpecificAndChannelCodeCCAndEligibilityAllowedThenServiceResponseIs200(String clientId) {
        eligibilityOverrideAllowedSteps = new EligibilityOverrideAllowedSteps(noSolutionIdPlatformContextWithChannelCodeCC, headers);
        EligibilityOverrideAllowedResponseDTO eligibilityOverrideAllowedResponse = eligibilityOverrideAllowedSteps.getIsEligibilityOverrideAllowed(clientId);

        switch (clientId) {
            case CLIENT_ID_220:
                softly.then(eligibilityOverrideAllowedResponse).isNotNull();
                softly.then(eligibilityOverrideAllowedResponse.getMessage()).isNull();
                softly.then(eligibilityOverrideAllowedResponse.getScriptLabel()).isNull();
                softly.then(eligibilityOverrideAllowedResponse.isEligibilityOverrideAllowed()).isTrue();
                softly.then(eligibilityOverrideAllowedResponse.getScript()).isEqualTo(ELIGIBILITY_SCRIPT_MESSAGE_SOLUTION_OPTIONAL_220);
                softly.then(eligibilityOverrideAllowedResponse.getNote()).isNull();
                softly.then(eligibilityOverrideAllowedResponse.getSecondNote()).isNull();
                break;
            default:
                softly.then(eligibilityOverrideAllowedResponse).isNotNull();
                softly.then(eligibilityOverrideAllowedResponse.getMessage()).isNull();
                softly.then(eligibilityOverrideAllowedResponse.getScriptLabel()).isNull();
                softly.then(eligibilityOverrideAllowedResponse.isEligibilityOverrideAllowed()).isTrue();
                softly.then(eligibilityOverrideAllowedResponse.getScript()).isEqualTo(ELIGIBILITY_SCRIPT_MESSAGE_SOLUTION_OPTIONAL);
                softly.then(eligibilityOverrideAllowedResponse.getNote()).isEqualTo(NOTE_SOLUTION_OPTIONAL_CHANNEL_CODE_CC);
                softly.then(eligibilityOverrideAllowedResponse.getSecondNote()).isNull();
                break;
        }
        softly.assertAll();
    }

    @Test(dataProvider = "overrideSolutionIdNullForEligibleClientId", dataProviderClass = DataProviders.class)
    public void whenSolutionIsOverrideSpecificAndChannelCodePAndEligibilityAllowedThenServiceResponseIs200(String clientId) {
        eligibilityOverrideAllowedSteps = new EligibilityOverrideAllowedSteps(noSolutionIdPlatformContextWithChannelCodeP, headers);
        EligibilityOverrideAllowedResponseDTO eligibilityOverrideAllowedResponse = eligibilityOverrideAllowedSteps.getIsEligibilityOverrideAllowed(clientId);

        switch (clientId) {
            case CLIENT_ID_220:
                softly.then(eligibilityOverrideAllowedResponse).isNotNull();
                softly.then(eligibilityOverrideAllowedResponse.getMessage()).isNull();
                softly.then(eligibilityOverrideAllowedResponse.getScriptLabel()).isNull();
                softly.then(eligibilityOverrideAllowedResponse.isEligibilityOverrideAllowed()).isTrue();
                softly.then(eligibilityOverrideAllowedResponse.getScript()).isEqualTo(ELIGIBILITY_SCRIPT_MESSAGE_SOLUTION_OPTIONAL_220);
                softly.then(eligibilityOverrideAllowedResponse.getNote()).isNull();
                softly.then(eligibilityOverrideAllowedResponse.getSecondNote()).isNull();
                break;
            default:
                softly.then(eligibilityOverrideAllowedResponse).isNotNull();
                softly.then(eligibilityOverrideAllowedResponse.getMessage()).isNull();
                softly.then(eligibilityOverrideAllowedResponse.getScriptLabel()).isNull();
                softly.then(eligibilityOverrideAllowedResponse.isEligibilityOverrideAllowed()).isTrue();
                softly.then(eligibilityOverrideAllowedResponse.getScript()).isNull();
                softly.then(eligibilityOverrideAllowedResponse.getNote()).isEqualTo(NOTE_SOLUTION_OPTIONAL_CHANNEL_CODE_P);
                softly.then(eligibilityOverrideAllowedResponse.getSecondNote()).isNull();
                break;
        }
        softly.assertAll();
    }

    @Test(dataProvider = "overrideSolutionIdNullForEligibleClientId", dataProviderClass = DataProviders.class)
    public void whenSolutionIsOverrideSpecificWithInvalidChannelCodeAndEligibilityAllowedThenServiceResponseIs200(String clientId) {
        eligibilityOverrideAllowedSteps = new EligibilityOverrideAllowedSteps(noSolutionIdPlatformContextWithInvalidChannelCode, headers);
        EligibilityOverrideAllowedResponseDTO eligibilityOverrideAllowedResponse = eligibilityOverrideAllowedSteps.getIsEligibilityOverrideAllowed(clientId);

        softly.then(eligibilityOverrideAllowedResponse).isNotNull();
        softly.then(eligibilityOverrideAllowedResponse.getMessage()).isNull();
        softly.then(eligibilityOverrideAllowedResponse.getScriptLabel()).isNull();
        softly.then(eligibilityOverrideAllowedResponse.isEligibilityOverrideAllowed()).isFalse();
        softly.then(eligibilityOverrideAllowedResponse.getScript()).isNull();
        softly.then(eligibilityOverrideAllowedResponse.getNote()).isNull();
        softly.then(eligibilityOverrideAllowedResponse.getSecondNote()).isNull();
        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-400---------------------------------------------
    @Test(dataProvider = "ClientIdNegative", dataProviderClass = DataProviders.class)
    public void whenSentInvalidClientIdThenSC400(String clientId) {
        eligibilityOverrideAllowedSteps = new EligibilityOverrideAllowedSteps(platformContextHeader, headers);
        ErrorDTO error = eligibilityOverrideAllowedSteps.getIsEligibilityOverrideAllowedWithError(clientId);

        softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.then(error.getMessage()).isEqualTo(ERROR_MESSAGE_CLIENT_ID_VALIDATION);
        softly.assertAll();
    }

    @Test(dataProvider = "ClientIdNegative", dataProviderClass = DataProviders.class)
    public void whenSentInvalidClientIdAndSolutionIdThenSC400(String clientId) {
        PlatformContextUtils platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeSolutionId(platformContextHeader, invalidSolutionId);

        eligibilityOverrideAllowedSteps = new EligibilityOverrideAllowedSteps(platformContextHeader, headers);
        ErrorDTO error = eligibilityOverrideAllowedSteps.getIsEligibilityOverrideAllowedWithError(clientId);

        softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.then(error.getMessage()).isEqualTo(ERROR_MESSAGE_CLIENT_ID_VALIDATION);
        softly.assertAll();
    }

}
