package factories.clientconfig;

import dtos.clientconfig.MemberRestrictionRequestDTO;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by VBaliyska on 6/21/2019.
 */
public class MemberRestrictionDTOFactory {


    public MemberRestrictionRequestDTO createRestrictionRequestMemberDTO(String clientId, String employerGroupNumber, String dependentRelationCode, String restrictionType, String memberId) {
        MemberRestrictionRequestDTO memberRestrictionRequestDTO = new MemberRestrictionRequestDTO();
        memberRestrictionRequestDTO.setClientId(clientId);
        memberRestrictionRequestDTO.setEmployerGroupNumber(employerGroupNumber);
        memberRestrictionRequestDTO.setDependentRelationCode(dependentRelationCode);
        memberRestrictionRequestDTO.setRestrictionType(restrictionType);
        memberRestrictionRequestDTO.setMemberId(memberId);
        return memberRestrictionRequestDTO;
    }

    public List<MemberRestrictionRequestDTO> createSearchRestrictionRequestMemberDTO(String clientId, String employerGroupNumber, String dependentRelationCode, String restrictionType, String memberId, String issuanceStateCode, String lineOfBusinessCode) {
        MemberRestrictionRequestDTO memberRestrictionRequestDTO = new MemberRestrictionRequestDTO();
        memberRestrictionRequestDTO.setClientId(clientId);
        memberRestrictionRequestDTO.setEmployerGroupNumber(employerGroupNumber);
        memberRestrictionRequestDTO.setDependentRelationCode(dependentRelationCode);
        memberRestrictionRequestDTO.setRestrictionType(restrictionType);
        memberRestrictionRequestDTO.setMemberId(memberId);
        memberRestrictionRequestDTO.setIssuanceStateCode(issuanceStateCode);
        memberRestrictionRequestDTO.setLineOfBusinessCode(lineOfBusinessCode);
        return Arrays.asList(memberRestrictionRequestDTO);
    }
    public MemberRestrictionRequestDTO createRestrictionRequestMemberDTO(String clientId, String employerGroupNumber, String dependentRelationCode, String restrictionType, String memberId, String issuanceStateCode, String lineOfBusinessCode) {
        MemberRestrictionRequestDTO memberRestrictionRequestDTO = new MemberRestrictionRequestDTO();
        memberRestrictionRequestDTO.setClientId(clientId);
        memberRestrictionRequestDTO.setEmployerGroupNumber(employerGroupNumber);
        memberRestrictionRequestDTO.setDependentRelationCode(dependentRelationCode);
        memberRestrictionRequestDTO.setRestrictionType(restrictionType);
        memberRestrictionRequestDTO.setMemberId(memberId);
        memberRestrictionRequestDTO.setIssuanceStateCode(issuanceStateCode);
        memberRestrictionRequestDTO.setLineOfBusinessCode(lineOfBusinessCode);
        return memberRestrictionRequestDTO;
    }
}
