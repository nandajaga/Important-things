package dtos.clientconfig;

public class IsManualAddAllowedResponseDTO {
    private boolean isManualAddAllowed;
    private String message;
    private String script;
    private String scriptLabel;

    public boolean getIsManualAddAllowed() {return isManualAddAllowed;}

    public void setManualAddAllowed(boolean manualAddAllowed) {isManualAddAllowed = manualAddAllowed;}

    public String getMessage() {return message;}

    public void setMessage(String message) {this.message = message;}

    public String getScript() {return script;}

    public void setScript(String script) {this.script = script;}

    public String getScriptLabel() {
        return scriptLabel;
    }

    public void setScriptLabel(String scriptLabel) {
        this.scriptLabel = scriptLabel;
    }
}
