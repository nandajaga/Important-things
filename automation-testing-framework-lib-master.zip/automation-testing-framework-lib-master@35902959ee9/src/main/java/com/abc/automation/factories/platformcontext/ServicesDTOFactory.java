package com.abc.automation.factories.platformcontext;

import com.abc.servicemodel.domain.Service;

import java.util.ArrayList;

import static com.abc.automation.helpers.constants.PlatformContextConstants.PC_SERVICES_TREATMENT_CODE;
import static com.abc.automation.helpers.constants.PlatformContextConstants.PC_SERVICES_TREATMENT_CODE_TYPE;

public class ServicesDTOFactory {
    private String treatmentCode = PC_SERVICES_TREATMENT_CODE;
    private String treatmentCodeType = PC_SERVICES_TREATMENT_CODE_TYPE;

    public ArrayList<Service> createServicesPCDTO() {
        ArrayList<Service> services = new ArrayList<>();
        Service service = new Service();
        service.setTreatmentCode(treatmentCode);
        service.setTreatmentCodeType(treatmentCodeType);

        services.add(service);

        return services;
    }

    public ArrayList<Service> createServicesPCDTO(String treatmentCode, String treatmentCodeType) {
        ArrayList<Service> services = new ArrayList<>();
        Service service = new Service();
        service.setTreatmentCodeType(treatmentCode);
        service.setTreatmentCodeType(treatmentCodeType);

        services.add(service);

        return services;
    }
}
