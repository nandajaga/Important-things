package steps.sharedreferencedata;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.ErrorSpringDTO;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static helpers.constants.BasePathConstants.BASE_PATH_SHARED_REFERENCE_DATA_RETRIEVE_BY_TYPES;


/**
 * Created by RKohli on 15/09/2020.
 */
public class SharedReferenceDataRetrieveByTypesSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public SharedReferenceDataRetrieveByTypesSteps(String platformContext, Headers headers) {

        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BASE_PATH_SHARED_REFERENCE_DATA_RETRIEVE_BY_TYPES);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);

    }


    public Map<String, List> postSharedReferenceDataRetrieveByTypesForPositiveTests(List<String> collectionName) {


        requestSpecification.addBodyToRequest(collectionName);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_OK);

        Map<String, List> responseList = result.getBody().as(Map.class);


        return  responseList;
    }


}
