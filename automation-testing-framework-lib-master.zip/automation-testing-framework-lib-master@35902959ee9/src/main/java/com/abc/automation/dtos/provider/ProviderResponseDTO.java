package com.abc.automation.dtos.provider;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
public class ProviderResponseDTO {

    private String ngProviderId;
    private String previousSnapshotId;
    private Integer providerClientId;

    public String getNgProviderId() {
        return ngProviderId;
    }

    public void setNgProviderId(String ngProviderId) {
        this.ngProviderId = ngProviderId;
    }

    public Integer getProviderClientId() {
        return providerClientId;
    }

    public void setProviderClientId(Integer providerClientId) {
        this.providerClientId = providerClientId;
    }

    public String getPreviousSnapshotId() {
        return previousSnapshotId;
    }

    public void setPreviousSnapshotId(String previousSnapshotId) {
        this.previousSnapshotId = previousSnapshotId;
    }
}
