package com.abc.automation.helpers.enums.cases.caserequest;

public enum ReviewTypeEnum {
    /**
     * Prospective review type
     */
    PROSPECTIVE("PROSPECTIVE"),

    /**
     * Retrospective review type
     */
    RETROSPECTIVE("RETROSPECTIVE"),
    PCCA("PCCA"),
    INVALID_REVIEW_TYPE("WERTYJKL");

    private String code;

    ReviewTypeEnum(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

}
