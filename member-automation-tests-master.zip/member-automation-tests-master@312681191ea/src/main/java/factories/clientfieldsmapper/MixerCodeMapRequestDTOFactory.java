package factories.clientfieldsmapper;

import dtos.clientfieldsmapper.MixerCodeMapRequestDTO;

/**
 * Created by VBaliyska on 10/11/2019.
 */
public class MixerCodeMapRequestDTOFactory {

    public MixerCodeMapRequestDTO createMixerCodeMapRequestBody(String clientId, String employerGroupName, String sourceSystem) {

        MixerCodeMapRequestDTO mixerCodeMapRequestDTO = new MixerCodeMapRequestDTO();

        mixerCodeMapRequestDTO.setClientId(clientId);
        mixerCodeMapRequestDTO.setEmployerGroupNumber(employerGroupName);
        mixerCodeMapRequestDTO.setSourceSystem(sourceSystem);

        return mixerCodeMapRequestDTO;
    }
}
