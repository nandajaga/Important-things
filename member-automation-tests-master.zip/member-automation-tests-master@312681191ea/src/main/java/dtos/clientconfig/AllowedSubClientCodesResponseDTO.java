package dtos.clientconfig;

import java.util.List;

public class AllowedSubClientCodesResponseDTO {

    private List<String> allowedSubClientCodes;


    public List<String> getAllowedSubClientCodes() {
        return allowedSubClientCodes;
    }

    public void setAllowedSubClientCodes(List<String> allowedSubClientCodes) {
        this.allowedSubClientCodes = allowedSubClientCodes;
    }
}
