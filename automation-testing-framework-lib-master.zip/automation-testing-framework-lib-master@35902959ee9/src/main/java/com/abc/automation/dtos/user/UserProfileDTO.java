package com.abc.automation.dtos.user;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserProfileDTO {
    private String userName;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private String status;
    private String userId;
    private String externalUserIdNUM;
    private String sso;

    private UserLocationDTO userLocation;
    private List<UserRoleDTO> userRole;
    private List<UserStateLicenseDTO> userStateLicenses;


    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public UserLocationDTO getUserLocation() {
        return userLocation;
    }

    public void setUserLocation(UserLocationDTO userLocation) {
        this.userLocation = userLocation;
    }

    public List<UserRoleDTO> getUserRole() {
        if (userRole != null) {
            return new ArrayList<>(userRole);
        } else {
            return null;
        }
    }

    public void setUserRole(List<UserRoleDTO> userRole) {
        if (userRole != null) {
            this.userRole = new ArrayList<>(userRole);
        } else {
            this.userRole = null;
        }
    }

    public List<UserStateLicenseDTO> getUserStateLicenses() {
        if (userStateLicenses != null) {
            return new ArrayList<>(userStateLicenses);
        } else {
            return null;
        }
    }

    public void setUserStateLicenses(List<UserStateLicenseDTO> userStateLicenses) {
        if (userStateLicenses != null) {
            this.userStateLicenses = new ArrayList<>(userStateLicenses);
        } else {
            this.userStateLicenses = null;
        }
    }

    public String getExternalUserIdNUM() {
        return externalUserIdNUM;
    }

    public void setExternalUserIdNUM(String externalUserIdNUM) {
        this.externalUserIdNUM = externalUserIdNUM;
    }

    public String getSso() {
        return sso;
    }

    public void setSso(String sso) {
        this.sso = sso;
    }
}
