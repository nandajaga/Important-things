package steps.search;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.search.GETMemberSearchDTO;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

import static helpers.constants.BasePathConstants.BASE_PATH_SEARCH_ID_DOB;

/**
 * Created by RKondakova on 6/12/2019.
 */
public class SearchClientMemberDOBSteps {


    private CustomFilterableRequestSpecification requestSpecification;
    private RequestOperationsHelper requestOperationsHelper;

    //constructor
    public SearchClientMemberDOBSteps(String platformContext, Headers headers) {

        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BASE_PATH_SEARCH_ID_DOB);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }
    //for the positive tests
    public GETMemberSearchDTO getMemberSearch( String clientMemberId, String dob ){

        Map<String, String> queryParamsMap = new HashMap<>();

        if(clientMemberId != null) queryParamsMap.put("client-member-id", clientMemberId);
        if(dob != null) queryParamsMap.put("date-of-birth", dob);
        requestSpecification.addQueryParams(queryParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_OK);

        return result.as(GETMemberSearchDTO.class);

    }

    //for negative tests
    public ErrorDTO getMemberSearchWithInvalidParams( String clientMemberId, String dob, String size, String page, String sort){

        Map<String, String> queryParamsMap = new HashMap<>();

        if(clientMemberId != null) queryParamsMap.put("client-member-id", clientMemberId);
        if(dob != null) queryParamsMap.put("date-of-birth", dob);
        if(size != null) queryParamsMap.put("size", size);
        if(page != null) queryParamsMap.put("page", page);
        if(sort != null) queryParamsMap.put("sort", sort);
        requestSpecification.addQueryParams(queryParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorDTO.class);

    }

    public ErrorDTO getMemberSearchWithInvalidParamsWhitoutCheckForNull( String clientMemberId, String dob, String size, String page, String sort){

        Map<String, String> queryParamsMap = new HashMap<>();

        queryParamsMap.put("client-member-id", clientMemberId);
        queryParamsMap.put("date-of-birth", dob);
        queryParamsMap.put("size", size);
        queryParamsMap.put("page", page);
        queryParamsMap.put("sort", sort);
        requestSpecification.addQueryParams(queryParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorDTO.class);

    }
}
