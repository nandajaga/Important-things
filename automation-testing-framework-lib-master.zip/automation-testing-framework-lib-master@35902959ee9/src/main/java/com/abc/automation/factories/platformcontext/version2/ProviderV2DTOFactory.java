package com.abc.automation.factories.platformcontext.version2;

import com.abc.servicemodel.domainV2.ProviderV2;
import com.abc.servicemodel.domainV2.provider.OrderingProviderV2;
import com.abc.servicemodel.domainV2.provider.ServicingProviderV2;

public class ProviderV2DTOFactory {
    public ProviderV2 createProviderDTO() {
        OrderingProviderV2 ordering = new OrderingProviderV2DTOFactory().createOrderingProviderDTO();
        ServicingProviderV2 servicing = new ServicingPoviderV2DTOFactory().createServicingProviderDTO();

        return createProviderDTO(ordering, servicing);
    }
    public ProviderV2 createProviderDTO(OrderingProviderV2 ordering, ServicingProviderV2 servicing) {
        ProviderV2 provider = new ProviderV2();

        provider.setOrdering(ordering);
        provider.setServicing(servicing);

        return provider;
    }
}
