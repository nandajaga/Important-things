package com.abc.automation.helpers.enums.cases.caserequest;

public enum ProgramTypeEnum {
    UM("UM"),
    RQI("RQI"),
    OQI("OQI"),
    INVALID_PROGRAM_TYPE("DFGHJK");

    private String programType;

    ProgramTypeEnum(String programType) {
        this.programType = programType;
    }

    public String getProgramType() {
        return programType;
    }

}
