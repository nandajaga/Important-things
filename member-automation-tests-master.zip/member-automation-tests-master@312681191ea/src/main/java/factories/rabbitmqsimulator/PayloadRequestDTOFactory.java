package factories.rabbitmqsimulator;

import dtos.rabbitmqsimulator.PayloadMemberDeletionDTO;
import dtos.rabbitmqsimulator.PayloadMixerCodeDTO;
import factories.demographics.MemberDemographicsDTOFactory;

/**
 * Created by VBaliyska on 10/3/2019.
 */
public class PayloadRequestDTOFactory {

    public PayloadMixerCodeDTO createPayloadDTO(int mixerCodeMapIdentifier, String clientId, String sourceSystemCode, String employerGroupCode, String mixerCode, String effectiveStartDate, String effectiveEndDate, boolean manualAddEnableFlag) {
        PayloadMixerCodeDTO payload = new PayloadMixerCodeDTO();
        payload.setMixerCodeMapIdentifier(mixerCodeMapIdentifier);
        payload.setClientIdentifier(clientId);
        payload.setSourceSystemCode(sourceSystemCode);
        payload.setEmployerGroupCode(employerGroupCode);
        payload.setMixerCode(mixerCode);
        payload.setEffectiveStartDate(effectiveStartDate);
        payload.setEffectiveEndDate(effectiveEndDate);
        payload.setManualAddEnableFlag(manualAddEnableFlag);
        return payload;
    }

    public PayloadMemberDeletionDTO createPayloadForMemberDeletionDTO(String clientId, String id) {
        PayloadMemberDeletionDTO payload = new PayloadMemberDeletionDTO();
        payload.setMemberDemographics(new MemberDemographicsDTOFactory().createMemberDemographicsForDeletionViaRabbitMQDTO(clientId, id));
        return payload;
    }
}
