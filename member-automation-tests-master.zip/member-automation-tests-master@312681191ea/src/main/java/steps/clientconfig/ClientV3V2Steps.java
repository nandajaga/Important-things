package steps.clientconfig;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.clientconfig.ClientResponseDTO;
import helpers.constants.BasePathConstants;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

public class ClientV3V2Steps {
    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public ClientV3V2Steps(String platformContext, Headers headers,String basePath) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(basePath);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    //for positive tests
    public ClientResponseDTO[] getClientV2PositiveDTO(String clientId, String fields) {
        Map<String, String> pathParamsMap = new HashMap<>();
        Map<String, String> queryPathParas = new HashMap<>();

        if (clientId != null)pathParamsMap.put("clientId", clientId);
        if (fields != null)queryPathParas.put("fields", fields);

        requestSpecification.addPathParams(pathParamsMap);
        requestSpecification.addQueryParams(queryPathParas);

        Response response = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        response.then().statusCode(HttpStatus.SC_OK);

        return response.as(ClientResponseDTO[].class);
    }

    //for negative tests
    public ErrorDTO getClientRequestErrorDTO(String clientId, String fields) {

        Map<String, String> pathParamsMap = new HashMap<>();
        Map<String, String> queryParamsMap = new HashMap<>();

        pathParamsMap.put("clientId", clientId);
        queryParamsMap.put("fields", fields);

        requestSpecification.addPathParams(pathParamsMap);
        requestSpecification.addQueryParams(queryParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorDTO.class);
    }
}
