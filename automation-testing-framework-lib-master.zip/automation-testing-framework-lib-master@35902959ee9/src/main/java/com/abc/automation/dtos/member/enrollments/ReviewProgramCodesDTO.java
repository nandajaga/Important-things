package com.abc.automation.dtos.member.enrollments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ReviewProgramCodesDTO {

    private Boolean isEligible;

    public Boolean getIsEligible() {
        return isEligible;
    }

    public void setIsEligible(Boolean Eligible) {
        this.isEligible = Eligible;
    }


    public String getReviewProgramCode() {
        return reviewProgramCode;
    }

    public void setReviewProgramCode(String reviewProgramCode) {
        this.reviewProgramCode = reviewProgramCode;
    }

    private String reviewProgramCode;

}
