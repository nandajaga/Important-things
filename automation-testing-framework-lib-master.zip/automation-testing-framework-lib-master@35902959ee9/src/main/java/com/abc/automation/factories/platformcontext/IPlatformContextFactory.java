package com.abc.automation.factories.platformcontext;

import com.abc.servicemodel.domain.IPlatformContext;

/**
 * Created by PPetarcheva on 6/25/2019.
 */
public interface IPlatformContextFactory<T extends IPlatformContext> {

    T createPlatformContextDTO();
//    T editPlatformContextDTO(T platformContext, String field, String value);
}
