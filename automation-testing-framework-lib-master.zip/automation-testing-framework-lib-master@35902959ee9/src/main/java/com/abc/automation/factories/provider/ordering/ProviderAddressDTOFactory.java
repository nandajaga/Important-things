package com.abc.automation.factories.provider.ordering;

import com.abc.automation.dtos.provider.ProviderAddressDTO;
import com.abc.automation.helpers.constants.MemberConstants;
import com.abc.automation.helpers.constants.ProviderConstants;
import org.apache.commons.lang3.RandomStringUtils;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
public class ProviderAddressDTOFactory {

    public ProviderAddressDTO createAddressV3AddDTO() {
        ProviderAddressDTO createAddressV3 = new ProviderAddressDTO();

        createAddressV3.setAddressLine1("AutoAddress1-" + RandomStringUtils.random(10, true, true));
        createAddressV3.setAddressLine2(ProviderConstants.ADDRESS_LINE_2);
        createAddressV3.setCity(MemberConstants.CITY_NAME);
        createAddressV3.setStateCode(ProviderConstants.STATE_CODE);
        createAddressV3.setZip(ProviderConstants.ZIP_CODE);

        return createAddressV3;
    }
}
