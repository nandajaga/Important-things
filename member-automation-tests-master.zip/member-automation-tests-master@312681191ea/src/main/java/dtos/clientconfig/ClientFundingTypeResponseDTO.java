package dtos.clientconfig;

public class ClientFundingTypeResponseDTO {

    private String clientFundingTypeCode;

    private String fundType;

    public String getClientFundingTypeCode() {
        return clientFundingTypeCode;
    }

    public void setClientFundingTypeCode(String clientFundingTypeCode) {
        this.clientFundingTypeCode = clientFundingTypeCode;
    }

    public String getFundType() {
        return fundType;
    }

    public void setFundType(String fundType) {
        this.fundType = fundType;
    }


}
