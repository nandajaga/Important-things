package factories.enrollments;

import dtos.enrollments.ReviewProgramsDTO;
import dtos.enrollments.SolutionDTO;

import java.util.ArrayList;

import static helpers.constants.Constants.SOLUTION_PAYLOAD;
import static helpers.constants.Constants.SOLUTION_PROGRAM_TYPE;

public class SolutionDTOFactory {

    private ArrayList<ReviewProgramsDTO> reviewProgramCode = new ReviewProgramsDTOFactory().reviewProgramCodes();

    public ArrayList<SolutionDTO> createSolutionDTO() {
        ArrayList<SolutionDTO> solutions = new ArrayList<>();
        SolutionDTO solution = new SolutionDTO();
        solution.setProgramType(SOLUTION_PROGRAM_TYPE);
        solution.setSolutionId(SOLUTION_PAYLOAD);
        solution.setReviewPrograms(reviewProgramCode);

        solutions.add(solution);

        return solutions;
    }
}
