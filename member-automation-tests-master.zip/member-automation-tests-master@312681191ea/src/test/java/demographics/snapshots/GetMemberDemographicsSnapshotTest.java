package demographics.snapshots;

import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.datamanager.MemberResponseDTO;
import dtos.demographics.snapshot.MemberDemographicsSnapshotDTO;
import dtos.demographics.snapshot.MemberDemographicsSnapshotGetDTO;
import helpers.constants.BasePathConstants;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.datamanager.MemberDataManagerSteps;
import steps.demographics.snapshots.GetMemberDemographicsSnapshotSteps;
import steps.demographics.snapshots.PostMemberDemographicsSnapshotSteps;

import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_85;
import static org.apache.http.HttpStatus.SC_NOT_FOUND;

/**
 * Created by VBaliyska on 5/14/2019.
 */
public class GetMemberDemographicsSnapshotTest extends GetTests {

    private MemberDataManagerSteps memberDataManagerSteps;
    private PostMemberDemographicsSnapshotSteps postMemberDemographicsSnapshotSteps;
    private GetMemberDemographicsSnapshotSteps memberDemographicsSnapshotSteps;
    private String CLIENT_MEMBER_ID;

    @BeforeClass
    public void init() {
        basePath = BasePathConstants.BASE_PATH_MEMBER_DEMOGRAPHICS_SNAPSHOT_GET;

        pathParamsMap.clear();
        pathParamsMap.put("clientId", CLIENT_ID_186);
        pathParamsMap.put("snapshotId", VALID_SNAPSHOT_ID);
    }

    @BeforeMethod
    public void initMethod() {
        CLIENT_MEMBER_ID = RandomStringUtils.randomNumeric(10) + RandomStringUtils.randomAlphabetic(5).toUpperCase();
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test
    public void whenGetValidMemberIdThenDemographicsSnapshotIsReturned() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        postMemberDemographicsSnapshotSteps = new PostMemberDemographicsSnapshotSteps(platformContextHeader, headers);
        memberDemographicsSnapshotSteps = new GetMemberDemographicsSnapshotSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_186, CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();

        MemberDemographicsSnapshotDTO memberDemographicsSnapshotDTO = postMemberDemographicsSnapshotSteps.createMemberDemographicsSnapshot(CLIENT_ID_186, memberId);
        String snapshotIdFromPost = memberDemographicsSnapshotDTO.getSnapshotId();

        MemberDemographicsSnapshotGetDTO memberDemographicsSnapshotGetDTO = memberDemographicsSnapshotSteps.getMemberDemographicsSnapshot(CLIENT_ID_186, snapshotIdFromPost);
        String snapshotId = memberDemographicsSnapshotGetDTO.getSnapshotId();

        softly.then(snapshotId).isEqualTo(snapshotIdFromPost);
        softly.then(memberDemographicsSnapshotDTO.getMemberDemographics().getClientId()).isEqualTo(CLIENT_ID_186);
        softly.then(memberDemographicsSnapshotDTO.getMemberDemographics().getId()).isEqualTo(memberId);
        softly.assertAll();
    }

    @Test
    public void whenGetValidClientId210ThenDemographicsSnapshotIsReturned() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        postMemberDemographicsSnapshotSteps = new PostMemberDemographicsSnapshotSteps(platformContextHeader, headers);
        memberDemographicsSnapshotSteps = new GetMemberDemographicsSnapshotSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_210, CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();

        MemberDemographicsSnapshotDTO memberDemographicsSnapshotDTO = postMemberDemographicsSnapshotSteps.createMemberDemographicsSnapshot(CLIENT_ID_210, memberId);
        String snapshotIdFromPost = memberDemographicsSnapshotDTO.getSnapshotId();

        MemberDemographicsSnapshotGetDTO memberDemographicsSnapshotGetDTO = memberDemographicsSnapshotSteps.getMemberDemographicsSnapshot(CLIENT_ID_210, snapshotIdFromPost);
        String snapshotId = memberDemographicsSnapshotGetDTO.getSnapshotId();

        softly.then(snapshotId).isEqualTo(snapshotIdFromPost);
        softly.then(memberDemographicsSnapshotDTO.getMemberDemographics().getClientId()).isEqualTo(CLIENT_ID_210);
        softly.then(memberDemographicsSnapshotDTO.getMemberDemographics().getId()).isEqualTo(memberId);
        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-404---------------------------------------------

    @Test
    public void whenSendValidClientIdAndInvalidSnapshotIdSentThenServiceReturnsError() {
        memberDemographicsSnapshotSteps = new GetMemberDemographicsSnapshotSteps(platformContextHeader, headers);

        ErrorDTO error = memberDemographicsSnapshotSteps.getMemberDemographicsSnapshotWithError(CLIENT_ID_85, SNAPSHOT_ID_TEST);

        softly.then(error.getCode()).isEqualTo(SC_NOT_FOUND);
        softly.then(error.getMessage()).contains(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }

    //TODO The test is legal, but due to BUG https://jira.aimspecialtyhealth.com/browse/NCP-20854 it will fail. Uncomment once the bug is fixed.
//    @Test
    public void whenSendInValidClientIdAndValidSnapshotIdSentThenServiceReturnsError() {
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        postMemberDemographicsSnapshotSteps = new PostMemberDemographicsSnapshotSteps(platformContextHeader, headers);
        memberDemographicsSnapshotSteps = new GetMemberDemographicsSnapshotSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_186, CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();

        MemberDemographicsSnapshotDTO memberDemographicsSnapshotDTO = postMemberDemographicsSnapshotSteps.createMemberDemographicsSnapshot(CLIENT_ID_186, memberId);
        String snapshotIdFromPost = memberDemographicsSnapshotDTO.getSnapshotId();

        ErrorDTO error = memberDemographicsSnapshotSteps.getMemberDemographicsSnapshotWithError(CLIENT_ID_TEST, snapshotIdFromPost);

        softly.then(error.getCode()).isEqualTo(SC_NOT_FOUND);
        softly.then(error.getMessage()).contains(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }
}
