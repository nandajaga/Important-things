package com.abc.automation.factories.platformcontext.version2;

import com.abc.servicemodel.domainV2.provider.ServicingProviderV2;

import java.util.ArrayList;

import static com.abc.automation.helpers.constants.PlatformContextConstants.*;

public class ServicingPoviderV2DTOFactory {
    public ServicingProviderV2 createServicingProviderDTO() {
        ArrayList<String> networkCodes = new ArrayList<>();
        networkCodes.add(PC_ENROLLMENT_NETWORK_CODE);
        ArrayList<String> specialtyCodes = new ArrayList<>();
        specialtyCodes.add(PC_SPECIALTY_CODE);

        return createServicingProviderDTO(PC_MEMBER_CLIENT_ID, PC_ENROLLMENT_INSURANCE_STATE_CODE, PC_PLACE_OF_SERVICE_CODE, networkCodes, specialtyCodes);
    }

    public ServicingProviderV2 createServicingProviderDTO(Integer clientId, String stateCode, String placeOfServiceCode, ArrayList<String> networkCodes, ArrayList<String> specialtyCodes) {
        ServicingProviderV2 servicing = new ServicingProviderV2();

        servicing.setClientId(clientId);
        servicing.setStateCode(stateCode);
        servicing.setPlaceOfServiceCode(placeOfServiceCode);
        servicing.setNetworkCodes(networkCodes);
        servicing.setSpecialtyCodes(specialtyCodes);

        return servicing;
    }
}
