package search;

import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.datamanager.MemberResponseDTO;
import dtos.search.EnrollmentsDTO;
import dtos.search.GETMemberSearchDTO;
import dtos.search.MemberSearchDTO;
import helpers.constants.BasePathConstants;
import helpers.dataproviders.DataProviders;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.datamanager.MemberDataManagerSteps;
import steps.rabbitmqsimulator.PublishEventSteps;
import steps.search.MemberSearchSteps;

import java.lang.reflect.Array;
import java.util.ArrayList;

import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_186;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_85;
import static helpers.constants.ErrorMessagesForMemberEndpointsConstants.*;
import static org.apache.http.HttpStatus.SC_BAD_REQUEST;
import static org.apache.http.HttpStatus.SC_UNPROCESSABLE_ENTITY;

/**
 * Created by RKondakova on 6/5/2019.
 */
public class GetMembersSearchTests extends GetTests {

    private static final String ZERO = "0";
    private static final String MINUS_ONE = "-1";
    private static final String INVALID_DOB = "00-00-00";
    private static final String INVALID_DOB_MONTH = "1985-13-25";
    private static final String INVALID_DOB_DATE = "1967-12-32";
    private static final String INVALID_SORT_FIRST_NAME_WITH_DOT = "firstName.";
    private String CLIENT_MEMBER;
    private MemberDataManagerSteps memberDataManagerSteps;

    @BeforeClass
    public void init() {
        basePath = BasePathConstants.BASE_PATH_SEARCH_MEMBERS;
    }

    @BeforeMethod
    public void clientMemberID(){
         CLIENT_MEMBER = RandomStringUtils.randomNumeric(10) + RandomStringUtils.randomAlphabetic(5).toUpperCase();
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test
    public void whenAGetAndValidQueryParametersWithoutClientMemberIdSentThenServiceReturnsSuccessResponseSC200() {

        GETMemberSearchDTO memberSearchDTO = new MemberSearchSteps(platformContextHeader, headers).getMemberSearch(CLIENT_ID_85, null, DOB, FIRST_NAME_STARTS_WITH, LAST_NAME_STARTS_WITH);

        softly.then(memberSearchDTO.getTotalPages()).isGreaterThan(0);
        softly.then(memberSearchDTO.getTotalElements()).isGreaterThan(0);
        softly.then(memberSearchDTO.getMembers()).isNotEmpty();

        ArrayList<MemberSearchDTO> members = memberSearchDTO.getMembers();
        for (MemberSearchDTO member : members) {
            softly.then(member.getClientId()).isEqualTo(CLIENT_ID_85);
            softly.then(member.getFirstName()).containsSequence(FIRST_NAME_STARTS_WITH);
            softly.then(member.getLastName()).containsSequence(LAST_NAME_STARTS_WITH);
        }
        softly.assertAll();
    }

    @Test
    public void whenAGetAndValidQueryParametersWithoutClientMemberIdAndClientIdSentThenServiceReturnsSuccessResponseSC200() {

        GETMemberSearchDTO memberSearchDTO = new MemberSearchSteps(platformContextHeader, headers).getMemberSearch(null, null, DOB, FIRST_NAME_STARTS_WITH, LAST_NAME_STARTS_WITH);

        softly.then(memberSearchDTO.getTotalPages()).isGreaterThan(0);
        softly.then(memberSearchDTO.getTotalElements()).isGreaterThan(0);
        softly.then(memberSearchDTO.getMembers()).isNotEmpty();

        ArrayList<MemberSearchDTO> members = memberSearchDTO.getMembers();
        for (MemberSearchDTO member : members) {
            softly.then(member.getFirstName()).containsSequence(FIRST_NAME_STARTS_WITH);
            softly.then(member.getLastName()).containsSequence(LAST_NAME_STARTS_WITH);
        }
        softly.assertAll();
    }

    @Test
    public void whenAGetAndValidQueryParametersWithoutClientMemberIdAndDateOfBirthSentThenServiceReturnsSuccessResponseSC200() {

        GETMemberSearchDTO memberSearchDTO = new MemberSearchSteps(platformContextHeader, headers).getMemberSearch(CLIENT_ID_85, null, null, FIRST_NAME_STARTS_WITH, LAST_NAME_STARTS_WITH);

        softly.then(memberSearchDTO.getTotalPages()).isGreaterThan(0);
        softly.then(memberSearchDTO.getTotalElements()).isGreaterThan(0);
        softly.then(memberSearchDTO.getMembers()).isNotEmpty();

        ArrayList<MemberSearchDTO> members = memberSearchDTO.getMembers();
        for (MemberSearchDTO member : members) {
            softly.then(member.getClientId()).isEqualTo(CLIENT_ID_85);
            softly.then(member.getFirstName()).containsSequence(FIRST_NAME_STARTS_WITH);
            softly.then(member.getLastName()).containsSequence(LAST_NAME_STARTS_WITH);
        }
        softly.assertAll();
    }

    @Test
    public void whenAGetAndValidClientIdAndClientMemberIdSentThenServiceReturnsSuccessResponseSC200() {

        GETMemberSearchDTO memberSearchDTO = new MemberSearchSteps(platformContextHeader, headers).getMemberSearch(CLIENT_ID_85, CLIENT_MEMBER_ID, null, null, null);

        softly.then(memberSearchDTO.getTotalPages()).isGreaterThan(0);
        softly.then(memberSearchDTO.getTotalElements()).isGreaterThan(0);
        softly.then(memberSearchDTO.getMembers()).isNotEmpty();

        ArrayList<MemberSearchDTO> members = memberSearchDTO.getMembers();
        for (MemberSearchDTO member : members) {
            softly.then(member.getClientId()).isEqualTo(CLIENT_ID_85);
            softly.then(member.getClientMemberId()).isEqualTo(CLIENT_MEMBER_ID);
        }
        softly.assertAll();
    }

    @Test
    public void whenAGetAndClientMemberIdSentThenServiceReturnsSuccessResponseSC200() {

        GETMemberSearchDTO  memberSearchDTO = new MemberSearchSteps(platformContextHeader, headers).getMemberSearch(null, CLIENT_MEMBER_ID, null, null, null);

        softly.then(memberSearchDTO.getTotalPages()).isGreaterThan(0);
        softly.then(memberSearchDTO.getTotalElements()).isGreaterThan(0);
        softly.then(memberSearchDTO.getMembers()).isNotEmpty();

        ArrayList<MemberSearchDTO> members = memberSearchDTO.getMembers();
        for (MemberSearchDTO member : members) {
            softly.then(member.getAdditionalMemberIds().get(0).getValue()).isEqualTo(CLIENT_MEMBER_ID);
        }
        softly.assertAll();
    }

    @Test(dataProvider = "contextModeValue", dataProviderClass = DataProviders.class)
    public void whenGetValidClientIdMemberIdAndSolutionIdSentWithTestContextModeThenServiceReturnsSC200(String contextMode) {
        PlatformContextUtils platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeContextMode(platformContextHeader, contextMode);
        GETMemberSearchDTO memberSearchDTO = new MemberSearchSteps(platformContextHeader, headers).getMemberSearch(CLIENT_ID_85, CLIENT_MEMBER_ID, null, null, null);

        softly.then(memberSearchDTO.getTotalPages()).isGreaterThan(0);
        softly.then(memberSearchDTO.getTotalElements()).isGreaterThan(0);
        softly.then(memberSearchDTO.getMembers()).isNotEmpty();

        ArrayList<MemberSearchDTO> members = memberSearchDTO.getMembers();
        for (MemberSearchDTO member : members) {
            softly.then(member.getClientId()).isEqualTo(CLIENT_ID_85);
            softly.then(member.getClientMemberId()).isEqualTo(CLIENT_MEMBER_ID);
        }
        softly.assertAll();
    }

    @Test(dataProvider = "contextModeInDataBase", dataProviderClass = DataProviders.class)
    public void whenGetValidClientIdMemberIdAndSolutionIdSentWithReversedContextModeThenServiceReturnsEmptyList(String contextMode, String dataBaseMode) {
        PlatformContextUtils platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeContextMode(platformContextHeader, contextMode);

        //Create unique clientMemberId
        String clientMemberId = RandomStringUtils.random(10, true, true);

        //Create a member with specific enrollment and demographics
        MemberDataManagerSteps memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMemberClientMemberId(CLIENT_ID_85, clientMemberId);

        //Get the memberId that is created
        String memberId = memberResponseDTO.getId();
        softly.then(memberId).isNotNull().isNotEmpty().isNotBlank();

        //search for member in different DB
        platformContextHeader = platformContextUtils.changeContextMode(platformContextHeader, dataBaseMode);
        GETMemberSearchDTO memberSearchDTO = new MemberSearchSteps(platformContextHeader, headers).getMemberSearch(CLIENT_ID_85, clientMemberId, null, null, null);

        ArrayList<MemberSearchDTO> members = memberSearchDTO.getMembers();
        for (MemberSearchDTO member : members) {
            softly.then(member).isNull();
        }
        softly.assertAll();
    }

    @Test
    public void whenAGetAndValidQueryParametersWithoutDateOfBirthFirstNameAndLastNameSentThenServiceReturnsSuccessResponseSC200() {
        MemberDataManagerSteps memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberDataManagerSteps.createMember(CLIENT_ID_186, EMPLOYER_GROUP_NUMBER, 1, null, null, CLIENT_MEMBER);
        GETMemberSearchDTO memberSearchDTO = new MemberSearchSteps(platformContextHeader, headers).getMemberSearch(CLIENT_ID_186, CLIENT_MEMBER, null, null, null);
        softly.then(memberSearchDTO.getTotalPages()).isGreaterThan(0);
        softly.then(memberSearchDTO.getTotalElements()).isGreaterThan(0);
        softly.then(memberSearchDTO.getMembers()).isNotEmpty();
        ArrayList<MemberSearchDTO> members = memberSearchDTO.getMembers();
        for (MemberSearchDTO member : members) {
            softly.then(member.getClientId()).isEqualTo(CLIENT_ID_186);
            for (EnrollmentsDTO enrollments : member.getEnrollments()) {
                softly.then(enrollments.getEmployerGroupCode()).isEqualTo(EMPLOYER_GROUP_NUMBER);
                softly.then(enrollments.getFundType()).isEqualTo(FUND_TYPE);
                softly.then(enrollments.getIssuanceState()).isEqualTo(ISSUANCE_STATE_CA);
                softly.then(enrollments.getProductCode()).isEqualTo(PRODUCT_CODE);
                softly.then(enrollments.getLineOfBusiness()).isEqualTo(MEDICARE_CODE);
                softly.then(enrollments.getBaseIdentifier()).isEqualTo("2");
            }
        }
        softly.assertAll();
    }

    @Test
    public void whenAGetAndValidQueryParametersWithoutDateOfBirthFirstNameAndLastNameWithMultipleEnrollmentsThenServiceReturnsSuccessResponseSC200() {
        MemberDataManagerSteps memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        memberDataManagerSteps.createMember(CLIENT_ID_186, EMPLOYER_GROUP_NUMBER, 2, null, null, CLIENT_MEMBER);
        GETMemberSearchDTO memberSearchDTO = new MemberSearchSteps(platformContextHeader, headers).getMemberSearch(CLIENT_ID_186, CLIENT_MEMBER, null, null, null);
        softly.then(memberSearchDTO.getTotalPages()).isGreaterThan(0);
        softly.then(memberSearchDTO.getTotalElements()).isGreaterThan(0);
        softly.then(memberSearchDTO.getMembers()).isNotEmpty();
        ArrayList<MemberSearchDTO> members = memberSearchDTO.getMembers();
        for (MemberSearchDTO member : members) {
            softly.then(member.getClientId()).isEqualTo(CLIENT_ID_186);
            for (EnrollmentsDTO enrollments : member.getEnrollments()) {
                softly.then(enrollments.getEmployerGroupCode()).isEqualTo(EMPLOYER_GROUP_NUMBER);
                softly.then(enrollments.getFundType()).isEqualTo(FUND_TYPE);
                softly.then(enrollments.getIssuanceState()).isEqualTo(ISSUANCE_STATE_CA);
                softly.then(enrollments.getProductCode()).isEqualTo(PRODUCT_CODE);
                softly.then(enrollments.getLineOfBusiness()).isEqualTo(MEDICARE_CODE);
                softly.then(enrollments.getBaseIdentifier()).isEqualTo("2");
            }
        }
        softly.assertAll();
    }



    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-422---------------------------------------------

    @Test(dataProvider = "clientMemberId", dataProviderClass = DataProviders.class)
    public void whenAGetAndInvalidClientMemberIdSentThenServiceReturnsError(String clientMemberId) {
        ErrorDTO error;

        if (clientMemberId == null) {
            error = new MemberSearchSteps(platformContextHeader, headers).getMemberSearchWithInvalidParamsWhitoutCheckForNull(CLIENT_ID_85, clientMemberId, DOB, FIRST_NAME_STARTS_WITH, LAST_NAME_STARTS_WITH, null, null, null);

        } else
            error = new MemberSearchSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(CLIENT_ID_85, clientMemberId, DOB, FIRST_NAME_STARTS_WITH, LAST_NAME_STARTS_WITH, null, null, null);

        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.then(error.getMessage()).contains(ERR_MSG_CLIENT_MEMBER_ID_NOT_LENGTH);
        softly.assertAll();
    }

    @Test(dataProvider = "FirstName", dataProviderClass = DataProviders.class)
    public void whenAGetAndInvalidFirstNameSentThenServiceReturnsError(String firstName) {
        ErrorDTO error;

        if (firstName == null) {
            error = new MemberSearchSteps(platformContextHeader, headers).getMemberSearchWithInvalidParamsWhitoutCheckForNull(CLIENT_ID_85, CLIENT_MEMBER_ID, DOB, firstName, LAST_NAME_STARTS_WITH, null, null, null);

        } else
            error = new MemberSearchSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(CLIENT_ID_85, CLIENT_MEMBER_ID, DOB, firstName, LAST_NAME_STARTS_WITH, null, null, null);

        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.then(error.getMessage()).contains(ERR_MSG_FIRST_LAST_NAME);
        softly.assertAll();
    }

    @Test(dataProvider = "LastName", dataProviderClass = DataProviders.class)
    public void whenAGetAndInvalidLastNameSentThenServiceReturnsError(String lastName) {
        ErrorDTO error;

        if (lastName == null) {
            error = new MemberSearchSteps(platformContextHeader, headers).getMemberSearchWithInvalidParamsWhitoutCheckForNull(CLIENT_ID_85, CLIENT_MEMBER_ID, DOB, FIRST_NAME_STARTS_WITH, lastName, null, null, null);

        } else
            error = new MemberSearchSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(CLIENT_ID_85, CLIENT_MEMBER_ID, DOB, FIRST_NAME_STARTS_WITH, lastName, null, null, null);

        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.then(error.getMessage()).contains(ERR_MSG_FIRST_LAST_NAME);
        softly.assertAll();
    }

    @Test(dataProvider = "clientIdSearch", dataProviderClass = DataProviders.class)
    public void whenAGetAndInvalidClientIdSentThenServiceReturnsError(String clientId) {
        ErrorDTO error;

        if (clientId == null) {
            error = new MemberSearchSteps(platformContextHeader, headers).getMemberSearchWithInvalidParamsWhitoutCheckForNull(clientId, CLIENT_MEMBER_ID, DOB, FIRST_NAME_STARTS_WITH, LAST_NAME_STARTS_WITH, null, null, null);

        } else
            error = new MemberSearchSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(clientId, CLIENT_MEMBER_ID, DOB, FIRST_NAME_STARTS_WITH, LAST_NAME_STARTS_WITH, null, null, null);

        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.then(error.getMessage()).contains(ERR_MSG_CLIENT_ID_LENGTH);
        softly.assertAll();
    }

    @Test(dataProvider = "invalidDate", dataProviderClass = DataProviders.class)
    public void whenAGetAndInvalidDateOfBirthSentThenServiceReturnsError(String dob) {

        ErrorDTO error = new MemberSearchSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(CLIENT_ID_85, CLIENT_MEMBER_ID, dob, FIRST_NAME_STARTS_WITH, LAST_NAME_STARTS_WITH, null, null, null);

        switch (dob) {
            case INVALID_DOB:
                softly.then(error.getMessage()).contains(ERR_MSG_DOB_YEAR_FORMAT);
                softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
                break;
            case INVALID_DOB_MONTH:
                softly.then(error.getMessage()).contains(ERR_MSG_DOB_MONTH_FORMAT);
                softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
                break;
            case INVALID_DOB_DATE:
                softly.then(error.getMessage()).contains(ERR_MSG_DOB_DAY_FORMAT);
                softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
                break;
            case INVALID_DOB_YEAR:
            case DOB_150Plus:
                softly.then(error.getMessage()).contains(ERR_MSG_DOB_VALID_PERIOD);
                softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
                break;
            default:
                softly.then(error.getMessage()).contains(ERR_MSG_DOB_FORMAT);
                softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
                break;
        }

        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-400---------------------------------------------

    @Test
    public void whenAGetAndInvalidSizeSentThenServiceReturnsError() {

        GETMemberSearchDTO memberSearchDTO = new MemberSearchSteps(platformContextHeader, headers).getMemberSearchWithInvalidParamPage(CLIENT_ID_85, CLIENT_MEMBER_ID, DOB, FIRST_NAME_STARTS_WITH, LAST_NAME_STARTS_WITH, ZERO, null, null);

        softly.then(memberSearchDTO.getTotalPages()).isEqualTo(0);
        softly.then(memberSearchDTO.getTotalElements()).isGreaterThanOrEqualTo(0);
        softly.then(memberSearchDTO.getMembers()).isEmpty();
        softly.assertAll();
    }

    @Test
    public void whenAGetAndInvalidPageSentThenServiceReturnsError() {

        ErrorDTO error = new MemberSearchSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(CLIENT_ID_85, CLIENT_MEMBER_ID, DOB, FIRST_NAME_STARTS_WITH, LAST_NAME_STARTS_WITH, null, MINUS_ONE, null);

        softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.then(error.getMessage()).contains(ERR_MSG_INDEX_VALUE);
        softly.assertAll();
    }

    @Test(dataProvider = "sortNegative", dataProviderClass = DataProviders.class)
    public void whenAGetAndInvalidSortSentThenServiceReturnsError(String sort) {

        ErrorDTO error = new MemberSearchSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(CLIENT_ID_85, CLIENT_MEMBER_ID, DOB, FIRST_NAME_STARTS_WITH, LAST_NAME_STARTS_WITH, null, null, sort);

        if (INVALID_SORT_FIRST_NAME_WITH_DOT.equals(sort)) {
            //https://jira.aimspecialtyhealth.com/browse/NCP-17468
            softly.then(error.getMessage()).contains(ERR_MSG_SORT_PROPERTY);
        } else {
            softly.then(error.getMessage()).contains(ERR_MSG_SORT_FORMAT_INCORRECT);

        }
        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.assertAll();
    }

    //-----------------------------------MANUAL-ADD-TESTS---RABBITMQ-CONSUMER---------------------------------------------
    /*
     *Test if manual added member via RabbitMq is distributed to member-search services
     * Manual added member via RabbitMq should be find only once in search result
     */
    @Test
    public void whenSuccessfulAddMemberViaRabbitMqThenMemberIsLoadedInSearch() {
        // create member through Rabbit Mq
        String clientMemberId = RandomStringUtils.random(24, true, true);

        PublishEventSteps publishEventSteps = new PublishEventSteps(platformContextHeader, headers);
        publishEventSteps.publishEventMemberManualAdd(CLIENT_ID_85, clientMemberId);

        //search for member
        GETMemberSearchDTO memberSearchDTO = new MemberSearchSteps(platformContextHeader, headers).getMemberSearch(CLIENT_ID_85, clientMemberId, null, null, null);

        softly.then(memberSearchDTO.getMembers()).isNotEmpty();
        softly.then(memberSearchDTO.getTotalElements()).isEqualTo(1);

        ArrayList<MemberSearchDTO> members = memberSearchDTO.getMembers();
        for (MemberSearchDTO member : members) {
            softly.then(member.getClientMemberId()).isEqualTo(clientMemberId);
        }
        softly.assertAll();
    }


    //@Test
    public void whenAGetAndAllValidQueryParametersSentThenServiceReturnsSuccessResponseSC200() {

        GETMemberSearchDTO memberSearchDTO = new MemberSearchSteps(platformContextHeader, headers).getMemberSearch(CLIENT_ID_85, CLIENT_MEMBER_ID, DOB, FIRST_NAME_STARTS_WITH, LAST_NAME_STARTS_WITH);

        softly.then(memberSearchDTO.getTotalPages()).isGreaterThan(0);
        softly.then(memberSearchDTO.getTotalElements()).isGreaterThan(0);
        softly.then(memberSearchDTO.getMembers()).isNotEmpty();

        ArrayList<MemberSearchDTO> members = memberSearchDTO.getMembers();
        for (MemberSearchDTO member : members) {
            softly.then(member.getClientId()).isEqualTo(CLIENT_ID_85);
            softly.then(member.getClientMemberId()).isEqualTo(CLIENT_MEMBER_ID);
            softly.then(member.getFirstName()).containsSequence(FIRST_NAME_STARTS_WITH);
            softly.then(member.getLastName()).containsSequence(LAST_NAME_STARTS_WITH);
        }
        softly.assertAll();
    }

}