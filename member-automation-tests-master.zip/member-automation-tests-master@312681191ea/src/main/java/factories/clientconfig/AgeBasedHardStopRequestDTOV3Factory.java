package factories.clientconfig;

import dtos.clientconfig.AgeBasedHardStopRequestDTOV3;

public class AgeBasedHardStopRequestDTOV3Factory {

    public AgeBasedHardStopRequestDTOV3 postMemberAgeHardStop(int memberAge){

        AgeBasedHardStopRequestDTOV3 payload = new AgeBasedHardStopRequestDTOV3();
        payload.setMemberAge(memberAge);

        return payload;
    }
}
