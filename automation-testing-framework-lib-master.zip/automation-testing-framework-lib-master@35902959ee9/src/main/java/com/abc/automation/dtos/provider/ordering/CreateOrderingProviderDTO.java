package com.abc.automation.dtos.provider.ordering;

import com.abc.automation.dtos.provider.ProviderAddressDTO;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
public class CreateOrderingProviderDTO {
    private ProviderAddressDTO addressDTO;
    private String caseRequestId;
    private Integer clientId;
    private String clientPhysicianNumber;
    private String email;
    private String fax;
    private String firstName;
    private boolean isManual;
    private String lastName;
    private String npi;
    private String phone;
    private Integer specialtyCode;
    private String tin;


    public ProviderAddressDTO getAddressDTO() {
        return addressDTO;
    }

    public void setAddressDTO(ProviderAddressDTO addressDTO) {
        this.addressDTO = addressDTO;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public Integer getSpecialtyCode() {
        return specialtyCode;
    }

    public void setSpecialtyCode(Integer specialtyCode) {
        this.specialtyCode = specialtyCode;
    }

    public String getNpi() {
        return npi;
    }

    public void setNpi(String npi) {
        this.npi = npi;
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public String getClientPhysicianNumber() {
        return clientPhysicianNumber;
    }

    public void setClientPhysicianNumber(String clientPhysicianNumber) {
        this.clientPhysicianNumber = clientPhysicianNumber;
    }

    public Integer getClientId() {
        return clientId;
    }

    public void setClientId(Integer clientId) {
        this.clientId = clientId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean getIsManual() {
        return isManual;
    }

    public void setIsManual(boolean manual) {
        this.isManual = manual;
    }

    public String getCaseRequestId() {
        return caseRequestId;
    }

    public void setCaseRequestId(String caseRequestId) {
        this.caseRequestId = caseRequestId;
    }
}
