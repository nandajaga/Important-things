package dtos.demographics;

public class ClientSpecificDemographicsDTO {

    private Boolean estimatedDateOfBirthFlag;
    private String langPreferenceCode;
    private String langPreferenceOriginalCode;
    private String restrictedAccessCode;
    private String subClientCode;
    private Boolean updateFlag;

    public Boolean getEstimatedDateOfBirthFlag() {
        return this.estimatedDateOfBirthFlag;
    }

    public void setEstimatedDateOfBirthFlag(Boolean estimatedDateOfBirthFlag) {
        this.estimatedDateOfBirthFlag = estimatedDateOfBirthFlag;
    }

    public String getLangPreferenceCode() {
        return this.langPreferenceCode;
    }

    public void setLangPreferenceCode(String langPreferenceCode) {
        this.langPreferenceCode = langPreferenceCode;
    }

    public String getLangPreferenceOriginalCode() {
        return this.langPreferenceOriginalCode;
    }

    public void setLangPreferenceOriginalCode(String langPreferenceOriginalCode) {
        this.langPreferenceOriginalCode = langPreferenceOriginalCode;
    }

    public String getRestrictedAccessCode() {
        return this.restrictedAccessCode;
    }

    public void setRestrictedAccessCode(String restrictedAccessCode) {
        this.restrictedAccessCode = restrictedAccessCode;
    }

    public Boolean getUpdateFlag() {
        return this.updateFlag;
    }

    public void setUpdateFlag(Boolean updateFlag) {
        this.updateFlag = updateFlag;
    }

    public String getSubClientCode() {
        return this.subClientCode;
    }

    public void setSubClientCode(String subClientCode) {
        this.subClientCode = subClientCode;
    }
}
