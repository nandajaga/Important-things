package com.abc.automation.dtos.provider.servicing;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
public class BenefitExceptionPackageDTO {

    private boolean benefitExceptionFlag;
    private boolean clinicalReviewBenefitOverrideFlag;
    private String defaultBenefitLevel;
    private String packageName;
    private String packageType;
    private boolean referToHealthPlanFlag;

    public boolean getBenefitExceptionFlag() {
        return benefitExceptionFlag;
    }

    public void setBenefitExceptionFlag(boolean benefitExceptionFlag) {
        this.benefitExceptionFlag = benefitExceptionFlag;
    }

    public boolean getClinicalReviewBenefitOverrideFlag() {
        return clinicalReviewBenefitOverrideFlag;
    }

    public void setClinicalReviewBenefitOverrideFlag(boolean clinicalReviewBenefitOverrideFlag) {
        this.clinicalReviewBenefitOverrideFlag = clinicalReviewBenefitOverrideFlag;
    }

    public String getDefaultBenefitLevel() {
        return defaultBenefitLevel;
    }

    public void setDefaultBenefitLevel(String defaultBenefitLevel) {
        this.defaultBenefitLevel = defaultBenefitLevel;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getPackageType() {
        return packageType;
    }

    public void setPackageType(String packageType) {
        this.packageType = packageType;
    }

    public boolean getReferToHealthPlanFlag() {
        return referToHealthPlanFlag;
    }

    public void setReferToHealthPlanFlag(boolean referToHealthPlanFlag) {
        this.referToHealthPlanFlag = referToHealthPlanFlag;
    }
}
