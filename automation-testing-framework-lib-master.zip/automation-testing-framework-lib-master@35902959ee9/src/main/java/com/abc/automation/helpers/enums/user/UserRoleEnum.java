package com.abc.automation.helpers.enums.user;

import com.abc.automation.helpers.constants.Constants;

public enum UserRoleEnum {
    RS("5192496E-BBFF-4F7B-9FDA-1B0823B0DE4C", "RS", "Referral Specialist", "RS (Referral Specialist)", "offshore_AUt0_userid_for_RS_role"),
    MD("7BA48660-CF5E-4504-9C31-7F6937236230", "MD", "MD", "MD", "offshore_AUt0_userid_for_MD_role"),
    MD1("10a2b1cf-d3bb-459d-8926-cdc514523cf8", "MD", "MD", "MD", "offshore_AUt0_userid_for_MD1_role"),
    RN("8A110B47-B2B0-480E-BC4D-632656C07A8F", "RN", "RN", "RN", "offshore_AUt0_userid_for_RN_role"),
    RN1("c27c6341-adc1-45dd-8226-dbff2e14cdc4", "RN", "RN", "RN", "offshore_AUt0_userid_for_RN1_role_Deemed_Approval"),
    RSA("3065096F-EA46-41C8-A4E7-F956DAE05024", "RSA", "RSA", "RSA", "offshore_AUt0_userid_for_RSA_role"),
    MGR("7DFDC4EE-BA5D-46BB-9F55-73F2A2C75951", "MGR", "Manager", "Manager", "offshore_AUt0_userid_for_MGR_role"),
    TRPT("73525A54-C7B3-4B78-ABAF-FF54AAD2EDB1", "TRPT", "Therapist", "Therapist", "offshore_AUt0_userid_for_TRPT_role"),
    PTRPT("21a33a9e-d93a-11e8-9f8b-f2801f1b9fd1", "PTRPT", "Portal Therapist", "Portal Therapist", "offshore_AUt0_userid_for_PTRPT_role"),
    OP("1C53D336-FC2B-43F8-A14F-5ACF295D203B", "OP", "Ordering Provider", "Ordering Provider", "offshore_AUt0_userid_for_OP_role"),
    SP("437873CB-1A06-4BC3-8C2E-688AE5F438FC", "SP", "Servicing Provider", "Servicing Provider", "offshore_AUt0_userid_for_SP_role"),
    Clerk("786D53E0-6271-4AB7-A96A-42B9E571FBB3", "Clerk", "Clerk", "Clerk", "offshore_AUt0_userid_for_Clerk_role"),
    RRS("2B136AD9-748A-4EE3-A1C3-887ACBAE197E", "RestrictedRS", "RestrictedRS", "RestrictedRS", "offshore_AUt0_userid_for_RestrictedRS_role"),
    RSHA("5192496E-BBFF-4F7B-9FDA-1B0823B0DE4C", "RS", "Referral Specialist", "RSHA", Constants.USER_HOUSE_ACCOUNT),
    INVALID("3065096F-EA46-41C8-A4E7-F956DAE05024", "TRPT", "Portal Therapist", "Manager", "offshore_AUt0_userid_for_INVALID_role");

    private String id;
    private String code;
    private String name;
    private String description;
    private String userId;

    UserRoleEnum(String id, String code, String name, String description, String userId) {
        this.id = id;
        this.code = code;
        this.name = name;
        this.description = description;
        this.userId = userId;
    }

    public String getId() {
        return id;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getUserId() {
        return userId;
    }
}
