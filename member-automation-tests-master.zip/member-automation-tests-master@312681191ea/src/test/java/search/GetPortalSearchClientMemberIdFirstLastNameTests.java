package search;

import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.demographics.AdditionalMemberIdDTO;
import dtos.search.GETMemberSearchDTO;
import dtos.search.MemberSearchDTO;
import helpers.dataproviders.DataProviders;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import steps.search.MemberSearchSteps;
import steps.search.SearchClientMemberIdFirstLastNameSteps;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static helpers.constants.BasePathConstants.BASE_PATH_SEARCH_ID_FIRST_LAST_NAME;
import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_85;
import static helpers.constants.ErrorMessagesForMemberEndpointsConstants.*;
import static org.apache.http.HttpStatus.SC_BAD_REQUEST;
import static org.apache.http.HttpStatus.SC_UNPROCESSABLE_ENTITY;

/**
 * Only some of the positive tests are included in the smokesuite.xml
 * All the negative tests and the rest of the positive will be included in the functionalsuite.xml
 */
public class GetPortalSearchClientMemberIdFirstLastNameTests extends GetTests {

    private static final String ZERO = "0";
    private static final String MINUS_ONE = "-1";
    private static final String INVALID_SORT_FIRST_NAME_WITH_DOT = "firstName.";


    @BeforeClass
    public void init() {
        basePath = BASE_PATH_SEARCH_ID_FIRST_LAST_NAME;
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test(dataProvider = "clientMemberIdPositive", dataProviderClass = DataProviders.class)
    public void whenAGetAndValidClientMemberIdAndFLNamesSentThenServiceReturnsSuccessResponseSC200(String clientMemberId) {

        GETMemberSearchDTO memberSearchDTO = new SearchClientMemberIdFirstLastNameSteps(platformContextHeader, headers).getMemberSearch(clientMemberId, FIRST_NAME_STARTS_WITH, LAST_NAME_STARTS_WITH);

        softly.then(memberSearchDTO.getTotalPages()).isGreaterThan(0);
        softly.then(memberSearchDTO.getTotalElements()).isGreaterThan(0);
        softly.then(memberSearchDTO.getMembers()).isNotEmpty();

        ArrayList<MemberSearchDTO> members = memberSearchDTO.getMembers();

        List<AdditionalMemberIdDTO> additionalMembers;
        for (MemberSearchDTO member : members) {
            additionalMembers = member.getAdditionalMemberIds();

            for (AdditionalMemberIdDTO additionalMember : additionalMembers) {
                if (additionalMember.getValue().equals(clientMemberId)) {
                    softly.then(additionalMember.getValue()).isEqualTo(clientMemberId);
                }
            }

            softly.then(member.getFirstName()).containsIgnoringCase(FIRST_NAME_STARTS_WITH);
            softly.then(member.getLastName()).containsIgnoringCase(LAST_NAME_STARTS_WITH);
        }
        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-400---------------------------------------------

    @Test
    public void whenGetAndNotValidParamSize0SentThenServiceReturnsBadRequestSC400() {

        GETMemberSearchDTO memberSearchDTO = new MemberSearchSteps(platformContextHeader, headers).getMemberSearchWithInvalidParamPage(CLIENT_ID_85, CLIENT_MEMBER_ID, DOB, FIRST_NAME_STARTS_WITH, LAST_NAME_STARTS_WITH, ZERO, null, null);

        softly.then(memberSearchDTO.getTotalPages()).isEqualTo(0);
        softly.then(memberSearchDTO.getTotalElements()).isGreaterThanOrEqualTo(0);
        softly.then(memberSearchDTO.getMembers()).isEmpty();
        softly.assertAll();
    }

    @Test
    public void whenGetAndNotValidParamPageMinusValueSentThenServiceReturnsBadRequestSC400() {

        ErrorDTO error = new SearchClientMemberIdFirstLastNameSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(CLIENT_MEMBER_ID, FIRST_NAME_STARTS_WITH, LAST_NAME_STARTS_WITH, null, MINUS_ONE, null);

        softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.then(error.getMessage()).contains(ERR_MSG_INDEX_VALUE);
        softly.assertAll();

    }

    @Test(dataProvider = "sortNegative", dataProviderClass = DataProviders.class)
    public void whenGetAndNotValidParamSortSentThenServiceReturnsBadRequestSC400(String sort) {
        ErrorDTO error = new SearchClientMemberIdFirstLastNameSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(CLIENT_MEMBER_ID, FIRST_NAME_STARTS_WITH, LAST_NAME_STARTS_WITH, null, null, sort);

        if (INVALID_SORT_FIRST_NAME_WITH_DOT.equals(sort)) {
            //https://jira.aimspecialtyhealth.com/browse/NCP-17468
            softly.then(error.getMessage()).contains(ERR_MSG_SORT_PROPERTY);
        } else {
            softly.then(error.getMessage()).contains(ERR_MSG_SORT_FORMAT_INCORRECT);
        }
        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-422---------------------------------------------

    @Test(dataProvider = "clientMemberIdNegative", dataProviderClass = DataProviders.class)
    public void whenGetAndNotValidClientMemberIdWithNullValueSentThenServiceReturnsSC422(String clientMemberId) {
        ErrorDTO error;

        if (clientMemberId == null) {
            error = new SearchClientMemberIdFirstLastNameSteps(platformContextHeader, headers).getMemberSearchWithInvalidParamsWhitoutCheckForNull(clientMemberId, FIRST_NAME_STARTS_WITH, LAST_NAME_STARTS_WITH, null, null, null);

        } else
            error = new SearchClientMemberIdFirstLastNameSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(clientMemberId, FIRST_NAME_STARTS_WITH, LAST_NAME_STARTS_WITH, null, null, null);

        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.then(error.getMessage()).contains(ERR_MSG_CLIENT_MEMBER_ID_NOT_LENGTH);
        softly.assertAll();

    }

    @Test(dataProvider = "FirstName", dataProviderClass = DataProviders.class)
    public void whenGetAndNotValidFirstNameWithNullValueSentThenServiceReturnsSC422(String firstName) throws IOException {
        ErrorDTO error;

        if (firstName == null) {
            error = new SearchClientMemberIdFirstLastNameSteps(platformContextHeader, headers).getMemberSearchWithInvalidParamsWhitoutCheckForNull(CLIENT_MEMBER_ID, firstName, LAST_NAME_STARTS_WITH, null, null, null);

        } else
            error = new SearchClientMemberIdFirstLastNameSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(CLIENT_MEMBER_ID, firstName, LAST_NAME_STARTS_WITH, null, null, null);

        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.then(error.getMessage()).contains(ERR_MSG_FIRST_LAST_NAME);
        softly.assertAll();
    }

    @Test(dataProvider = "LastName", dataProviderClass = DataProviders.class)
    public void whenGetAndNotValidLastNameWithNullValueSentThenServiceReturnsSC422(String lastName) {
        ErrorDTO error;

        if (lastName == null) {
            error = new SearchClientMemberIdFirstLastNameSteps(platformContextHeader, headers).getMemberSearchWithInvalidParamsWhitoutCheckForNull(CLIENT_MEMBER_ID, FIRST_NAME_STARTS_WITH, lastName, null, null, null);

        } else
            error = new SearchClientMemberIdFirstLastNameSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(CLIENT_MEMBER_ID, FIRST_NAME_STARTS_WITH, lastName, null, null, null);

        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.then(error.getMessage()).contains(ERR_MSG_FIRST_LAST_NAME);
        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-400---------------------------------------------

    @Test
    public void whenGetAndParamClientMemberIdNotSentThenServiceReturnsSC400() {
        ErrorDTO error = new SearchClientMemberIdFirstLastNameSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(null, FIRST_NAME_STARTS_WITH, LAST_NAME_STARTS_WITH, null, null, null);

        softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.then(error.getMessage()).contains(ERR_MSG_CLIENT_MEMBER_ID_NOT_PRESENT);
        softly.assertAll();
    }

    @Test
    public void whenGetAndParamFirstNameNotSentThenServiceReturnsSC400() {
        ErrorDTO error = new SearchClientMemberIdFirstLastNameSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(CLIENT_MEMBER_ID, null, LAST_NAME_STARTS_WITH, null, null, null);

        softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.then(error.getMessage()).contains(ERR_MSG_FIRST_NAME_NOT_PRESENT);
        softly.assertAll();
    }

    @Test
    public void whenGetAndParamLastNameNotSentThenServiceReturnsSC400() {
        ErrorDTO error = new SearchClientMemberIdFirstLastNameSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(CLIENT_MEMBER_ID, FIRST_NAME_STARTS_WITH, null, null, null, null);

        softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.then(error.getMessage()).contains(ERR_MSG_CLIENT_LAST_NAME_NOT_PRESENT);
        softly.assertAll();
    }
}