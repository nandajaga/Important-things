package com.abc.automation.helpers.constants;

public class ConditionSearchConstants {
    public static final String TYPE = "ICD10";
    public static final Integer COUNT = 10;
    public static final String SEARCH_STRING = "A1";
}
