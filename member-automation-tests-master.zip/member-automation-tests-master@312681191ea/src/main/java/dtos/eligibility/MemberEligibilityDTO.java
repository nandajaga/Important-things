package dtos.eligibility;

import dtos.enrollments.MemberEnrollmentDTO;

import java.util.List;

/**
 * Created by RKondakova on 5/9/2019.
 */
public class MemberEligibilityDTO {

    private Boolean status;
    private String message;
    private List<MemberEnrollmentDTO> memberEnrollmentList;

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean levelOfCare) {
        this.status = levelOfCare;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String caseRequestId) {
        this.message = caseRequestId;
    }

    public List<MemberEnrollmentDTO> getMemberEnrollmentList() {
        return memberEnrollmentList;
    }

    public void setMemberEnrollmentList(List<MemberEnrollmentDTO> memberEnrollmentList) {
        this.memberEnrollmentList = memberEnrollmentList;
    }
}
