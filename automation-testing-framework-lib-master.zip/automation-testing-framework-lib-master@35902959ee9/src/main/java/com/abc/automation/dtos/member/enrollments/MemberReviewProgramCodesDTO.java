package com.abc.automation.dtos.member.enrollments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MemberReviewProgramCodesDTO {

    public List<ReviewProgramCodesDTO> getReviewProgramCodes() {
        return reviewProgramCodes;
    }

    public void setReviewProgramCodes(List<ReviewProgramCodesDTO> reviewProgramCodes) {
        this.reviewProgramCodes = reviewProgramCodes;
    }

    private List<ReviewProgramCodesDTO> reviewProgramCodes;
}
