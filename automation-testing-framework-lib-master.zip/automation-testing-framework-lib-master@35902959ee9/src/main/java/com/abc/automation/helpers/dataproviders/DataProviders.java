package com.abc.automation.helpers.dataproviders;

import com.abc.automation.helpers.ExcelUtils;
import com.abc.automation.helpers.enums.RequestHeadersEnum;
import org.testng.annotations.DataProvider;

public class DataProviders {

    @DataProvider(name = "Headers")
    public Object[][] headers() {
        return new Object[][]{
                {RequestHeadersEnum.BUS_CORRELATION_ID},
                {RequestHeadersEnum.CORRELATION_ID},
                {RequestHeadersEnum.PLATFORM_CONTEXT},
                {RequestHeadersEnum.REQUEST_ID},
                {RequestHeadersEnum.SERVICE_CONSUMER}};
    }


    @DataProvider(name = "PlatformContextFieldsValidation")
    public Object[][] getPlatformContextFieldsValidation() {
        ExcelUtils excelUtils = new ExcelUtils();

        return excelUtils.readDataFromXL("DataProvider.xlsx", "PlatformContextFieldsValidation");
    }

}
