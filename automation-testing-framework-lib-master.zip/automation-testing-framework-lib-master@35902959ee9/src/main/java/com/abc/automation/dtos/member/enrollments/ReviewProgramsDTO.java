package com.abc.automation.dtos.member.enrollments;

import java.util.List;

public class ReviewProgramsDTO {
    private List<String> reviewProgramCode;

    public List<String> getReviewProgramCode() {
        return reviewProgramCode;
    }

    public void setReviewProgramCode(List<String> reviewProgramCode) {
        this.reviewProgramCode = reviewProgramCode;
    }
}
