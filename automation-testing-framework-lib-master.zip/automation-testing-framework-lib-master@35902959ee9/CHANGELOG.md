# Automation testing framework
#1.0.200
- Updated Justification DTO

#1.0.198
- Added User location.

#1.0.194
- Added User location.

#1.0.190
- Added House account user.

#1.0.187
- Added Change User Primary role Code in Platform Context Utils

#1.0.185
- Added new DTOs for Member Enrollments and Updated MemberEnrollment and Solution DTOs

#1.0.183
- Added Restricted RS User.

#1.0.179
- Added Justification Service Data

#1.0.174
- Added Json property for solution DTO

#1.0.171
- Updated Justification ResponseDTO

#1.0.169
- Added Provider Justification Questions DTO

#1.0.164
- Changed the path  of Extent report, to run the tests in containerization

#1.0.157
- Added ReviewCategoryCodeDefinitionsDTO

#1.0.153
- Added the new method in PlatformContextUtils class to change the AlphaPrefixCode in PlatformContext

#1.0.150
Added Functionality
- Added New Method to get the Erisa Indicator and Funding Type.

#1.0.143
Added Functionality
- Added MemberEnrollmentSnapshotResponseV3
#1.0.129
Added functionality 
- Updated BitBucket URL in Jenkins file.

#1.0.121
Added functionality 
- Added randomUUID generation under PrepareHeadersWithUUID class to generate and Assign Random UUID to the headers and added Additional DTO to OP and SP snapshot DTO.

#1.0.120
Added functionality 
- Added new method to get the grouperName from "Condition/services" endpoint response.

#1.0.119
Added functionality 
- Modified the createCaseRequestWithMultipleServices method for Zerotype case creation.

#1.0.118
Added functionality 
- Added CaseV5DTO.

#1.0.117
Added functionality 
- Added Copy Service Request DTO.

#1.0.116
Added functionality 
- Added new method to change values for treatmentCode and treatmentCodeType in PlatformContext.

#1.0.113
Added functionality 
 - Updated case flow as per new member field ABP.
 
#1.0.112
Added functionality
- Added new fields to member ClientSpecificEnrollmentsDTO for HCSC.
- Added new methods to create member and corresponding steps and factories class which accepts clientId and alternateBenefitPlanCode

#1.0.111
Added functionality 
 - Adding RN User with deemed Approval permission in UserRoleEnum.

#1.0.109
Added functionality 
- Updated methods to create a case with multiple treatment codes.

#1.0.108
Added functionality 
 - Adding methods to create a case with multiple treatment codes.

#1.0.105
Added functionality 
 -Updated build.gradle file.

#1.0.103
Added functionality
 - Added Root level Change DateOfService method in PC Utils.
 
#1.0.102
Added functionality
 - Updated CaseReviewCategoryCode in PC in caseRequestSteps.
 - Added Maximum number of approved custom methods.
 
#1.0.101
Added functionality
 - Added grouper type in service DTO.
 
#1.0.100
Added functionality
 - Added methods in PlatformContextUtils to change the value for parentSolutionCode and organizationId.
 
#1.0.99
Added functionality
 - Added California in UserStateLicenseEnum .

#1.0.98
Added functionality
 - Updated Ordering provider address details.
 
#1.0.97
Added functionality
 - Added Funding type in Platform Utilities.

#1.0.96
Added functionality
 - Added Facility name in Servicing provider DTO.

#1.0.93
Added functionality
 - Added ExtentRepotSetup , ExtentTestReport , ExtentTestListener , ConsoleoutputStream (captures Console output log) to generate Extent report
 
#1.0.92
Added functionality
- added Label Type and Benefit Level Fields in servicing Provider DTO

#1.0.91
Added functionality
- updated the caseRequestTracking number to Random string Value

##1.0.90
Added functionality
 - Updated the service DTO for Single and Multiple Grouper Scenario's
 
##1.0.89
Added functionality
 - Added facility field to ServicingProviderAddressDTO 
 
##1.0.88
Added functionality
 - Removed Urgent Justification fields from Update SolutionDTO and Update SolutionDTOFactory.
 
##1.0.87
Added functionality
 - Updated LineOfBusiness name in Constants.

##1.0.86
Added functionality
 - Added new method in PlatformcontextUtil to change zipcode in platformcontext.
 
##1.0.85
Added functionality
 - Added DeleteTest and DeleteWithPlatformContextTests to covered basic test scenarios for delete endpoint.
 
##1.0.81
Added functionality
 - Added dateOfService as path param in DateOfServiceSteps and removed from body.

##1.0.80
Added functionality
 - Added UrgentDTO and UrgentDTO Factory.
 - Set UrgentDTO request in submitCaseRequestResponse in SubmitCaseRequestSteps.
 - Created MemberEnrollmentSteps and DateOfService Steps.
 - Added MemberEnrollment and DateOfService in CaseRequest flow in CreateCaseSteps for new caseRequest flow as part of dateOfService Changes.

##1.0.77
Added functionality
 - Added dateOfService, memberEnrollment, OverrideEligibility New fields to CasRequestDTO 

##1.0.74
Added functionality
 -Upgraded the shared-tool-chain:service-model-lib:1.2.67 to shared-tool-chain:service-model-lib:1.2.75
 -Service-model-lib change reflects dateOfService (moves to root level),enrollment-(enrollmentGroupCode, issuanceStateCode) as optional instead of mandatory in platformcontext

##1.0.70
Added functionality
 - Adding new method "addMemberToCaseRequest" having membergender parameter

##1.0.69
Added functionality
 - Updated clientId to providerClientId in createServicingProviderSnapshotDTO
 - Updated clientId to providerClientId in createOrderingProviderSnapshotDTO
 - Added New method to fetch the providerClientID in Create OrderingProviderSteps and ServicingProviderSteps

##1.0.67
Added functionality
 - Increase timeout between requests from 2 to 10 seconds for creating ordering and servicing provider snapshot

##1.0.65
Added functionality
 - Decrease timeout between requests from 10 to 2 seconds for creating ordering and servicing provider snapshot

##1.0.64
Added functionality
 - Adding autsimSelected to preclinical
 - Adding methods to create a case with autismSelected

##1.0.63
 Fixes
- Increase the number of retries from 3 to 30 for creating ordering and servicing provider snapshot 
- Increase timeout between requests from 5 to 10 seconds for creating ordering and servicing provider snapshot

##1.0.62
Added functionality
 - Adding additionalClinicalCategories field to NonVisualsDTO
 - Adding clinicalCategory field to FunctionalToolDTO
 - Adding createNonVisualsDTOHavingTwoToolIds method to NonVisualsDTOFactory
 - Changing second tool id value from 2 to 4 in steps for creating Case object with two functional tools.

##1.0.61
Added functionality
- Adding methods to create a case having two Tool Ids.
 
## 1.0.60
Fixes
- Update platform-context in case request creation steps to include the case request id 

## 1.0.59
Added functionality
- Adding option to configure the *contextMode* from property file or suite xml
- Adding method for editing the *contextMode* in `PlatformContextUtils`
- Adding method for editing the *userRoles* in `PlatformContextUtils`
- Adding `alwaysRun` to all before methods from base tests
- Add JsonAlias to `isManual` field in `OrderingProviderDTO`

Fixes
- Fixing the expected message in platform context generic tests

## 1.0.58
Fixes
- Fixing the expected message when member location is wrong in `GenericPlatformContextTests`
- Adding method to initialize `requestSpecification` with all headers
- Adding *restrictions* to `SelectedMemberDTO` and propagated it to the steps of creating a case
- Adding methods for changing of *jurisdictionCode* and *dateOfService* in `PlatformContextUtils` class

## 1.0.56
Fixes
- Adding *changeEmployerGroupCode* method in `PlatformContextUtils` class
- Adding *changeRequestCreatedDate* method in `PlatformContextUtils` class

## 1.0.55
Fixes
- Removing retried tests with passed result from skipped results
- Adding `UserActionServiceEnum` with values to be used for value lever
- Adding *changeCaseId* method in `PlatformContextUtils` class

## 1.0.54
Fixes
- Adding retry for creating of snapshots for ordering and servicing provider

## 1.0.53
Fixes
- Fixing the initialization of *requestSpecification* to be done in `BasePreparationSteps`
- Removing not used methods for initialization of `Headers` in `BasePreparationSteps`
- Updating version of `shared-tool-chain:service-model-lib` to *1.2.67*
- Updating `SubmitCaseRequestRespV2DTO` to include `NextStepsDTO`

## 1.0.52
Fixes
- Adjusting the implementation of *changeSolutionId* in `PlatformContextUtils` to allow setting `null` value
- Fixing the generation of `solutionId` to be `Integer`
- Adding methods for generation of random *int* in `GeneralFunctionality`
- Updating all base tests to set Headers
- Adding method for converting from one dto to another

## 1.0.51
Added functionality
- Adding *readDtoFromFile* method to `ReadContentResourceFiles` class

Fixes
- Making *readContentResourceFile* method in `ReadContentResourceFiles` class non-static
- Moving *isLogEnabled* logic configuration from `RequestOperationHelper` to `BaseTest`
- Changing the type of *dateTimeReceived* to `ZonedDateTime` in `AttachmentDTO`
- Updating the version of `shared-tool-chain:service-model-lib` to include the changes for Platform context v1 extension
- Enhancing the assert for checking the message when post with no body is sent

## 1.0.50
Added functionality
- Adding method for editing the *network code* in `PlatformContextUtils`
- Adding steps to search user by *uid*
- Modifying the steps for creating user to check if user exist before creating it
- Adding fields to `ServicingProviderDTO` `OrderingProviderDTO` `ServicingProviderDTO` `AssociateOrderingProviderDTO`

Removed
- Removing the methods for creating user

## 1.0.48
Fixes
- Marking a test as failure instead of skipped when we have configuration failure
- Updating the factories and the steps to set the *number of approved visits* to 0

Added functionality
- Adding option to create servicing provider with type *Facility* and to add it to case

## 1.0.47
Fixes
- Moving initialization of all objects in constructors in factories, steps and helpers
- Adding new `clinicalDecision` endpoint

Added functionality
- Adding generic platform context tests

## 1.0.46
Fixes
- Fixing getters of boolean fields in dto definitions
- Adding `clientName` and `fundingType` fields to `CaseMemberDTO` class

## 1.0.45
Fixes
- Improving log message on test success
- Moving `RequestOperationHelper` initialization to constructor in each step class
- Adding `reviewType` field to `ClinicalDecisionDTO`
- Adding method to *remove* field from a DTO object
- Adding handling for `null` values for `List` and `Date` objects in all DTOs

## 1.0.44
Fixes
- Adding methods for changing *ProductCode*, *StateCode* and *InteractionId* in `PlatformContextUtils`
- Fixing the reporting of retried tests in `StatusTestListener`

## 1.0.43
Fixes
- Removing `ContentType.JSON` from Post multi-part request
- Adding `caseIdentifier` to `ActionLogDTO`
- Adding name of successfully executed test case

Added functionality
- Adding `GenericTests` class that combines all tests available in `<Method>Tests` 
- Adding `Method endpointHttpMethod` to define the endpoint method
- Adding `List<Method> notAllowedMethodsList` to store the not allowed methods per endpoint

## 1.0.42
Added functionality
- Adding methods that accepts `String` parameter of platform context and modify it

## 1.0.41
Added functionality
- Create user profile uses v2 of the endpoint
- Adding support for multiple case creation
- Adding new methods with parameters for *additional information reason* and *case review category code* to `AddClinicalToCaseRequestSteps` and `CreateCaseSteps` 
- Adding new method in `PlatformContextUtils` for changing the *case review category type* in Platform Context

Fixes
- Moving all base paths to `BasePathConstants`
- Changing the package of `CaseRequestConstants`
- Adding `AdditionalInformationDTO` to `ClinicalDecisionDTO` and `RehabQnADTO`
- Adding `AdditionalInformationDTOFactory` and update `ClinicalDecisionDTOFactory`

## 1.0.40
Fixes
- Adding `clientMemberProductCode` to the `MemberEnrollmentDTO`

## 1.0.39
Fixes
- Adding `mpc` and `mixerCode` to the `ClientSpecificEnrollmentsDTO`

## 1.0.38
Fixes
- Moving the check for success status code to the steps that return DTOs
- Adding message informing what went wrong to the asserts in `<Method>Tests`

## 1.0.37
Fixes
- Removing `DTO` from `PreClinical` and `ByPassClinical` getters and setters
- Fixing dates in `AssociateOrderingProviderDTOFactory` and `WorkItemDTOFactory`
- Adding check for the expected status code in every step

Improvements
- Update versions of case request `ServicingProviders` and `Submissions` endpoints as well as DTOs required
- Removed all previous DTOs and Factories related to `ServicingProviders` and `Submissions` endpoints

## 1.0.36
Fixes
- Fixing assert message for no headers test
- Removing `DTO` from `PreClinical` and `BypassClinical` names
- Adding class `PlatformContextUtils` with utilities for operating with PlatformContext header (PC v1 available)

## 1.0.35
Fixes
- Fixing `ContentType` for the tests where the headers are removed

## 1.0.34
Fixes
- Fixing the asserts in `<Method>Tests`
- Fixing the convert of dates in `stringToDTO`
- Tests for missing headers remove header instead creating all except the missing one
- Added `body` object for `PostTests` and `PutTests`
- Adding option the steps for `cases` to accept `RequestSpecification`

## 1.0.33
Fixes
- Renaming the enums to have `Enum` to the end of the class name
- Updating the `StatusListener` to log the request and response on test fail
- Enhancing the asserts in `<Method>Tests` to check the response message
- Adding value for `employerGroupCode` field in the factory for Platform Context 2
- Removing `INFO` logs from `CustomFilterableRequestSpecification`
- `ErrorSpringDTO` and all related methods are removed. `GenericErrorDTO` is used instead

## 1.0.31
Fixes
- Fixing the convert of dates
- Deprecating `ConvertObjectToString` and `ConvertPlatformContextPOJOToString`
- Fixing the base tests
- Fixing typo in `BasePreparationSteps`

New functionality
- Adding option platform context to be passed as parameter from the suite xml

## 1.0.30
Improvements
- Adding abstraction for using platform context 1 and 2 - `AbstractPlatformContext`
- Fixing issue with parsing the dates in `CaseV2DTOFactory`
- Changing the structure of base tests - `<Method>Tests` and `<Method>WithPlatformContextTests`
- Refactoring the base tests to use `requestSpecification` and `dataProvider`

## 1.0.29
Improvements
- Adding factories for Platform Context 2.0
- Upgrading dependencies for `jackson` and `rest assured`

## 1.0.28
Improvements
- Enhancing the logging on test results
- Adding copy constructor for `CustomFilterableRequestSpecification`
- Changed `convertDateTimeToUTC` to accept date format pattern

## 1.0.27
Fixes
- Adding timeout before creating a snapshot for servicing provider because of a bug
- Adding method for converting date to utc that accepts formatter

## 1.0.26
Fixes
- Adding timeout before creating a snapshot for ordering provider because of a bug
- Adding reason for failed and skipped tests to the log output

## 1.0.25
Fixes
- Adding `externalUserIdNUM` to user profile
- Changing `Instant` with `Date` in DTO classes

## 1.0.24
Fixes
- Fixing the functionality for creating user
- Changed values for User state license

## 1.0.23
Improvements
- Fixed a bug in the `ExcelHelper` while loading the file
- Updating the default `ClabcNumber` length to 13 characters
- Adding multiple options to create a user - `UserRole and UserStateLicense`
- Adding generic converts - `stringToDTO` and `dtoToString`
- Removing `ConvertRequestResponseToDTOObject`
- Adding additional items to `PreclinicalDTO`
- Fixing NPE when getting `ClabcDTO` with `null` date

## 1.0.22
Added functionality
- Function that allows to edit a field in the dto with provided value
- Ignoring unknown properties in provider snapshot response

## 1.0.21
Added functionality
- Adding option to set `ReviewType` when creating case
- Adding option to create case without submitting it
- Adding functionality that removes the query parameters before adding the new map

## 1.0.20
Introduced functionality
- Adding method returning `Response` object to step classes
- Adding option to get the `baseURI` from `config.properties` when the provided value as runtime parameter is empty
- Adding enum with User Roles and option to set specific one
- Adding clabc to conditions/services


## 1.0.19
Fixes
- Changing initialization of headers, request specification and assertions in the @BeforeMethod
- Disabling assertAll invocation
- Changing the access modifier of the objects defined in BaseTest to `protected`

## 1.0.18
Fixes
- Moving header initialization to @BeforeClass method
- Renaming of field in case-request member from gender to sex 

## 1.0.17
Update of functionality
- Adding functionality for reading of data from Excel file
- Adding testNG soft assert `softNG` variable to be used in the tests
- Adding HEAD method to `RequestOperationHelper`
- Adding functionality to get the proxy from the `config.properties` file
- Adding ContentType.JSON to the steps for creation of case
- Adding option to get the `serviceId` while creating case
- Adding option to set `clinicalDecision` to case creation

## 1.0.16
Fixing bugs
- Fixed a NullPointerException when converting date to utc
- Added DTO for the Spring error messages (timestamp included)
- Added logging on successfully executed test cases
- Fixing asserts in the base tests

New functionality
- Adding option to change the baseURI by provided domain name (environment is defined by runtime parameter or config.properties. Example: `"https://member.xformdevpoc.com/"`)
- Adding steps for case creation
- Additional steps added for creation of member, servicing provider, ordering provider, user, case request
- Adding steps for snapshot of member enrollments, member demographics, ordering provider, servicing provider
- Adding steps adding lock, member, conditions and services, ordering provider, servicing provider, clinical decision, preclinical to case request

## 1.0.15
Enhancing the functionality
- Adding option for configuration of the logging and baseURI using config.properties
- Changed method for adding body to request to accept Object as parameter

## 1.0.14 
Initial version of the shared lib for automation tests
- DTO classes for working with action log and error messages
- enum with mandatory headers 
- Factory for platform context header
- Helper classes for conversion of objects, test execution and retrying, reading from file and properties, Rest-assured based requests
- Steps for working with action log and error messages
- Tests for checking the error messages for invalid headers and verbs
- Config file for controlling the logging of the requests and responses

