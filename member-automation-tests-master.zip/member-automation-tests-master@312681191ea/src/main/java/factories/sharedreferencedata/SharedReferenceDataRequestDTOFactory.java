package factories.sharedreferencedata;

import dtos.sharedreferencedata.SharedReferenceDataDTO;

import java.util.HashMap;

/**
 * Created by RKohli on 15/09/2020.
 */
public class SharedReferenceDataRequestDTOFactory {

    public SharedReferenceDataDTO createSharedReferneceDataDTO(HashMap searchCriteria, String effectiveDate) {
        SharedReferenceDataDTO payload = new SharedReferenceDataDTO();
        payload.setSearchCriteria(searchCriteria);
        payload.setEffectiveDate(effectiveDate);
        return payload;
    }


}
