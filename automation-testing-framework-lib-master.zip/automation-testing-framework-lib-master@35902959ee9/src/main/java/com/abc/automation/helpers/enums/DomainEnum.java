package com.abc.automation.helpers.enums;

/**
 * Created by PPetarcheva on 4/18/2019.
 */
public enum DomainEnum {
    MEMBER("member"),
    PROVIDER("provider"),
    CASE("case"),
    CLINICAL("clinical"),
    USER("user"),
    CIT("cit"),
    COMMUNICATIONS("communications");

    private String name;

    DomainEnum(String n) {
        name = n;
    }

    public String getName() {
        return name;
    }
}
