package steps.clientconfig;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.clientconfig.AllowedSubClientCodesResponseDTO;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;

import static helpers.constants.BasePathConstants.BASE_PATH_GET_ALLOWED_SUB_CLIENT_CODES;

/**
 * Created by SDoneva at 9/19/2019
 */

public class GetAllowedSubClientCodesSteps {

    private CustomFilterableRequestSpecification requestSpecification;
    private RequestOperationsHelper requestOperationsHelper;

    public GetAllowedSubClientCodesSteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addBasePath(BASE_PATH_GET_ALLOWED_SUB_CLIENT_CODES);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.addHeaders(headers);
    }

    //for the positive tests
    public AllowedSubClientCodesResponseDTO getAllowedSubClientCodes(String clientId, String issuanceStateCode, String lineOfBusiness) {

        HashMap<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);
        HashMap<String, String> queryParamsMap = new HashMap<>();
        queryParamsMap.put("issuance-state-code", issuanceStateCode);
        queryParamsMap.put("line-of-business-code", lineOfBusiness);
        requestSpecification.addPathParams(pathParamsMap);

        if (issuanceStateCode != null && lineOfBusiness != null) {
            requestSpecification.addQueryParams(queryParamsMap);
        }

        Response response = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());
        response.then().statusCode(HttpStatus.SC_OK);

        return response.as(AllowedSubClientCodesResponseDTO.class);
    }


    public ErrorDTO getAllowedSubClientCodesWithError(String clientId, String issuanceStateCode, String lineOfBusiness) {

        HashMap<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);
        HashMap<String, String> queryParamsMap = new HashMap<>();
        queryParamsMap.put("issuance-state-code", issuanceStateCode);
        queryParamsMap.put("line-of-business-code", lineOfBusiness);
        requestSpecification.addPathParams(pathParamsMap);

        if (issuanceStateCode != null && lineOfBusiness != null) {
            requestSpecification.addQueryParams(queryParamsMap);
        }

        Response response = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return response.as(ErrorDTO.class);
    }

}
