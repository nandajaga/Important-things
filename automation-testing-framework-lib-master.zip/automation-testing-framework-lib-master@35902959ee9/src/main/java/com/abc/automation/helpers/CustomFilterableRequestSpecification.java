package com.abc.automation.helpers;

import com.abc.automation.helpers.enums.RequestHeadersEnum;
import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.specification.FilterableRequestSpecification;

import java.util.Map;
import java.util.Set;

import static io.restassured.RestAssured.given;

public class CustomFilterableRequestSpecification {

    private FilterableRequestSpecification filterableRequestSpecification;

    public CustomFilterableRequestSpecification() {
        filterableRequestSpecification = (FilterableRequestSpecification) given();
    }

    public CustomFilterableRequestSpecification(CustomFilterableRequestSpecification requestSpecification) {
        filterableRequestSpecification = (FilterableRequestSpecification) given();

        FilterableRequestSpecification spec = requestSpecification.getFilterableRequestSpecification();
        addHeaders(spec.getHeaders());
        String type = spec.getContentType();
        setContentType(ContentType.fromContentType(type));
    }

    /**
     * @param headerName  - the name of the header that is to be added
     * @param headerValue - the value of the header that is to be added
     *                    NOTE: removeHeader is used because if a header with that value has been already set, we need to clear it
     *                    otherwise it will just add a second header with the same name, but different value
     */
    public void addCustomHeader(String headerName, String headerValue) {
        removeHeader(headerName);
        filterableRequestSpecification.header(headerName, headerValue);
    }

    /**
     * This method takes each header object form headers
     * and using addCustomHeader() method adds it to the request
     * This way the addition of headers is all done by a single method that checks if the header already exists
     * and overrides it's value to the new one
     *
     * @param headers An object of type Headers containing all the headers that are to be added to the request
     */
    public final void addHeaders(Headers headers) {
        if (headers != null) {
            for (Header header : headers) {
                addCustomHeader(header.getName(), header.getValue());
            }
        }
    }

    /**
     * This method is used to add custom value for platform context header
     * Please note that it uses addCustomHeader() method so if there was another PC added, only the last one will remain
     *
     * @param platformContext - the value of the platfromContext header
     */
    public void addPlatformContextToRequest(String platformContext) {
        addCustomHeader(RequestHeadersEnum.PLATFORM_CONTEXT.getName(), platformContext);
    }

    /**
     * This method is used to set the body that is to be sent with the request
     *
     * @param body - the json body as an object
     */
    public void addBodyToRequest(Object body) {
        filterableRequestSpecification.body(body);
    }

    /**
     * This method is used to set the body that is to be sent with the request
     *
     * @param body - the json body as a string
     */
    public void addBodyToRequest(String body) {
        filterableRequestSpecification.body(body);
    }

    /**
     * This method is used to set values for the path parameters stored in a Map
     * The path parameter's name is equivalent to the key of a Map's entry.
     * The path parameter's value is equivalent to the value of a Map's entry.
     * Note: The first string is the placeholder and the second is the value that is to be put in it's place
     * <p>
     * Example: In /v3/caseRequests/caseRequest/{caseRequestId}/solution/{solutionId}/preclinical
     * {caseRequestId} and {solutionId} are the placeholders that are to be substituted by the value
     * So a valid map would be pathParam.put("caseRequestId","thisIsAValue123")
     *
     * @param pathParamsMap - the map containing the params where the first string is the placeholder and the second string is the value
     */
    public void addPathParams(Map<String, String> pathParamsMap) {
        Set<String> keys = filterableRequestSpecification.getNamedPathParams().keySet();

        Object[] keyArray = keys.toArray();

        for (Object key : keyArray) {
            filterableRequestSpecification.removeNamedPathParam(key.toString());
        }

        filterableRequestSpecification.pathParams(pathParamsMap);
    }

    /**
     * This method is used to set the query parameters
     * Example: Endpoint /v3/caseRequests/trackingNumberQuery accepts query parameters in the form of size - integer
     * So a valid map would be queryParams.put("size","123")
     *
     * @param queryParamsMap
     */
    public void addQueryParams(Map<String, String> queryParamsMap) {
        Set<String> keys = filterableRequestSpecification.getQueryParams().keySet();

        Object[] keyArray = keys.toArray();

        for (Object key : keyArray) {
            filterableRequestSpecification.removeQueryParam(key.toString());
        }

        filterableRequestSpecification.queryParams(queryParamsMap);
    }

    /**
     * This method is used to set the base path to which the request must be sent
     * Note that if the baseURI provided by restAssured is set, the basePath value will be appended to the baseURI
     * <p>
     * basePath = /v3/caseRequests/caseRequest/{caseRequestId}/solution/{solutionId}/preClinical
     *
     * @param basePath
     */
    public void addBasePath(String basePath) {
        filterableRequestSpecification.basePath(basePath);
    }

    /**
     * This method is used to set the base URI to which the request must be sent
     * Note that if the baseURI provided by restAssured is set, the basePath value will be appended to the baseURI
     * <p>
     * Example: baseURL = case.xformdevpoc.com/cases/
     *
     * @param baseURI
     */
    public void addBaseURI(String baseURI) {
        filterableRequestSpecification.baseUri(baseURI);
    }

    /**
     * This method is used to set the content type header of the specification
     *
     * @param contentType - the value itself, e.g. "application/json"
     */
    public final void setContentType(ContentType contentType) {
        filterableRequestSpecification.contentType(contentType);
    }

    /**
     * This method is used to remove a header from the specification
     *
     * @param headerName - the name of the header that is to be removed from the spec (the key from the key/ value pair)
     */
    public void removeHeader(String headerName) {
        filterableRequestSpecification.removeHeader(headerName);
    }

    /**
     * Invoking this method will set the https validation to relaxed, meaning that any incorrect or outdated certificates will not stop the execution
     */
    public void setRelaxedHttpsValidation() {
        filterableRequestSpecification.relaxedHTTPSValidation();
    }

    /**
     * @return the object to which all the specifications were set
     */
    public FilterableRequestSpecification getFilterableRequestSpecification() {
        return filterableRequestSpecification;
    }
}
