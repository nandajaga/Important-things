package dtos.enrollments;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MemberEnrollmentDTO {
    private String baseId;
    private String clientId;
    private String clientPrimaryCarePhysician;
    private ClientSpecificEnrollmentsDTO clientSpecificEnrollments;
    private Boolean covered;
    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = "yyyy-MM-dd"
    )
    private Date effectiveEndDate;
    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = "yyyy-MM-dd"
    )
    private Date effectiveStartDate;
    private String employerGroupNumber;
    private String enrollmentId;
    private String healthPlan;
    private String enrollmentPrefix;
    private String fundType;
    private String issuanceState;
    private String lineOfBusiness;
    private String lineOfBusinessId;
    private Boolean manuallyEntered;
    private Boolean nationalFlag;
    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = "yyyy-MM-dd"
    )
    private Date originalEffectiveEndDate;
    private String practitionerCode;
    private String primaryCarePhysicianNumber;
    private String productCode;
    private String productCodeId;
    private String programCoverageIndicator;
    private String updateDate;
    private String actionCode;
    private ArrayList<SolutionDTO> solutions;
    private String clientMemberProductCode;
    private Integer reviewPackageId;
    private Integer consumerEngagementId;
    private List<ConsumerEngagementPreferencesDTO> consumerEngagementPreferences;


    public String getBaseId() {
        return baseId;
    }

    public void setBaseId(String baseId) {
        this.baseId = baseId;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getEnrollmentId() {
        return enrollmentId;
    }

    public void setEnrollmentId(String enrollmentId) {
        this.enrollmentId = enrollmentId;
    }

    public String getHealthPlan() {
        return healthPlan;
    }

    public void setHealthPlan(String healthPlan) {
        this.healthPlan = healthPlan;
    }

    public String getClientPrimaryCarePhysician() {
        return clientPrimaryCarePhysician;
    }

    public void setClientPrimaryCarePhysician(String clientPrimaryCarePhysician) {
        this.clientPrimaryCarePhysician = clientPrimaryCarePhysician;
    }

    public ClientSpecificEnrollmentsDTO getClientSpecificEnrollments() {
        return clientSpecificEnrollments;
    }

    public void setClientSpecificEnrollments(ClientSpecificEnrollmentsDTO clientSpecificEnrollments) {
        this.clientSpecificEnrollments = clientSpecificEnrollments;
    }

    public Boolean getCovered() {
        return covered;
    }

    public void setCovered(Boolean covered) {
        this.covered = covered;
    }

    public Date getEffectiveEndDate() {
        return effectiveEndDate;
    }

    public void setEffectiveEndDate(Date effectiveEndDate) {
        this.effectiveEndDate = effectiveEndDate;
    }

    public Date getEffectiveStartDate() {
        return effectiveStartDate;
    }

    public void setEffectiveStartDate(Date effectiveStartDate) {
        this.effectiveStartDate = effectiveStartDate;
    }

    public String getEmployerGroupNumber() {
        return employerGroupNumber;
    }

    public void setEmployerGroupNumber(String employerGroupNumber) {
        this.employerGroupNumber = employerGroupNumber;
    }

    public String getEnrollmentPrefix() {
        return enrollmentPrefix;
    }

    public void setEnrollmentPrefix(String enrollmentPrefix) {
        this.enrollmentPrefix = enrollmentPrefix;
    }

    public String getFundType() {
        return fundType;
    }

    public void setFundType(String fundType) {
        this.fundType = fundType;
    }

    public String getIssuanceState() {
        return issuanceState;
    }

    public void setIssuanceState(String issuanceState) {
        this.issuanceState = issuanceState;
    }

    public Boolean getManuallyEntered() {
        return manuallyEntered;
    }

    public void setManuallyEntered(Boolean manuallyEntered) {
        this.manuallyEntered = manuallyEntered;
    }

    public Boolean getNationalFlag() {
        return nationalFlag;
    }

    public void setNationalFlag(Boolean nationalFlag) {
        this.nationalFlag = nationalFlag;
    }

    public Date getOriginalEffectiveEndDate() {
        return originalEffectiveEndDate;
    }

    public void setOriginalEffectiveEndDate(Date originalEffectiveEndDate) {
        this.originalEffectiveEndDate = originalEffectiveEndDate;
    }

    public String getPractitionerCode() {
        return practitionerCode;
    }

    public void setPractitionerCode(String practitionerCode) {
        this.practitionerCode = practitionerCode;
    }

    public String getPrimaryCarePhysicianNumber() {
        return primaryCarePhysicianNumber;
    }

    public void setPrimaryCarePhysicianNumber(String primaryCarePhysicianNumber) {
        this.primaryCarePhysicianNumber = primaryCarePhysicianNumber;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductCodeId() {
        return productCodeId;
    }

    public void setProductCodeId(String productCodeId) {
        this.productCodeId = productCodeId;
    }

    public String getProgramCoverageIndicator() {
        return programCoverageIndicator;
    }

    public void setProgramCoverageIndicator(String programCoverageIndicator) {
        this.programCoverageIndicator = programCoverageIndicator;
    }

    public String getLineOfBusinessId() {
        return lineOfBusinessId;
    }

    public void setLineOfBusinessId(String lineOfBusinessId) {
        this.lineOfBusinessId = lineOfBusinessId;
    }

    public String getLineOfBusiness() {
        return lineOfBusiness;
    }

    public void setLineOfBusiness(String lineOfBusiness) {
        this.lineOfBusiness = lineOfBusiness;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public String getActionCode() {
        return actionCode;
    }

    public void setActionCode(String updateDate) {
        this.actionCode = actionCode;
    }

    public ArrayList<SolutionDTO> getSolutions() {
        if (this.solutions != null) {
            return new ArrayList<>(solutions);
        }
        return null;
    }

    public void setSolutions(ArrayList<SolutionDTO> solutions) {
        if (solutions != null) {
            this.solutions = new ArrayList<>(solutions);
        }
    }

    public String getClientMemberProductCode() {
        return clientMemberProductCode;
    }

    public void setClientMemberProductCode(String clientMemberProductCode) {
        this.clientMemberProductCode = clientMemberProductCode;
    }

    public Integer getReviewPackageId() {
        return reviewPackageId;
    }

    public void setReviewPackageId(Integer reviewPackageId) {
        this.reviewPackageId = reviewPackageId;
    }

    public Integer getConsumerEngagementId() {
        return consumerEngagementId;
    }

    public void setConsumerEngagementId(Integer consumerEngagementId) {
        this.consumerEngagementId = consumerEngagementId;
    }

    public List<ConsumerEngagementPreferencesDTO> getConsumerEngagementPreferences() {
        return consumerEngagementPreferences;
    }

    public void setConsumerEngagementPreferences(List<ConsumerEngagementPreferencesDTO> consumerEngagementPreferences) {
        this.consumerEngagementPreferences = consumerEngagementPreferences;
    }
}

