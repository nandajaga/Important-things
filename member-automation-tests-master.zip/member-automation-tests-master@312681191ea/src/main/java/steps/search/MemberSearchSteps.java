package steps.search;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.search.GETMemberSearchDTO;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

import static helpers.constants.BasePathConstants.BASE_PATH_SEARCH_MEMBERS;
import static helpers.constants.Constants.*;

/**
 * Created by RKondakova on 6/7/2019.
 */
public class MemberSearchSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    //constructor
    public MemberSearchSteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BASE_PATH_SEARCH_MEMBERS);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    //for the positive tests
    public GETMemberSearchDTO getMemberSearch(String clientId, String clientMemberId, String dob, String firstName, String lastName) {

        Map<String, String> queryParamsMap = new HashMap<>();

        if (clientId != null) queryParamsMap.put(CLIENT_IDS, clientId);
        if (clientMemberId != null) queryParamsMap.put(CLIENT_MEMBER_IDS, clientMemberId);
        if (dob != null) queryParamsMap.put(ENROLLMENT_DOB, dob);
        if (firstName != null) queryParamsMap.put(FIRST_NAME, firstName);
        if (lastName != null) queryParamsMap.put(LAST_NAME, lastName);
        requestSpecification.addQueryParams(queryParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_OK);

        return result.as(GETMemberSearchDTO.class);

    }

    public GETMemberSearchDTO getMemberSearchWithInvalidParamPage(String clientId, String clientMemberId, String dob, String firstName, String lastName, String size, String page, String sort) {
        Response result = getResult(clientId, clientMemberId, dob, firstName, lastName, size, page, sort);
        return result.as(GETMemberSearchDTO.class);
    }

    //for negative tests
    public ErrorDTO getMemberSearchWithInvalidParams(String clientId, String clientMemberId, String dob, String firstName, String lastName, String size, String page, String sort) {
        Response result = getResult(clientId, clientMemberId, dob, firstName, lastName, size, page, sort);
        return result.as(ErrorDTO.class);
    }

    public ErrorDTO getMemberSearchWithInvalidParamsWhitoutCheckForNull(String clientId, String clientMemberId, String dob, String firstName, String lastName, String size, String page, String sort) {
        Map<String, String> queryParamsMap = new HashMap<>();

        queryParamsMap.put(CLIENT_IDS, clientId);
        queryParamsMap.put(CLIENT_MEMBER_IDS, clientMemberId);
        queryParamsMap.put(ENROLLMENT_DOB, dob);
        queryParamsMap.put(FIRST_NAME, firstName);
        queryParamsMap.put(LAST_NAME, lastName);
        queryParamsMap.put(SIZE, size);
        queryParamsMap.put(PAGE, page);
        queryParamsMap.put(SORT, sort);
        requestSpecification.addQueryParams(queryParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorDTO.class);

    }

    public Response getResult(String clientId, String clientMemberId, String dob, String firstName, String lastName, String size, String page, String sort) {
        Map<String, String> queryParamsMap = new HashMap<>();

        if (clientId != null) queryParamsMap.put(CLIENT_IDS, clientId);
        if (clientMemberId != null) queryParamsMap.put(CLIENT_MEMBER_IDS, clientMemberId);
        if (dob != null) queryParamsMap.put(ENROLLMENT_DOB, dob);
        if (firstName != null) queryParamsMap.put(FIRST_NAME, firstName);
        if (lastName != null) queryParamsMap.put(LAST_NAME, lastName);
        if (size != null) queryParamsMap.put(SIZE, size);
        if (page != null) queryParamsMap.put(PAGE, page);
        if (sort != null) queryParamsMap.put(SORT, sort);
        requestSpecification.addQueryParams(queryParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());
        return result;
    }

}
