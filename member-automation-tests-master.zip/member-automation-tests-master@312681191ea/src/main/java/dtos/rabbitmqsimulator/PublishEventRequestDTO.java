package dtos.rabbitmqsimulator;

import java.util.Map;

/**
 * Created by VBaliyska on 10/2/2019.
 */
public class PublishEventRequestDTO {

    private Map<String, String> additionalHeaders;
    private Object payload;

    public Map<String, String> getAdditionalHeaders() {
        return additionalHeaders;
    }

    public void setAdditionalHeaders(Map<String, String> additionalHeaders) {
        this.additionalHeaders = additionalHeaders;
    }

    public Object getPayload() {
        return payload;
    }

    public void setPayload(Object payload) {
        this.payload = payload;
    }
}
