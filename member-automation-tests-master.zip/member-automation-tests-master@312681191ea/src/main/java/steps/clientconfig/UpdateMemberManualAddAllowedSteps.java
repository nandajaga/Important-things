package steps.clientconfig;

import com.aim.automation.dtos.ErrorDTO;
import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.clientconfig.UpdateIsManualAddAllowedResponseDTO;
import helpers.constants.BasePathConstants;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

public class UpdateMemberManualAddAllowedSteps {
    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public UpdateMemberManualAddAllowedSteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();
        requestSpecification.addBasePath(BasePathConstants.BASE_PATH_UPDATE_MANUAL_ADD_ALLOWED);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    public UpdateIsManualAddAllowedResponseDTO getIsManualAddAllowed(String clientId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);

        Response response = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        response.then().statusCode(HttpStatus.SC_OK);

        return response.as(UpdateIsManualAddAllowedResponseDTO.class);
    }

    public ErrorDTO getIsManualAddAllowedWithError(String clientId) {

        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);
        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorDTO.class);
    }
}
