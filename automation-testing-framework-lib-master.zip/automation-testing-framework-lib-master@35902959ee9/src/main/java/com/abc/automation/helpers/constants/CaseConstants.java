package com.abc.automation.helpers.constants;

public class CaseConstants {

    // Condition
    public static final String ICD_CODE = "G92";
    public static final String ICD_DESCRIPTION = "Benign neoplasm of lip";
    public static final String ICD_TYPE_CODE = "ICD10";

    // Solution
    public static final String REVIEW_TYPE = "PROSPECTIVE";
    public static final String SOLUTION_DISPLAY_NAME = "Physical Therapy";
    public static final String SOLUTION_DISPLAY_NAME_OT = "Occupational Therapy";
    public static final String SOLUTION_DISPLAY_NAME_ST = "Speech Therapy";
    public static final String SOLUTION_ID = "17";
    public static final String SOLUTION_ID_15 = "15";
    public static final String SOLUTION_ID_16 = "16";
    public static final String SOLUTION_ID_17 = "17";
    public static final String SOLUTION_NAME = "PT";
    public static final String SOLUTION_NAME_OT = "OT";
    public static final String SOLUTION_NAME_ST = "ST";
    public static final String URGENT_CASE_JUSTIFICATION_ANSWER = "YES";
    public static final String URGENT_CASE_JUSTIFICATION_QUESTION_ID = "dc58feed-6c8c-4161-9ee3-4df4b1ce9809";

    // MemberEnrollment
    public static final String FUNDING_TYPE = "String";
    public static final String HEALTH_PLAN_BRAND_NAME = "String";
    public static final String LINE_OF_BUSINESS_NAME = "String";
    public static final String PROGRAM_TYPE = "UM";
    public static final String STATE_OF_ISSUANCE = "NY";

    // Service
    public static final String TREATMENT_CODE = "90901";
    public static final String TREATMENT_CODE_SINGLE_GROUPER = "97012";
    public static final String TREATMENT_CODE_EXCEPTION_TAG_ALONG = "97016";
    public static final String TREATMENT_CODE_MULTI_GROUPER = "97026";
    public static final String TREATMENT_CODE_MAIN = "97018";
    public static final String TREATMENT_CODE_DESCRIPTION = "Injection, leucovorin calcium, per 50 mg";
    public static final String TREATMENT_CODE_DESCRIPTION_97012 = "Mechanical traction therapy";
    public static final String TREATMENT_CODE_DESCRIPTION_97014 = "Electric stimulation therapy";
    public static final String TREATMENT_CODE_DESCRIPTION_97026 = "Infrared therapy";
    public static final String TREATMENT_CODE_DESCRIPTION_90901 = "Physical Therapy Modality- Biofeedback Training";
    public static final String TREATMENT_CODE_DESCRIPTION_97016 = "Physical Therapy Modality- Blood vessel compression";
    public static final String LABEL_TYPE = "Facility";
    public static final String BENEFIT_LEVEL = "low";
    public static final String MAIN_ALGO="MainAlgo";
    public static final String EXCEPTION_TAG_ALONG="Exception-TagAlong";
    public static final String EXCEPTION_SUPPRESSED="Exception-Suppressed";


    public static final String TREATMENT_CODE_ID = "J0640-Identifier";
    public static final String TREATMENT_CODE_TYPE = "HCPCS";
    public static final String TREATMENT_CODE_TYPES = "CPT";
    public static final String SOLUTION_GROUP_DISPLAY_NAME = "Rehabilitation";
    public static final String SOLUTION_GROUP_ID = "14";
    public static final String SOLUTION_GROUP_NAME = "Rehab";

    // Case request
    public static final String CASE_REQUEST_ID = "123456789";
    public static final String NUMBER_OF_APPROVED_VISITS = "0";

}
