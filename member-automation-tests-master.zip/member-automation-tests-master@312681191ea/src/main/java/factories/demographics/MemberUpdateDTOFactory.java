package factories.demographics;

import dtos.demographics.EmailsDTO;
import dtos.demographics.MemberUpdateRequestDTO;
import dtos.demographics.PhonesDTO;

import java.util.ArrayList;

/**
 * Created by PPetarcheva on 3/20/2019.
 */
public class MemberUpdateDTOFactory {

    public MemberUpdateRequestDTO createMemberUpdateDTO(String clientId, String memberId, ArrayList<EmailsDTO> emails, ArrayList<PhonesDTO> phones, boolean isEmailInformationConfirmed, boolean isPhoneInformationConfirmed, boolean noEmailInformationProvided, boolean noPhoneInformationProvided) {
        MemberUpdateRequestDTO memberUpdateRequestDTO = new MemberUpdateRequestDTO();

        memberUpdateRequestDTO.setClientId(clientId);
        memberUpdateRequestDTO.setId(memberId);
        memberUpdateRequestDTO.setNoEmailInformationProvided(noEmailInformationProvided);
        memberUpdateRequestDTO.setNoPhoneInformationProvided(noPhoneInformationProvided);
        memberUpdateRequestDTO.setIsEmailInformationConfirmed(isEmailInformationConfirmed);
        memberUpdateRequestDTO.setIsPhoneInformationConfirmed(isPhoneInformationConfirmed);

        if (phones != null) {
            memberUpdateRequestDTO.setPhones(phones);
        }

        if (emails != null) {
            memberUpdateRequestDTO.setEmails(emails);
        }

        return memberUpdateRequestDTO;
    }
}
