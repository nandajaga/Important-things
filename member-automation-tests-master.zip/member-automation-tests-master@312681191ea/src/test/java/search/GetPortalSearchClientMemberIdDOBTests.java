package search;

import com.aim.automation.helpers.convert.ConvertDateTimeToUTC;
import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.demographics.AdditionalMemberIdDTO;
import dtos.search.GETMemberSearchDTO;
import dtos.search.MemberSearchDTO;
import helpers.dataproviders.DataProviders;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import steps.search.MemberSearchSteps;
import steps.search.SearchClientMemberDOBSteps;

import java.util.ArrayList;
import java.util.List;

import static helpers.constants.BasePathConstants.BASE_PATH_SEARCH_ID_DOB;
import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_85;
import static helpers.constants.ErrorMessagesForMemberEndpointsConstants.*;
import static org.apache.http.HttpStatus.SC_BAD_REQUEST;
import static org.apache.http.HttpStatus.SC_UNPROCESSABLE_ENTITY;

/**
 * Only some of the positive tests are included in the smokesuite.xml
 * All the negative tests and the rest of the positive will be included in the functionalsuite.xml
 */
public class GetPortalSearchClientMemberIdDOBTests extends GetTests {

    private static final String ZERO = "0";
    private static final String MINUS_ONE = "-1";
    private static final String INVALID_DOB = "00-00-00";
    private static final String INVALID_DOB_MONTH = "1985-13-25";
    private static final String INVALID_DOB_DATE = "1967-12-32";
    private static final String INVALID_SORT_FIRST_NAME_WITH_DOT = "firstName.";

    @BeforeClass
    public void init() {
        basePath = BASE_PATH_SEARCH_ID_DOB;
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------
    @Test(dataProvider = "clientMemberIdPositive", dataProviderClass = DataProviders.class)
    public void whenAGetAndValidClientMemberIdAndDOBSentThenServiceReturnsSuccessResponseSC200(String clientMemberId) {
        GETMemberSearchDTO memberSearchDTO = new SearchClientMemberDOBSteps(platformContextHeader, headers).getMemberSearch(clientMemberId, DOB);

        softly.then(memberSearchDTO.getTotalPages()).isGreaterThan(0);
        softly.then(memberSearchDTO.getTotalElements()).isGreaterThan(0);
        softly.then(memberSearchDTO.getMembers()).isNotEmpty();

        ArrayList<MemberSearchDTO> members = memberSearchDTO.getMembers();

        ConvertDateTimeToUTC convertDateTimeToUTC = new ConvertDateTimeToUTC();
        String pattern = "yyyy-MM-dd";

        List<AdditionalMemberIdDTO> additionalMembers;
        for (MemberSearchDTO member : members) {
            additionalMembers = member.getAdditionalMemberIds();

            for (AdditionalMemberIdDTO additionalMember : additionalMembers) {
                if (additionalMember.getValue().equals(clientMemberId)) {
                    softly.then(additionalMember.getValue()).isEqualTo(clientMemberId);
                }
            }

            softly.then(convertDateTimeToUTC.convertDateTimeToUTC(member.getDateOfBirth(), pattern)).isEqualTo(DOB);
        }
        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODES-400-404-422------------------------------------

    @Test(dataProvider = "clientMemberId", dataProviderClass = DataProviders.class)
    public void whenGetAndNotValidClientMemberIdWithNullValueSentThenServiceReturnsSC422(String clientMemberId) {
        ErrorDTO error;

        if (clientMemberId == null) {
            error = new SearchClientMemberDOBSteps(platformContextHeader, headers).getMemberSearchWithInvalidParamsWhitoutCheckForNull(clientMemberId, DOB, null, null, null);

        } else
            error = new SearchClientMemberDOBSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(clientMemberId, DOB, null, null, null);

        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.then(error.getMessage()).contains(ERR_MSG_CLIENT_MEMBER_ID_NOT_LENGTH);
        softly.assertAll();
    }

    @Test
    public void whenGetAndNotValidParamSize0SentThenServiceReturnsBadRequestSC400() {

        GETMemberSearchDTO memberSearchDTO = new MemberSearchSteps(platformContextHeader, headers).getMemberSearchWithInvalidParamPage(CLIENT_ID_85, CLIENT_MEMBER_ID, DOB, FIRST_NAME_STARTS_WITH, LAST_NAME_STARTS_WITH, ZERO, null, null);

        softly.then(memberSearchDTO.getTotalPages()).isEqualTo(0);
        softly.then(memberSearchDTO.getTotalElements()).isGreaterThanOrEqualTo(0);
        softly.then(memberSearchDTO.getMembers()).isEmpty();
        softly.assertAll();

    }

    @Test(dataProvider = "invalidDate", dataProviderClass = DataProviders.class)
    public void whenGetAndNotValidDOBWithNullValueSentThenServiceReturnsSC400(String dob) {

        ErrorDTO error = new SearchClientMemberDOBSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(CLIENT_MEMBER_ID, dob, null, null, null);

        switch (dob) {
            case INVALID_DOB:
                softly.then(error.getMessage()).contains(ERR_MSG_DOB_YEAR_FORMAT);
                softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
                break;
            case INVALID_DOB_MONTH:
                softly.then(error.getMessage()).contains(ERR_MSG_DOB_MONTH_FORMAT);
                softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
                break;
            case INVALID_DOB_DATE:
                softly.then(error.getMessage()).contains(ERR_MSG_DOB_DAY_FORMAT);
                softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
                break;
            case INVALID_DOB_YEAR:
            case DOB_150Plus:
                softly.then(error.getMessage()).contains(ERR_MSG_DOB_VALID_PERIOD);
                softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
                break;
            default:
                softly.then(error.getMessage()).contains(ERR_MSG_DOB_FORMAT);
                softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
                break;
        }

        softly.assertAll();
    }

    @Test
    public void whenGetAndNotValidParamPageMinusValueSentThenServiceReturnsBadRequestSC400() {

        ErrorDTO error = new SearchClientMemberDOBSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(CLIENT_MEMBER_ID, DOB, null, MINUS_ONE, null);

        softly.then(error.getCode()).isEqualTo(SC_BAD_REQUEST);
        softly.then(error.getMessage()).contains(ERR_MSG_INDEX_VALUE);
        softly.assertAll();
    }

    @Test(dataProvider = "sortNegative", dataProviderClass = DataProviders.class)
    public void whenGetAndNotValidParamSortPropertyWithValueZeroSentThenServiceReturnsBadRequestSC400(String sort) {

        ErrorDTO error = new SearchClientMemberDOBSteps(platformContextHeader, headers).getMemberSearchWithInvalidParams(CLIENT_MEMBER_ID, DOB, null, null, sort);

        if (INVALID_SORT_FIRST_NAME_WITH_DOT.equals(sort)) {
            //https://jira.aimspecialtyhealth.com/browse/NCP-17468
            softly.then(error.getMessage()).contains(ERR_MSG_SORT_PROPERTY);
        } else {
            softly.then(error.getMessage()).contains(ERR_MSG_SORT_FORMAT_INCORRECT);
        }
        softly.then(error.getCode()).isEqualTo(SC_UNPROCESSABLE_ENTITY);
        softly.assertAll();
    }
}
