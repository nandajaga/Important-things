package com.abc.automation.steps.provider.ordering;

import com.abc.automation.factories.provider.ordering.CreateOrderingProviderDTOFactory;
import com.abc.automation.helpers.CustomFilterableRequestSpecification;
import com.abc.automation.helpers.EnvironmentHelper;
import com.abc.automation.helpers.RequestOperationsHelper;
import com.abc.automation.helpers.constants.BasePathConstants;
import com.abc.automation.helpers.constants.PrepareHeadersWithUUID;
import com.abc.automation.helpers.enums.DomainEnum;
import com.abc.automation.dtos.provider.ProviderResponseDTO;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
public class CreateOrderingProviderSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public CreateOrderingProviderSteps(String platformContext, Headers headers) {
        headers = new PrepareHeadersWithUUID().prepareHeaderWithUUID();
        requestSpecification = new CustomFilterableRequestSpecification();
        requestOperationsHelper = new RequestOperationsHelper();
        EnvironmentHelper environmentHelper = new EnvironmentHelper();

        requestSpecification.addBasePath(BasePathConstants.PROVIDER_CREATE_ORDERING_BASE_PATH);
        requestSpecification.addPlatformContextToRequest(platformContext);

        requestSpecification.addBaseURI(environmentHelper.constructBaseURIForDomain(DomainEnum.PROVIDER));
        requestSpecification.addHeaders(headers);
        requestSpecification.setContentType(ContentType.JSON);

    }

    public CreateOrderingProviderSteps(CustomFilterableRequestSpecification requestSpecification) {
        Headers headers = new PrepareHeadersWithUUID().prepareHeaderWithUUID();

        this.requestSpecification = new CustomFilterableRequestSpecification();
        requestOperationsHelper = new RequestOperationsHelper();
        EnvironmentHelper environmentHelper = new EnvironmentHelper();

        this.requestSpecification.addHeaders(headers);
        this.requestSpecification.setContentType(ContentType.JSON);
        this.requestSpecification.addBasePath(BasePathConstants.PROVIDER_CREATE_ORDERING_BASE_PATH);
        this.requestSpecification.addBaseURI(environmentHelper.constructBaseURIForDomain(DomainEnum.PROVIDER));
    }

    public Response createOrderingProviderResponse(int clientId) {
        CreateOrderingProviderDTOFactory createOrderingProviderDTOFactory = new CreateOrderingProviderDTOFactory();

        Object body = createOrderingProviderDTOFactory.createOrderingProviderDTO(clientId);
        requestSpecification.addBodyToRequest(body);

        requestSpecification.addPathParams(new HashMap<>());

        return requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());
    }

    public ProviderResponseDTO createOrderingProvider(int clientId) {
        Response result = createOrderingProviderResponse(clientId);

        result.then().statusCode(HttpStatus.SC_CREATED);

        return result.getBody().as(ProviderResponseDTO.class);
    }

    public String createOrderingProviderAndGetNgProviderId(int clientId) {
        return createOrderingProvider(clientId).getNgProviderId();
    }

    public Integer createOrderingProviderAndGetProviderClientId(int clientId) {
        return createOrderingProvider(clientId).getProviderClientId();
    }

}
