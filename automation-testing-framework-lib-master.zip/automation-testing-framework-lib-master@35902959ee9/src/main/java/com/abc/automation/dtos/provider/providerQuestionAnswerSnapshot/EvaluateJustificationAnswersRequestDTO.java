package com.abc.automation.dtos.provider.providerQuestionAnswerSnapshot;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EvaluateJustificationAnswersRequestDTO {

    private String justificationAnswerSnapshotId;


    public String getJustificationAnswerSnapshotId() {
        return justificationAnswerSnapshotId;
    }

    public void setJustificationAnswerSnapshotId(String justificationAnswerSnapshotId) {
        this.justificationAnswerSnapshotId = justificationAnswerSnapshotId;
    }

}
