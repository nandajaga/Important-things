package dtos.demographics;

import java.util.List;

/**
 * Created by PPetarcheva on 3/18/2019.
 */
public class MemberUpdateRequestDTO {

    private String clientId;
    private List<EmailsDTO> emails;
    private String id;
    private boolean noEmailInformationProvided;
    private boolean noPhoneInformationProvided;
    private boolean isPhoneInformationConfirmed;
    private boolean isEmailInformationConfirmed;
    private List<PhonesDTO> phones;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public boolean getNoEmailInformationProvided() {
        return noEmailInformationProvided;
    }

    public void setNoEmailInformationProvided(boolean noEmailInformationProvided) {
        this.noEmailInformationProvided = noEmailInformationProvided;
    }

    public boolean getNoPhoneInformationProvided() {
        return noPhoneInformationProvided;
    }

    public void setNoPhoneInformationProvided(boolean noPhoneInformationProvided) {
        this.noPhoneInformationProvided = noPhoneInformationProvided;
    }

    public boolean getIsPhoneInformationConfirmed() {
        return isPhoneInformationConfirmed;
    }

    public void setIsPhoneInformationConfirmed(boolean phoneInformationConfirmed) {
        isPhoneInformationConfirmed = phoneInformationConfirmed;
    }

    public boolean getIsEmailInformationConfirmed() {
        return isEmailInformationConfirmed;
    }

    public void setIsEmailInformationConfirmed(boolean emailInformationConfirmed) {
        isEmailInformationConfirmed = emailInformationConfirmed;
    }

    public List<EmailsDTO> getEmails() {
        return emails;
    }

    public void setEmails(List<EmailsDTO> emails) {
        this.emails = emails;
    }

    public List<PhonesDTO> getPhones() {
        return phones;
    }

    public void setPhones(List<PhonesDTO> phones) {
        this.phones = phones;
    }
}
