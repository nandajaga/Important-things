package com.abc.automation.helpers.enums;

/**
 * Created by PPetarcheva on 3/19/2019.
 */
public enum RequestHeadersEnum {
    BUS_CORRELATION_ID("bus-correlation-id"),
    CORRELATION_ID("correlation-id"),
    REQUEST_ID("request-id"),
    SERVICE_CONSUMER("service-consumer"),
    PLATFORM_CONTEXT("platform-context");

    private String name;

    RequestHeadersEnum(String n) {
        name = n;
    }

    public String getName() {
        return name;
    }
}
