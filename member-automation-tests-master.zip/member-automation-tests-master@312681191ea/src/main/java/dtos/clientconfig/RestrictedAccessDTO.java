package dtos.clientconfig;

public class RestrictedAccessDTO {
    private String memberId;
    private String dependentRelationCode;
    private String restrictionType;
    private String clientId;
    private String employerGroupNumber;

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getDependentRelationCode() {
        return dependentRelationCode;
    }

    public void setDependentRelationCode(String dependentRelationCode) {
        this.dependentRelationCode = dependentRelationCode;
    }

    public String getRestrictionType() {
        return restrictionType;
    }

    public void setRestrictionType(String restrictionType) {
        this.restrictionType = restrictionType;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getEmployerGroupNumber() {
        return employerGroupNumber;
    }

    public void setEmployerGroupNumber(String employerGroupNumber) {
        this.employerGroupNumber = employerGroupNumber;
    }
}
