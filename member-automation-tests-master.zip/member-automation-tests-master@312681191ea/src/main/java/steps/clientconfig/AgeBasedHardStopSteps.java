package steps.clientconfig;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.clientconfig.AgeBasedHardStopRequestDTOV3;
import dtos.clientconfig.AgeBasedHardStopResponseDTOV3;
import factories.clientconfig.AgeBasedHardStopRequestDTOV3Factory;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import static helpers.constants.BasePathConstants.BASE_PATH_AGE_HARD_STOP;

public class AgeBasedHardStopSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public AgeBasedHardStopSteps(String platformContext, Headers headers) {

        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BASE_PATH_AGE_HARD_STOP);
        requestSpecification.addHeaders(headers);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);

    }

    public AgeBasedHardStopResponseDTOV3 postMemberAgeHardStop(int memberAge) {

        AgeBasedHardStopRequestDTOV3 ageBasedHardStopRequestDTOV3 = new AgeBasedHardStopRequestDTOV3Factory().postMemberAgeHardStop(memberAge);

        requestSpecification.addBodyToRequest(ageBasedHardStopRequestDTOV3);

        Response response = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        response.then().statusCode(HttpStatus.SC_OK);

        return response.as(AgeBasedHardStopResponseDTOV3.class);
    }

    public ErrorDTO postMmberAgeHardStopWithError(int memberAge){

        AgeBasedHardStopRequestDTOV3 ageBasedHardStopRequestDTOV3 = new AgeBasedHardStopRequestDTOV3Factory().postMemberAgeHardStop(memberAge);

        requestSpecification.addBodyToRequest(ageBasedHardStopRequestDTOV3);

        Response response = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        return  response.as(ErrorDTO.class);
    }
}
