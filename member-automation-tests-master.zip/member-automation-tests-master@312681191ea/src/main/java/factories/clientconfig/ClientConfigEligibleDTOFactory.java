package factories.clientconfig;

import dtos.clientconfig.ClientEligibilityRequestDTOV2;

/**
 * Created by RKondakova on 7/10/2019.
 */
public class ClientConfigEligibleDTOFactory {

    public ClientEligibilityRequestDTOV2 setClientEligibility(String dateOfService, String memberId, String solutionId, String subClientCode) {
        ClientEligibilityRequestDTOV2 clientEligibilityRequestDTOV2 = new ClientEligibilityRequestDTOV2();
        clientEligibilityRequestDTOV2.setDateOfService(dateOfService);
        clientEligibilityRequestDTOV2.setMemberId(memberId);
        clientEligibilityRequestDTOV2.setSolutionId(solutionId);
        clientEligibilityRequestDTOV2.setSubClientCode(subClientCode);
        return clientEligibilityRequestDTOV2;
    }
}
