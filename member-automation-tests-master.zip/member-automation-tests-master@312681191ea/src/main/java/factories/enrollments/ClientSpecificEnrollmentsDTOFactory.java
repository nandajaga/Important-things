package factories.enrollments;


import dtos.enrollments.ClientSpecificEnrollmentsDTO;

import static helpers.constants.Constants.*;

public class ClientSpecificEnrollmentsDTOFactory {

    public ClientSpecificEnrollmentsDTO createClientSpecificEnrollDTO(String sourceSystem) {
        return createClientSpecificEnrollmentDTOWithMixerCode(sourceSystem, MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAGHMO);
    }

    public ClientSpecificEnrollmentsDTO createClientSpecificEnrollmentDTOWithMixerCode(String sourceSystem, String mixerCode) {

        ClientSpecificEnrollmentsDTO clientSpecificEnrollmentsDTO = new ClientSpecificEnrollmentsDTO();

        clientSpecificEnrollmentsDTO.setSourceSystem(sourceSystem);
        clientSpecificEnrollmentsDTO.setMixerCode(mixerCode);

        return clientSpecificEnrollmentsDTO;
    }

    public ClientSpecificEnrollmentsDTO createClientSpecificEnrollmentDTOWithAdditionalFields(String subGroupCode, String clientAccountNumber, String clientLineOfBusinessCode,String businessMarketSegmentName, String alternateBenefitPlanCode, Boolean preAcaHonorContractFlag, String clientAccountName, String clientFundingTypeCode) {

        ClientSpecificEnrollmentsDTO clientSpecificEnrollmentsDTO = new ClientSpecificEnrollmentsDTO();

        clientSpecificEnrollmentsDTO.setSubGroupCode(subGroupCode);
        clientSpecificEnrollmentsDTO.setClientAccountNumber(clientAccountNumber);
        clientSpecificEnrollmentsDTO.setClientLineOfBusinessCode(clientLineOfBusinessCode);
        clientSpecificEnrollmentsDTO.setBusinessMarketSegmentName(businessMarketSegmentName);
        clientSpecificEnrollmentsDTO.setAlternateBenefitPlanCode(alternateBenefitPlanCode);
        clientSpecificEnrollmentsDTO.setPreAcaHonorContractFlag(preAcaHonorContractFlag);
        clientSpecificEnrollmentsDTO.setClientAccountName(clientAccountName);
        clientSpecificEnrollmentsDTO.setClientFundingTypeCode(clientFundingTypeCode);


        return clientSpecificEnrollmentsDTO;
    }
}
//AREA 51

