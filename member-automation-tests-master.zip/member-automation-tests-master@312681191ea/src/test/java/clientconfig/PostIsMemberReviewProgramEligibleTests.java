package clientconfig;

import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.tests.base.PostTests;
import dtos.clientconfig.MemberReviewProgramEligibilityResponseDTO;
import helpers.constants.BasePathConstants;
import helpers.dataproviders.DataProviders;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import steps.clientconfig.MemberReviewProgramEligibleSteps;

import static helpers.constants.ClientConfigConstants.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_300;

public class PostIsMemberReviewProgramEligibleTests extends PostTests {

    @BeforeClass
    public void init() {
        basePath = BasePathConstants.BASE_PATH_IS_MEMBER_REVIEW_PROGRAM_ELIGIBLE;
        body = "";
    }


    @Test(dataProvider = "IsClientSOCEligible", dataProviderClass = DataProviders.class)
    public void whenValidClientIdWithReviewProgramsSOCThenServiceReturnsMemberReviewProgramEligibility(String clientId, String issuanceStateCode, String lob) {
        PlatformContextUtils platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));
        platformContextHeader = platformContextUtils.changeIssuanceStateCode(platformContextHeader, issuanceStateCode);
        platformContextHeader = platformContextUtils.changeLineOfBusinessCode(platformContextHeader, lob);

        MemberReviewProgramEligibilityResponseDTO[] memberReviewProgramEligibilityResponseDTO = new MemberReviewProgramEligibleSteps(platformContextHeader, headers).searchReviewProgramsWithRequestBody(REVIEW_PROGRAMS_SOC);

        switch (clientId) {
            case CLIENT_ID_85:
            case CLIENT_ID_183:
            case CLIENT_ID_184:
            case CLIENT_ID_185:
            case CLIENT_ID_187:
            case CLIENT_ID_188:
                softly.then(memberReviewProgramEligibilityResponseDTO[0].getIsEligible()).isEqualTo(IS_ELIGIBLE);
                break;
            case CLIENT_ID_186:
            case CLIENT_ID_189:
            case CLIENT_ID_210:
            case CLIENT_ID_220:
            case CLIENT_ID_300:
                softly.then(memberReviewProgramEligibilityResponseDTO[0].getIsEligible()).isEqualTo(IS_ELIGIBLE_FALSE);
                break;

        }
        softly.then(memberReviewProgramEligibilityResponseDTO[0].getReviewProgramCode()).isEqualTo(REVIEW_PROGRAM_CODE);
        softly.assertAll();
    }

    @Test(dataProvider = "IsClientSOCEligible", dataProviderClass = DataProviders.class)
    public void whenValidClientIdWithDifferentReviewProgramsThenServiceReturnsMemberReviewProgramEligibility(String clientId, String issuanceStateCode, String lob) {
        PlatformContextUtils platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));
        platformContextHeader = platformContextUtils.changeIssuanceStateCode(platformContextHeader, issuanceStateCode);
        platformContextHeader = platformContextUtils.changeLineOfBusinessCode(platformContextHeader, lob);

        MemberReviewProgramEligibilityResponseDTO[] memberReviewProgramEligibilityResponseDTO = new MemberReviewProgramEligibleSteps(platformContextHeader, headers).searchReviewProgramsWithRequestBody(MULTIPLE_REVIEW_PROGRAMS);

        switch (clientId) {
            case CLIENT_ID_85:
            case CLIENT_ID_183:
            case CLIENT_ID_184:
            case CLIENT_ID_185:
            case CLIENT_ID_187:
            case CLIENT_ID_188:
                softly.then(memberReviewProgramEligibilityResponseDTO[0].getIsEligible()).isEqualTo(IS_ELIGIBLE);
                break;
            case CLIENT_ID_186:
            case CLIENT_ID_189:
            case CLIENT_ID_210:
            case CLIENT_ID_220:
            case CLIENT_ID_300:
                softly.then(memberReviewProgramEligibilityResponseDTO[0].getIsEligible()).isEqualTo(IS_ELIGIBLE_FALSE);
                break;
        }
        softly.then(memberReviewProgramEligibilityResponseDTO[0].getReviewProgramCode()).isEqualTo(REVIEW_PROGRAM_CODE);
        softly.then(memberReviewProgramEligibilityResponseDTO[1].getReviewProgramCode()).isEqualTo(REVIEW_PROGRAM_CODE_LOC);
        softly.then(memberReviewProgramEligibilityResponseDTO[1].getIsEligible()).isEqualTo(IS_ELIGIBLE_FALSE);
        softly.assertAll();
    }

    @Test(dataProvider = "IsClientSOCEligible", dataProviderClass = DataProviders.class)
    public void whenValidClientIdWithReviewProgramsAsNullThenServiceReturnsEmptyResponse(String clientId, String issuanceStateCode, String lob) {
        PlatformContextUtils platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));
        platformContextHeader = platformContextUtils.changeIssuanceStateCode(platformContextHeader, issuanceStateCode);
        platformContextHeader = platformContextUtils.changeLineOfBusinessCode(platformContextHeader, lob);

        MemberReviewProgramEligibilityResponseDTO[] memberReviewProgramEligibilityResponseDTO = new MemberReviewProgramEligibleSteps(platformContextHeader, headers).searchReviewProgramsWithRequestBody(null);

        switch (clientId) {
            case CLIENT_ID_85:
            case CLIENT_ID_183:
            case CLIENT_ID_184:
            case CLIENT_ID_185:
            case CLIENT_ID_186:
            case CLIENT_ID_187:
            case CLIENT_ID_188:
            case CLIENT_ID_189:
            case CLIENT_ID_210:
            case CLIENT_ID_220:
            case CLIENT_ID_300:
                softly.then(memberReviewProgramEligibilityResponseDTO).isEmpty();
                break;

        }
        softly.assertAll();
    }

    @Test(dataProvider = "IsClientSOCEligible", dataProviderClass = DataProviders.class)
    public void whenValidClientIdWithoutRequestBodyThenServiceReturnsEmptyResponse(String clientId, String issuanceStateCode, String lob) {
        PlatformContextUtils platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));
        platformContextHeader = platformContextUtils.changeIssuanceStateCode(platformContextHeader, issuanceStateCode);
        platformContextHeader = platformContextUtils.changeLineOfBusinessCode(platformContextHeader, lob);

        MemberReviewProgramEligibilityResponseDTO[] memberReviewProgramEligibilityResponseDTO = new MemberReviewProgramEligibleSteps(platformContextHeader, headers).searchReviewProgramsWithoutRequestBody();

        switch (clientId) {
            case CLIENT_ID_85:
            case CLIENT_ID_183:
            case CLIENT_ID_184:
            case CLIENT_ID_185:
            case CLIENT_ID_186:
            case CLIENT_ID_187:
            case CLIENT_ID_188:
            case CLIENT_ID_189:
            case CLIENT_ID_210:
            case CLIENT_ID_220:
            case CLIENT_ID_300:
                softly.then(memberReviewProgramEligibilityResponseDTO).isEmpty();
                break;

        }
        softly.assertAll();
    }

    public void whenPostWithNoBodyThenServiceReturnsBadRequest() {
    }
}



