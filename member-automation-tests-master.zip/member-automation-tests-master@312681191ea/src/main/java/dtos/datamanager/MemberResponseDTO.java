package dtos.datamanager;

/**
 * Created by PPetarcheva on 3/18/2019.
 */
public class MemberResponseDTO {

    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
