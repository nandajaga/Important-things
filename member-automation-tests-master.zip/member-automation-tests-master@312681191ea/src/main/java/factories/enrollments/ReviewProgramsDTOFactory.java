package factories.enrollments;

import dtos.enrollments.ReviewProgramsDTO;

import java.util.ArrayList;

import static helpers.constants.Constants.REVIEW_PROGRAM_CODE_LOC;
import static helpers.constants.Constants.REVIEW_PROGRAM_CODE_SOC;

public class ReviewProgramsDTOFactory {
    public ArrayList<ReviewProgramsDTO> reviewProgramCodes() {
        ArrayList<ReviewProgramsDTO> listOfReviewProgram = new ArrayList<>();

        ReviewProgramsDTO codes = new ReviewProgramsDTO();
        codes.setReviewProgramCode(REVIEW_PROGRAM_CODE_SOC);
        listOfReviewProgram.add(codes);

        ReviewProgramsDTO codes1 = new ReviewProgramsDTO();
        codes1.setReviewProgramCode(REVIEW_PROGRAM_CODE_LOC);
        listOfReviewProgram.add(codes1);

        return listOfReviewProgram;
    }
}
