package helpers.constants;

public final class Constants {

    //Platform-Context fields values
    public static final String PC_CHANNEL_CODE_CC = "CC";
    public static final String PC_CHANNEL_CODE_P = "P";
    public static final Integer PC_SOLUTION_ID = 15;
    public static final String PC_ENROLLMENT_EMPLOYER_GROUP_CODE = "100";
    public static final String PC_ENROLLMENT_LINE_OF_BUSINESS_CODE = "MEDICAID";

    //Sample Date Format
    public static final String SAMPLE_TIMESTAMP = "2018-08-08";

    //===========================---MEMBER---GET-REFERENCE-DATA---TESTS---============================================
    public static final String ERROR_BAD_REQUEST = "Bad Request";
    public static final String ERROR_ENTITY_NOT_FOUND = "Entity not found!";
    public static final String ERROR_MESSAGE_SC400 = "Required List parameter 'fields' is not present";

    //Reference Type collections in MongoDB
    public static final String REFERENCE_TYPE_GENDER = "gender";

    //Data Manager | MemberDTOFactory
    public static final String CASE_REQUEST_ID = "12345678901";
    public static final boolean LEVEL_OF_CARE = true;
    public static final String DOB = "2001-06-02";
    public static final String DOB_1 = "2001-06-01";
    public static final String DOB_150Plus = "1869-01-30";

    public static final String FIRST_NAME_STARTS_WITH = "Auto-";
    public static final String LAST_NAME_STARTS_WITH = "Test-";
    public static final String CLIENT_DEPENDENT_RELATION_CODE = "S";

    public static final String CLIENT_MEMBER_ID = "9931231423ABC";
    public static final String DEPENDENT_CODE = "CV";
    public static final String GENDER = "M";
    public static final String LEGACY_MEMBER_ID = "12345678";
    public static final boolean MANUALLY_CREATED = true;
    public static final boolean MANUALLY_UPDATED = true;
    public static final String MEMBER_PREFIX = "ABC";
    public static final int NUMBER_OF_ENROLLMENTS_ONE = 1;

    //AdditionalMemberIdsMediaCareIdDTOFactory part of MemberDemographicsDTOFactory
    public static final String MEDICARE_ID_NAME = "medicareId";
    public static final String MEDICARE_ID_VALUE = "9931231423ABC";
    public static final String MEDICAID_ID_NAME = "medicaidId";
    public static final String MEDICAID_ID_VALUE = "999987978978";
    public static final String PREFIX_CLIENT_MEMBER_ID = "ABC9931231423ABC";
    public static final String PREFIX_CLIENT_MEMBER_ID_DEPENDENT_CODE = "ABC9931231423ABCCV";
    public static final String CLIENT_MEMBER_ID_DEPENDENT_CODE = "9931231423ABCCV";

    //Ensureworkflow PC Changes
    public static final String CASE_ID = "d4f7ebce-b749-44a8-980b-3d3bd55d42e6";
    public static final String USER_ID = "offshore_AUt0_userid_for_RS_role";

    //AddressesDTOFactory part of MemberDemographicsDTOFactory
    public static final String ADDRESS_1 = "8600 W Bryn Mawr Ave";
    public static final String CITY_NAME = "Chicago";
    public static final String STATE_CODE = "IL";
    public static final String ZIP_CODE = "60631";
    public static final String ZIP_EXTENSION = "060";

    //ClientSpecificDemographicsDTOFactory part of MemberDemographicsDTOFactory
    public static final boolean ESTIMATED_DOB_FLAG = true;
    public static final String LANG_PREFERENCE_CODE = "AB";
    public static final String LANG_PREFERENCE_ORIGINAL_CODE = "ABC";
    public static final String RESTRICTED_ACCESS_CODE = "ADS";
    public static final String SUB_CLIENT_CODE = "123C";
    public static final boolean UPDATE_FLAG = true;
    public static final String RESTRICTED_TYPE_EXPANDED_ACCESS = "EXPANDED_RESTRICT_ACCESS";
    public static final String RESTRICTED_TYPE_EXPANDED_ACCESS_NONE = "None";
    public static final String WRONG_CLIENTID_RESTRICTED_TYPE_MESSAGE = "Requested clientId: 184 does NOT matches the retrieved clientId: 183";

    //EmailsDTOFactory part of MemberDemographicsDTOFactory
    public static final boolean EMAIL_CLIENT_SOURCE = false;
    public static final String EMAIL_TYPE = "Personal";
    public static final String EMAIL_VALUE = "automation@aimspecialtyhealth.com";

    //PhonesDTOFactory part of MemberDemographicsDTOFactory
    public static final boolean PHONE_CLIENT_SOURCE = false;
    public static final String PHONE_TYPE = "Home";
    public static final String PHONE_VALUE = "7234567890";

    //MemberEnrollmentDTOFactory part of MemberDTOFactory
    public static final boolean COVERED = true;
    public static final String EFFECTIVE_END_DATE = "2018-05-29";
    public static final String EFFECTIVE_START_DATE = "1999-07-20";
    public static final String EMPLOYER_GROUP_NUMBER = "00218643";
    public static final String ENROLLMENT_PREFIX = "TYH";
    public static final String FUND_TYPE = "QY";
    public static final String ISSUANCE_STATE = "CA";
    public static final String LINE_OF_BUSINESS = "MEDICARE";
    public static final String LINE_OF_BUSINESS_ID = "1234";
    public static final boolean MANUALLY_ENTERED = true;
    public static final boolean NATIONAL_FLAG = true;
    public static final String ORIGINAL_EFFECTIVE_END_DATE = "2007-02-05";
    public static final String PRACTITIONER_CODE = "S";
    public static final String PRIMARY_CARE_PHYSICIAN_NUMBER = "312";
    public static final String PRODUCT_CODE = "Z";
    public static final String PRODUCT_CODE_ID = "1234";
    public static final String PROGRAM_COVERAGE_INDICATOR = "12";
    public static final String HEALTHPLAN_AUTHEM_CR = "Anthem CR";
    public static final String HEALTHPLAN_AUTHEM_BC = "Anthem BC";
    public static final String HEALTHPLAN_ANTHEM_BCBS_WI = "Anthem BCBS WI";
    public static final String HEALTHPLAN_AMERIGROUP_FL = "Amerigroup - Florida";
    public static final String MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAGHMO = "HYFMMED0000";
    public static final String MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAFHMO = "HXJRMED0000";
    public static final String MIXER_CODE_CLIENTID_185_PRODUCTCODE_PIHMO = "HXKAMED0000";
    public static final String MIXER_CODE_CLIENTID_185_PRODUCTCODE_PIXHMO = "HYFNMED0000";
    public static final String MIXER_CODE_SPACE_ON_4TH_POSITION = "HYF MMED000";
    public static final String PRODUCT_CODE_VAGHMO = "VAGHMO";
    public static final String PRODUCT_CODE_VAFHMO = "VAFHMO";
    public static final String PRODUCT_CODE_PIHMO = "PIHMO";
    public static final String PRODUCT_CODE_PIXHMO = "PIXHMO";
    public static final String CLIENT_MEMBER_PRODUCT_CODE = "ABCD";

    //SolutionDTOFactory part of MemberEnrollmentDTOFactory
    public static final String SOLUTION_PROGRAM_TYPE = "UM";
    public static final String SOLUTION_PROGRAM_TYPE_QI = "QI";
    public static final String SOLUTION_PAYLOAD = "15";

    //GET /v2/clients/{clientId}/members/{memberId}/enrollments
    public static final String ISSUANCE_STATE_CA = "CA";
    public static final String ISSUANCE_STATE_FL = "FL";
    public static final String ISSUANCE_STATE_WI = "WI";
    public static final String ISSUANCE_STATE_CO = "CO";
    public static final String CLIENT_IDS = "client-id";
    public static final String CLIENT_MEMBER_IDS = "client-member-id";
    public static final String ENROLLMENT_DOB = "date-of-birth";
    public static final String FIRST_NAME = "first-name";
    public static final String LAST_NAME = "last-name";
    public static final String SIZE = "size";
    public static final String PAGE = "page";
    public static final String SORT = "sort";
    public static final String USER_LOC_CODE = "user-location-code";
    public static final String USER_LOC_CODE_RESTRICTED = "RRS";
    public static final String WRONG_USER_LOC_CODE_RESTRICTED = "ABC";
    public static final String DEPENDENT_CD = "dependent-code";

    public static final String DEPENDENT_CD_RESTRICTED = "CV";

    //ClientSpecificEnrollmentsDTOFactory part of MemberEnrollmentDTOFactory
    //SS=SOURCE_SYSTEM
    public static final String SS_WGS = "WGS";     //ID=186/CA  | MMS=WMDS  | BASE_ID=1
    public static final String SS_ISG = "ISG";     //ID=186/CA  | MMS=WMDS  | BASE_ID=2
    public static final String SS_NASCO = "NASCO"; //ID=186/CA  | MMS=WMDS  | BASE_ID=3
    public static final String SS_NULL = null;     //ID=210/Any | MMS=FACET | BASE_ID=1
    //MMS=MEDICAL_MANAGEMENT_SYSTEM
    public static final String MMS_WMDS = "WMDS";
    public static final String MMS_FACET = "FACET";
    //Testing dummy data
    public static final String MEMBER_ID_TEST = "Testing";
    public static final String CLIENT_ID_TEST = "Automation";
    public static final String DEFAULT_CLIENT_ID = "Default";

    public static final String ENROLLMENT_ID_TEST = "Test Enrollment";
    public static final String SNAPSHOT_ID_TEST = "1234567890";
    public static final String COMPARE_DATE = "2018-05-20";
    public static final String COMPARE_DATE_TEST = "1568-12-31";
    public static final String COMPARE_DATE_INVALID = "1234-13-100";
    public static final String COMPARE_YEAR = "1234";
    public static final String COMPARE_YEAR_TEST = "0.1234656789";

    //Real member with enrollments for Client 85
    public static final String ENROLLMENT_ID_REAL = "8d8d15fa-17c7-4a46-9257-4e9b164dbde4";
    public static final String MEMBER_ID_REAL = "4ff68fa0-ef6e-4ca6-a47f-35335ec83e9a";
    public static final String VALID_SNAPSHOT_ID = "5cdeb8be08b3910001f823ca";
    public static final String REVIEW_TYPE_PCCA = "C";
    public static final String REVIEW_TYPE_PROSPECTIVE = "P";
    public static final String REVIEW_TYPE_RETROSPECTIVE = "R";
    public static final String COMPARE_DATE_2019 = "2019-04-16";
    public static final String COMPARE_YEAR_3 = "3";

    //positive sort parameters for /v2/members/unique
    public static final String SORT_VALID_CLIENT_MEMBER_ID = "clientMemberId";
    public static final String SORT_VALID_MEMBER_PREFIX = "memberPrefix";
    public static final String SORT_VALID_CLIENT_MEMBER_IDENTIFIER = "clientMemberIdentifier";
    public static final String SORT_VALID_DEPENDENT_CODE = "dependentCode";
    public static final String SORT_VALID_FIRST_NAME = "firstName";
    public static final String SORT_VALID_HEALTH_PLAN = "healthPlan";
    public static final String SORT_VALID_LAST_NAME = "lastName";
    public static final String SORT_VALID_GENDER = "gender";
    public static final String SORT_VALID_STATE = "state";

    public static final String CLIENT_ID_85 = "85";
    public static final String DOLLAR_SIGN = "$";
    public static final String SINGLE_CHAR = "A";
    public static final String ZERO_CHAR = "0";
    public static final String INVALID_DOB = "00-00-00";
    public static final String INVALID_DOB_MONTH = "1985-13-25";
    public static final String INVALID_DOB_DATE = "1967-12-32";
    public static final String INVALID_DOB_YEAR = "2025-01-01";
    public static final String INVALID_SORT_FIRST_NAME_WITH_DOT = "firstName.";
    public static final String INVALID_CLIENT_ID_100 = "100";
    public static final String INVALID_PRODUCT_CODE = "DHDDJJ@#";

    //member/client-config/v2/isClientEligible
    public static final String MESSAGE_SOLUTION_ID_2 = "SRX";
    public static final String MESSAGE_SOLUTION_ID_12 = "MSK";
    public static final String MESSAGE_SOLUTION_ID_15 = "ST";
    public static final String MESSAGE_SOLUTION_ID_16 = "OT";
    public static final String MESSAGE_SOLUTION_ID_17 = "PT";

    public static final String SCRIPT_HEALTH_PLAN_DOES_NOT_PARTICIPATE_FIRST_PART = "The health plan is no longer participating in the ";
    public static final String SCRIPT_HEALTH_PLAN_DOES_NOT_PARTICIPATE_SECOND_PART = " program. Please contact the member's health plan using the number on the back of the member's ID card.";
    public static final String MESSAGE_CASE_CANNOT_BE_CREATED = "A case cannot be created before the program start date.";
    public static final String SCRIPT_PROGRAM_HAS_NOT_STARTED = " has not started yet. If you wish to request services, please contact the member's health plan using the number on the back of the member's ID card.";
    public static final String MESSAGE_DOS_CANNOT_BE_BEFORE_CLIENT_EFFECTIVE_DATE = "The selected date of service cannot be before the clients program effective date.";
    public static final String SCRIPT_CLIENT_ELIGIBILITY_FIRST_PART = "The ";
    public static final String SCRIPT_CLIENT_ELIGIBILITY_SECOND_PART = " program for ";
    public static final String SCRIPT_CLIENT_ELIGIBILITY_CODE_003_THIRD_PART = " has not started. If you wish to request services, please contact the member's health plan using the number on the back of the member's ID card.";
    public static final String MESSAGE_HEALTH_PLAN_TERMINATED = "The health plan has been terminated for this program.";
    public static final String SCRIPT_HEALTH_PLAN_TERMINATED_CODE_004_FIRST_PART = "The health plan will no longer participate in the ";
    public static final String SCRIPT_HEALTH_PLAN_TERMINATED_CODE_004_SECOND_PART = " program. For any request for services please contact the number on the back of the member's ID card.";
    public static final String MESSAGE_CLIENT_IS_ELIGIBLE = "This client is eligible.";
    public static final String CASE_CANNOT_BE_CREATED_MESSAGE_15 = "The ST program for Anthem CR has not started yet. If you wish to request services, please contact the member's health plan using the number on the back of the member's ID card.";
    public static final String CASE_CANNOT_BE_CREATED_MESSAGE_16 = "The OT program for Anthem CR has not started yet. If you wish to request services, please contact the member's health plan using the number on the back of the member's ID card.";
    public static final String CASE_CANNOT_BE_CREATED_MESSAGE_17 = "The PT program for Anthem CR has not started yet. If you wish to request services, please contact the member's health plan using the number on the back of the member's ID card.";
    public static final String CASE_CANNOT_BE_CREATED_MESSAGE_003_15 = "The ST program for Anthem CR has not started. If you wish to request services, please contact the member's health plan using the number on the back of the member's ID card.";
    public static final String CASE_CANNOT_BE_CREATED_MESSAGE_003_16 = "The OT program for Anthem CR has not started. If you wish to request services, please contact the member's health plan using the number on the back of the member's ID card.";
    public static final String CASE_CANNOT_BE_CREATED_MESSAGE_003_17 = "The PT program for Anthem CR has not started. If you wish to request services, please contact the member's health plan using the number on the back of the member's ID card.";

    public static final String COMMON_MESSAGE_P = " does not participate with any AIM program. If you have any questions, please contact the member's health plan using the number on the back of the member's ID card.";
    public static final String COMMON_MESSAGE_CC = " does not participate with any AIM program";
    public static final String CLIENT_186_NAME = "Anthem BC";
    public static final String CLIENT_210_NAME = "Amerigroup";
    public static final String CLIENT_212_NAME = "Anthem Medicare Advantage";
    public static final String CLIENT_185_NAME = "Anthem BCBSNV";

    public static final String SOLUTION_ID_1 = "1";
    public static final String SOLUTION_ID_2 = "2";
    public static final String SOLUTION_ID_11 = "11";
    public static final String SOLUTION_ID_12 = "12";
    public static final String SOLUTION_ID_15 = "15";
    public static final String SOLUTION_ID_16 = "16";
    public static final String SOLUTION_ID_17 = "17";
    public static final String SOLUTION_ID_3 = "3";
    public static final String SOLUTION_ID_6 = "6";
    public static final String SOLUTION_ID_7 = "7";
    public static final String SOLUTION_ID_8 = "8";
    public static final String SOLUTION_ID_9 = "9";
    public static final String SOLUTION_ID_ONE = "1";
    public static final String SOLUTION_ID_TWO = "2";


    public static final String DATE_OF_SERVICE = "2019-10-02";
    public static final String CASE_CREATION_DATE_BEFORE_START_DATE = "01-01-2200"; //can be validated using isClientEligible csv
    public static final String DOS_BEFORE_EFFECTIVE_DATE = "01-01-2010";
    public static final String DOS_AFTER_TERMINATION_DATE = "10000-10-02";
    public static final String CASE_CREATION_DATE_AFTER_TERMINATION_DATE = "16-08-10000";
    public static final String CASE_CREATION_TEST_DATE = "2019-03-17";

    public static final String CLIENT_CASE_CREATION_DATE_BEFORE_START_DATE_ERROR_CODE = "002";
    public static final String CLIENT_DOS_BEFORE_EFFECTIVE_DATE_ERROR_CODE = "003";
    public static final String CLIENT_DOS_AFTER_TERMINATION_DATE_ERROR_CODE = "004";
    public static final String CLIENT_CASE_CREATION_DATE_AFTER_TERMINATION_DATE_ERROR_CODE = "005";
    public static final String CLIENT_ELIGIBLE_RESPONSE_CODE_006 = "006";
    public static final String CLIENT_ELIGIBLE_RESPONSE_CODE_001 = "001";
    public static final String CLIENT_ELIGIBLE_EMPTY_RESPONSE = "";

    public static final String SUBCLIENT_CODE = "WN";

    public static final String DISPLAY_PARAMETER_MANUAL_ADD = "manualadd";
    public static final String DISPLAY_PARAMETER_ENROLLMENTS = "enrollments";
    public static final String DISPLAY_PARAMETER_DEMOGRAPHICS = "demographics";
    public static final String LABEL_SUB_CLIENT_CODE = "Sub Client Code";

    public static final String DISPLAY_PARAMETER_NEGATIVE = "manualadd@123";

    public static final String ALLOWS_ELIGIBILITY_OVERRIDE = "allowsEligibilityOverride";
    public static final String ALLOWS_CONTACT_EDIT = "allowsContactEdit";
    public static final String CONFIRM_CONTACT_INFORMATION_PROMPT = "confirmContactInformationPrompt";
    public static final String PROVIDE_PHONE_INFORMATION_PROMPT = "providePhoneInformationPrompt";
    public static final String PROVIDE_EMAIL_INFORMATION_PROMPT = "provideEmailInformationPrompt";

    //positive clientV3fields
    public static final String DISPLAY_PCP_INFORMATION = "displayPCPInformation";

    //client member productCode and mixerCode
    public static final String VALIDATION_MIXER_CODE_ALPHANUMRIC = "Mixer Code must be consisting of digits and letters with length of 11. Only fourth position allows space.";
    public static final String VALIDATION_CLIENT_MEMBER_PRODUCT_CODE_ALPHANUMRIC = "Client Member Product Code must be consisting of digits and letters with length of 4.";

    //clientConfig for productCodes in clientConfig service
    public static final String PRODUCT_CODE_189401_210_MEDICARE = "189401";
    public static final String PRODUCT_CODE_IACHP1_210_MEDICAID = "IACHP1";
    public static final String PRODUCT_CODE_ECLPR0_212_MEDICARE = "ECLPR0";
    public static final String PRODUCT_CODE_HIAC_85 = "HIAC";
    public static final String PRODUCT_CODE_IND_183 = "IND";
    public static final String PRODUCT_CODE_VAGHMO_184 = "VAGHMO";
    public static final String PRODUCT_CODE_HMO_185 = "HMO";
    public static final String PRODUCT_CODE_MEDADV_186 = "MEDADV";
    public static final String PRODUCT_CODE_HMO_187 = "HMO";
    public static final String PRODUCT_CODE_4703_188 = "4703";
    public static final String PRODUCT_CODE_PPO_189 = "PPO";
    public static final String PRODUCT_CODE_SHO_199 = "SHO";
    public static final String ERROR_MSG_404 = "Not found";
    public static final String PRODUCT_CODE_CANNOT_BE_NULL_ERROR__MSG = "PlatformContext Enrollment productCode cannot be null or empty";
    public static final String INVALID_PLATFORMCONTEXT_ERROR_MSG = "Invalid platform-context header";
    public static final String INVALID_PLATFORMCONTEXT = "{\"applicationId\":100,\"case\":{\"caseId\":\"d4f7ebce-b749-44a8-980b-3d3bd55d42e6\",\"caseRequestId\":\"94d10a63-1f59-4481-8dfd-f3b741231988\",\"caseReviewCategoryCode\":\"PROSPECTIVE\",\"creationDate\":\"2019-06-13 00:00:00\",\"requestCreatedDate\":\"2019-06-13T00:00:00.000Z\"},\"channelCode\":\"CC\",\"contextMode\":\"TEST\",\"interactionId\":\"systeminteraction-0001\",\"interactionType\":\"Outgoing Email\",\"member\":{\"alphaPrefixCode\":\"WMW\",\"clientId\":186,\"enrollment\":{\"employerGroupCode\":\"ABC\",\"fundingTypeCode\":\"FLF\",\"issuanceStateCode\":\"FL\",\"jurisdictionCode\":\"LA\",\"lineOfBusinessCode\":\"MEDICAID\",\"networkCode\":\"PPO\",\"productCode\":,\"programCode\":\"UM\"},\"location\":{\"regionCode\":\"10\",\"stateCode\":\"CA\",\"zipCode\":\"60061\"}},\"organizationId\":1111,\"provider\":{\"ordering\":{\"clientId\":185,\"networkCodes\":[\"PPO\"],\"placeOfServiceCode\":\"OP\",\"specialtyCodes\":[\"1\"],\"stateCode\":\"CA\"},\"servicing\":{\"clientId\":185,\"networkCodes\":[\"PPO\"],\"placeOfServiceCode\":\"OP\",\"specialtyCodes\":[\"1\"],\"stateCode\":\"CA\"}},\"services\":[{\"treatmentCode\":\"J9324\",\"treatmentCodeType\":\"HCSPC\"}],\"solution\":{\"dateOfService\":\"2019-06-13\",\"id\":15},\"user\":{\"id\":\"systemuser-0001\",\"primaryRoleCode\":\"MD\",\"roles\":[\"MD\"]}}";

    //client 210
    public static final String ISUUANCE_STATE_CODE_NM = "NM";
    public static final String ISUUANCE_STATE_CODE_TX = "TX";
    public static final String ISUUANCE_STATE_CODE_WA = "WA";
    public static final String ISUUANCE_STATE_CODE_NJ = "NJ";
    public static final String LAST_ID_CLIENT_210 = "965";
    public static final String FIRST_ID_CLIENT_210 = "850";
    public static final int START_ID_CLIENT_210_NY = 55;
    public static final int END_ID_CLIENT_210_NY = 3092;

    //client 212
    public static final String ISUUANCE_STATE_CODE_CT = "CT";
    public static final String ISUUANCE_STATE_CODE_GA = "GA";
    public static final String ISSUANCE_STATE_CODE_IN = "IN";
    public static final String ISUUANCE_STATE_CODE_KY = "KY";
    public static final String ISUUANCE_STATE_CODE_ME = "ME";
    public static final String ISUUANCE_STATE_CODE_MO = "MO";
    public static final String ISUUANCE_STATE_CODE_NH = "NH";
    public static final String ISUUANCE_STATE_CODE_NY = "NY";
    public static final String ISUUANCE_STATE_CODE_OH = "OH";
    public static final String ISUUANCE_STATE_CODE_TN = "TN";
    public static final String ISUUANCE_STATE_CODE_VA = "VA";
    public static final String ISUUANCE_STATE_CODE_FL = "FL";

    //client 220
    public static final int START_ID_CLIENT_220_NM = 3133;
    public static final int END_ID_CLIENT_220_NM = 3133;

    //client 233
    public static final String ISUUANCE_STATE_CODE_NE = "NE";
    public static final int START_ID_CLIENT_233_NE = 3094;
    public static final int END_ID_CLIENT_233_NE = 3417;

    //client 234
    public static final int START_ID_CLIENT_234_MO = 3123;
    public static final int END_ID_CLIENT_234_MO = 3132;

    //allowed lines of business

    //Commercial
    public static final String COMMERCIAL_ID = "1";
    public static final String COMMERCIAL_CODE = "COMMERCIAL";
    public static final String COMMERCIAL_NAME = "Commercial";

    public static final String MEDICARE_ID = "2";
    public static final String MEDICARE_CODE = "MEDICARE";
    public static final String MEDICARE_NAME = "Medicare";

    public static final String MEDICAID_ID = "3";
    public static final String MEDICAID_CODE = "MEDICAID";
    public static final String MEDICAID_NAME = "Medicaid";

    //error message
    public static final String ERROR_MESSAGE_CLIENT_ID_VALIDATION = "Please provide valid format of clientId with up to 10 digits. Should not be null, empty or contain special characters.";
    public static final String ALLOWED_LINES_OF_BUSINESS_ISSUANCE_STATE_CODE_VALIDATION = "Please provide valid format for issuance state code with two capital letters.";
    public static final String ALLOWED_LINES_OF_BUSINESS_CLIENT_ID_ISSUANCE_STATE_CODE_VALIDATION_PARTIAL_MESSAGE = "Should not be null, empty or contain special characters.";

    //error messages allowed sub-client-codes
    public static final String ALLOWED_SUB_CLIENT_CODES_LINE_OF_BUSINESS_VALIDATION_MESSAGE = "Please provide valid format for line of business code with letters only.";
    public static final String ALLOWED_SUB_CLIENT_CODE_LINE_BUSINESS_VALIDATION_LENGHT = "Please provide valid size of line of business code with max 15 letters.";
    public static final String INVALID_LINE_OF_BUSINESS_ALPHABETIC = "ASUHbhugdtEFohng";
    public static final String INVALID_LINE_OF_BUSINESS_NUMERIC = "12365478978963";
    public static final String INVALID_LINE_OF_BUSINESS_NUMERIC_16_CHARS = "123654789789632";

    //rabbitMQ simulator constants
    public static final String STREAM_EXCHANGE_TYPE = "Stream";
    public static final String RIVER_EXCHANGE_TYPE = "River";
    public static final String MIXERCODEMAP_ROUTING_KEY = "EIM.ReferenceData.mixerCodeMap";
    public static final String RIVER_ROUTING_KEY = "aim.river.member.add";
    public static final String MIXERCODEMAP_MESSAGE_TYPE = "mixerCodeMap";
    public static final String MANUAL_ADD_MESSAGE_TYPE = "member manual add";
    public static final String SOURCE_SYSTEM_CODE_OSS = "OSS";
    public static final String EMPLOYER_GROUP_CODE = "D74495074D";
    public static final String EMPLOYER_GROUP_CODE_INVALID = "874495074D";
    public static final String SOURCE_SYSTEM_CODE_OS = "OS";
    public static final String EMPLOYER_GROUP_CODE_D74495074D = "D74495074D";
    public static final String DELETE_ACTION_EVENT = "Delete";
    public static final String DELETE_ACTION_EVENT_INVALID = "delete";
    public static final String SOURCE_SYSTEM_CODE_OT = "OT";
    public static final String EMPLOYER_GROUP_CODE_D7449507DD = "D7449507DD";

    //headers
    public static final String EXCHANGE_TYPE_HEADER = "exchange-type";
    public static final String ROUTING_KEY_HEADER = "routing-key";
    public static final String MESSAGE_TYPE_HEADER = "message-type";
    public static final String EVENT_ACTION_HEADER = "event-action";

    //Mixer Code Map
    public static final String DATE_2019_08_31 = "2019-08-31T00:00:00Z";
    public static final String DATE_9999_12_31 = "9999-12-31T00:00:00Z";
    public static final String MIXER_CODE_CALCMED0000 = "CALCMED0000";
    public static final int MIXER_CODE_MAP_IDENTIFIER = 1;
    public static final int LENGHT_256 = 256;
    public static final int LENGHT_11 = 11;

    //MixerCodeIdentifier
    public static final int MIXER_CODE_IDENTIFIER_13 = 13;
    public static final int MIXER_CODE_IDENTIFIER_14 = 14;
    public static final int MIXER_CODE_IDENTIFIER_23 = 23;
    public static final int MIXER_CODE_IDENTIFIER_24 = 24;
    public static final int MIXER_CODE_IDENTIFIER_26 = 26;

    //SharedReferenceDataRequestDTOFactory
    public static final String SHARED_REFERENCE_DATA_PRODUCT_CODE = "productCode";
    public static final String SHARED_REFERENCE_DATA_PRODUCT_CODE_HMO = "HMO";
    public static final String EFFECTIVE_DATE = "2020-06-09T12:20:30.000Z";

    //Date
    public static final String DATE_2017_08_31 = "2017-08-31T00:00:00Z";
    public static final String DATE_2018_12_31 = "2018-12-31T00:00:00Z";
    public static final String DATE_2020_08_31 = "2020-08-31T00:00:00Z";
    public static final String DATE_2025_12_31 = "2025-12-31T00:00:00Z";

    //Get referenceData constants for the types
    public static final String CLIENT_TYPE_QUERY_PARAM = "client";
    public static final String EMAIL_TYPE_QUERY_PARAM = "emailType";
    public static final String LANGUAGE_PREFERENCE_CODE_TYPE_QUERY_PARAM = "languagePreferenceCode";
    public static final String PHONE_TYPE_QUERY_PARAM = "phoneType";
    public static final String PROGRAM_TYPE_QUERY_PARAM = "program";
    public static final String SUB_DIVISION_STATE_TYPE_QUERY_PARAM = "subDivisionState";
    public static final String REFERENCE_TYPE_CLIENT_REFENCE_ID = "40";
    public static final String REFERENCE_TYPE_CLIENT_REFERENCE_DESCRIPTION = "AmeriHealth";
    public static final String REFERENCE_TYPE_PROGRAM_REFERENCE_DESCRIPTION = "Utilization Management";
    public static final String REFERENCE_TYPE_SUB_DEVISION_STATE_REFENCE_ID = "AL";
    public static final String REFERENCE_TYPE_SUB_DEVISION_STATE_REFENCE_DESCRIPTION = "Alabama";

    public static final String ERR_MESSAGE_DISPLAY_NOT_SUPPORTED = "The entered display fields' name is not supported!";

    public static final String CLIENT_ID_PARAM = "clientId";
    public static final String AVAILITY_MEMBER = "Availity";
    public static final String NAVINET_MEMBER = "Navinet";
    public static final String WEBDENIS_MEMBER = "WebDenis";
    public static final String BLUUE_MEMBER = "BlueE";

    //Invalid mixer codes
    public static final String INVALID_MIXERCODE_1 = " ALCMED0000";
    public static final String INVALID_MIXERCODE_2 = "CALCMED000 ";
    public static final String INVALID_MIXERCODE_3 = "CALCM D0000";
    public static final String INVALID_MIXERCODE_4 = "#ALCMED0000";
    public static final String INVALID_MIXERCODE_5 = "CALCMED000&";
    public static final String INVALID_MIXERCODE_6 = "CAL@MED0000";
    public static final String INVALID_MIXERCODE_7 = "CALCMED!@#%";

    public static final String CLIENT_ID_FIELD = "client-id";
    public static final String CLIENT_MEMBER_ID_FIELD = "client-member-id";
    public static final String DATE_OF_BIRTH_FIELD = "date-of-birth";
    public static final String DEPENDENT_CODE_FIELD = "dependent-code";
    public static final String FIRST_NAME_FIELD = "first-name";
    public static final String SORT_FIELD = "sort";
    public static final String PAGE_FIELD = "page";
    public static final String SIZE_FIELD = "size";

    //Context mode value
    public static final String CONTEXT_MODE_DEFAULT = null;
    public static final int START_VALUE_ID = 859;
    public static final int END_VALUE_ID = 3366;
    public static final int START_VALUE_ID_85 = 188;
    public static final int END_VALUE_ID_85 = 3418;
    public static final int START_VALUE_ID_183 = 553;
    public static final int END_VALUE_ID_183 = 3419;
    public static final int START_VALUE_ID_184 = 281;
    public static final int END_VALUE_ID_184 = 3384;
    public static final int START_VALUE_ID_187 = 317;
    public static final int END_VALUE_ID_187 = 3420;
    public static final int START_VALUE_ID_188 = 413;
    public static final int END_VALUE_ID_188 = 3421;
    public static final int START_VALUE_ID_189 = 462;
    public static final int END_VALUE_ID_189 = 3422;
    public static final int START_VALUE_ID_199 = 518;
    public static final int END_VALUE_ID_199 = 3151;

    //PlatformContext changed for solution id object (removed)
    public static final String noSolutionIdPlatformContextWithInvalidChannelCode = "{\"applicationId\":100,\"case\":{\"caseId\":\"d4f7ebce-b749-44a8-980b-3d3bd55d42e6\",\"caseRequestId\":\"94d10a63-1f59-4481-8dfd-f3b741231988\",\"caseReviewCategoryCode\":\"PROSPECTIVE\",\"creationDate\":\"2019-06-13 00:00:00\",\"requestCreatedDate\":\"2019-06-13T00:00:00.000Z\"},\"channelCode\":\"1\",\"contextMode\":\"TEST\",\"interactionId\":\"systeminteraction-0001\",\"interactionType\":\"Outgoing Email\",\"member\":{\"alphaPrefixCode\":\"WMW\",\"clientId\":185,\"enrollment\":{\"employerGroupCode\":\"ABC\",\"fundingTypeCode\":\"FLF\",\"issuanceStateCode\":\"FL\",\"jurisdictionCode\":\"LA\",\"lineOfBusinessCode\":\"COMMERCIAL\",\"networkCode\":\"PPO\",\"productCode\":\"PPO\",\"programCode\":\"UM\"},\"location\":{\"regionCode\":\"10\",\"stateCode\":\"CA\",\"zipCode\":\"60061\"}},\"organizationId\":1111,\"provider\":{\"ordering\":{\"clientId\":185,\"networkCodes\":[\"PPO\"],\"placeOfServiceCode\":\"OP\",\"specialtyCodes\":[\"1\"],\"stateCode\":\"CA\"},\"servicing\":{\"clientId\":185,\"networkCodes\":[\"PPO\"],\"placeOfServiceCode\":\"OP\",\"specialtyCodes\":[\"1\"],\"stateCode\":\"CA\"}},\"services\":[{\"treatmentCode\":\"J9324\",\"treatmentCodeType\":\"HCSPC\"}],\"user\":{\"id\":\"systemuser-0001\",\"primaryRoleCode\":\"MD\",\"roles\":[\"MD\"]}}";
    public static final String noSolutionIdPlatformContextWithChannelCodeCC = "{\"applicationId\":100,\"case\":{\"caseId\":\"d4f7ebce-b749-44a8-980b-3d3bd55d42e6\",\"caseRequestId\":\"94d10a63-1f59-4481-8dfd-f3b741231988\",\"caseReviewCategoryCode\":\"PROSPECTIVE\",\"creationDate\":\"2019-06-13 00:00:00\",\"requestCreatedDate\":\"2019-06-13T00:00:00.000Z\"},\"channelCode\":\"CC\",\"contextMode\":\"TEST\",\"interactionId\":\"systeminteraction-0001\",\"interactionType\":\"Outgoing Email\",\"member\":{\"alphaPrefixCode\":\"WMW\",\"clientId\":185,\"enrollment\":{\"employerGroupCode\":\"ABC\",\"fundingTypeCode\":\"FLF\",\"issuanceStateCode\":\"FL\",\"jurisdictionCode\":\"LA\",\"lineOfBusinessCode\":\"COMMERCIAL\",\"networkCode\":\"PPO\",\"productCode\":\"PPO\",\"programCode\":\"UM\"},\"location\":{\"regionCode\":\"10\",\"stateCode\":\"CA\",\"zipCode\":\"60061\"}},\"organizationId\":1111,\"provider\":{\"ordering\":{\"clientId\":185,\"networkCodes\":[\"PPO\"],\"placeOfServiceCode\":\"OP\",\"specialtyCodes\":[\"1\"],\"stateCode\":\"CA\"},\"servicing\":{\"clientId\":185,\"networkCodes\":[\"PPO\"],\"placeOfServiceCode\":\"OP\",\"specialtyCodes\":[\"1\"],\"stateCode\":\"CA\"}},\"services\":[{\"treatmentCode\":\"J9324\",\"treatmentCodeType\":\"HCSPC\"}],\"user\":{\"id\":\"systemuser-0001\",\"primaryRoleCode\":\"MD\",\"roles\":[\"MD\"]}}";
    public static final String noSolutionIdPlatformContextWithChannelCodeP = "{\"applicationId\":100,\"case\":{\"caseId\":\"d4f7ebce-b749-44a8-980b-3d3bd55d42e6\",\"caseRequestId\":\"94d10a63-1f59-4481-8dfd-f3b741231988\",\"caseReviewCategoryCode\":\"PROSPECTIVE\",\"creationDate\":\"2019-06-13 00:00:00\",\"requestCreatedDate\":\"2019-06-13T00:00:00.000Z\"},\"channelCode\":\"P\",\"contextMode\":\"TEST\",\"interactionId\":\"systeminteraction-0001\",\"interactionType\":\"Outgoing Email\",\"member\":{\"alphaPrefixCode\":\"WMW\",\"clientId\":185,\"enrollment\":{\"employerGroupCode\":\"ABC\",\"fundingTypeCode\":\"FLF\",\"issuanceStateCode\":\"FL\",\"jurisdictionCode\":\"LA\",\"lineOfBusinessCode\":\"COMMERCIAL\",\"networkCode\":\"PPO\",\"productCode\":\"PPO\",\"programCode\":\"UM\"},\"location\":{\"regionCode\":\"10\",\"stateCode\":\"CA\",\"zipCode\":\"60061\"}},\"organizationId\":1111,\"provider\":{\"ordering\":{\"clientId\":185,\"networkCodes\":[\"PPO\"],\"placeOfServiceCode\":\"OP\",\"specialtyCodes\":[\"1\"],\"stateCode\":\"CA\"},\"servicing\":{\"clientId\":185,\"networkCodes\":[\"PPO\"],\"placeOfServiceCode\":\"OP\",\"specialtyCodes\":[\"1\"],\"stateCode\":\"CA\"}},\"services\":[{\"treatmentCode\":\"J9324\",\"treatmentCodeType\":\"HCSPC\"}],\"user\":{\"id\":\"systemuser-0001\",\"primaryRoleCode\":\"MD\",\"roles\":[\"MD\"]}}";

    //Path Param and query Params
    public static final String CLIENT_ID = "clientId";
    public static final String MEMBER_ID = "memberId";
    public static final String COMPARE_DATE_PATH_PARM = "compare-date";
    public static final String SOLUTION_ID = "solution-id";
    public static final String REFERENCE_TYPE = "clientProductCode";

    //Disaster Declaration
    public static final String BUSINESS_KEY = "disaster";
    public static final String BUSINESS_KEY_CODE = "covid19";
    public static final String BUSINESS_KEY_CODE_DESCRIPTION = "Corona Virus";
    public static final String WORK_FLOW_TYPE = "StrictHardStop";
    public static final String WORK_FLOW_REASON = "Hard stopping due to covid19 disaster";
    public static final String WORK_FLOW_MESSAGING = "Message to display on the screen for user";
    public static final String BUSINESS_KEY_CODE_HURRICANE = "hurricane";
    public static final String HURRICANE_WARNING = "Hurricane Warning";
    public static final String WORK_FLOW_REASON_46403 = "Hard stop due to hurricane";
    public static final String WORK_FLOW_MESSAGING_46403 = "Due to a State of Emergency and/or Disaster Declaration, authorization is not required for this member for the requested service date. You can proceed with providing the necessary services. Please check back for future requests or in the event the service date changes. ";
    public static final String BUSINESS_KEY_CODE_TORNADO = "tornado";
    public static final String BUSINESS_KEY_HEAT = "heat";
    public static final String BUSINESS_KEY_FIRE = "fire";
    public static final String TORNADO_ALERT = "Tornado Alert";
    public static final String HEAT_WAVE = "heatwave";
    public static final String WILD_FIRE = "wildfire";
    public static final String FOREST_FIRE = "forest fire";

    public static final String ZIP_CODE_75006 = "75006";
    public static final String ZIP_CODE_75001 = "75001";
    public static final String ZIP_CODE_46403 = "46403";
    public static final String ZIP_CODE_60423 = "60423";
    public static final String ZIP_CODE_89002 = "89002";
    public static final String ZIP_CODE_30030 = "30030";
    public static final String ZIP_CODE_12084 = "12084";
    public static final String ZIP_CODE_80538 = "80538";
    public static final String ZIP_CODE_30080 = "30080";

    public static final String STATE_CODE_IN = "IN";
    public static final String STATE_CODE_KY = "KY";
    public static final String STATE_CODE_WA = "WA";
    public static final String STATE_CODE_IA = "IA";
    public static final String STATE_CODE_CA = "CA";
    public static final String STATE_CODE_NE = "NE";
    public static final String STATE_CODE_MO = "MO";
    public static final String STATE_CODE_NM = "NM";
    public static final String STATE_CODE_NV = "NV";
    public static final String STATE_CODE_NY = "NY";
    public static final String EMPLOYER_GROUP_CODE_720902 = "720902";
    public static final String EMPLOYER_GROUP_CODE_720903 = "720903";
    public static final String EMPLOYER_GROUP_CODE_720904 = "720904";
    public static final String EMPLOYER_GROUP_CODE_720905 = "720905";
    public static final String EMPLOYER_GROUP_CODE_720906 = "720906";
    public static final String BUSINESS_KEY_EMPLOYER_GROUP_RESTRICTION = "employergrouprestriction";
    public static final String BUSINESS_KEY_CODE_32BJ = "32BJ";
    public static final String WORK_FLOW_REASON_EMPLOYER_GROUP_RESTRICTION = "employer group restriction";
    public static final String WORK_FLOW_REASON_EMPLOYER_GROUP_HARD_STOP = "employer group hard stop";
    public static final String WORK_FLOW_MESSAGING_EMPLOYER_GROUP_CODE_32BJ = "Speech Therapy services for this member for the service date entered do not require authorization by AIM.  Please note that benefit limits, if applicable will still be applied";
    public static final String WRONG_EMPLOYER_GROUP_CODE = "637383888";
    public static final String MEMBER_RESTRICTED_MESSAGE = "Please transfer the caller to the appropriate AIM number.";
    public static final String ERROR_MSG_MISSING_FIRSTNAME = "Required String parameter 'first-name' is not present";
    public static final String ERROR_MSG_MISSING_DOB = "Required Date parameter 'date-of-birth' is not present";
    public static final String ERROR_MSG_MISSING_DEPENDANT_CODE = "Required String parameter 'dependent-code' is not present";
    public static final String ERROR_MSG_MISSING_CLIENT_MEMBER_ID = "Required String parameter 'client-member-id' is not present";
    public static final String ERROR_MSG_MISSING_CLIENT_ID = "Required String parameter 'client-id' is not present";
    public static final String SIZE_RESULT = "15";

    //Additional Fields
    public static final String ADDITIONAL_FIELD_SUB_GROUP_CODE = "subGroupCode";
    public static final String ADDITIONAL_FIELD_CLIENT_ACCOUNT_NUMBER = "clientAccountNumber";
    public static final String ADDITIONAL_FIELD_CLIENT_LINE_OF_BUSINESS_CODE = "clientLineOfBusinessCode";
    public static final String ADDITIONAL_FIELD_BUSINESS_MARKET_SEGMENT_NAME = "businessMarketSegmentName";
    public static final String ADDITIONAL_FIELD_ALTERNATE_BENEFIT_PLAN_CODE = "alternateBenefitPlanCode";
    public static final String ADDITIONAL_FIELD_CLIENT_ACCOUNT_NAME = "clientAccountName";
    public static final String ADDITIONAL_FIELD_CLIENT_FUNDING_TYPE_CODE = "clientFundingTypeCode";

    public static final String REVIEW_PROGRAM_CODE_SOC = "SOC";
    public static final String REVIEW_PROGRAM_CODE_LOC = "LOC";
}


