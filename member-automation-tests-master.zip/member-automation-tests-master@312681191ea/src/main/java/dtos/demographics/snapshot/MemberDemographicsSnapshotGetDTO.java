package dtos.demographics.snapshot;

import com.fasterxml.jackson.annotation.JsonFormat;
import dtos.demographics.*;

import java.util.Date;
import java.util.List;

/**
 * Created by VBaliyska on 5/16/2019.
 */
public class MemberDemographicsSnapshotGetDTO {

    private String id;
    private Date createdOn;
    private List<AdditionalMemberIdDTO> additionalMemberIds;
    private List<AddressesDTO> addresses;
    private String clientDependentRelationCode;
    private String clientId;
    private String clientMemberCode;
    private String clientMemberId;
    private ClientSpecificDemographicsDTO clientSpecificDemographics;

    @JsonFormat(
            shape = JsonFormat.Shape.STRING,
            pattern = "yyyy-MM-dd"
    )

    private Date dateOfBirth;
    private String dependentCode;
    private String dependentRelationCode;
    private String dependentRelationName;
    private List<DoNotCallRecordDTO> doNotCallRecords;
    private List<EmailsDTO> emails;
    private String firstName;
    private String gender;
    private String healthPlan;
    private String lastName;
    private String legacyMemberId;
    private Boolean manuallyUpdated;
    private String memberPrefix;
    private Boolean manuallyCreated;
    private List<PhonesDTO> phones;
    private List<RestrictedAccessesDTO> restrictedAccesses;
    private Date updateDate;
    private String snapshotId;

    public MemberDemographicsSnapshotGetDTO() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    public List<AdditionalMemberIdDTO> getAdditionalMemberIds() {
        return additionalMemberIds;
    }

    public void setAdditionalMemberIds(List<AdditionalMemberIdDTO> additionalMemberIds) {
        this.additionalMemberIds = additionalMemberIds;
    }

    public List<AddressesDTO> getAddresses() {
        return addresses;
    }

    public void setAddresses(List<AddressesDTO> addresses) {
        this.addresses = addresses;
    }

    public String getClientDependentRelationCode() {
        return clientDependentRelationCode;
    }

    public void setClientDependentRelationCode(String clientDependentRelationCode) {
        this.clientDependentRelationCode = clientDependentRelationCode;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientMemberCode() {
        return clientMemberCode;
    }

    public void setClientMemberCode(String clientMemberCode) {
        this.clientMemberCode = clientMemberCode;
    }

    public String getClientMemberId() {
        return clientMemberId;
    }

    public void setClientMemberId(String clientMemberId) {
        this.clientMemberId = clientMemberId;
    }

    public ClientSpecificDemographicsDTO getClientSpecificDemographics() {
        return clientSpecificDemographics;
    }

    public void setClientSpecificDemographics(ClientSpecificDemographicsDTO clientSpecificDemographics) {
        this.clientSpecificDemographics = clientSpecificDemographics;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getDependentCode() {
        return dependentCode;
    }

    public void setDependentCode(String dependentCode) {
        this.dependentCode = dependentCode;
    }

    public String getDependentRelationCode() {
        return dependentRelationCode;
    }

    public void setDependentRelationCode(String dependentRelationCode) {
        this.dependentRelationCode = dependentRelationCode;
    }

    public String getDependentRelationName() {
        return dependentRelationName;
    }

    public void setDependentRelationName(String dependentRelationName) {
        this.dependentRelationName = dependentRelationName;
    }

    public List<DoNotCallRecordDTO> getDoNotCallRecords() {
        return doNotCallRecords;
    }

    public void setDoNotCallRecords(List<DoNotCallRecordDTO> doNotCallRecords) {
        this.doNotCallRecords = doNotCallRecords;
    }

    public List<EmailsDTO> getEmails() {
        return emails;
    }

    public void setEmails(List<EmailsDTO> emails) {
        this.emails = emails;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getHealthPlan() {
        return healthPlan;
    }

    public void setHealthPlan(String healthPlan) {
        this.healthPlan = healthPlan;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLegacyMemberId() {
        return legacyMemberId;
    }

    public void setLegacyMemberId(String legacyMemberId) {
        this.legacyMemberId = legacyMemberId;
    }

    public Boolean getManuallyUpdated() {
        return manuallyUpdated;
    }

    public void setManuallyUpdated(Boolean manuallyUpdated) {
        this.manuallyUpdated = manuallyUpdated;
    }

    public String getMemberPrefix() {
        return memberPrefix;
    }

    public void setMemberPrefix(String memberPrefix) {
        this.memberPrefix = memberPrefix;
    }

    public Boolean getManuallyCreated() {
        return manuallyCreated;
    }

    public void setManuallyCreated(Boolean manuallyCreated) {
        this.manuallyCreated = manuallyCreated;
    }

    public List<PhonesDTO> getPhones() {
        return phones;
    }

    public void setPhones(List<PhonesDTO> phones) {
        this.phones = phones;
    }

    public List<RestrictedAccessesDTO> getRestrictedAccesses() {
        return restrictedAccesses;
    }

    public void setRestrictedAccesses(List<RestrictedAccessesDTO> restrictedAccesses) {
        this.restrictedAccesses = restrictedAccesses;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getSnapshotId() {
        return snapshotId;
    }

    public void setSnapshotId(String snapshotId) {
        this.snapshotId = snapshotId;
    }
}
