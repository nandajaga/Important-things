package enrollments;

import com.aim.automation.dtos.ErrorDTO;
import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.steps.cases.caserequest.CreateCaseRequestSteps;
import com.aim.automation.steps.cases.servicelock.CaseServiceLockSteps;
import com.aim.automation.tests.base.PostTests;
import dtos.workflow.WorkFlowResponseDTO;
import factories.workflow.WorkFlowFactory;
import helpers.constants.Constants;
import helpers.dataproviders.DataProviders;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.enrollments.PostMemberEnrollmentEnsureWorkFlowSteps;

import static helpers.constants.BasePathConstants.*;
import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_210;
import static helpers.constants.ErrorMessagesForMemberEndpointsConstants.ERR_MSG_CASEREQUESTID_CANNOT_NULL;

/**
 * https://dbg-jira.antheminc.com/browse/CAP-3629
 * Created by @sbioi on 03/01/2020
 */

public class PostMemberEnrollmentEnsureWorkFlowTests extends PostTests {
    private WorkFlowResponseDTO[] enrollmentEnsureWorkFlowResponseDTO;
    private PostMemberEnrollmentEnsureWorkFlowSteps postMemberEnrollmentEnsureWorkFlowSteps;
    private PlatformContextUtils platformContextUtils;

    @BeforeClass
    public void initClass() {
        basePath = BASE_PATH_POST_ENROLLMENT_ENSUREWORKFLOW;
        body = new WorkFlowFactory().createWorkFlowDTO(SUBCLIENT_CODE);
    }

    @BeforeMethod
    public void initMethod() {
        //Create caseRequestId and put a lock on it by changing baseURI to C&S
        requestSpecification.addBaseURI(CASE_REQUEST_BASE_URI);
        requestSpecification.addPlatformContextToRequest(new PlatformContextUtils().changeUserId(requestSpecification, USER_ID));
        CreateCaseRequestSteps createCaseRequestSteps = new CreateCaseRequestSteps(requestSpecification);
        String caseRequestId = createCaseRequestSteps.createCaseRequest();

        //Create caseRequestId and put a lock on it
        CaseServiceLockSteps caseServiceLockStep = new CaseServiceLockSteps(requestSpecification);
        caseServiceLockStep.lockCaseOrCaseRequest(caseRequestId, USER_ID);

        platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(CLIENT_ID_210));
        platformContextHeader = platformContextUtils.changeStateCode(platformContextHeader, ISUUANCE_STATE_CODE_TX);
        platformContextHeader = platformContextUtils.changeSolutionId(platformContextHeader, String.valueOf(PC_SOLUTION_ID));
        platformContextHeader = platformContextUtils.changeCaseId(platformContextHeader, null);
        platformContextHeader = platformContextUtils.changeUserId(platformContextHeader, USER_ID);
        platformContextHeader = platformContextUtils.changeCaseRequestId(platformContextHeader, caseRequestId);
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-201---------------------------------------------
    /* https://jira.aimspecialtyhealth.com/browse/OSPP-5787
     * ClientId - 210, Zipcode - 75006,75001 , solution id=15 and StateCode - TX
     * Validate Member is in Disaster area and Hard stop is provided
     * Updated by sbioi on 20/05/2020
     */
    @Test(dataProvider = "validZipCodeForClient210DisasterDeclaration", dataProviderClass = DataProviders.class)
    public void whenDisasterZipcodeAndClientIdAndStateCodeAndSolutionIdPassed(String zipCode, String subClientCode) {
        platformContextHeader = platformContextUtils.changeZipCode(platformContextHeader, zipCode);

        postMemberEnrollmentEnsureWorkFlowSteps = new PostMemberEnrollmentEnsureWorkFlowSteps(platformContextHeader, headers);
        enrollmentEnsureWorkFlowResponseDTO = postMemberEnrollmentEnsureWorkFlowSteps.postEnrollmentEnsureWorkFlowSteps(subClientCode);

        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getWorkFlow()).isNull();
        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getFlow()).isNull();
        softly.assertAll();
    }

    @Test(dataProvider = "ensureWorkFlowClientIdZipcodeState", dataProviderClass = DataProviders.class)
    public void whenPostDifferentClientIdZipCodeAndStateCodeResponseIs200(String clientId, String stateCode, String zipCode) {
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(clientId));
        platformContextHeader = platformContextUtils.changeStateCode(platformContextHeader, stateCode);
        platformContextHeader = platformContextUtils.changeZipCode(platformContextHeader, zipCode);

        postMemberEnrollmentEnsureWorkFlowSteps = new PostMemberEnrollmentEnsureWorkFlowSteps(platformContextHeader, headers);
        enrollmentEnsureWorkFlowResponseDTO = postMemberEnrollmentEnsureWorkFlowSteps.postEnrollmentEnsureWorkFlowSteps(SUBCLIENT_CODE);

        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getFlow()).isNull();
        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getWorkFlow()).isNull();
        softly.assertAll();
    }


    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-404---------------------------------------------//
    @Test
    public void whenCaseIdIsPassedWithValueInPlatformContextThenEmptyBody() {
        platformContextHeader = platformContextUtils.changeCaseId(platformContextHeader, CASE_ID);

        postMemberEnrollmentEnsureWorkFlowSteps = new PostMemberEnrollmentEnsureWorkFlowSteps(platformContextHeader, headers);
        Response response = postMemberEnrollmentEnsureWorkFlowSteps.whenCaseIdIsNotNullSendError(SUBCLIENT_CODE);

        softly.then(response.asString()).isEmpty();
        softly.then(response.asString()).isBlank();
        softly.assertAll();
    }

    @Test
    public void whenCaseRequestIdIsPassedEmptyInPlatformContextResponseIs500() {
        platformContextHeader = platformContextUtils.changeCaseRequestId(platformContextHeader, null);

        postMemberEnrollmentEnsureWorkFlowSteps = new PostMemberEnrollmentEnsureWorkFlowSteps(platformContextHeader, headers);
        ErrorDTO errorDTO = postMemberEnrollmentEnsureWorkFlowSteps.whenCaseRequestIdIsNullSendError(SUBCLIENT_CODE);

        softly.then(errorDTO.getCode()).isEqualTo(HttpStatus.SC_INTERNAL_SERVER_ERROR);
        softly.then(errorDTO.getMessage()).isEqualTo(ERR_MSG_CASEREQUESTID_CANNOT_NULL);
        softly.assertAll();
    }

    @Test
    public void whenDisasterAndOption1ZipcodeAndInvalidChannelCodePassedInPlatformContextThenNullWorkFlowReturned() {
        platformContextHeader = platformContextUtils.changeZipCode(platformContextHeader, ZIP_CODE_46403);
        platformContextHeader = platformContextUtils.changeClientId(platformContextHeader, Integer.valueOf(Constants.CLIENT_ID_85));
        platformContextHeader = platformContextUtils.changeChannelCode(platformContextHeader, "TEST");
        platformContextHeader = platformContextUtils.changeIssuanceStateCode(platformContextHeader, STATE_CODE_IN);
        platformContextHeader = platformContextUtils.changeStateCode(platformContextHeader, STATE_CODE_IN);

        postMemberEnrollmentEnsureWorkFlowSteps = new PostMemberEnrollmentEnsureWorkFlowSteps(platformContextHeader, headers);
        enrollmentEnsureWorkFlowResponseDTO = postMemberEnrollmentEnsureWorkFlowSteps.postEnrollmentEnsureWorkFlowSteps(SUBCLIENT_CODE);

        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getFlow()).isNull();
        softly.then(enrollmentEnsureWorkFlowResponseDTO[0].getWorkFlow()).isNull();

        softly.assertAll();
    }
}
