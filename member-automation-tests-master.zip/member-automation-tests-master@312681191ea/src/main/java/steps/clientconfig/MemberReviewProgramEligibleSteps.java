package steps.clientconfig;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.clientconfig.MemberReviewProgramEligibilityRequestDTO;
import dtos.clientconfig.MemberReviewProgramEligibilityResponseDTO;
import helpers.constants.BasePathConstants;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;

import java.util.List;

public class MemberReviewProgramEligibleSteps {
    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;


    public MemberReviewProgramEligibleSteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();
        requestSpecification.addBasePath(BasePathConstants.BASE_PATH_IS_MEMBER_REVIEW_PROGRAM_ELIGIBLE);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    public MemberReviewProgramEligibilityResponseDTO[] searchReviewProgramsWithoutRequestBody() {
        requestSpecification.addBodyToRequest("{}");
        Response result = this.requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());
        return result.as(MemberReviewProgramEligibilityResponseDTO[].class);
    }

    public MemberReviewProgramEligibilityResponseDTO[] searchReviewProgramsWithRequestBody(List<String> reviewPrograms) {
        MemberReviewProgramEligibilityRequestDTO requestBody = new MemberReviewProgramEligibilityRequestDTO();
        requestBody.setReviewPrograms(reviewPrograms);
        requestSpecification.addBodyToRequest(requestBody);
        Response result = this.requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());
        return result.as(MemberReviewProgramEligibilityResponseDTO[].class);
    }
}



