package com.abc.automation.factories.platformcontext.version2;

import com.abc.automation.helpers.enums.user.UserRoleEnum;
import com.abc.servicemodel.domainV2.UserV2;

import java.util.ArrayList;

import static com.abc.automation.helpers.constants.PlatformContextConstants.PC_USER_ID;

public class UserV2DTOFactory {
    public UserV2 createUserDTO() {
        ArrayList<String> roleCodes = new ArrayList();
        UserV2 user = new UserV2();

        roleCodes.add(UserRoleEnum.MD.getCode());
        user.setRoleCodes(roleCodes);
        user.setId(PC_USER_ID);
        user.setPrimaryRoleCode(UserRoleEnum.MD.getCode());
        return user;
    }

    public UserV2 createUserDTO(String id, ArrayList<String> roleCodes,String primaryRoleCode) {
        UserV2 user = new UserV2();
        user.setRoleCodes(roleCodes);
        user.setId(id);
        user.setPrimaryRoleCode(primaryRoleCode);

        return user;
    }
}
