package com.abc.automation.helpers.constants;

/**
 * Created by PPetarcheva on 8/1/2019.
 */
public class BasePathConstants {

    // Case action log
    public final static String ACTION_LOG_BASE_PATH = "/cases/action-log/v1/actionlogs";

    // Case request
    public static final String CASE_CREATE_BASE_PATH = "/cases/case-request/v3/caseRequests";
    public static final String CASE_GET_BASE_PATH = "/cases/case-request/v3/caseRequests/{caseRequestId}";
    public static final String CASE_SUBMIT_BASE_PATH = "/cases/case-request/v4/caseRequests/{caseRequestId}/submissions";
    public static final String CASE_CLINICAL_DECISION_V4_BASE_PATH = "/cases/case-request/v4/caseRequests/{caseRequestId}/services/clinicalDecision";
    public static final String CASE_CONDITION_SERVICES_BASE_PATH = "/cases/case-request/v4/caseRequests/{caseRequestId}/conditions/services";
    public static final String CASE_MEMBERS_BASE_PATH = "/cases/case-request/v3/caseRequests/{caseRequestId}/members";
    public static final String CASE_PRE_CLINICAL_BASE_PATH = "/cases/case-request/v3/caseRequests/caseRequest/{caseRequestId}/solution/{solutionId}/preClinical";
    public static final String CASE_ORDERING_PROVIDER_BASE_PATH = "/cases/case-request/v3/caseRequests/{caseRequestId}/orderingProviders";
    public static final String CASE_SERVICING_PROVIDER_BASE_PATH = "/cases/case-request/v4/caseRequests/{caseRequestId}/servicingProviders";
    public static final String CASE_DATE_OF_SERVICE_BASE_PATH = "/cases/case-request/v3/caseRequests/{caseRequestId}/dateOfService/{dateOfService}";
    public static final String CASE_MEMBER_ENROLLMENT_BASE_PATH = "/cases/case-request/v3/caseRequests/{caseRequestId}/memberEnrollment";
    public static final String CASE_COPY_SERVICES = "cases/case/v1/copyservices";
    public static final String CASE_REQUEST_JUSTIFICATION = "cases/case-request/v1/caseRequests/{caseRequestId}/justification";

    // Case condition search
    public static final String CASE_CONDITION_SEARCH_BASE_PATH = "/condition-search/v1/condition/search";

    // Case service lock
    public static final String CASE_LOCK_BASE_PATH = "/cases/case-service-lock/v1/workitems/{wid}/lock";

    // Case service search
    public static final String CASE_SERVICE_SEARCH_BASE_PATH = "/service-search/v1/service/search";

    // Member data manager
    public static final String MEMBER_CREATE_BASE_PATH = "/member/data/manager/v2/clients/{clientId}/members";

    // Member enrollments
    public static final String MEMBER_GET_ENROLLMENTS_BASE_PATH = "/member/enrollments/v2/clients/{clientId}/members/{memberId}/enrollments";

    // Member snapshots
    public static final String MEMBER_CREATE_DEMOGRAPHICS_SNAPSHOT_BASE_PATH = "/member/demographics-snapshot/v2/clients/{clientId}/members/{memberId}/demographics/snapshots";
    public static final String MEMBER_CREATE_ENROLLMENTS_SNAPSHOT_BASE_PATH = "/member/enrollments-snapshot/v2/clients/{clientId}/members/{memberId}/enrollments/{enrollmentId}/snapshots";
    public static final String MEMBER_CREATE_ENROLLMENTS_V3_SNAPSHOT_BASE_PATH = "/member/enrollments-snapshot/v3/clients/{clientId}/members/{memberId}/enrollments/{enrollmentId}/snapshots";

    // Provider ordering
    public static final String PROVIDER_CREATE_ORDERING_BASE_PATH = "/providers/ordering/v3";

    // Provider servicing
    public static final String PROVIDER_CREATE_SERVICING_BASE_PATH = "/providers/servicing/v2/servicingproviders";

    // Provider snapshot
    public static final String PROVIDER_CREATE_ORDERING_SNAPSHOT_BASE_PATH = "/providers/ordering/snapshot/v3";
    public static final String PROVIDER_CREATE_SERVICING_SNAPSHOT_BASE_PATH = "/providers/servicing/snapshot/v1";
    public static final String PROVIDER_GET_SERVICING_SNAPSHOT_BASE_PATH = "/providers/servicing/snapshot/v1/get";

    // User profile
    public static final String USER_CREATE_PROFILE_BASE_PATH = "/user/management/command/v2/userprofiles/";
    public static final String USER_MANAGEMENT_QUERY_GET_PATH = "/user/management/query/v2/userprofiles/{uid}";
}
