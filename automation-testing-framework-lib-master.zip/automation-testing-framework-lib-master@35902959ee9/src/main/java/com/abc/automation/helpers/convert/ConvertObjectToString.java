package com.abc.automation.helpers.convert;

import com.abc.automation.helpers.constants.Constants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Deprecated
public class ConvertObjectToString {
    private final static Logger LOGGER = LoggerFactory.getLogger(ConvertObjectToString.class);

    public static String convertObjectToString(Object object) {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(createJavaTimeModuleLocalInstance());
        String objectAsString = null;

        try {
            objectAsString = mapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            LOGGER.error("An error has occurred while converting object {} to string", object, e);
        }

        return objectAsString;
    }

    private static JavaTimeModule createJavaTimeModuleLocalInstance() {
        JavaTimeModule javaTimeModule = new JavaTimeModule();
        javaTimeModule.addSerializer(LocalDateTime.class, new LocalDateTimeSerializer(Constants.DATE_TIME_FORMATTER));
        javaTimeModule.addSerializer(LocalDate.class, new LocalDateSerializer(Constants.DATE_FORMATTER));

        return javaTimeModule;
    }
}
