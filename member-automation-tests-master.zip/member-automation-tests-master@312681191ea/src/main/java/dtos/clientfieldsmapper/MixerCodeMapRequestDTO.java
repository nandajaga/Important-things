package dtos.clientfieldsmapper;

/**
 * Created by VBaliyska on 10/11/2019.
 */
public class MixerCodeMapRequestDTO {

    private String clientId;
    private String sourceSystem;
    private String employerGroupNumber;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public String getEmployerGroupNumber() {
        return employerGroupNumber;
    }

    public void setEmployerGroupNumber(String employerGroupNumber) {
        this.employerGroupNumber = employerGroupNumber;
    }
}
