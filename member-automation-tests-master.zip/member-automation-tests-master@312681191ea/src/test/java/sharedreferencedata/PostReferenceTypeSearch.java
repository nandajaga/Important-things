package sharedreferencedata;

import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.tests.base.PostTests;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import dtos.sharedreferencedata.SharedReferenceDataResponseDTO;
import factories.sharedreferencedata.SharedReferenceDataRequestDTOFactory;
import helpers.constants.BasePathConstants;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import steps.sharedreferencedata.SharedReferenceDataRetrieveByTypesSteps;
import steps.sharedreferencedata.SharedReferenceDataSearchSteps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static helpers.constants.Constants.*;

/**
 * Created by RKohli on 15/09/2020.
 */
public class PostReferenceTypeSearch extends PostTests {
    private Map<String, List> sharedReferenceDataRetrieveTypesResponseDTO;
    private SharedReferenceDataResponseDTO[] sharedReferenceDataResponseDTO;
    private SharedReferenceDataSearchSteps sharedReferenceDataSearchSteps;
    private SharedReferenceDataRetrieveByTypesSteps sharedReferenceDataRetrieveByTypesSteps;
    private PlatformContextUtils platformContextUtils;
    private HashMap<String, Object> searchCriteria = new HashMap<>();
    private List<String> collectionName = new ArrayList<>();

    @BeforeClass
    public void init() {
        basePath = BasePathConstants.BASE_PATH_SHARED_REFERENCE_DATA;
        searchCriteria.put(SHARED_REFERENCE_DATA_PRODUCT_CODE, SHARED_REFERENCE_DATA_PRODUCT_CODE_HMO);
        pathParamsMap.clear();
        pathParamsMap.put("referenceType", "clientProductCode");

        body = new SharedReferenceDataRequestDTOFactory().createSharedReferneceDataDTO(searchCriteria, EFFECTIVE_DATE);
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    /* https://jira.aimspecialtyhealth.com/browse/OSPP-8975
     * ProductCode - HMO, EffectiveDate -2020-06-09T12:20:30.000Z
     * Updated by RKohli on 18/05/2020
     */

    @Test
    public void whenPostProductCodeAndEffectiveDateIsProvidedThenResponseSC200() throws JsonProcessingException {

        sharedReferenceDataSearchSteps = new SharedReferenceDataSearchSteps(platformContextHeader, headers);

        sharedReferenceDataResponseDTO = sharedReferenceDataSearchSteps.postSharedReferenceDataForPositiveTests(searchCriteria, EFFECTIVE_DATE);

        softly.then(sharedReferenceDataResponseDTO[0].getDisplayOrder().equals(0));
        softly.then(sharedReferenceDataResponseDTO[0].getReferenceData().containsKey("productCode"));
        softly.then(sharedReferenceDataResponseDTO[0].getReferenceData().containsValue("HMO"));
        softly.then(sharedReferenceDataResponseDTO[0].getReferenceData().containsKey("clientId"));
        softly.then(sharedReferenceDataResponseDTO[0].getReferenceData().containsValue("123"));
        softly.then(sharedReferenceDataResponseDTO[0].getReferenceData().containsKey("productDescription"));
        softly.then(sharedReferenceDataResponseDTO[0].getReferenceData().containsValue("HMO Blue Texas"));

        collectionName.add("clientProductCode");

        sharedReferenceDataRetrieveByTypesSteps = new SharedReferenceDataRetrieveByTypesSteps(platformContextHeader, headers);
        sharedReferenceDataRetrieveTypesResponseDTO = sharedReferenceDataRetrieveByTypesSteps.postSharedReferenceDataRetrieveByTypesForPositiveTests(collectionName);
        List response = (List) sharedReferenceDataRetrieveTypesResponseDTO.get("clientProductCode");
        ObjectMapper obj = new ObjectMapper();

        SharedReferenceDataResponseDTO responseValue = obj.convertValue(response.get(0), SharedReferenceDataResponseDTO.class);
        softly.then(responseValue.getDisplayOrder().equals(0));
        softly.then(responseValue.getReferenceData().containsKey("productCode"));
        softly.then(responseValue.getReferenceData().containsValue("HMO"));
        softly.then(responseValue.getReferenceData().containsKey("clientId"));
        softly.then(responseValue.getReferenceData().containsValue("123"));
        softly.then(responseValue.getReferenceData().containsKey("productDescription"));
        softly.then(responseValue.getReferenceData().containsValue("HMO Blue Texas"));

        responseValue = obj.convertValue(response.get(1), SharedReferenceDataResponseDTO.class);
        softly.then(responseValue.getDisplayOrder().equals(0));
        softly.then(responseValue.getReferenceData().containsKey("productCode"));
        softly.then(responseValue.getReferenceData().containsValue("HPT"));
        softly.then(responseValue.getReferenceData().containsKey("clientId"));
        softly.then(responseValue.getReferenceData().containsValue("123"));
        softly.then(responseValue.getReferenceData().containsKey("productDescription"));
        softly.then(responseValue.getReferenceData().containsValue("HPT Blue Texas"));
        softly.assertAll();

    }

}