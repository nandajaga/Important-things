package steps.datamanager;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.ErrorSpringDTO;
import dtos.datamanager.MemberDTO;
import dtos.datamanager.MemberResponseDTO;
import dtos.demographics.EmailsDTO;
import dtos.demographics.PhonesDTO;
import factories.datamanager.MemberDTOFactory;
import helpers.constants.BasePathConstants;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


/**
 * Created by PPetarcheva on 3/20/2019.
 */
public class MemberDataManagerSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;


    public MemberDataManagerSteps(String platformContextHeaders, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BasePathConstants.BASE_PATH_ADD_MEMBERS);
        requestSpecification.addPlatformContextToRequest(platformContextHeaders);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    public MemberResponseDTO createMember(String clientId, String clientMemberId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);

        MemberDTOFactory memberDTOFactory = new MemberDTOFactory();
        MemberDTO body = memberDTOFactory.createMemberDTO(clientId, clientMemberId);

        requestSpecification.addBodyToRequest(body);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_CREATED);

        return result.as(MemberResponseDTO.class);
    }

    public MemberResponseDTO createMember(String clientId, String employerGroupNumber, int numberOfEnrollments, String mixerCode, String clientMemberProductCode, String clientMemberId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);

        MemberDTOFactory memberDTOFactory = new MemberDTOFactory();
        MemberDTO body = memberDTOFactory.createMemberSpecificClientIdEmployerGroupNumberDTO(clientId, employerGroupNumber, numberOfEnrollments, mixerCode, clientMemberProductCode, clientMemberId);

        requestSpecification.addBodyToRequest(body);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_CREATED);

        return result.as(MemberResponseDTO.class);
    }

    public MemberResponseDTO createMemberClientMemberId(String clientId, String clientMemberId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);

        MemberDTOFactory memberDTOFactory = new MemberDTOFactory();
        MemberDTO body = memberDTOFactory.createMemberClientMemberId(clientId, clientMemberId);

        requestSpecification.addBodyToRequest(body);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_CREATED);

        return result.as(MemberResponseDTO.class);
    }

    public MemberResponseDTO createMember(String clientId, String issuanceState, String sourceSystem, String clientMemberId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);

        MemberDTOFactory memberDTOFactory = new MemberDTOFactory();
        MemberDTO body = memberDTOFactory.createMemberSourceSystemDTO(clientId, issuanceState, sourceSystem, clientMemberId);

        requestSpecification.addBodyToRequest(body);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_CREATED);

        return result.as(MemberResponseDTO.class);
    }

    public String createMemberWithContacts(String clientId, String firstName, String lastName, ArrayList<EmailsDTO> emails, ArrayList<PhonesDTO> phones, String clientMemberId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);

        MemberDTOFactory memberDTOFactory = new MemberDTOFactory();

        Object body = memberDTOFactory.createMemberDTO(clientId, firstName, lastName, emails, phones, clientMemberId);

        requestSpecification.addBodyToRequest(body);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_CREATED);

        String memberId = result.as(MemberResponseDTO.class).getId();

        return memberId;
    }

    public MemberResponseDTO createMemberWithContacts(String clientId, String firstName, String lastName, String dob, String clientMemberId) throws ParseException {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);

        MemberDTOFactory memberDTOFactory = new MemberDTOFactory();

        Object body = memberDTOFactory.createMemberDTO(clientId, firstName, lastName, dob, clientMemberId);

        requestSpecification.addBodyToRequest(body);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_CREATED);

        return result.as(MemberResponseDTO.class);
    }


    public MemberResponseDTO createMember(String clientId, String firstName, String lastName, ArrayList<EmailsDTO> emails, ArrayList<PhonesDTO> phones, int statusCode, String clientMemberId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);

        MemberDTOFactory memberDTOFactory = new MemberDTOFactory();

        MemberDTO body = memberDTOFactory.createMemberDTO(clientId, firstName, lastName, emails, phones, clientMemberId);

        requestSpecification.addBodyToRequest(body);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(statusCode);

        return result.as(MemberResponseDTO.class);
    }

    public MemberResponseDTO createMemberWithSpecificClientIdAndAdditionalFields(String clientId, String subGroupCode, String clientAccountNumber, String clientLineOfBusinessCode, String businessMarketSegmentName, String alternateBenefitPlanCode, Boolean preAcaHonorContractFlag, String clientAccountName, String clientFundingTypeCode, String clientMemberId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);

        MemberDTOFactory memberDTOFactory = new MemberDTOFactory();
        MemberDTO body = memberDTOFactory.createMemberWithSpecificClientIdAndAdditionalFields(clientId, subGroupCode, clientAccountNumber, clientLineOfBusinessCode, businessMarketSegmentName, alternateBenefitPlanCode, preAcaHonorContractFlag, clientAccountName, clientFundingTypeCode, clientMemberId);

        requestSpecification.addBodyToRequest(body);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_CREATED);

        return result.as(MemberResponseDTO.class);
    }

    public MemberResponseDTO createMemberWithSpecificClientIdAndLOBAndIssuanceStateCode(String clientId, String issuanceStateCode, String clientLineOfBusinessCode, String clientMemberId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);

        MemberDTOFactory memberDTOFactory = new MemberDTOFactory();
        MemberDTO body = memberDTOFactory.createMemberWithSpecificClientIdAndLOBAndIssuanceStateCode(clientId, issuanceStateCode, clientLineOfBusinessCode, clientMemberId);

        requestSpecification.addBodyToRequest(body);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_CREATED);

        return result.as(MemberResponseDTO.class);
    }

    public ErrorSpringDTO createMemberWithoutBody(String clientId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorSpringDTO.class);
    }

    public ErrorDTO createMemberErrors(String clientId, String clientMemberId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);

        MemberDTOFactory memberDTOFactory = new MemberDTOFactory();
        MemberDTO body = memberDTOFactory.createMemberDTO(clientId, clientMemberId);

        requestSpecification.addBodyToRequest(body);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorDTO.class);
    }

    public ErrorDTO createMemberWithClientMemberProductCodeAndMixerCodeWithError(String clientId, String employerGroupNumber, int numberOfEnrollments, String mixerCode, String clientMemberProductCode, String clientMemberId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);

        MemberDTOFactory memberDTOFactory = new MemberDTOFactory();
        MemberDTO body = memberDTOFactory.createMemberSpecificClientIdEmployerGroupNumberDTO(clientId, employerGroupNumber, numberOfEnrollments, mixerCode, clientMemberProductCode, clientMemberId);

        requestSpecification.addBodyToRequest(body);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorDTO.class);
    }

    public MemberResponseDTO createMemberWithSpecificEmployerGroupNumberAndSystemSourceCode(String clientId, String employerGroupNumber, String sourceSystem, String mixerCode, String clientMemberId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);

        requestSpecification.addPathParams(pathParamsMap);

        MemberDTOFactory memberDTOFactory = new MemberDTOFactory();
        MemberDTO body = memberDTOFactory.createMemberWithSpecificClientIdEmployerGroupNumberAndSourceSystemCode(clientId, employerGroupNumber, sourceSystem, mixerCode, clientMemberId);

        requestSpecification.addBodyToRequest(body);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_CREATED);

        return result.as(MemberResponseDTO.class);
    }
}
