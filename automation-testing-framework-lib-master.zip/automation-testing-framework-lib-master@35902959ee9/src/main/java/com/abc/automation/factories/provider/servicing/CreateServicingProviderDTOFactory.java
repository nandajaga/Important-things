package com.abc.automation.factories.provider.servicing;

import com.abc.automation.dtos.provider.servicing.CreateServicingProviderDTO;
import com.abc.automation.helpers.constants.ProviderConstants;

import java.util.*;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
public class CreateServicingProviderDTOFactory {

    public CreateServicingProviderDTO createServicingProviderDTO(int clientId) {
        Map<String, String> manualProvider = new HashMap<>();
        manualProvider.put("manual","true");

        return createServicingProviderDTO(clientId, manualProvider);
    }

    public CreateServicingProviderDTO createServicingProviderDTO(int clientId, Map<String, String> servicingProvider) {
        CreateServicingProviderDTO payload = new CreateServicingProviderDTO();

        List<Integer> specialtyCodes = new ArrayList<>(Arrays.asList(1, 2));

        payload.setSpecialtyCodes(specialtyCodes);
        payload.setAddress(new AddressSearchDTOFactory().setAddressDTO());
        payload.setClientId(clientId);
        payload.setFacilityName(ProviderConstants.FACILITY_NAME);
        payload.setFax(ProviderConstants.FAX);
        payload.setManual(Boolean.parseBoolean(servicingProvider.get("manual")));
        payload.setPhone(ProviderConstants.PHONE);
        payload.setPhysicianFirstName(ProviderConstants.PHY_FIRST_NAME);
        payload.setPhysicianLastName(ProviderConstants.PHY_LAST_NAME);

        return payload;
    }


}
