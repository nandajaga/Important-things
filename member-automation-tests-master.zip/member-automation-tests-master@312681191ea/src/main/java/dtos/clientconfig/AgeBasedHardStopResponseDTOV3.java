package dtos.clientconfig;

public class AgeBasedHardStopResponseDTOV3 {

    private boolean isAgeBasedHardStop;
    private String message;

    public boolean getIsAgeBasedHardStop() {
        return isAgeBasedHardStop;
    }

    public void setIsAgeBasedHardStop(boolean ageBasedHardStop) {
        isAgeBasedHardStop = ageBasedHardStop;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
