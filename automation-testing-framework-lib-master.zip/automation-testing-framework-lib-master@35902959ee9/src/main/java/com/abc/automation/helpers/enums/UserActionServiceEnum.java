package com.abc.automation.helpers.enums;

public enum UserActionServiceEnum {
    MEDICAL_NECESSITY("MEDICAL_NECESSITY"),
    ADMIN_DENIAL("ADMIN_DENIAL"),
    SERVICE_WITHDRAWN("SERVICE_WITHDRAWN"),
    SERVICING_PROVIDER_ADDED("SERVICING_PROVIDER_ADDED"),
    SERVICING_PROVIDER_UPDATED("SERVICING_PROVIDER_UPDATED"),
    MEDICAL_NECESSITY_BUTTON_CLICKED_MET("MEDICAL_NECESSITY_BUTTON_CLICKED_MET"),
    MEDICAL_NECESSITY_BUTTON_CLICKED_NOT_MET("MEDICAL_NECESSITY_BUTTON_CLICKED_NOT_MET"),
    CLEAR_LOI("CLEAR_LOI"),
    REOPEN_LOI("REOPEN_LOI"),
    OTHER_REASON_MANUALLY_SET("OTHER_REASON_MANUALLY_SET");

    private String userActionService;

    UserActionServiceEnum(String userActionService) {
        this.userActionService = userActionService;
    }

    public String getUserActionService() {
        return userActionService;
    }

}
