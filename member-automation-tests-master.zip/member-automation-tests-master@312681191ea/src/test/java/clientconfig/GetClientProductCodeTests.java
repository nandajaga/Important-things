package clientconfig;

import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.clientconfig.ClientProductCodesResponseDTO;
import helpers.dataproviders.DataProviders;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import steps.clientconfig.ClientProductCodeSteps;

import java.util.Arrays;
import java.util.List;

import static helpers.constants.BasePathConstants.BASE_PATH_GET_V2_CLIENT_PRODUCT_CODES;
import static helpers.constants.ClientConfigConstants.*;
import static helpers.constants.Constants.CLIENT_ID_85;
import static helpers.constants.Constants.*;
import static helpers.constants.Constants.LINE_OF_BUSINESS;

/**
 * Created by RKondakova on 7/12/2019.
 */
public class GetClientProductCodeTests extends GetTests {

    @BeforeClass
    public void init() {
        basePath = BASE_PATH_GET_V2_CLIENT_PRODUCT_CODES;
        pathParamsMap.clear();
        pathParamsMap.put("clientId", CLIENT_ID_85);
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test(dataProvider = "clientId-85-186-187-210", dataProviderClass = DataProviders.class)
    public void whenGetClientProductCodeAndValidLineOfBusinessIsSentWithValidClientIdThenValidResponseAndStatus200(String clientId) {
        ClientProductCodeSteps clientProductCodeSteps = new ClientProductCodeSteps(platformContextHeader, headers);
        ClientProductCodesResponseDTO[] clientProductCodesResponseDTOV2 = clientProductCodeSteps.getClientProductCodesRequestPositive(clientId, ISUUANCE_STATE_CODE_TX, LINE_OF_BUSINESS);

        for (ClientProductCodesResponseDTO clientProductCodesResponseDTO : clientProductCodesResponseDTOV2) {
            softly.then(clientProductCodesResponseDTO.getId()).isNotBlank().isNotEmpty().isNotNull();
            softly.then(clientProductCodesResponseDTO.getCode()).isNotBlank().isNotNull().isNotEmpty();
            if (clientId.equals(CLIENT_ID_210)) {
                softly.then(Integer.valueOf(clientProductCodesResponseDTO.getId())).isBetween(START_VALUE_ID, END_VALUE_ID);
                softly.then(clientProductCodesResponseDTO.getDescription()).isNotBlank().isNotNull().isNotEmpty();
            } else if (clientId.equals(CLIENT_ID_186) || clientId.equals(CLIENT_ID_187)) {
                softly.then(clientProductCodesResponseDTO.getDescription()).isNotBlank().isNotNull().isNotEmpty();
            }
        }

        softly.assertAll();
    }

    @Test(dataProvider = "state-of-issuance", dataProviderClass = DataProviders.class)
    public void whenGetClientProductCodeWithValidClientId210AndClientId212AndIssuanceStateThenValidResponseAndStatus200(String clientId, String issuanceState) {
        ClientProductCodeSteps clientProductCodeSteps = new ClientProductCodeSteps(platformContextHeader, headers);
        ClientProductCodesResponseDTO[] clientProductCodesResponseDTOV2 = clientProductCodeSteps.getClientProductCodesRequestPositive(clientId, issuanceState, LINE_OF_BUSINESS);

        for (ClientProductCodesResponseDTO clientProductCodesResponseDTO : clientProductCodesResponseDTOV2) {
            softly.then(clientProductCodesResponseDTO.getId()).isNotEmpty();
            softly.then(clientProductCodesResponseDTO.getCode()).isNotEmpty();
            softly.then(clientProductCodesResponseDTO.getDescription()).isNotEmpty();
        }

        softly.assertAll();
    }

    @Test(dataProvider = "clientId-85-183-184-186-187-188-189-199", dataProviderClass = DataProviders.class)
    public void whenGenClientConfigWithClientIdAndWithoutLineOfBusinessAndWithoutIssuanceStateCodeThenResponseSC200(String clientId) {
        ClientProductCodeSteps clientProductCodeSteps = new ClientProductCodeSteps(platformContextHeader, headers);
        ClientProductCodesResponseDTO[] clientProductCodesResponseDTOV2 = clientProductCodeSteps.getClientProductCodesRequestPositive(clientId, null, null);

        for (ClientProductCodesResponseDTO clientProductCodesResponseDTO : clientProductCodesResponseDTOV2) {
            softly.then(clientProductCodesResponseDTO.getId()).isNotEmpty();
            softly.then(clientProductCodesResponseDTO.getCode()).isNotEmpty();

            if (clientId.equals(CLIENT_ID_85)) {
                softly.then(Integer.valueOf(clientProductCodesResponseDTO.getId())).isBetween(START_VALUE_ID_85, END_VALUE_ID_85);
            }
            else if (clientId.equals(CLIENT_ID_183)) {
                softly.then(Integer.valueOf(clientProductCodesResponseDTO.getId())).isBetween(START_VALUE_ID_183, END_VALUE_ID_183);
            }
            else if (clientId.equals(CLIENT_ID_184)) {
                softly.then(Integer.valueOf(clientProductCodesResponseDTO.getId())).isBetween(START_VALUE_ID_184, END_VALUE_ID_184);
                softly.then(clientProductCodesResponseDTO.getDescription()).isNotEmpty();
            }
            else if (clientId.equals(CLIENT_ID_186)) {
                softly.then(clientProductCodesResponseDTO.getDescription()).isNotEmpty();
            }
            else if (clientId.equals(CLIENT_ID_187)) {
                softly.then(Integer.valueOf(clientProductCodesResponseDTO.getId())).isBetween(START_VALUE_ID_187, END_VALUE_ID_187);
                softly.then(clientProductCodesResponseDTO.getDescription()).isNotEmpty();
            }
            else if (clientId.equals(CLIENT_ID_188)) {
                softly.then(Integer.valueOf(clientProductCodesResponseDTO.getId())).isBetween(START_VALUE_ID_188, END_VALUE_ID_188);
                softly.then(clientProductCodesResponseDTO.getDescription()).isNotEmpty();
            }
            else if (clientId.equals(CLIENT_ID_189)) {
                softly.then(Integer.valueOf(clientProductCodesResponseDTO.getId())).isBetween(START_VALUE_ID_189, END_VALUE_ID_189);
                softly.then(clientProductCodesResponseDTO.getDescription()).isNotEmpty();
            }
            else if (clientId.equals(CLIENT_ID_199)) {
                softly.then(Integer.valueOf(clientProductCodesResponseDTO.getId())).isBetween(START_VALUE_ID_199, END_VALUE_ID_199);
                softly.then(clientProductCodesResponseDTO.getDescription()).isNotEmpty();
            }
        }

        softly.assertAll();
    }

    /* https://jira.aimspecialtyhealth.com/browse/OSPP-5186
     * Created test case to validate new product code "S85300" for clientId 212 and StateOfIssuance CA.
     * Created by VHarugeri on 08/05/2020
     */
    @Test(dataProvider = "clientId212-and-issuance-state-code", dataProviderClass = DataProviders.class)
    public void whenGetClientProductCodeWithValidClientId212AndIssuanceStateThenValidResponseAndStatus200(String clientId, String issuanceState) {
        ClientProductCodeSteps clientProductCodeSteps = new ClientProductCodeSteps(platformContextHeader, headers);
        ClientProductCodesResponseDTO[] clientProductCodesResponseDTOV2 = clientProductCodeSteps.getClientProductCodesRequestPositive(clientId, issuanceState, LINE_OF_BUSINESS);

        for (ClientProductCodesResponseDTO clientProductCodesResponseDTO : clientProductCodesResponseDTOV2) {
            if(clientProductCodesResponseDTO.getId().equals(3051)) {
                softly.then(clientProductCodesResponseDTO.getCode()).isEqualTo("S85300");
                softly.then(clientProductCodesResponseDTO.getDescription().equalsIgnoreCase("CA H8552-030-000 Anthem MediBlue Dual Access (PPO D-SNP) Partial"));
            }
        }
        softly.assertAll();
    }

    /* https://jira.aimspecialtyhealth.com/browse/OSPP-8217
     * Validation of new product codes for clientId_210, lineOfBusiness_MEDICAID & StateOfIssuance_NY.
     */
    @Test(dataProvider = "clientId210-and-issuance-state-code", dataProviderClass = DataProviders.class)
    public void whenGetClientProductCodeWithValidClientId210AndIssuanceStateThenValidResponseAndStatus200(String clientId, String issuanceState) {
        ClientProductCodeSteps clientProductCodeSteps = new ClientProductCodeSteps(platformContextHeader, headers);
        ClientProductCodesResponseDTO[] clientProductCodesResponseDTOV2 = clientProductCodeSteps.getClientProductCodesRequestPositive(clientId, issuanceState, MEDICAID_CODE);

        for (ClientProductCodesResponseDTO clientProductCodesResponseDTO : clientProductCodesResponseDTOV2) {
            softly.then(Integer.valueOf(clientProductCodesResponseDTO.getId())).isBetween(START_ID_CLIENT_210_NY, END_ID_CLIENT_210_NY);
            softly.then(clientProductCodesResponseDTO.getCode()).isNotBlank().isNotNull().isNotEmpty();
            softly.then(clientProductCodesResponseDTO.getDescription()).isNotBlank().isNotNull().isNotEmpty();
        }

        softly.assertAll();
    }

    /**
     * Validation of new product code for clientId-220,StateOfIssuance_NM and LineOfBusiness_MEDICAID
     */
    @Test(dataProvider = "clientId220-and-issuance-state-code", dataProviderClass = DataProviders.class)
    public void whenGetClientProductCodeWithValidClientId220AndIssuanceStateThenValidResponseAndStatus200(String clientId, String issuanceState) {
        ClientProductCodeSteps clientProductCodeSteps = new ClientProductCodeSteps(platformContextHeader, headers);
        ClientProductCodesResponseDTO[] clientProductCodesResponseDTOV2 = clientProductCodeSteps.getClientProductCodesRequestPositive(clientId, issuanceState, MEDICAID_CODE);
        for (ClientProductCodesResponseDTO clientProductCodesResponseDTO : clientProductCodesResponseDTOV2) {
            softly.then(Integer.valueOf(clientProductCodesResponseDTO.getId())).isBetween(START_ID_CLIENT_220_NM, END_ID_CLIENT_220_NM);
            softly.then(clientProductCodesResponseDTO.getCode()).isNotBlank().isNotNull().isNotEmpty();
            softly.then(clientProductCodesResponseDTO.getDescription()).isNotBlank().isNotNull().isNotEmpty();
        }

        softly.assertAll();
    }

    /**
     * Validation of new product code for clientId-233 ,StateOfIssuance_NE and LineOfBusiness_MEDICAID
     */
    @Test(dataProvider = "clientId233-and-issuance-state-code", dataProviderClass = DataProviders.class)
    public void whenGetClientProductCodeWithValidClientId233AndIssuanceStateThenValidResponseAndStatus200(String clientId, String issuanceState) {
        ClientProductCodeSteps clientProductCodeSteps = new ClientProductCodeSteps(platformContextHeader, headers);
        ClientProductCodesResponseDTO[] clientProductCodesResponseDTOV2 = clientProductCodeSteps.getClientProductCodesRequestPositive(clientId, issuanceState, MEDICAID_CODE);

        for (ClientProductCodesResponseDTO clientProductCodesResponseDTO : clientProductCodesResponseDTOV2) {
            softly.then(Integer.valueOf(clientProductCodesResponseDTO.getId())).isBetween(START_ID_CLIENT_233_NE, END_ID_CLIENT_233_NE);
            softly.then(clientProductCodesResponseDTO.getCode()).isNotBlank().isNotNull().isNotEmpty();
            softly.then(clientProductCodesResponseDTO.getDescription()).isNotBlank().isNotNull().isNotEmpty();
        }

        softly.assertAll();
    }

    /**
     * Validation of new product code for clientId-234,StateOfIssuance_MO and LineOfBusiness_MEDICAID
     */
    @Test(dataProvider = "clientId234-and-issuance-state-code", dataProviderClass = DataProviders.class)
    public void whenGetClientProductCodeWithValidClientId234AndIssuanceStateThenValidResponseAndStatus200(String clientId, String issuanceState) {
        ClientProductCodeSteps clientProductCodeSteps = new ClientProductCodeSteps(platformContextHeader, headers);
        ClientProductCodesResponseDTO[] clientProductCodesResponseDTOV2 = clientProductCodeSteps.getClientProductCodesRequestPositive(clientId, issuanceState, MEDICAID_CODE);
        for (ClientProductCodesResponseDTO clientProductCodesResponseDTO : clientProductCodesResponseDTOV2) {
            softly.then(Integer.valueOf(clientProductCodesResponseDTO.getId())).isBetween(START_ID_CLIENT_234_MO, END_ID_CLIENT_234_MO);
            softly.then(clientProductCodesResponseDTO.getCode()).isNotBlank().isNotNull().isNotEmpty();
            softly.then(clientProductCodesResponseDTO.getDescription()).isNotBlank().isNotNull().isNotEmpty();
        }

        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-400---------------------------------------------

    // TODO When bug NCP-24397 is fixed, the negative tests should be uncommented and adjusted
//    @Test(dataProvider = "ClientIdNegative", dataProviderClass =  DataProviders.class)
    public void whenGetClientProductCodeWithInvalidClientIdThenResponseStatus400(String clientId) {
        ClientProductCodeSteps clientProductCodeSteps = new ClientProductCodeSteps(platformContextHeader, headers);

        ErrorDTO error = clientProductCodeSteps.getClientProductCodesRequestErrorDTO(clientId, null);
        softly.then(error.getMessage()).isEqualTo(""/*TODO proper response message*/);
        softly.then(error.getCode()).isEqualTo(""/*TODO proper response code*/);
        softly.assertAll();
    }

    //    @Test(dataProvider = "issuanceStateNegative", dataProviderClass =  DataProviders.class)
    public void whenGetClientProductCode210WithInvalidIssuanceStateThenResponseStatus400(String issuanceState) {
        ClientProductCodeSteps clientProductCodeSteps = new ClientProductCodeSteps(platformContextHeader, headers);

        ErrorDTO error = clientProductCodeSteps.getClientProductCodesRequestErrorDTO(CLIENT_ID_210, issuanceState);
        softly.then(error.getMessage()).isEqualTo(""/*TODO proper response message*/);
        softly.then(error.getCode()).isEqualTo(""/*TODO proper response code*/);
        softly.assertAll();
    }
}
