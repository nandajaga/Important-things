package com.abc.automation.factories.member.demographics;

import com.abc.automation.dtos.member.demographics.AddressesDTO;
import com.abc.automation.helpers.constants.MemberConstants;

import java.util.ArrayList;

/**
 * Created by PPetarcheva on 4/17/2019.
 */
public class AddressesDTOFactory {

    public ArrayList<AddressesDTO> createAddressesDTO() {
        ArrayList<AddressesDTO> list = new ArrayList<>();
        AddressesDTO address = new AddressesDTO();

        address.setAddress1(MemberConstants.ADDRESS_1);
        address.setCity(MemberConstants.CITY_NAME);
        address.setState(MemberConstants.STATE_CODE);
        address.setZipCode(MemberConstants.ZIP_CODE);
        address.setZipExtension(MemberConstants.ZIP_EXTENSION);

        list.add(address);

        return list;
    }
}
