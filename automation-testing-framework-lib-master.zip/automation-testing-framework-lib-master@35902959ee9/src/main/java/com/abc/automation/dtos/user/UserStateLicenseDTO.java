package com.abc.automation.dtos.user;

public class UserStateLicenseDTO {

    private String stateLicenseCode;
    private String stateLicenseNumber;
    private String stateLicenseNumberIssueDate;
    private String stateLicenseNumberExpiryDate;


    public String getStateLicenseCode() {
        return stateLicenseCode;
    }

    public void setStateLicenseCode(String stateLicenseCode) {
        this.stateLicenseCode = stateLicenseCode;
    }

    public String getStateLicenseNumber() {
        return stateLicenseNumber;
    }

    public void setStateLicenseNumber(String stateLicenseNumber) {
        this.stateLicenseNumber = stateLicenseNumber;
    }

    public String getStateLicenseNumberIssueDate() {
        return stateLicenseNumberIssueDate;
    }

    public void setStateLicenseNumberIssueDate(String stateLicenseNumberIssueDate) {
        this.stateLicenseNumberIssueDate = stateLicenseNumberIssueDate;
    }

    public String getStateLicenseNumberExpiryDate() {
        return stateLicenseNumberExpiryDate;
    }

    public void setStateLicenseNumberExpiryDate(String stateLicenseNumberExpiryDate) {
        this.stateLicenseNumberExpiryDate = stateLicenseNumberExpiryDate;
    }
}
