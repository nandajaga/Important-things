package com.abc.automation.helpers;

import com.abc.automation.helpers.convert.GenericConvertHelper;
import com.abc.automation.helpers.enums.RequestHeadersEnum;
import com.abc.servicemodel.domain.PlatformContext;
import com.abc.servicemodel.domain.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Utility methods for operating with the PlatformContext header
 */
public class PlatformContextUtils {
    private GenericConvertHelper converter;

    public PlatformContextUtils() {
        converter = new GenericConvertHelper();
    }


    /**
     * Get the userId from platformContext
     *
     * @param requestSpecification the requestSpecification from which to get the platformContext
     * @return the userId as String
     */
    public String getUserFromPlatformContext(CustomFilterableRequestSpecification requestSpecification) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return getUserFromPlatformContext(platformContextString);
    }

    public String getUserFromPlatformContext(String platformContextString) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);

        return platformContext.getUser().getId();
    }

    /**
     * Update the channelCode in platformContext
     *
     * @param requestSpecification the requestSpecification from which to get the platformContext
     * @param channelCode          the value which will be assigned
     * @return PlatformContext as String
     */
    public String changeChannelCode(CustomFilterableRequestSpecification requestSpecification, String channelCode) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeChannelCode(platformContextString, channelCode);
    }

    public String changeChannelCode(String platformContextString, String channelCode) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);

        platformContext.setChannelCode(channelCode);

        return converter.dtoToString(platformContext);
    }

    /**
     * Update the interactionType in platformContext
     *
     * @param requestSpecification the requestSpecification from which to get the platformContext
     * @param interactionType      the value which will be assigned
     * @return PlatformContext as String
     */
    public String changeInteractionType(CustomFilterableRequestSpecification requestSpecification, String interactionType) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeInteractionType(platformContextString, interactionType);
    }

    public String changeInteractionType(String platformContextString, String interactionType) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);

        platformContext.setInteractionType(interactionType);

        return new GenericConvertHelper().dtoToString(platformContext);
    }

    /**
     * Adds a list of user roles to platformContext's user object
     *
     * @param requestSpecification request specification
     * @param userRoles            user roles as a List<String>
     * @return PlatformContext as String
     */
    public String addUserRoles(CustomFilterableRequestSpecification requestSpecification, List<String> userRoles) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return addUserRoles(platformContextString, userRoles);
    }

    public String addUserRoles(String platformContextString, List<String> userRoles) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);

        platformContext.getUser().setRoles(userRoles);

        return converter.dtoToString(platformContext);
    }

    /**
     * Update the userId in platformContext
     *
     * @param requestSpecification the requestSpecification from which to get the platformContext
     * @param userId               the value which will be assigned
     * @return PLatformContext as String
     */
    public String changeUserId(CustomFilterableRequestSpecification requestSpecification, String userId) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeUserId(platformContextString, userId);
    }

    public String changeUserId(String platformContextString, String userId) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);

        platformContext.getUser().setId(userId);

        return converter.dtoToString(platformContext);
    }

    /**
     * Changes PrimaryRoleCode inside a PlatformContext
     *
     * @param requestSpecification request specification object
     * @param primaryRoleCode      User Primary Role Code
     */
    public String changeUserPrimaryRoleCode(CustomFilterableRequestSpecification requestSpecification, String primaryRoleCode) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeUserPrimaryRoleCode(platformContextString, primaryRoleCode);
    }

    public String changeUserPrimaryRoleCode(String platformContextString, String primaryRoleCode) {
        PlatformContext platformContext = new GenericConvertHelper().stringToDTO(platformContextString, PlatformContext.class);

        platformContext.getUser().setPrimaryRoleCode(primaryRoleCode);

        return converter.dtoToString(platformContext);

    }

    /**
     * Changes case request identifier inside a platformContext
     *
     * @param requestSpecification request specification object
     * @param caseRequestId        case request identifier
     * @return platformContext as string
     */
    public String changeCaseRequestId(CustomFilterableRequestSpecification requestSpecification, String caseRequestId) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeCaseRequestId(platformContextString, caseRequestId);
    }

    public String changeCaseRequestId(String platformContextString, String caseRequestId) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);
        platformContext.getCaseObject().setCaseRequestId(caseRequestId);

        return converter.dtoToString(platformContext);
    }

    /**
     * Changes case identifier inside a platformContext
     *
     * @param requestSpecification request specification object
     * @param caseId               case request identifier
     * @return platformContext as string
     */
    public String changeCaseId(CustomFilterableRequestSpecification requestSpecification, String caseId) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeCaseId(platformContextString, caseId);
    }

    public String changeCaseId(String platformContextString, String caseId) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);
        platformContext.getCaseObject().setCaseId(caseId);

        return converter.dtoToString(platformContext);

    }

    /**
     * Changes clientId inside platform context header of a request specification object.
     *
     * @param requestSpecification request specification object
     * @param clientId             client identifier to change in platform context
     * @return platform context as String
     */
    public String changeClientId(CustomFilterableRequestSpecification requestSpecification, Integer clientId) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeClientId(platformContextString, clientId);
    }

    public String changeClientId(String platformContextString, Integer clientId) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);
        platformContext.getMember().setClientId(clientId);

        return converter.dtoToString(platformContext);
    }

    /**
     * Changes line of business code inside platform context header of a request specification object.
     *
     * @param requestSpecification request specification object
     * @param lineOfBusinessCode   line of business code to change in platform context
     * @return platform context as String
     */
    public String changeLineOfBusinessCode(CustomFilterableRequestSpecification requestSpecification, String lineOfBusinessCode) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeLineOfBusinessCode(platformContextString, lineOfBusinessCode);
    }

    public String changeLineOfBusinessCode(String platformContextString, String lineOfBusinessCode) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);
        platformContext.getMember().getEnrollment().setLineOfBusinessCode(lineOfBusinessCode);

        return converter.dtoToString(platformContext);
    }

    /**
     * Changes jurisdiction code inside platform context header of a request specification object.
     *
     * @param requestSpecification request specification object
     * @param jurisdictionCode     jurisdictionCode to change in platform context
     * @return platform context as String
     */
    public String changeJurisdictionCode(CustomFilterableRequestSpecification requestSpecification, String jurisdictionCode) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeJurisdictionCode(platformContextString, jurisdictionCode);
    }

    public String changeJurisdictionCode(String platformContextString, String jurisdictionCode) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);
        platformContext.getMember().getEnrollment().setJurisdictionCode(jurisdictionCode);

        return converter.dtoToString(platformContext);
    }

    /**
     * Changes issuance state code inside platform context header of a request specification object.
     *
     * @param requestSpecification request specification object
     * @param issuanceStateCode    issuance state code to change in platform context
     * @return platform context as String
     */
    public String changeIssuanceStateCode(CustomFilterableRequestSpecification requestSpecification, String issuanceStateCode) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeIssuanceStateCode(platformContextString, issuanceStateCode);
    }

    public String changeIssuanceStateCode(String platformContextString, String issuanceStateCode) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);
        platformContext.getMember().getEnrollment().setIssuanceStateCode(issuanceStateCode);

        return converter.dtoToString(platformContext);
    }

    /**
     * @param requestSpecification request specification object
     * @param caseCreationDate     case creation date to set in platform context
     * @return platform context as String
     */
    public String changeCaseCreationDate(CustomFilterableRequestSpecification requestSpecification, Date caseCreationDate) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeCaseCreationDate(platformContextString, caseCreationDate);
    }

    public String changeCaseCreationDate(String platformContextString, Date caseCreationDate) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);
        platformContext.getCaseObject().setCreationDate(caseCreationDate);

        return converter.dtoToString(platformContext);
    }

    public String changeCaseReviewCategoryCode(CustomFilterableRequestSpecification requestSpecification, String caseReviewCategoryCode) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeCaseReviewCategoryCode(platformContextString, caseReviewCategoryCode);
    }

    public String changeCaseReviewCategoryCode(String platformContextString, String caseReviewCategoryCode) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);
        platformContext.getCaseObject().setCaseReviewCategoryCode(caseReviewCategoryCode);

        return converter.dtoToString(platformContext);
    }

    /**
     * Change solution identifier inside platform context header
     *
     * @param requestSpecification {@link io.restassured.specification.RequestSpecification}
     * @param solutionId           solution identifier to set in platform context header
     * @return platform context header as String
     */
    public String changeSolutionId(CustomFilterableRequestSpecification requestSpecification, String solutionId) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeSolutionId(platformContextString, solutionId);
    }

    public String changeSolutionId(String platformContextString, String solutionId) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);

        if (solutionId != null) {
            platformContext.getSolution().setId(Integer.valueOf(solutionId));
        } else {
            platformContext.getSolution().setId(null);
        }

        return converter.dtoToString(platformContext);
    }

    /**
     * Change parent solution code inside platform context header
     *
     * @param requestSpecification {@link io.restassured.specification.RequestSpecification}
     * @param parentSolutionCode   parent solution code to set in platform context header
     * @return platform context header as String
     */
    public String changeParentSolutionCode(CustomFilterableRequestSpecification requestSpecification, String parentSolutionCode) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeParentSolutionCode(platformContextString, parentSolutionCode);
    }

    public String changeParentSolutionCode(String platformContextString, String parentSolutionCode) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);

        if (parentSolutionCode != null) {
            platformContext.getSolution().setParentSolutionCode(Integer.valueOf(parentSolutionCode));
        } else {
            platformContext.getSolution().setParentSolutionCode(null);
        }

        return converter.dtoToString(platformContext);
    }

    /**
     * Change organization id inside platform context header
     *
     * @param requestSpecification {@link io.restassured.specification.RequestSpecification}
     * @param organizationId       parent solution code to set in platform context header
     * @return platform context header as String
     */
    public String changeOrganizationId(CustomFilterableRequestSpecification requestSpecification, String organizationId) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeOrganizationId(platformContextString, organizationId);
    }

    public String changeOrganizationId(String platformContextString, String organizationId) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);

        if (organizationId != null) {
            platformContext.setOrganizationId(Integer.valueOf(organizationId));
        } else {
            platformContext.setOrganizationId(null);
        }

        return converter.dtoToString(platformContext);
    }

    public String changeProductCode(CustomFilterableRequestSpecification requestSpecification, String productCode) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeProductCode(platformContextString, productCode);
    }

    public String changeProductCode(String platformContextString, String productCode) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);
        platformContext.getMember().getEnrollment().setProductCode(productCode);

        return converter.dtoToString(platformContext);
    }

    public String changeStateCode(CustomFilterableRequestSpecification requestSpecification, String stateCode) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeStateCode(platformContextString, stateCode);
    }

    public String changeStateCode(String platformContextString, String stateCode) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);
        platformContext.getMember().getLocation().setStateCode(stateCode);

        return converter.dtoToString(platformContext);
    }

    public String changeInteractionId(CustomFilterableRequestSpecification requestSpecification, String interactionId) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeInteractionId(platformContextString, interactionId);
    }

    public String changeInteractionId(String platformContextString, String interactionId) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);
        platformContext.setInteractionId(interactionId);

        return converter.dtoToString(platformContext);
    }

    public String changeNetworkCode(CustomFilterableRequestSpecification requestSpecification, String networkCode) {

        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeNetworkCode(platformContextString, networkCode);
    }

    public String changeNetworkCode(String platformContextString, String networkCode) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);
        platformContext.getMember().getEnrollment().setNetworkCode(networkCode);

        return converter.dtoToString(platformContext);
    }

    public String changeEmployerGroupCode(CustomFilterableRequestSpecification requestSpecification, String employerGroupCode) {

        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeEmployerGroupCode(platformContextString, employerGroupCode);
    }

    public String changeEmployerGroupCode(String platformContextString, String employerGroupCode) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);
        platformContext.getMember().getEnrollment().setEmployerGroupCode(employerGroupCode);

        return converter.dtoToString(platformContext);
    }

    public String changeRequestCreatedDate(CustomFilterableRequestSpecification requestSpecification, Date requestCreatedDate) {

        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeRequestCreatedDate(platformContextString, requestCreatedDate);
    }

    public String changeRequestCreatedDate(String platformContextString, Date requestCreatedDate) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);
        platformContext.getCaseObject().setRequestCreatedDate(requestCreatedDate);

        return converter.dtoToString(platformContext);
    }

    /**
     * @param requestSpecification request specification object
     * @param dateOfService        date of service to set in platform context
     * @return platform context as String
     */
    public String changeDateOfServiceDate(CustomFilterableRequestSpecification requestSpecification, Date dateOfService) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeDateOfServiceDate(platformContextString, dateOfService);
    }

    public String changeDateOfServiceDate(String platformContextString, Date dateOfService) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);
        platformContext.getSolution().setDateOfService(dateOfService);

        return converter.dtoToString(platformContext);
    }

    /**
     * @param requestSpecification CustomFilterableRequestSpecification object that contains the platform context
     * @param contextMode          the value that will be set to contextMode field
     * @return platform context as string
     */
    public String changeContextMode(CustomFilterableRequestSpecification requestSpecification, String contextMode) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeContextMode(platformContextString, contextMode);
    }

    public String changeContextMode(String platformContextString, String contextMode) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);
        platformContext.setContextMode(contextMode);

        return converter.dtoToString(platformContext);
    }

    /**
     * @param requestSpecification CustomFilterableRequestSpecification object that contains the platform context
     * @param userRoles            the value that will be set to userRoles field
     * @return platform context as string
     */
    public String changeUserRoles(CustomFilterableRequestSpecification requestSpecification, List<String> userRoles) {
        String platformContextString = requestSpecification
                .getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeUserRoles(platformContextString, userRoles);
    }

    public String changeUserRoles(String platformContextString, List<String> userRoles) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);
        platformContext.getUser().setRoles(userRoles);

        return converter.dtoToString(platformContext);
    }

    /**
     * Change zipcode identifier inside platform context header
     * sbioi
     *
     * @param requestSpecification {@link io.restassured.specification.RequestSpecification}
     * @param zipCode              zipcode identifier to set in platform context header
     * @return platform context header as String
     */
    public String changeZipCode(CustomFilterableRequestSpecification requestSpecification, String zipCode) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeZipCode(platformContextString, zipCode);
    }

    public String changeZipCode(String platformContextString, String zipCode) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);

        platformContext.getMember().getLocation().setZipCode(zipCode);
        return converter.dtoToString(platformContext);
    }

    public String changeFundingType(CustomFilterableRequestSpecification requestSpecification, String fundingTypeCode) {

        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeFundingType(platformContextString, fundingTypeCode);
    }

    public String changeFundingType(String platformContextString, String fundingTypeCode) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);
        platformContext.getMember().getEnrollment().setFundingTypeCode(fundingTypeCode);

        return converter.dtoToString(platformContext);
    }

    public String changeRootLevelDateOfServiceDate(CustomFilterableRequestSpecification requestSpecification, Date dateOfService) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeRootLevelDateOfServiceDate(platformContextString, dateOfService);
    }

    public String changeRootLevelDateOfServiceDate(String platformContextString, Date dateOfService) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);
        platformContext.setDateOfService(dateOfService);

        return converter.dtoToString(platformContext);
    }

    public String changeTreatmentCode(String platformContextString, String treatmentCode, String treatmentCodeType) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);

        Service service = new Service();
        service.setTreatmentCode(treatmentCode);
        service.setTreatmentCodeType(treatmentCodeType);

        ArrayList<Service> services = new ArrayList<>();
        services.add(service);

        platformContext.setServices(services);

        return converter.dtoToString(platformContext);
    }

    public String changeAlphaPrefixCode(CustomFilterableRequestSpecification requestSpecification, String alphaPrefixCode) {
        String platformContextString = requestSpecification.getFilterableRequestSpecification().getHeaders().getValue(RequestHeadersEnum.PLATFORM_CONTEXT.getName());

        return changeAlphaPrefixCode(platformContextString, alphaPrefixCode);
    }

    public String changeAlphaPrefixCode(String platformContextString, String alphaPrefixCode) {
        PlatformContext platformContext = converter.stringToDTO(platformContextString, PlatformContext.class);

        platformContext.getMember().setAlphaPrefixCode(alphaPrefixCode);
        return converter.dtoToString(platformContext);
    }
}
