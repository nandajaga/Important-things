package dtos.clientconfig;

public class UpdateIsManualAddAllowedResponseDTO {
    private boolean isManualAddAllowed;
    private String message;
    private String script;
    private String scriptLabel;
    private String note;
    private String secondNote;

    public boolean getIsManualAddAllowed() {
        return isManualAddAllowed;
    }

    public void setManualAddAllowed(boolean manualAddAllowed) {
        isManualAddAllowed = manualAddAllowed;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getScript() {
        return script;
    }

    public void setScript(String script) {
        this.script = script;
    }

    public String getScriptLabel() {
        return scriptLabel;
    }

    public void setScriptLabel(String scriptLabel) {
        this.scriptLabel = scriptLabel;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getSecondNote() {
        return secondNote;
    }

    public void setSecondNote(String secondNote) {
        this.secondNote = secondNote;
    }
}
