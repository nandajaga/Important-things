package enrollments.snapshots;

import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.datamanager.MemberResponseDTO;
import dtos.enrollments.MemberEnrollmentsDTO;
import dtos.enrollments.SolutionDTO;
import dtos.enrollments.snapshots.MemberEnrollmentSnapshotDTOV2GetOnly;
import dtos.enrollments.snapshots.MemberEnrollmentsSnapshotDTO;
import helpers.dataproviders.DataProviders;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.datamanager.MemberDataManagerSteps;
import steps.enrollments.MemberEnrollmentsSteps;
import steps.enrollments.snapshots.MemberEnrollmentSnapshotCreateSteps;
import steps.enrollments.snapshots.MemberEnrollmentSnapshotIdSteps;

import java.util.ArrayList;

import static helpers.constants.BasePathConstants.BASE_PATH_GET_ENROLLMENT_SNAPSHOT;
import static helpers.constants.ClientConfigConstants.CLIENT_ID_184;
import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_85;
import static helpers.constants.ConstantsClientIds.*;
import static org.apache.http.HttpStatus.SC_NOT_FOUND;

/**
 * Created by RKondakova on 4/30/2019.
 */
public class GetMemberEnrollmentSnapshotIdTest extends GetTests {

    private MemberEnrollmentSnapshotIdSteps memberEnrollmentSnapshotIdSteps;
    private MemberEnrollmentSnapshotCreateSteps memberEnrollmentSnapshotCreateSteps;
    private MemberEnrollmentsSteps memberEnrollmentsSteps;
    private MemberDataManagerSteps memberDataManagerSteps;
    private String client_test = "TST";
    private String CLIENT_MEMBER_ID;

    @BeforeMethod
    public void initMethod() {
        CLIENT_MEMBER_ID = RandomStringUtils.randomNumeric(10) + RandomStringUtils.randomAlphabetic(5).toUpperCase();
    }

    @BeforeClass
    public void init() {
        basePath = BASE_PATH_GET_ENROLLMENT_SNAPSHOT;

        pathParamsMap.clear();
        pathParamsMap.put("clientId", CLIENT_ID_85);
        pathParamsMap.put("snapshotId", MEMBER_ID_REAL);
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test(dataProvider = "clientId-85-184", dataProviderClass = DataProviders.class)
    public void whenGetAndValidClientId85AndValidSnapshotIdSentThenServiceReturnSnapshot(String clientId) {
        MemberEnrollmentsSnapshotDTO memberEnrollmentsSnapshotDTO = new MemberEnrollmentsSnapshotDTO();
        MemberEnrollmentSnapshotDTOV2GetOnly memberEnrollmentSnapshotDTOV2GetOnly = new MemberEnrollmentSnapshotDTOV2GetOnly();
        memberEnrollmentSnapshotCreateSteps = new MemberEnrollmentSnapshotCreateSteps(platformContextHeader, headers);
        memberEnrollmentSnapshotIdSteps = new MemberEnrollmentSnapshotIdSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(clientId, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(clientId, memberId);

        String enrollmentId = memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId();

        memberEnrollmentsSnapshotDTO = memberEnrollmentSnapshotCreateSteps.createMemberEnrollmentSnapshot(clientId, memberId, enrollmentId);

        String snapshotId = memberEnrollmentsSnapshotDTO.getSnapshotId();
        softly.then(snapshotId).isNotEmpty().isNotBlank().isNotNull();

        memberEnrollmentSnapshotDTOV2GetOnly = memberEnrollmentSnapshotIdSteps.getMemberEnrollmentSnapshotId(clientId, snapshotId);

        if (clientId.equals(CLIENT_ID_184)) {
            softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getClientMemberProductCode()).isEqualTo(CLIENT_MEMBER_PRODUCT_CODE);
            softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getClientSpecificEnrollments().getMixerCode()).isEqualTo(MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAGHMO);
            softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMixerCode()).isEqualTo(MIXER_CODE_CLIENTID_184_PRODUCTCODE_VAGHMO);
            softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientMemberProductCode()).isEqualTo(CLIENT_MEMBER_PRODUCT_CODE);
            softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getErisaIndicator()).isNull();
            softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMarketSegmentCode()).isNull();

        } else {
            softly.then(memberEnrollmentsSnapshotDTO.getSnapshotId()).contains(snapshotId);
            softly.then(memberEnrollmentSnapshotDTOV2GetOnly.getSnapshotId()).contains(snapshotId);
            softly.then(memberEnrollmentSnapshotDTOV2GetOnly.getEnrollmentId()).contains(enrollmentId);
            softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getEnrollmentId()).contains(enrollmentId);
            softly.then(memberEnrollmentSnapshotDTOV2GetOnly.getClientId()).contains(clientId);
            softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getClientId()).contains(clientId);
            softly.then(memberEnrollmentSnapshotDTOV2GetOnly.getHealthPlan()).contains(HEALTHPLAN_AUTHEM_CR);
            softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getHealthPlan()).contains(HEALTHPLAN_AUTHEM_CR);
            softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getErisaIndicator()).isNull();
            softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMarketSegmentCode()).isNull();

        }
        softly.assertAll();
    }

    @Test
    public void whenGetAndValidClientId186AndValidSnapshotIdSentThenServiceReturnSnapshot() {
        MemberEnrollmentsSnapshotDTO memberEnrollmentsSnapshotDTO = new MemberEnrollmentsSnapshotDTO();
        MemberEnrollmentSnapshotDTOV2GetOnly memberEnrollmentSnapshotDTOV2GetOnly = new MemberEnrollmentSnapshotDTOV2GetOnly();
        memberEnrollmentSnapshotCreateSteps = new MemberEnrollmentSnapshotCreateSteps(platformContextHeader, headers);
        memberEnrollmentSnapshotIdSteps = new MemberEnrollmentSnapshotIdSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_186, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_186, memberId);

        String enrollmentId = memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId();

        memberEnrollmentsSnapshotDTO = memberEnrollmentSnapshotCreateSteps.createMemberEnrollmentSnapshot(CLIENT_ID_186, memberId, enrollmentId);

        String snapshotId = memberEnrollmentsSnapshotDTO.getSnapshotId();
        softly.then(snapshotId).isNotEmpty().isNotBlank().isNotNull();

        memberEnrollmentSnapshotDTOV2GetOnly = memberEnrollmentSnapshotIdSteps.getMemberEnrollmentSnapshotId(CLIENT_ID_186, snapshotId);

        softly.then(memberEnrollmentsSnapshotDTO.getSnapshotId()).contains(snapshotId);
        softly.then(memberEnrollmentSnapshotDTOV2GetOnly.getSnapshotId()).contains(snapshotId);
        softly.then(memberEnrollmentSnapshotDTOV2GetOnly.getEnrollmentId()).contains(enrollmentId);
        softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getEnrollmentId()).contains(enrollmentId);
        softly.then(memberEnrollmentSnapshotDTOV2GetOnly.getClientId()).contains(CLIENT_ID_186);
        softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getClientId()).contains(CLIENT_ID_186);
        softly.then(memberEnrollmentSnapshotDTOV2GetOnly.getHealthPlan()).contains(HEALTHPLAN_AUTHEM_BC);
        softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getHealthPlan()).contains(HEALTHPLAN_AUTHEM_BC);
        softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getClientMemberProductCode()).isEqualTo(CLIENT_MEMBER_PRODUCT_CODE);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientMemberProductCode()).isEqualTo(CLIENT_MEMBER_PRODUCT_CODE);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getErisaIndicator()).isNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMarketSegmentCode()).isNull();

        softly.assertAll();
    }

    @Test
    public void whenGetAndValidClientId210WIAndValidSnapshotIdSentThenServiceReturnSnapshot() {
        MemberEnrollmentsSnapshotDTO memberEnrollmentsSnapshotDTO = new MemberEnrollmentsSnapshotDTO();
        MemberEnrollmentSnapshotDTOV2GetOnly memberEnrollmentSnapshotDTOV2GetOnly = new MemberEnrollmentSnapshotDTOV2GetOnly();
        memberEnrollmentSnapshotCreateSteps = new MemberEnrollmentSnapshotCreateSteps(platformContextHeader, headers);
        memberEnrollmentSnapshotIdSteps = new MemberEnrollmentSnapshotIdSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_210, ISSUANCE_STATE_WI, SS_WGS, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_210, memberId);

        String enrollmentId = memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId();

        memberEnrollmentsSnapshotDTO = memberEnrollmentSnapshotCreateSteps.createMemberEnrollmentSnapshot(CLIENT_ID_210, memberId, enrollmentId);
        String snapshotId = memberEnrollmentsSnapshotDTO.getSnapshotId();
        softly.then(snapshotId).isNotEmpty().isNotBlank().isNotNull();

        memberEnrollmentSnapshotDTOV2GetOnly = memberEnrollmentSnapshotIdSteps.getMemberEnrollmentSnapshotId(CLIENT_ID_210, snapshotId);

        softly.then(memberEnrollmentsSnapshotDTO.getSnapshotId()).contains(snapshotId);
        softly.then(memberEnrollmentSnapshotDTOV2GetOnly.getSnapshotId()).contains(snapshotId);
        softly.then(memberEnrollmentSnapshotDTOV2GetOnly.getEnrollmentId()).contains(enrollmentId);
        softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getEnrollmentId()).contains(enrollmentId);
        softly.then(memberEnrollmentSnapshotDTOV2GetOnly.getClientId()).contains(CLIENT_ID_210);
        softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getClientId()).contains(CLIENT_ID_210);
        softly.then(memberEnrollmentSnapshotDTOV2GetOnly.getHealthPlan()).contains(HEALTHPLAN_ANTHEM_BCBS_WI);
        softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getHealthPlan()).contains(HEALTHPLAN_ANTHEM_BCBS_WI);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getErisaIndicator()).isNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMarketSegmentCode()).isNull();
        softly.assertAll();
    }

    @Test
    public void whenGetAndValidClientId210FLAndValidSnapshotIdSentThenServiceReturnSnapshot() {
        MemberEnrollmentsSnapshotDTO memberEnrollmentsSnapshotDTO = new MemberEnrollmentsSnapshotDTO();
        MemberEnrollmentSnapshotDTOV2GetOnly memberEnrollmentSnapshotDTOV2GetOnly = new MemberEnrollmentSnapshotDTOV2GetOnly();
        memberEnrollmentSnapshotCreateSteps = new MemberEnrollmentSnapshotCreateSteps(platformContextHeader, headers);
        memberEnrollmentSnapshotIdSteps = new MemberEnrollmentSnapshotIdSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_210, ISSUANCE_STATE_FL, SS_WGS, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_210, memberId);

        String enrollmentId = memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId();

        memberEnrollmentsSnapshotDTO = memberEnrollmentSnapshotCreateSteps.createMemberEnrollmentSnapshot(CLIENT_ID_210, memberId, enrollmentId);
        String snapshotId = memberEnrollmentsSnapshotDTO.getSnapshotId();
        softly.then(snapshotId).isNotEmpty().isNotBlank().isNotNull();

        memberEnrollmentSnapshotDTOV2GetOnly = memberEnrollmentSnapshotIdSteps.getMemberEnrollmentSnapshotId(CLIENT_ID_210, snapshotId);

        softly.then(memberEnrollmentsSnapshotDTO.getSnapshotId()).contains(snapshotId);
        softly.then(memberEnrollmentSnapshotDTOV2GetOnly.getSnapshotId()).contains(snapshotId);
        softly.then(memberEnrollmentSnapshotDTOV2GetOnly.getEnrollmentId()).contains(enrollmentId);
        softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getEnrollmentId()).contains(enrollmentId);
        softly.then(memberEnrollmentSnapshotDTOV2GetOnly.getClientId()).contains(CLIENT_ID_210);
        softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getClientId()).contains(CLIENT_ID_210);
        softly.then(memberEnrollmentSnapshotDTOV2GetOnly.getHealthPlan()).contains(HEALTHPLAN_AMERIGROUP_FL);
        softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getHealthPlan()).contains(HEALTHPLAN_AMERIGROUP_FL);
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getErisaIndicator()).isNull();
        softly.then(memberEnrollmentsDTO.getEnrollments().get(0).getClientSpecificEnrollments().getMarketSegmentCode()).isNull();
        softly.assertAll();
    }


    @Test(dataProvider = "clientId-85-183-184-186-187-188-189-199", dataProviderClass = DataProviders.class)
    public void whenGetAndValidClientId85AndValidSnapshotIdSentThenServiceReturnSnapshotWithReviewProgramCodes(String clientId) {
        MemberEnrollmentsSnapshotDTO memberEnrollmentsSnapshotDTO = new MemberEnrollmentsSnapshotDTO();
        MemberEnrollmentSnapshotDTOV2GetOnly memberEnrollmentSnapshotDTOV2GetOnly = new MemberEnrollmentSnapshotDTOV2GetOnly();
        memberEnrollmentSnapshotCreateSteps = new MemberEnrollmentSnapshotCreateSteps(platformContextHeader, headers);
        memberEnrollmentSnapshotIdSteps = new MemberEnrollmentSnapshotIdSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(clientId, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(clientId, memberId);

        String enrollmentId = memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId();

        memberEnrollmentsSnapshotDTO = memberEnrollmentSnapshotCreateSteps.createMemberEnrollmentSnapshot(clientId, memberId, enrollmentId);

        String snapshotId = memberEnrollmentsSnapshotDTO.getSnapshotId();
        softly.then(snapshotId).isNotEmpty().isNotBlank().isNotNull();

        memberEnrollmentSnapshotDTOV2GetOnly = memberEnrollmentSnapshotIdSteps.getMemberEnrollmentSnapshotId(clientId, snapshotId);

        softly.then(memberEnrollmentsSnapshotDTO.getSnapshotId()).contains(snapshotId);
        softly.then(memberEnrollmentSnapshotDTOV2GetOnly.getSnapshotId()).contains(snapshotId);
        softly.then(memberEnrollmentSnapshotDTOV2GetOnly.getEnrollmentId()).contains(enrollmentId);
        softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getEnrollmentId()).contains(enrollmentId);
        softly.then(memberEnrollmentSnapshotDTOV2GetOnly.getClientId()).contains(clientId);
        softly.then(memberEnrollmentsSnapshotDTO.getMemberEnrollment().getClientId()).contains(clientId);

        ArrayList<SolutionDTO> solutions = memberEnrollmentSnapshotDTOV2GetOnly.getSolutions();
        for (SolutionDTO solution : solutions) {
            switch (solution.getSolutionId()) {
                case SOLUTION_ID_15:
                case SOLUTION_ID_16:
                case SOLUTION_ID_17:
                    softly.then(solution.getReviewPrograms().get(0).getReviewProgramCode()).isEqualTo(REVIEW_PROGRAM_CODE_SOC);
                    break;
                case SOLUTION_ID_1:
                case SOLUTION_ID_2:
                case SOLUTION_ID_3:
                case SOLUTION_ID_11:
                case SOLUTION_ID_12:
                case SOLUTION_ID_6:
                case SOLUTION_ID_7:
                case SOLUTION_ID_8:
                case SOLUTION_ID_9:
                    softly.then(solution.getReviewPrograms()).isNull();
                    break;
            }
        }

        softly.assertAll();
    }

    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-404---------------------------------------------
//Todo this test is legal, but due to BUG https://jira.aimspecialtyhealth.com/browse/NCP-20854 it will fail. Uncomment once the bug is fixed.
//    @Test
    public void whenGetAndInvalidClientIdAndValidSnapshotIdSentThenServiceReturnsError() {
        MemberEnrollmentsSnapshotDTO memberEnrollmentsSnapshotDTO = new MemberEnrollmentsSnapshotDTO();
        MemberEnrollmentSnapshotDTOV2GetOnly memberEnrollmentSnapshotDTOV2GetOnly = new MemberEnrollmentSnapshotDTOV2GetOnly();
        memberEnrollmentSnapshotCreateSteps = new MemberEnrollmentSnapshotCreateSteps(platformContextHeader, headers);
        memberEnrollmentSnapshotIdSteps = new MemberEnrollmentSnapshotIdSteps(platformContextHeader, headers);
        memberEnrollmentsSteps = new MemberEnrollmentsSteps(platformContextHeader, headers);
        memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);

        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_210, CLIENT_MEMBER_ID);
        String memberId = memberResponseDTO.getId();

        MemberEnrollmentsDTO memberEnrollmentsDTO = memberEnrollmentsSteps.getMemberEnrollments(CLIENT_ID_210, memberId);

        String enrollmentId = memberEnrollmentsDTO.getEnrollments().get(0).getEnrollmentId();
        softly.then(enrollmentId).isNotEmpty().isNotBlank().isNotNull();

        pathParamsMap.put("enrollmentId", enrollmentId);
        memberEnrollmentsSnapshotDTO = memberEnrollmentSnapshotCreateSteps.createMemberEnrollmentSnapshot(CLIENT_ID_210, memberId, enrollmentId);
        String snapshotId = memberEnrollmentsSnapshotDTO.getSnapshotId();
        softly.then(snapshotId).isNotEmpty().isNotBlank().isNotNull();

        pathParamsMap.clear();
        pathParamsMap.put("clientId", client_test);
        pathParamsMap.put("snapshotId", snapshotId);

        ErrorDTO error = memberEnrollmentSnapshotIdSteps.getMemberEnrollmentSnapshotIdErrors(platformContextHeader, snapshotId);

        softly.then(error.getCode()).isEqualTo(SC_NOT_FOUND);
        softly.then(error.getMessage()).contains(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }

    @Test
    public void whenGetAndValidClientIdAndInvalidSnapshotIdSentThenServiceReturnsError() {
        memberEnrollmentSnapshotIdSteps = new MemberEnrollmentSnapshotIdSteps(platformContextHeader, headers);

        ErrorDTO error = memberEnrollmentSnapshotIdSteps.getMemberEnrollmentSnapshotIdErrors(CLIENT_ID_85, SNAPSHOT_ID_TEST);

        softly.then(error.getCode()).isEqualTo(SC_NOT_FOUND);
        softly.then(error.getMessage()).contains(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }
}
