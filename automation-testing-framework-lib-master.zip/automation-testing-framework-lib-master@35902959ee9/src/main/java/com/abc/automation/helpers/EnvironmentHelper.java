package com.abc.automation.helpers;

import com.abc.automation.helpers.enums.DomainEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static io.restassured.RestAssured.baseURI;

/**
 * Created by PPetarcheva on 4/18/2019.
 */
public class EnvironmentHelper {

    private static final Logger LOGGER = LoggerFactory.getLogger(EnvironmentHelper.class);

    private static final String ENVIRONMENT_CONFIG = "environment.properties";

    /**
     * Constructs the base uri per domain and depending on the environment
     *
     * @param domain - the domain name for which the base uri is needed
     * @return the base uri based on the domain and environment
     */
    public String constructBaseURIForDomain(DomainEnum domain) {

        for (DomainEnum d : DomainEnum.values()) {
            if (baseURI.contains(d.getName())) {
                return baseURI.replace(d.getName(), domain.getName());
            }
        }

        LOGGER.error("Error when constructing baseURI for {}", domain.getName());

        return null;
    }
}
