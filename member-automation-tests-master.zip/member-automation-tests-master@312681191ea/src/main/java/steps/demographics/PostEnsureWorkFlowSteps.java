package steps.demographics;

import com.aim.automation.dtos.ErrorDTO;
import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.workflow.MemberDemographicWorkflowResDTO;
import factories.workflow.DemographicEnsureWorkflowDTOFactory;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import static helpers.constants.BasePathConstants.BASE_PATH_POST_ENSUREWORKFLOW;


/**
 * Created by @sbioi on 05/15/2020
 */
public class PostEnsureWorkFlowSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public PostEnsureWorkFlowSteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BASE_PATH_POST_ENSUREWORKFLOW);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    public Response postEnsureWorkFlow(String subClientCode) {
        Object payLoad = new DemographicEnsureWorkflowDTOFactory().createDisasterDTO(subClientCode);
        requestSpecification.addBodyToRequest(payLoad);

        return requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());
    }

    public MemberDemographicWorkflowResDTO postEnsureWorkFlowStep(String subClientCode) {

        Response response = postEnsureWorkFlow(subClientCode);
        response.then().statusCode(HttpStatus.SC_OK);
        return response.as(MemberDemographicWorkflowResDTO.class);

    }

    public ErrorDTO whenCaseRequestIdIsNullSendError(String subClientCode) {
        Response response = postEnsureWorkFlow(subClientCode);
        return response.as(ErrorDTO.class);
    }

    public Response whenCaseIdIsNotNullSendError(String subClientCode) {
        requestSpecification.setContentType(ContentType.JSON);

        return postEnsureWorkFlow(subClientCode);
    }
}
