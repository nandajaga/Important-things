package com.abc.automation.helpers;

import com.abc.automation.helpers.convert.GenericConvertHelper;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;

public class EditDTOHelper {

    /**
     * Changes the value of a specific field of an object or the value of a field of a nested object
     * Note: this can not be used to change values of fields in Collections of objects
     *
     * @param object - the object (e.g. user dto)
     * @param field  - the field that you want changed (e.g. "firstName")
     * @param value  - the value that you want (e.g. "Manoela")
     */
    public void changeSpecificFieldValueInDTO(Object object, String field, String value) {
//    - used to change the value of a specific field of an object. Pass the object (e.g. user), the field that you want changed (e.g. "firstName") and the value that you want (e.g. "Manoela"). This method will set the firstName of your user to Manoela.
//    - changeSpecificFieldValueInDTO(user, "lastName", "Georigeva") it will change the lastName of your user.
//    - used in a loop and in each iteration pass in different fields and values. changeSpecificFieldValueInDTO(user, field, value) where field is a list containing: firstName, lastName, username and value = "testValue". If you loop through the field list, you will have: first iteration: user with firstName of testValue; second iteration: user with lastName of testValue; third iteration: user with username of testValue. This is very convenient when you want to test the validations of different fields in a json.
//    - used to change the value of a field of a nested object. Eg: User has a UserRoleDTO role. UserRoleDTO has a roleName. You can use this method, pass in user, "role.roleName", "Manager" and it will set the role name in the role of your user to Manager.
//    - Note: you can not use this method to change values of fields in Collections of objects (e.g. if your user has a List<UserRoleDTO> you can not change the values in that list. )

        Field rootObjectField = null;
        Object rootObject = object;
        Class<?> rootClassType = object.getClass();

        if (field.contains(".")) {
            String[] fieldPath = field.split("\\.");
            StringBuilder processedFields = new StringBuilder();

            for (String objectFieldName : fieldPath) {
                processedFields.append(objectFieldName).append('.');
                Field innerObjectField = ReflectionUtils.findField(rootClassType, objectFieldName);

                Object innerObject;

                try {
                    ReflectionUtils.makeAccessible(innerObjectField);
                    innerObject = innerObjectField.get(rootObject);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException("Can not set value for object: ", e);
                }

                Class<?> innerClassType = innerObjectField.getType();
                boolean isCustomClassType = !innerClassType.getName().contains("java.lang");

                if (isCustomClassType) {
                    if (innerObject == null) {
                        try {
                            innerObject = innerClassType.newInstance();
                            innerObjectField.set(rootObject, innerObject);
                        } catch (InstantiationException | IllegalAccessException e) {
                            throw new RuntimeException("Can't create a new instance of " + innerClassType.getSimpleName(), e);
                        }
                    }

                    rootObject = innerObject;
                }

                rootClassType = innerObjectField.getType();
                rootObjectField = innerObjectField;
            }

            processedFields.setLength(0);
        } else {
            rootObjectField = ReflectionUtils.findField(rootClassType, field);
        }

        if (rootObjectField != null && rootObject != null) {
            ReflectionUtils.makeAccessible(rootObjectField);
            ReflectionUtils.setField(rootObjectField, rootObject, value);
        }
    }

    /**
     * Will remove the filedToRemove from the Object and will return a String of the Object without the fieldToRemove.
     * The filedToRemove must have a null value!
     *
     * @param object        - the object (e.g. user dto)
     * @param fieldToRemove - the field that should be removed (e.g. username)
     * @return - String representation on the user dto without its username
     */
    public String removeNullFieldFromJsonString(Object object, String fieldToRemove) {
        String json = new GenericConvertHelper().dtoToString(object);
        int startIndex;
        if (fieldToRemove.contains(".")) { //if a nested field is passed, e.g member.location.stateCode this will take the start index of the first stateCode after location
            long numberOfObjecs = fieldToRemove.chars().filter(ch -> ch == '.').count();
            String objectField = "";

            for (int i = 0; i < numberOfObjecs; i++) {
                objectField = fieldToRemove.substring(0, fieldToRemove.indexOf('.'));
                fieldToRemove = fieldToRemove.substring(fieldToRemove.indexOf('.') + 1);

            }
            startIndex = json.indexOf(fieldToRemove, json.indexOf(objectField)) - 1;
        } else {
            startIndex = json.indexOf(fieldToRemove) - 1;
        }
        //Adding 7 to the end index as there are 7 chars that need to be removed after the last char of the fieldToRemove. E.g. from "fieldToRemove": null,  you have to remove ": null as well
        int endIndex = startIndex + fieldToRemove.length() + 7;

        //if an extra comma after the field is left, remove it
        if ((json.charAt(endIndex) == ',')) {
            endIndex += 1;
        }
        //if an extra comma before the field is left, remove it
        else if ((json.charAt(startIndex - 1) == ',') && (json.charAt(endIndex) != ',')) {
            startIndex -= 1;
        }

        return json.substring(0, startIndex) + json.substring(endIndex);
    }
}
