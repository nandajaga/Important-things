package com.abc.automation.factories.platformcontext;

import com.abc.servicemodel.domain.Enrollment;
import com.abc.servicemodel.domain.Location;
import com.abc.servicemodel.domain.Member;

import static com.abc.automation.helpers.constants.PlatformContextConstants.PC_MEMBER_CLIENT_ID;

public class MemberDTOFactory {

    public Member createMemberDTO(Integer clientId, Location location, Enrollment enrollment) {
        Member member = new Member();

        member.setClientId(clientId);
        member.setLocation(location);
        member.setEnrollment(enrollment);

        return member;
    }

    public Member createMemberDTO() {
        Location location = new LocationDTOFactory().createLocationPCDTO();
        Enrollment enrollment = new EnrollmentPCDTOFactory().createEnrollmentPCDTO();
        return createMemberDTO(PC_MEMBER_CLIENT_ID, location, enrollment);
    }
}
