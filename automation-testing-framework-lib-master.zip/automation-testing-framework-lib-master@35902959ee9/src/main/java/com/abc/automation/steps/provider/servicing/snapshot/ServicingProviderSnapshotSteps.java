package com.abc.automation.steps.provider.servicing.snapshot;

import com.abc.automation.factories.provider.snapshot.CreateServicingProviderSnapshotDTOFactory;
import com.abc.automation.helpers.CustomFilterableRequestSpecification;
import com.abc.automation.helpers.EnvironmentHelper;
import com.abc.automation.helpers.constants.BasePathConstants;
import com.abc.automation.helpers.constants.PrepareHeadersWithUUID;
import com.abc.automation.helpers.enums.DomainEnum;
import com.abc.automation.dtos.provider.servicing.ServicingProviderSnapshotResponseDTO;
import com.abc.automation.helpers.RequestOperationsHelper;
import com.abc.automation.steps.provider.servicing.CreateServicingProviderSteps;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
public class ServicingProviderSnapshotSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public ServicingProviderSnapshotSteps(String platformContext, Headers headers) {
        headers = new PrepareHeadersWithUUID().prepareHeaderWithUUID();
        requestSpecification = new CustomFilterableRequestSpecification();
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.addHeaders(headers);
        requestSpecification.setContentType(ContentType.JSON);
    }

    public ServicingProviderSnapshotSteps(CustomFilterableRequestSpecification requestSpecification) {
        Headers headers = new PrepareHeadersWithUUID().prepareHeaderWithUUID();

        this.requestSpecification = new CustomFilterableRequestSpecification();
        requestOperationsHelper = new RequestOperationsHelper();

        this.requestSpecification.addHeaders(headers);
        this.requestSpecification.setContentType(ContentType.JSON);

    }

    public Response createServicingProviderSnapshotResponse(int clientId) {
        Map<String, String> manualProvider = new HashMap<>();
        manualProvider.put("manual", "true");

        return createServicingProviderSnapshotResponse(clientId, manualProvider);
    }

    public Response createServicingProviderSnapshotResponse(int clientId, Map<String, String> servicingProvider) {
        CreateServicingProviderSteps createServicingProviderSteps = new CreateServicingProviderSteps(requestSpecification);
        String ngProviderId = createServicingProviderSteps.createServicingProviderAndGetNgProviderId(clientId, servicingProvider);
        Integer providerClientId = createServicingProviderSteps.createServicingProviderAndGetClientProviderId(clientId, servicingProvider);

        EnvironmentHelper environmentHelper = new EnvironmentHelper();

        requestSpecification.addBasePath(BasePathConstants.PROVIDER_CREATE_SERVICING_SNAPSHOT_BASE_PATH);
        requestSpecification.addBaseURI(environmentHelper.constructBaseURIForDomain(DomainEnum.PROVIDER));

        CreateServicingProviderSnapshotDTOFactory createServicingProviderSnapshotDTOFactory = new CreateServicingProviderSnapshotDTOFactory();

        Object body = createServicingProviderSnapshotDTOFactory.createServicingProviderSnapshotDTO(providerClientId, ngProviderId, servicingProvider);
        requestSpecification.addBodyToRequest(body);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        // TODO: Temporary fix for ESS search for provider. Remove when the bug is fixed - NCP-27111
        int count = 0;

        while (result.statusCode() == HttpStatus.SC_NOT_FOUND && count < 30) {
            count++;

            try {
                Thread.sleep(10000);
            } catch (InterruptedException e) {
                // No need to do anything here
                Thread.currentThread().interrupt();
            }

            result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());
        }

        return result;
    }


    public ServicingProviderSnapshotResponseDTO createServicingProviderSnapshot(int clientId) {
        Response result = createServicingProviderSnapshotResponse(clientId);

        result.then().statusCode(HttpStatus.SC_CREATED);

        return result.getBody().as(ServicingProviderSnapshotResponseDTO.class);
    }

    public ServicingProviderSnapshotResponseDTO createServicingProviderSnapshot(int clientId, Map<String, String> servicingProvider) {
        Response result = createServicingProviderSnapshotResponse(clientId, servicingProvider);

        result.then().statusCode(HttpStatus.SC_CREATED);

        return result.getBody().as(ServicingProviderSnapshotResponseDTO.class);
    }

    public String createServicingProviderSnapshotAndSnapshotId(int clientId) {
        return createServicingProviderSnapshot(clientId).getSnapshotId();
    }


    public String createServicingProviderSnapshotAndSnapshotId(int clientId, Map<String, String> servicingProvider) {
        return createServicingProviderSnapshot(clientId, servicingProvider).getSnapshotId();
    }
}
