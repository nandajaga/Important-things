package clientconfig;

import com.aim.automation.tests.base.GetTests;
import dtos.clientconfig.ClientConfigReferencesResponseDTO;
import helpers.dataproviders.DataProviders;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import steps.clientconfig.ClientReferencesSteps;

import static helpers.constants.BasePathConstants.BASE_PATH_CLIENT_REFERENCES;
import static helpers.constants.ClientConfigConstants.*;
import static helpers.constants.Constants.DEFAULT_CLIENT_ID;

/**
 * Created by IAntonova on 7/3/2019.
 */

public class GetClientReferencesTests extends GetTests {

    @BeforeClass
    public void init() {
        basePath = BASE_PATH_CLIENT_REFERENCES;
        pathParamsMap.clear();
        pathParamsMap.put("clientId", CLIENT_ID_85);
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test(dataProvider = "clientIdAll", dataProviderClass = DataProviders.class)
    public void whenGetManuallyAddedMemberWithValidClientIdThenServiceResponseIs200(String clientId) {
        ClientReferencesSteps clientReferencesSteps = new ClientReferencesSteps(platformContextHeader, headers);
        ClientConfigReferencesResponseDTO configReferencesResponseDTO = clientReferencesSteps.getClientReferences(clientId);

        switch (clientId) {
            case CLIENT_ID_40:
            case CLIENT_ID_55:
            case DEFAULT_CLIENT_ID:
                softly.then(configReferencesResponseDTO.getAllowedBusinessIndicators()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedStatesOfIssuance()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedClientDependentRelationCodes()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedFundingTypes()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedLinesOfBusiness()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedNetworkCodes()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedSourceSystems()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedProgramTypes()).isNull();
                break;
            case CLIENT_ID_85:
                softly.then(configReferencesResponseDTO.getAllowedBusinessIndicators()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedStatesOfIssuance()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedClientDependentRelationCodes()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedFundingTypes()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedLinesOfBusiness()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedNetworkCodes()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedSourceSystems()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedProgramTypes()).isNotNull();
                break;
            case CLIENT_ID_183:
                softly.then(configReferencesResponseDTO.getAllowedBusinessIndicators()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedStatesOfIssuance()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedClientDependentRelationCodes()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedFundingTypes()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedLinesOfBusiness()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedNetworkCodes()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedSourceSystems()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedProgramTypes()).isNotNull();
                break;
            case CLIENT_ID_184:
            case CLIENT_ID_185:
            case CLIENT_ID_186:
                softly.then(configReferencesResponseDTO.getAllowedBusinessIndicators()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedStatesOfIssuance()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedClientDependentRelationCodes()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedFundingTypes()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedLinesOfBusiness()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedNetworkCodes()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedSourceSystems()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedProgramTypes()).isNotNull();
                break;
            case CLIENT_ID_187:
            case CLIENT_ID_188:
            case CLIENT_ID_189:
            case CLIENT_ID_199:
                softly.then(configReferencesResponseDTO.getAllowedBusinessIndicators()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedNetworkCodes()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedStatesOfIssuance()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedClientDependentRelationCodes()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedFundingTypes()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedLinesOfBusiness()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedSourceSystems()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedProgramTypes()).isNotNull();
                break;
            case CLIENT_ID_210:
                softly.then(configReferencesResponseDTO.getAllowedBusinessIndicators()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedNetworkCodes()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedFundingTypes()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedSourceSystems()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedStatesOfIssuance()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedClientDependentRelationCodes()).isNotNull();
                softly.then(configReferencesResponseDTO.getAllowedLinesOfBusiness()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedProgramTypes()).isNotNull();
                break;
            default:
                softly.then(configReferencesResponseDTO.getAllowedBusinessIndicators()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedStatesOfIssuance()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedClientDependentRelationCodes()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedFundingTypes()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedLinesOfBusiness()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedNetworkCodes()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedSourceSystems()).isNull();
                softly.then(configReferencesResponseDTO.getAllowedProgramTypes()).isNull();
                break;
        }

        softly.assertAll();
    }
}

