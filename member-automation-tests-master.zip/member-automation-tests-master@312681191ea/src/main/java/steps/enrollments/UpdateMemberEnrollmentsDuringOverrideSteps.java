package steps.enrollments;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.enrollments.MemberEnrollmentMixerCodeResponseDTO;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;

import static helpers.constants.BasePathConstants.BASE_PATH_ENROLLMENTS_UPDATE_ENROLLMENT_DURING_OVERRIDE;

/**
 * Created by SDoneva on 10/14/2019
 */

public class UpdateMemberEnrollmentsDuringOverrideSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public UpdateMemberEnrollmentsDuringOverrideSteps(String platformContext, Headers headers) {

        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BASE_PATH_ENROLLMENTS_UPDATE_ENROLLMENT_DURING_OVERRIDE);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.addHeaders(headers);
        requestSpecification.setContentType(ContentType.JSON);
    }

    /*
    This endpoint is POST operation, although no requestBody is needed, the member enrollments is updated only with
    the pathParams. In the both methods no body is sent, but only pathParams
     */

    public MemberEnrollmentMixerCodeResponseDTO updateMemberEnrollmentsDuringOverride(String clientId, String memberId, String enrollmentId) {

        HashMap<String, String> pathParams = new HashMap<>();
        pathParams.put("clientId", clientId);
        pathParams.put("memberId", memberId);
        pathParams.put("enrollmentId", enrollmentId);

        requestSpecification.addPathParams(pathParams);

        Response response = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());
        response.then().statusCode(HttpStatus.SC_OK);

        return response.as(MemberEnrollmentMixerCodeResponseDTO.class);
    }

    public ErrorDTO updateMemberEnrollmentsDuringOverrideWithError(String clientId, String memberId, String enrollmentId) {

        HashMap<String, String> pathParams = new HashMap<>();
        pathParams.put("clientId", clientId);
        pathParams.put("memberId", memberId);
        pathParams.put("enrollmentId", enrollmentId);

        requestSpecification.addPathParams(pathParams);

        Response response = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        return response.as(ErrorDTO.class);
    }
}
