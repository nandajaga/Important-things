package steps.clientconfig;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.clientconfig.ClientEligibilityRequestDTOV2;
import dtos.clientconfig.ClientEligibilityResponseDTOV2;
import factories.clientconfig.ClientConfigEligibleDTOFactory;
import helpers.constants.BasePathConstants;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

/**
 * Created by RKondakova on 7/10/2019.
 */
public class IsClientEligibleSteps {
    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public IsClientEligibleSteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BasePathConstants.BASE_PATH_POST_V2_IS_CLIENT_ELIGIBLE);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    public ClientEligibilityResponseDTOV2 postClientConfigEligibleRequest(String dateOfService, String memberId, String solutionId, String subClientCode) {

        ClientEligibilityRequestDTOV2 body = new ClientConfigEligibleDTOFactory().setClientEligibility(dateOfService, memberId, solutionId, subClientCode);
        requestSpecification.addBodyToRequest(body);

        Response response = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        response.then().statusCode(HttpStatus.SC_OK);

        return response.as(ClientEligibilityResponseDTOV2.class);
    }
    //for positive tests
    public ClientEligibilityResponseDTOV2 postClientConfigEligibleRequestPositive(String memberId, String solutionId) {
        return postClientConfigEligibleRequest(null, memberId, solutionId, null);
    }

    //for negative tests
    public ErrorDTO postClientConfigEligibleRequestErrorDTO(String dateOfService, String memberId, String solutionId, String subClientCode) {

        ClientEligibilityRequestDTOV2 body = new ClientConfigEligibleDTOFactory().setClientEligibility(dateOfService, memberId, solutionId, subClientCode);
        requestSpecification.addBodyToRequest(body);

        Response response = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        return response.as(ErrorDTO.class);
    }
}
