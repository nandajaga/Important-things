package com.abc.automation.helpers.enums.platformcontext;

import static org.testng.Assert.fail;

/**
 * Created by PPetarcheva on 6/25/2019.
 */
public enum PlatformContextVersionEnum {
    PC_V1("v1"),
    PC_V2("v2");

    private String version;

    PlatformContextVersionEnum(String v) {
        version = v;
    }

    public static PlatformContextVersionEnum fromString(String text) {
        for (PlatformContextVersionEnum v : PlatformContextVersionEnum.values()) {
            if (v.version.equalsIgnoreCase(text)) {
                return v;
            }
        }

        fail("Platform Context version '" + text + "' is not valid!");
        return null;
    }
}
