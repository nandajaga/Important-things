package com.abc.automation.factories.member.enrollments;

import com.abc.automation.dtos.member.enrollments.MemberEnrollmentDTO;
import com.abc.automation.helpers.constants.MemberConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by PPetarcheva on 4/17/2019.
 */
public class MemberEnrollmentDTOFactory {

    private static final Logger LOGGER = LoggerFactory.getLogger(MemberEnrollmentDTOFactory.class);

    public List<MemberEnrollmentDTO> createMemberEnrollmentDTO(String clientId) {

        return createMemberEnrollmentDTO(clientId, null);

    }

    public List<MemberEnrollmentDTO> createMemberEnrollmentDTO(String clientId, String alternateBenefitPlanCode) {

        return createMemberEnrollmentDTO(clientId, alternateBenefitPlanCode, null, null);
    }

    public List<MemberEnrollmentDTO> createMemberEnrollmentDTO(String clientId, String alternateBenefitPlanCode, String erisaIndicator, String caseFundType) {
        DateFormat date = new SimpleDateFormat("yyyy-MM-dd");
        MemberEnrollmentDTO memberEnrollment = new MemberEnrollmentDTO();
        List<MemberEnrollmentDTO> list = new ArrayList<>();
        Date effectiveEndDate = new Date();
        Date effectiveStartDate = new Date();
        Date originalEffectiveEndDate = new Date();

        try {
            effectiveEndDate = date.parse(MemberConstants.EFFECTIVE_END_DATE);
            effectiveStartDate = date.parse(MemberConstants.EFFECTIVE_START_DATE);
            originalEffectiveEndDate = date.parse(MemberConstants.ORIGINAL_EFFECTIVE_END_DATE);
        } catch (ParseException e) {
            LOGGER.error("Could not parse the dates!");
        }

        memberEnrollment.setClientId(clientId);
        memberEnrollment.setClientSpecificEnrollments(new ClientSpecificEnrollmentsDTOFactory().createClientSpecificEnrollDTO(MemberConstants.SS_ISG, alternateBenefitPlanCode, erisaIndicator));
        memberEnrollment.setCovered(Boolean.TRUE);
        memberEnrollment.setEffectiveEndDate(effectiveEndDate);
        memberEnrollment.setEffectiveStartDate(effectiveStartDate);
        memberEnrollment.setEmployerGroupNumber(MemberConstants.EMPLOYER_GROUP_NUMBER);
        memberEnrollment.setEnrollmentPrefix(MemberConstants.ENROLLMENT_PREFIX);
        memberEnrollment.setFundType(caseFundType);
        memberEnrollment.setIssuanceState(MemberConstants.ISSUANCE_STATE);
        memberEnrollment.setLineOfBusiness(MemberConstants.LINE_OF_BUSINESS);
        memberEnrollment.setLineOfBusinessId(MemberConstants.LINE_OF_BUSINESS_ID);
        memberEnrollment.setManuallyEntered(Boolean.TRUE);
        memberEnrollment.setNationalFlag(Boolean.TRUE);
        memberEnrollment.setOriginalEffectiveEndDate(originalEffectiveEndDate);
        memberEnrollment.setPractitionerCode(MemberConstants.PRACTITIONER_CODE);
        memberEnrollment.setPrimaryCarePhysicianNumber(MemberConstants.PRIMARY_CARE_PHYSICIAN_NUMBER);
        memberEnrollment.setProductCode(MemberConstants.PRODUCT_CODE);
        memberEnrollment.setProductCodeId(MemberConstants.PRODUCT_CODE_ID);
        memberEnrollment.setProgramCoverageIndicator(MemberConstants.PROGRAM_COVERAGE_INDICATOR);
        memberEnrollment.setSolutions(new SolutionDTOFactory().createSolutionDTO());

        list.add(memberEnrollment);

        return list;
    }
}
