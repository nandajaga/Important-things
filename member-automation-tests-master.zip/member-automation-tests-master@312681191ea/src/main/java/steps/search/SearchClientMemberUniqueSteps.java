package steps.search;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.search.GETMemberSearchDTO;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;

import java.util.HashMap;
import java.util.Map;

import static helpers.constants.BasePathConstants.BASE_PATH_MEMBERS_UNIQUE;
import static helpers.constants.Constants.*;

/**
 * Created by RKondakova on 6/21/2019.
 */
public class SearchClientMemberUniqueSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public SearchClientMemberUniqueSteps(String platformContext, Headers headers) {

        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BASE_PATH_MEMBERS_UNIQUE);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    //for the positive tests
    public GETMemberSearchDTO getMemberSearchWithValidParams(String clientId, String clientMemberId, String dob, String dependentCode, String firstName, String sort) {
        Response result = getResult(clientId, clientMemberId, dob, dependentCode, firstName, sort);
        return result.as(GETMemberSearchDTO.class);
    }

    public Response getResult(String clientId, String clientMemberId, String dob, String dependentCode, String firstName, String sort) {

        Map<String, String> queryParamsMap = new HashMap<>();

        if (clientId != null) queryParamsMap.put(CLIENT_ID_FIELD, clientId);
        if (clientMemberId != null) queryParamsMap.put(CLIENT_MEMBER_ID_FIELD, clientMemberId);
        if (dob != null) queryParamsMap.put(DATE_OF_BIRTH_FIELD, dob);
        if (dependentCode != null) queryParamsMap.put(DEPENDENT_CODE_FIELD, dependentCode);
        if (firstName != null) queryParamsMap.put(FIRST_NAME_FIELD, firstName);
        if (sort != null) queryParamsMap.put(SORT_FIELD, sort);

        requestSpecification.addQueryParams(queryParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return result;
    }

    //for negative tests
    public ErrorDTO getMemberSearchWithValidParamsReturnErrorDTO(String clientId, String clientMemberId, String dob, String dependentCode, String firstName, String sort) {
        Response result = getResult(clientId, clientMemberId, dob, dependentCode, firstName, sort);
        return result.as(ErrorDTO.class);
    }

    public ErrorDTO getMemberSearchWithInvalidParams(String clientId, String clientMemberId, String dob, String dependentCode, String firstName, String page, String size, String sort) {

        Map<String, String> queryParamsMap = new HashMap<>();

        queryParamsMap.put(CLIENT_ID_FIELD, clientId);
        queryParamsMap.put(CLIENT_MEMBER_ID_FIELD, clientMemberId);
        queryParamsMap.put(DATE_OF_BIRTH_FIELD, dob);
        queryParamsMap.put(DEPENDENT_CODE_FIELD, dependentCode);
        queryParamsMap.put(FIRST_NAME_FIELD, firstName);
        queryParamsMap.put(PAGE_FIELD, page);
        queryParamsMap.put(SIZE_FIELD, size);
        queryParamsMap.put(SORT_FIELD, sort);
        requestSpecification.addQueryParams(queryParamsMap);

        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorDTO.class);
    }
}