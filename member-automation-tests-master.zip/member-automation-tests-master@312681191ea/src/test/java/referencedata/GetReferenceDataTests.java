package referencedata;

import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.ErrorSpringDTO;
import dtos.referencedata.ReferenceDataResponseDTO;
import helpers.dataproviders.DataProviders;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import steps.references.ReferencesDataSteps;

import static helpers.constants.BasePathConstants.BASE_PATH_REFERENCES_DATA;
import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_210;
import static org.apache.http.HttpStatus.SC_INTERNAL_SERVER_ERROR;
import static org.apache.http.HttpStatus.SC_NOT_FOUND;

/**
 * Created by RKondakova on 7/22/2019.
 */
public class GetReferenceDataTests extends GetTests {

    private static final String[] GENDER_ASSERTION_LETTERS = {"M", "F", "O"};
    private static final String[] GENDER_ASSERTION_WORDS = {"Male", "Female", "Other"};

    private static final String[] EMAIL_TYPE_ASSERTION_LETTERS = {"P", "W", "O"};
    private static final String[] EMAIL_TYPE_ASSERTION_WORDS = {"Personal", "Office", "Other"};

    private static final String[] LANGUAGE_PREFERENCE_CODE_TYPE_ASSERTION_LETTERS = {"eng", "spa", "chi", "tgl", "nav"};
    private static final String[] LANGUAGE_PREFERENCE_CODE_ASSERTION_WORDS = {"English", "Spanish", "Chinese", "tagalog", "Navajo"};

    private static final String[] PHONE_TYPE_ASSERTION_LETTERS = {"H", "W", "M", "O"};
    private static final String[] PHONE_TYPE_ASSERTION_WORDS = {"Home", "Office", "Mobile", "Other"};

    private static final String ERR_MSG_COLLECTION_NAME_NOT_EMPTY = "state should be: collectionName is not empty";
    private static final String ERR_MSG_QUERY_FIELD_ERROR_CODE_73 = "Query failed with error code 73 and error message 'Invalid collection name specified 'member-reference-dev.$'' on server 172.27.40.188:27017; nested exception is com.mongodb.MongoQueryException: Query failed with error code 73 and error message 'Invalid collection name specified 'member-reference-dev.$'' on server 172.27.40.188:27017";
    private static final String ERR_MSG_NONE_REFERENCE_TYPE_PROVIDED = "None of the reference types provided in the request for the client has any results";

    @BeforeClass
    public void init() {
        basePath = BASE_PATH_REFERENCES_DATA;
        pathParamsMap.clear();
        pathParamsMap.put("clientId", CLIENT_ID_85);
        queryParamsMap.put("types", REFERENCE_TYPE_GENDER);
    }

    //-----------------------------------POSITIVE-TESTS---RESPONSE-CODE-200---------------------------------------------

    @Test(dataProvider = "types", dataProviderClass = DataProviders.class)
    public void whenAGetAndAllValidQueryParametersSentThenServiceReturnsSuccessResponseSC200(String type) {
        ReferencesDataSteps referencesDataSteps = new ReferencesDataSteps(platformContextHeader, headers);

        ReferenceDataResponseDTO[] referenceDataResponseDTO = referencesDataSteps.getReferenceDataForPositiveTests(CLIENT_ID_85, type);

        for (ReferenceDataResponseDTO aReferenceDataResponseDTO : referenceDataResponseDTO) {
            softly.then(aReferenceDataResponseDTO.getReferenceType()).isEqualTo(type);
            softly.then(aReferenceDataResponseDTO).isNotNull();
            softly.then(aReferenceDataResponseDTO.getReferences()).isNotNull().isNotEmpty();

            switch (type) {
                case CLIENT_TYPE_QUERY_PARAM:
                    softly.then(aReferenceDataResponseDTO.getReferences().get(0).getReferenceId()).isEqualTo(REFERENCE_TYPE_CLIENT_REFENCE_ID);
                    softly.then(aReferenceDataResponseDTO.getReferences().get(0).getReferenceDescription()).isEqualTo(REFERENCE_TYPE_CLIENT_REFERENCE_DESCRIPTION);
                    break;
                case PROGRAM_TYPE_QUERY_PARAM:
                    softly.then(aReferenceDataResponseDTO.getReferences().get(0).getReferenceId()).isEqualTo(SOLUTION_PROGRAM_TYPE);
                    softly.then(aReferenceDataResponseDTO.getReferences().get(0).getReferenceDescription()).isEqualTo(REFERENCE_TYPE_PROGRAM_REFERENCE_DESCRIPTION);
                    break;
                case SUB_DIVISION_STATE_TYPE_QUERY_PARAM:
                    softly.then(aReferenceDataResponseDTO.getReferences().get(0).getReferenceId()).isEqualTo(REFERENCE_TYPE_SUB_DEVISION_STATE_REFENCE_ID);
                    softly.then(aReferenceDataResponseDTO.getReferences().get(0).getReferenceDescription()).isEqualTo(REFERENCE_TYPE_SUB_DEVISION_STATE_REFENCE_DESCRIPTION);
                    break;
                default:
                    softly.then(aReferenceDataResponseDTO.getReferences().get(0).getReferenceId()).isNotBlank().isNotEmpty().isNotNull();
                    softly.then(aReferenceDataResponseDTO.getReferences().get(0).getReferenceDescription()).isNotNull().isNotEmpty().isNotBlank();
                    break;
            }

            for (int j = 0; j < aReferenceDataResponseDTO.getReferences().size(); j++) {

                softly.then(aReferenceDataResponseDTO.getReferences().get(j).getReferenceId()).isNotBlank().isNotNull().isNotEmpty();
                softly.then(aReferenceDataResponseDTO.getReferences().get(j).getReferenceName()).isEqualTo(aReferenceDataResponseDTO.getReferences().get(j).getReferenceDescription());

                switch (type) {
                    case EMAIL_TYPE_QUERY_PARAM:
                        softly.then(aReferenceDataResponseDTO.getReferences().get(j).getReferenceId()).isEqualTo(EMAIL_TYPE_ASSERTION_LETTERS[j]);
                        softly.then(aReferenceDataResponseDTO.getReferences().get(j).getReferenceName()).isEqualTo(EMAIL_TYPE_ASSERTION_WORDS[j]);
                        break;
                    case REFERENCE_TYPE_GENDER:
                        softly.then(aReferenceDataResponseDTO.getReferences().get(j).getReferenceId()).isEqualTo(GENDER_ASSERTION_LETTERS[j]);
                        softly.then(aReferenceDataResponseDTO.getReferences().get(j).getReferenceName()).isEqualTo(GENDER_ASSERTION_WORDS[j]);
                        break;
                    case LANGUAGE_PREFERENCE_CODE_TYPE_QUERY_PARAM:
                        softly.then(aReferenceDataResponseDTO.getReferences().get(j).getReferenceId()).isEqualTo(LANGUAGE_PREFERENCE_CODE_TYPE_ASSERTION_LETTERS[j]);
                        softly.then(aReferenceDataResponseDTO.getReferences().get(j).getReferenceName()).isEqualTo(LANGUAGE_PREFERENCE_CODE_ASSERTION_WORDS[j]);
                        break;
                    case PHONE_TYPE_QUERY_PARAM:
                        softly.then(aReferenceDataResponseDTO.getReferences().get(j).getReferenceId()).isEqualTo(PHONE_TYPE_ASSERTION_LETTERS[j]);
                        softly.then(aReferenceDataResponseDTO.getReferences().get(j).getReferenceName()).isEqualTo(PHONE_TYPE_ASSERTION_WORDS[j]);
                        break;
                    default:
                        softly.then(aReferenceDataResponseDTO.getReferences().get(0).getReferenceId()).isNotBlank().isNotEmpty().isNotNull();
                        softly.then(aReferenceDataResponseDTO.getReferences().get(0).getReferenceDescription()).isNotNull().isNotEmpty().isNotBlank();
                        break;
                }
            }
        }

        softly.assertAll();
    }

    @Test
    public void whenGetSameRefenreceTypesForDifferentClientIdForTheAsParametersSentThenServiceReturnsSuccessResponseSC200() {

        ReferencesDataSteps referencesDataSteps = new ReferencesDataSteps(platformContextHeader, headers);

        //Get first referenceData for clientId 85 and gender
        ReferenceDataResponseDTO[] referenceDataResponseClientId85DTO = referencesDataSteps.getReferenceDataForPositiveTests(CLIENT_ID_85, REFERENCE_TYPE_GENDER);

        //Get first referenceData for clientId 210 and gender
        ReferenceDataResponseDTO[] referenceDataResponseClient210DTO = referencesDataSteps.getReferenceDataForPositiveTests(CLIENT_ID_210, REFERENCE_TYPE_GENDER);

        for (int i = 0; i < referenceDataResponseClientId85DTO.length; i++) {
            softly.then(referenceDataResponseClientId85DTO[i].getReferenceType()).isEqualTo(referenceDataResponseClient210DTO[i].getReferenceType());

            for (int j = 0; j < referenceDataResponseClientId85DTO[i].getReferences().size(); j++) {
                softly.then(referenceDataResponseClientId85DTO[i].getReferences().get(j).getReferenceId()).isEqualTo(referenceDataResponseClient210DTO[i].getReferences().get(j).getReferenceId());
                softly.then(referenceDataResponseClientId85DTO[i].getReferences().get(j).getReferenceName()).isEqualTo(referenceDataResponseClient210DTO[i].getReferences().get(j).getReferenceName());
                softly.then(referenceDataResponseClientId85DTO[i].getReferences().get(j).getReferenceDescription()).isEqualTo(referenceDataResponseClient210DTO[i].getReferences().get(j).getReferenceDescription());

            }
        }

        softly.assertAll();
    }
    //-----------------------------------NEGATIVE-TESTS---RESPONSE-CODE-404-500-----------------------------------------

    //TODO open bug for validate clientId NCP-24470
//    @Test(dataProvider = "clientIdNegative", dataProviderClass = DataProviders.class)
    public void whenGetAndInputNegativeClientIdThenReturnStatus422(String clientId) {
        ErrorSpringDTO errorSpringDTO = new ReferencesDataSteps(platformContextHeader, headers).getReferenceDataForNegativeTestsErrorSpringDTO(clientId, "gender");
        if (clientId == null || clientId.isEmpty()) {
            softly.then(errorSpringDTO.getStatus()).isEqualTo(""/*TODO proper response status*/);
            softly.then(errorSpringDTO.getError()).contains(""/*TODO proper response error*/);
            softly.then(errorSpringDTO.getMessage()).contains(""/*TODO proper response message*/);
        } else {
            softly.then(errorSpringDTO.getStatus()).isEqualTo(""/*TODO proper response status*/);
            softly.then(errorSpringDTO.getError()).contains(""/*TODO proper response error*/);
            softly.then(errorSpringDTO.getMessage()).contains(""/*TODO proper response message*/);
        }
        softly.assertAll();
    }

    //Bug opened NCP-26995, please uncomment and TODO fix message once the bug is fixed
//    @Test(dataProvider = "genderNegative", dataProviderClass = DataProviders.class)
    public void whenGetAndInputNegativeTypesThenReturnStatus422(String types) {

        if (types == null || types.isEmpty()) {
            ErrorSpringDTO errorSpringDTO = new ReferencesDataSteps(platformContextHeader, headers).getReferenceDataForNegativeTestsErrorSpringDTO(CLIENT_ID_85, types);
            softly.then(errorSpringDTO.getStatus()).isEqualTo(SC_INTERNAL_SERVER_ERROR);
            softly.then(errorSpringDTO.getMessage()).contains(ERR_MSG_COLLECTION_NAME_NOT_EMPTY);
        } else {
            if (DOLLAR_SIGN.equals(types)) {
                ErrorSpringDTO errorSpringDTO = new ReferencesDataSteps(platformContextHeader, headers).getReferenceDataForNegativeTestsErrorSpringDTO(CLIENT_ID_85, types);
                softly.then(errorSpringDTO.getStatus()).isEqualTo(SC_INTERNAL_SERVER_ERROR);
                softly.then(errorSpringDTO.getMessage()).contains(ERR_MSG_QUERY_FIELD_ERROR_CODE_73);
            } else {
                ErrorDTO errorDTO = new ReferencesDataSteps(platformContextHeader, headers).getReferenceDataForNegativeTestsErrorDTO(CLIENT_ID_85, types);
                softly.then(errorDTO.getCode()).isEqualTo(SC_NOT_FOUND);
                softly.then(errorDTO.getMessage()).contains(ERR_MSG_NONE_REFERENCE_TYPE_PROVIDED);
            }
        }
        softly.assertAll();
    }
}
