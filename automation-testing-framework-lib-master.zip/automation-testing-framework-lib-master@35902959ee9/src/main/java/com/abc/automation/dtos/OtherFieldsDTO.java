package com.abc.automation.dtos;

/**
 * Created by HKirazyan on 4/9/2019
 */
public class OtherFieldsDTO {

    private String other;

    public String getOther() {
        return other;
    }

    public void setOther(String other) {
        this.other = other;
    }
}
