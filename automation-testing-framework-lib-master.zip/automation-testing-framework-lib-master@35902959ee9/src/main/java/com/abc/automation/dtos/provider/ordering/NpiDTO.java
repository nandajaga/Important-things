package com.abc.automation.dtos.provider.ordering;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
public class NpiDTO {
    
    private String code;
    private String type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String value) {
        this.code = value;
    }
}
