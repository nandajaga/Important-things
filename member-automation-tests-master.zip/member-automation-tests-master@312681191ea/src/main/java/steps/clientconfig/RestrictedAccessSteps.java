package steps.clientconfig;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.clientconfig.RestrictedAcessResponseDTOV4;
import factories.clientconfig.RestrictedAccessDTOFactory;
import helpers.constants.BasePathConstants;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;

public class RestrictedAccessSteps {
    private final CustomFilterableRequestSpecification requestSpecification;
    private final RequestOperationsHelper requestOperationsHelper;

    public RestrictedAccessSteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addHeaders(headers);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addBasePath(BasePathConstants.BASE_PATH_RESTRICTED_ACCESSS_V4);
    }

    public RestrictedAcessResponseDTOV4 postRestrictedAccessResponse(String memberId, String dependentRelationCode, String restrictionType, String clientId, String employerGroupNumber) {
        Object body = new RestrictedAccessDTOFactory().setRestrictedAccessDTO(memberId, dependentRelationCode, restrictionType, clientId, employerGroupNumber);
        requestSpecification.addBodyToRequest(body);

        Response response = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        return response.as(RestrictedAcessResponseDTOV4.class);
    }

    public ErrorDTO postRestrictedAccessErrorResponse(String memberId, String dependentRelationCode, String restrictionType, String clientId, String employerGroupNumber) {
        Object body = new RestrictedAccessDTOFactory().setRestrictedAccessDTO(memberId, dependentRelationCode, restrictionType, clientId, employerGroupNumber);
        requestSpecification.addBodyToRequest(body);

        Response response = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        return response.as(ErrorDTO.class);
    }
}
