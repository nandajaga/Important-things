package com.abc.automation.steps.user;

import com.abc.automation.factories.user.UserProfileDTOFactory;
import com.abc.automation.helpers.CustomFilterableRequestSpecification;
import com.abc.automation.helpers.EnvironmentHelper;
import com.abc.automation.helpers.RequestOperationsHelper;
import com.abc.automation.helpers.constants.BasePathConstants;
import com.abc.automation.helpers.enums.DomainEnum;
import com.abc.automation.helpers.enums.user.UserRoleEnum;
import com.abc.automation.helpers.enums.user.UserStateLicenseEnum;
import com.abc.automation.dtos.user.UserProfileDTO;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

public class CreateUserProfileSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    private UserProfileDTOFactory factory;

    public CreateUserProfileSteps(CustomFilterableRequestSpecification requestSpecification) {
        this.requestSpecification = new CustomFilterableRequestSpecification();
        requestOperationsHelper = new RequestOperationsHelper();
        factory = new UserProfileDTOFactory();
        EnvironmentHelper environmentHelper = new EnvironmentHelper();

        Headers headers = requestSpecification.getFilterableRequestSpecification().getHeaders();

        this.requestSpecification.addHeaders(headers);
        this.requestSpecification.addBasePath(BasePathConstants.USER_CREATE_PROFILE_BASE_PATH);
        this.requestSpecification.addBaseURI(environmentHelper.constructBaseURIForDomain(DomainEnum.USER));
    }

    private UserProfileDTO createUserWithIdOfRoleAndLicense(UserRoleEnum role, UserStateLicenseEnum license) {
        UserProfileDTO userToBeCreated = factory.createUserProfileWithUserIdForRole(role, license);
        requestSpecification.addBodyToRequest(userToBeCreated);
        Response response = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());
        response.then().statusCode(HttpStatus.SC_CREATED);
        return response.getBody().as(UserProfileDTO.class);
    }

    public String createUserAndGeId() {
        return createUserAndGeId(UserRoleEnum.RS, null);
    }

    public String createUserAndGeId(UserRoleEnum role, UserStateLicenseEnum license) {
        GetUserProfileSteps getUserProfileSteps = new GetUserProfileSteps(requestSpecification);
        if (getUserProfileSteps.isExistingUser(role.getUserId())) {
            return role.getUserId();
        } else {
            UserProfileDTO user = createUserWithIdOfRoleAndLicense(role, license);
            return user.getUserId();
        }
    }

    private UserProfileDTO createUserWithIdOfRoleAndLocation(UserRoleEnum role, UserStateLicenseEnum license) {
        UserProfileDTO userToBeCreated = factory.createUserProfileWithUserIdForRoleAndLocation(role, license);
        requestSpecification.addBodyToRequest(userToBeCreated);
        Response response = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());
        response.then().statusCode(HttpStatus.SC_CREATED);
        return response.getBody().as(UserProfileDTO.class);
    }

    public String createUserWithLocationAndGeId(UserRoleEnum role, UserStateLicenseEnum license) {
        UserProfileDTO user = createUserWithIdOfRoleAndLocation(role, license);
        return user.getUserId();
    }
}
