package com.abc.automation.steps.provider.servicing;

import com.abc.automation.factories.provider.servicing.CreateServicingProviderDTOFactory;
import com.abc.automation.helpers.CustomFilterableRequestSpecification;
import com.abc.automation.helpers.EnvironmentHelper;
import com.abc.automation.helpers.RequestOperationsHelper;
import com.abc.automation.helpers.constants.BasePathConstants;
import com.abc.automation.helpers.constants.PrepareHeadersWithUUID;
import com.abc.automation.helpers.enums.DomainEnum;
import com.abc.automation.dtos.provider.ProviderResponseDTO;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.Map;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
public class CreateServicingProviderSteps {
    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public CreateServicingProviderSteps(String platformContext, Headers headers) {
        headers = new PrepareHeadersWithUUID().prepareHeaderWithUUID();
        requestSpecification = new CustomFilterableRequestSpecification();
        requestOperationsHelper = new RequestOperationsHelper();
        EnvironmentHelper environmentHelper = new EnvironmentHelper();

        requestSpecification.addBasePath(BasePathConstants.PROVIDER_CREATE_SERVICING_BASE_PATH);
        requestSpecification.addPlatformContextToRequest(platformContext);

        requestSpecification.addBaseURI(environmentHelper.constructBaseURIForDomain(DomainEnum.PROVIDER));
        requestSpecification.addHeaders(headers);
        requestSpecification.setContentType(ContentType.JSON);
    }

    public CreateServicingProviderSteps(CustomFilterableRequestSpecification requestSpecification) {
        Headers headers = new PrepareHeadersWithUUID().prepareHeaderWithUUID();

        this.requestSpecification = new CustomFilterableRequestSpecification();
        requestOperationsHelper = new RequestOperationsHelper();
        EnvironmentHelper environmentHelper = new EnvironmentHelper();

        this.requestSpecification.addHeaders(headers);
        this.requestSpecification.addBasePath(BasePathConstants.PROVIDER_CREATE_SERVICING_BASE_PATH);
        this.requestSpecification.addBaseURI(environmentHelper.constructBaseURIForDomain(DomainEnum.PROVIDER));
        this.requestSpecification.setContentType(ContentType.JSON);
    }

    public Response createServicingProviderResponse(int clientId) {
        CreateServicingProviderDTOFactory createServicingProviderDTOFactory = new CreateServicingProviderDTOFactory();

        Object body = createServicingProviderDTOFactory.createServicingProviderDTO(clientId);
        requestSpecification.addBodyToRequest(body);

        return requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());
    }

    public Response createServicingProviderResponse(int clientId, Map<String, String> servicingProvider) {
        CreateServicingProviderDTOFactory createServicingProviderDTOFactory = new CreateServicingProviderDTOFactory();

        Object body = createServicingProviderDTOFactory.createServicingProviderDTO(clientId, servicingProvider);
        requestSpecification.addBodyToRequest(body);

        return requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());
    }

    public ProviderResponseDTO createServicingProvider(int clientId) {
        Response result = createServicingProviderResponse(clientId);

        result.then().statusCode(HttpStatus.SC_CREATED);

        return result.getBody().as(ProviderResponseDTO.class);
    }

    public ProviderResponseDTO createServicingProvider(int clientId, Map<String, String> servicingProvider) {
        Response result = createServicingProviderResponse(clientId, servicingProvider);

        result.then().statusCode(HttpStatus.SC_CREATED);

        return result.getBody().as(ProviderResponseDTO.class);
    }

    public String createServicingProviderAndGetNgProviderId(int clientId) {
        return createServicingProvider(clientId).getNgProviderId();
    }

    public String createServicingProviderAndGetNgProviderId(int clientId, Map<String, String> servicingProvider) {
        return createServicingProvider(clientId, servicingProvider).getNgProviderId();
    }

    public Integer createServicingProviderAndGetClientProviderId(int clientId) {
        return createServicingProvider(clientId).getProviderClientId();
    }

    public Integer createServicingProviderAndGetClientProviderId(int clientId, Map<String, String> servicingProvider) {
        return createServicingProvider(clientId, servicingProvider).getProviderClientId();
    }

}
