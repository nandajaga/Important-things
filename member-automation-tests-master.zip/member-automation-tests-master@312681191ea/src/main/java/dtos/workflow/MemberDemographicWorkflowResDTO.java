package dtos.workflow;

import dtos.workflow.FlowDTO;
import dtos.workflow.WorkFlowDTO;

/**
 * Created by RKohli on 04/28/2020
 */

public class MemberDemographicWorkflowResDTO {
    private FlowDTO flow;
    private WorkFlowDTO workFlow;


    public FlowDTO getFlow() {
        return flow;
    }

    public WorkFlowDTO getWorkFlow() {
        return workFlow;
    }


}