package dtos.clientconfig;

/**
 * Created by VBaliyska on 6/21/2019.
 */
public class RestrictionTypeResponseDTO {

    private boolean isRestricted;
    private String restrictionType;
    private String message;
    private String script;

    public boolean getIsRestricted() {
        return isRestricted;
    }

    public void setRestricted(boolean restricted) {
        isRestricted = restricted;
    }

    public String getRestrictionType() {
        return restrictionType;
    }

    public void setRestrictionType(String restrictionType) {
        this.restrictionType = restrictionType;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getScript() {
        return script;
    }

    public void setScript(String script) {
        this.script = script;
    }
}
