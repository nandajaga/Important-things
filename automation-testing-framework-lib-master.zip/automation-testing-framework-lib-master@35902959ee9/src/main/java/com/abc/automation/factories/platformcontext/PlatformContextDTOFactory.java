package com.abc.automation.factories.platformcontext;

import com.abc.automation.helpers.EditDTOHelper;
import com.abc.automation.helpers.constants.CaseConstants;
import com.abc.automation.helpers.constants.PlatformContextConstants;
import com.abc.servicemodel.domain.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import static com.abc.automation.helpers.constants.PlatformContextConstants.*;

public class PlatformContextDTOFactory implements IPlatformContextFactory<PlatformContext> {
    private Date dateOfService = null;

    public PlatformContext createPlatformContextDTO(Date dateOfService , String interactionType, String interactionId, String channelCode, int applicationId, User user, Member member, Solution solution, ArrayList<Service> services, Case casePC) {
        PlatformContext platformContext = new PlatformContext();

        platformContext.setDateOfService(dateOfService);
        platformContext.setInteractionType(interactionType);
        platformContext.setInteractionId(interactionId);
        platformContext.setChannelCode(channelCode);
        platformContext.setApplicationId(applicationId);
        platformContext.setUser(user);
        platformContext.setMember(member);
        platformContext.setSolution(solution);
        platformContext.setServices(services);
        platformContext.setCaseObject(casePC);
        platformContext.getCaseObject().setCaseRequestId(CaseConstants.CASE_REQUEST_ID);
        return platformContext;
    }

    public PlatformContext createPlatformContextDTO()  {
        Case casePC = new CasePCDTOFactory().createCasePCDTO(PC_CASE_ID);
        Solution solution = new SolutionDTOFactory().createSolutionPCDTO();
        ArrayList<Service> services = new ServicesDTOFactory().createServicesPCDTO();
        User user = new UserDTOFactory().createUserPCDTO();
        Member member = new MemberDTOFactory().createMemberDTO();
        String timeStamp = PlatformContextConstants.PC_SOLUTION_START_DATE;
        try {
            dateOfService = new SimpleDateFormat("yyyy-MM-dd").parse(timeStamp);
        } catch (ParseException e) {
            e.getMessage();
        }
        return createPlatformContextDTO(dateOfService, PC_INTERACTION_TYPE, PC_INTERACTION_ID, PC_CHANNEL_CODE, PC_APPLICATION_ID, user, member, solution, services, casePC);
    }

    public PlatformContext editPlatformContextDTO(PlatformContext platformContext, String field, String value) {
        EditDTOHelper editDTOHelper = new EditDTOHelper();
        editDTOHelper.changeSpecificFieldValueInDTO(platformContext, field, value);
        return platformContext;
    }

}
