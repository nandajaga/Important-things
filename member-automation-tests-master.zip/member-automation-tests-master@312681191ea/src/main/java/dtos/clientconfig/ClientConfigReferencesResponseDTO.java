package dtos.clientconfig;

/**
 * All fields are type Object due to the such definition into service implementation
 */

public class ClientConfigReferencesResponseDTO {
    private Object allowedClientDependentRelationCodes;
    private Object allowedFundingTypes;
    private Object allowedLinesOfBusiness;
    private Object allowedProgramTypes;
    private Object allowedSourceSystems;
    private Object allowedStatesOfIssuance;
    private Object allowedNetworkCodes;
    private Object allowedBusinessIndicators;

    public Object getAllowedBusinessIndicators() {return allowedBusinessIndicators;}

    public void setAllowedBusinessIndicators(Object allowedBusinessIndicators) {
        this.allowedBusinessIndicators = allowedBusinessIndicators;
    }

    public Object getAllowedClientDependentRelationCodes() {return allowedClientDependentRelationCodes;}

    public void setAllowedClientDependentRelationCodes(Object allowedClientDependentRelationCodes) {
        this.allowedClientDependentRelationCodes = allowedClientDependentRelationCodes;
    }

    public Object getAllowedFundingTypes() {return allowedFundingTypes;}

    public void setAllowedFundingTypes(Object allowedFundingTypes) {
        this.allowedFundingTypes = allowedFundingTypes;
    }

    public Object getAllowedLinesOfBusiness() {return allowedLinesOfBusiness;}

    public void setAllowedLinesOfBusiness(Object allowedLinesOfBusiness) {
        this.allowedLinesOfBusiness = allowedLinesOfBusiness;
    }

    public Object getAllowedNetworkCodes() {return allowedNetworkCodes;}

    public void setAllowedNetworkCodes(Object allowedNetworkCodes) {
        this.allowedNetworkCodes = allowedNetworkCodes;
    }

    public Object getAllowedProgramTypes() {return allowedProgramTypes;}

    public void setAllowedProgramTypes(Object allowedProgramTypes) {this.allowedProgramTypes = allowedProgramTypes;}

    public Object getAllowedSourceSystems() {return allowedSourceSystems;}

    public void setAllowedSourceSystems(Object allowedSourceSystems) {
        this.allowedSourceSystems = allowedSourceSystems;
    }

    public Object getAllowedStatesOfIssuance() {return allowedStatesOfIssuance;}

    public void setAllowedStatesOfIssuance(Object allowedStatesOfIssuance) {
        this.allowedStatesOfIssuance = allowedStatesOfIssuance;
    }
}
