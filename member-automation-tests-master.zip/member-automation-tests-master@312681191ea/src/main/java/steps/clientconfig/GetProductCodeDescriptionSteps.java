package steps.clientconfig;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.clientconfig.GetProductCodeDescriptionResponseDTO;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;

import static helpers.constants.BasePathConstants.*;

public class GetProductCodeDescriptionSteps {
    private CustomFilterableRequestSpecification requestSpecification;
    private RequestOperationsHelper requestOperationsHelper;

    public GetProductCodeDescriptionSteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addHeaders(headers);
        requestSpecification.addBasePath(BASE_PATH_GET_PRODUCT_CODE_DESCRIPTION);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
    }

    public Response getResponse() {
        Response result = requestOperationsHelper.sendGetRequest(requestSpecification.getFilterableRequestSpecification());
        return result;
    }

    public GetProductCodeDescriptionResponseDTO getProductCodeDescriptionResponse() {
        Response response = getResponse();
        return response.as(GetProductCodeDescriptionResponseDTO.class);
    }

    public ErrorDTO getProductCodeErrorResponse() {
        Response response = getResponse();
        return response.as(ErrorDTO.class);
    }
}
