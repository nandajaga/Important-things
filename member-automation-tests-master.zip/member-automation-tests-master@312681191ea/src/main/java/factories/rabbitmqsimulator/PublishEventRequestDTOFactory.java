package factories.rabbitmqsimulator;

import dtos.rabbitmqsimulator.PublishEventRequestDTO;
import factories.datamanager.MemberDTOFactory;

import java.util.HashMap;
import java.util.Map;

import static helpers.constants.Constants.*;

/**
 * Created by VBaliyska on 10/3/2019.
 */
public class PublishEventRequestDTOFactory {

    public PublishEventRequestDTO createMixerCodeMappingEvent(int mixerCodeMapIdentifier, String clientId, String sourceSystemCode, String employerGroupCode, String mixerCode){
        return createMixerCodeMappingEvent(mixerCodeMapIdentifier, clientId, sourceSystemCode, employerGroupCode, mixerCode, DATE_2019_08_31, DATE_9999_12_31, true);
    }

    public PublishEventRequestDTO createMixerCodeMappingEvent(int mixerCodeMapIdentifier, String clientId, String sourceSystemCode, String employerGroupCode, String mixerCode, String effectiveStartDate, String effectiveEndDate, boolean manualAddEnableFlag){
        PublishEventRequestDTO publishEvent = new PublishEventRequestDTO();
        publishEvent.setPayload(new PayloadRequestDTOFactory().createPayloadDTO(mixerCodeMapIdentifier, clientId, sourceSystemCode, employerGroupCode, mixerCode, effectiveStartDate, effectiveEndDate, manualAddEnableFlag));
        publishEvent.setAdditionalHeaders(new HashMap<>());
        return publishEvent;
    }

    public PublishEventRequestDTO createMemberManual(String clientId, String clientMemberId) {
        Map<String, String> additionalHeaders = new HashMap<>();
        PublishEventRequestDTO addMember = new PublishEventRequestDTO();

        addMember.setAdditionalHeaders(additionalHeaders);
        addMember.setPayload(new MemberDTOFactory().createMemberClientMemberId(clientId, clientMemberId));

        return addMember;
    }

    public PublishEventRequestDTO createMixerCodeMappingDeleteEvent(int mixerCodeMapIdentifier, String clientId, String sourceSystemCode, String employerGroupCode, String mixerCode){
        Map<String, String> additionalHeaders = new HashMap<>();
        additionalHeaders.put(EVENT_ACTION_HEADER, DELETE_ACTION_EVENT);
        PublishEventRequestDTO publishEvent = new PublishEventRequestDTO();
        publishEvent.setPayload(new PayloadRequestDTOFactory().createPayloadDTO(mixerCodeMapIdentifier, clientId, sourceSystemCode, employerGroupCode, mixerCode, DATE_2019_08_31, DATE_9999_12_31, true));
        publishEvent.setAdditionalHeaders(additionalHeaders);
        return publishEvent;
    }

    public PublishEventRequestDTO createMemberDeleteEvent(String clientId, String id){
        Map<String, String> additionalHeaders = new HashMap<>();
        additionalHeaders.put(EVENT_ACTION_HEADER, DELETE_ACTION_EVENT);
        PublishEventRequestDTO publishEvent = new PublishEventRequestDTO();
        publishEvent.setPayload(new PayloadRequestDTOFactory().createPayloadForMemberDeletionDTO(clientId, id));
        publishEvent.setAdditionalHeaders(additionalHeaders);
        return publishEvent;
    }

    public PublishEventRequestDTO createMemberInvalidDeleteEvent(String clientId, String id){
        Map<String, String> additionalHeaders = new HashMap<>();
        additionalHeaders.put(EVENT_ACTION_HEADER, DELETE_ACTION_EVENT_INVALID);
        PublishEventRequestDTO publishEvent = new PublishEventRequestDTO();
        publishEvent.setPayload(new PayloadRequestDTOFactory().createPayloadForMemberDeletionDTO(clientId, id));
        publishEvent.setAdditionalHeaders(additionalHeaders);
        return publishEvent;
    }
}
