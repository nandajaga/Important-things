package com.abc.automation.tests.base;

import com.abc.automation.dtos.GenericErrorDTO;
import com.abc.automation.helpers.CustomFilterableRequestSpecification;
import com.abc.automation.helpers.constants.ErrorMessagesConstants;
import com.abc.automation.helpers.dataproviders.DataProviders;
import com.abc.automation.helpers.enums.RequestHeadersEnum;
import com.abc.automation.steps.ErrorsSteps;
import io.restassured.http.ContentType;
import io.restassured.http.Method;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static org.apache.http.HttpStatus.SC_BAD_REQUEST;
import static org.apache.http.HttpStatus.SC_METHOD_NOT_ALLOWED;

public class DeleteTests extends BaseTest {

    private CustomFilterableRequestSpecification specification;
    ErrorsSteps errorsSteps = new ErrorsSteps();


    @BeforeMethod(alwaysRun = true)
    public void initDelete() {
        specification = new CustomFilterableRequestSpecification();
        specification.addBasePath(basePath);
        specification.addPathParams(pathParamsMap);
        specification.addQueryParams(queryParamsMap);
        specification.setContentType(ContentType.JSON);
        specification.addBodyToRequest(body);
        specification.addHeaders(headers);
        specification.addHeaders(additionalHeaders);
        specification.addPlatformContextToRequest(platformContextHeader);

    }

    @Test
    public void whenPostOnDeleteEndpointThenServiceReturnsMethodNotAllowedResponse() {
        GenericErrorDTO errorDTO = errorsSteps.sendPostRequestWithGenericError(specification);

        softNG.assertEquals(errorDTO.getStatus(), HttpStatus.SC_METHOD_NOT_ALLOWED, "Status code is not correct!");
        softNG.assertEquals(errorDTO.getMessage(), String.format(ErrorMessagesConstants.METHOD_NOT_ALLOWED_MESSAGE, Method.POST), "Error message is not correct!");
        softNG.assertAll();
    }

    @Test
    public void whenPatchOnDeleteEndpointThenServiceReturnMethodNotAllowedResponse() {
        GenericErrorDTO errorDTO = errorsSteps.sendPatchRequestWithGenericError(specification);

        softNG.assertEquals(errorDTO.getStatus(), HttpStatus.SC_METHOD_NOT_ALLOWED, "Status code is not correct!");
        softNG.assertEquals(errorDTO.getMessage(), String.format(ErrorMessagesConstants.METHOD_NOT_ALLOWED_MESSAGE, Method.PATCH), "Error message is not correct!");
        softNG.assertAll();
    }

    @Test
    public void whenGetOnDeleteEndpointThenServiceReturnsMethodNotAllowedResponse() {
        GenericErrorDTO errorDTO = errorsSteps.sendGetRequestWithGenericError(specification);

        softNG.assertEquals(errorDTO.getStatus(), SC_METHOD_NOT_ALLOWED, "Status code is not correct!");
        softNG.assertEquals(errorDTO.getMessage(), String.format(ErrorMessagesConstants.METHOD_NOT_ALLOWED_MESSAGE, Method.GET), "Error message is not correct!");
        softNG.assertAll();
    }


    @Test
    public void whenDeleteWithNoBodyThenServiceReturnsBadRequest() {
        specification.addHeaders(requestSpecification.getFilterableRequestSpecification().getHeaders());
        specification.addBodyToRequest("");
        GenericErrorDTO errorDTO = errorsSteps.sendDeleteRequestWithGenericError(specification);

        softNG.assertEquals(errorDTO.getStatus(), SC_BAD_REQUEST, "Status code is not correct!");
        softNG.assertTrue(ErrorMessagesConstants.BAD_REQUEST_ERROR.equals(errorDTO.getError()) || ErrorMessagesConstants.BAD_REQUEST_ERROR.equals(errorDTO.getMessage()), "Error message is not correct!");
        softNG.assertAll();
    }

    @Test
    public void whenDeleteAndNoRequestHeaderSentThenServiceReturnsBadRequest() {
        specification.getFilterableRequestSpecification().removeHeaders();
        specification.setContentType(ContentType.JSON);
        GenericErrorDTO errorDTO = errorsSteps.sendDeleteRequestWithGenericError(specification);

        softNG.assertEquals(errorDTO.getStatus(), SC_BAD_REQUEST, "Status code is not correct!");
        softNG.assertTrue(errorDTO.getMessage().startsWith(ErrorMessagesConstants.BAD_REQUEST_MESSAGE_START), "Error message is not correct!");
        softNG.assertTrue(errorDTO.getMessage().endsWith(ErrorMessagesConstants.BAD_REQUEST_MESSAGE_END), "Error message is not correct!");
        softNG.assertAll();
    }

    @Test(dataProvider = "Headers", dataProviderClass = DataProviders.class)
    public void whenDeleteWithMissingHeaderThenServiceReturnsBadRequest(RequestHeadersEnum missingHeader) {
        specification.removeHeader(missingHeader.getName());

        GenericErrorDTO errorDTO = errorsSteps.sendDeleteRequestWithGenericError(specification);

        softNG.assertEquals(errorDTO.getStatus(), SC_BAD_REQUEST, "Status code is not correct!");
        softNG.assertEquals(errorDTO.getMessage(), String.format(ErrorMessagesConstants.BAD_REQUEST_MESSAGE, missingHeader.getName()), "Error message is not correct!");
        softNG.assertAll();
    }

}
