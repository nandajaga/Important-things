package com.abc.automation.dtos.provider.servicing;

import com.abc.automation.dtos.provider.ClientSpecificAttributesDTO;
import com.abc.automation.dtos.provider.ordering.AddressSearchDTO;
import com.abc.automation.dtos.provider.ordering.NpiDTO;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ServicingProviderSnapshotResponseDTO {
    private AddressSearchDTO address;
    private BenefitExceptionPackageDTO benefitExceptionPackage;
    private Boolean benefitExceptionRequested;
    private boolean billingEntity;
    private int clientId;
    private String clientPhysicianNumber;
    private String createdOn;
    private String facilityName;
    private String fax;
    private String fromDate;
    private Boolean isBillingEntity;
    private boolean isInNetworkRedirectProvider;
    private Boolean isManual;
    private boolean isOptedOut;
    private boolean isOrderingProvider;
    private boolean isSanctioned;
    private String labelType;
    private boolean manual;
    private String medicareId;
    private List<String> networkCodes;
    private String networkStatus;
    private String ngProviderId;
    private List<NpiDTO> npi;
    private Boolean optOutLookupCompletedFlag;
    private Boolean optOutLookupRequiredFlag;
    private String optOutReviewAnswerSnapshotId;
    private boolean optOutThroughReviewFlag;
    private String order;
    private boolean orderingProvider;
    private String phone;
    private String physicianFirstName;
    private String physicianLastName;
    private PlaceOfServiceDTO placeOfService;
    private String providerGroupId;
    private Boolean sanctionLookupCompletedFlag;
    private Boolean sanctionLookupRequiredFlag;
    private String sanctionReviewAnswerSnapshotId;
    private boolean sanctionedThroughReviewFlag;
    private String servicingProvID;
    private String servicingProvType;
    private String snapshotId;
    private List<Integer> specialtyCodes;
    private String thruDate;
    private List<String> tin;
    private boolean unknownProvider;
    private List<ClientSpecificAttributesDTO> clientSpecificAttributes;


    public List<ClientSpecificAttributesDTO> getClientSpecificAttributes() {
        return clientSpecificAttributes;
    }

    public void setClientSpecificAttributes(List<ClientSpecificAttributesDTO> clientSpecificAttributes) {
        this.clientSpecificAttributes = clientSpecificAttributes;
    }

    public boolean getBillingEntity() {
        return billingEntity;
    }

    public void setBillingEntity(boolean billingEntity) {
        this.billingEntity = billingEntity;
    }

    public boolean getOrderingProvider() {
        return orderingProvider;
    }

    public void setOrderingProvider(boolean orderingProvider) {
        this.orderingProvider = orderingProvider;
    }

    public boolean getManual() {
        return manual;
    }

    public void setManual(boolean manual) {
        this.manual = manual;
    }

    public List<String> getTin() {
        if (tin != null) {
        return new ArrayList<>(tin);
    } else {
        return null;
    }
    }

    public void setTin(List<String> tin) {
        if (tin != null) {
            this.tin = new ArrayList<>(tin);
        } else {
            this.tin = null;
        }
    }

    public List<Integer> getSpecialtyCodes() {
        if (specialtyCodes != null) {
        return new ArrayList<>(specialtyCodes);
    } else {
        return null;
        }
    }

    public void setSpecialtyCodes(List<Integer> specialtyCodes) {
        if (specialtyCodes != null) {
            this.specialtyCodes = new ArrayList<>(specialtyCodes);
        } else {
            this.specialtyCodes = null;
        }
    }

    public List<String> getNetworkCodes() {
        if (networkCodes != null) {
        return new ArrayList<>(networkCodes);
        } else {
        return null;
        }
    }

    public void setNetworkCodes(List<String> networkCodes) {
        if (networkCodes != null) {
            this.networkCodes = new ArrayList<>(networkCodes);
        } else {
            this.networkCodes = null;
        }
    }

    public List<NpiDTO> getNpi() {
        if (npi != null) {
        return new ArrayList<>(npi);
        } else {
        return null;
        }
    }

    public void setNpi(List<NpiDTO> npi) {
        if (npi != null) {
            this.npi = new ArrayList<>(npi);
        } else {
            this.npi = null;
        }
    }

    public AddressSearchDTO getAddress() {
        return address;
    }

    public void setAddress(AddressSearchDTO address) {
        this.address = address;
    }

    public BenefitExceptionPackageDTO getBenefitExceptionPackage() {
        return benefitExceptionPackage;
    }

    public void setBenefitExceptionPackage(BenefitExceptionPackageDTO benefitExceptionPackage) {
        this.benefitExceptionPackage = benefitExceptionPackage;
    }

    public Boolean getBenefitExceptionRequested() {
        return benefitExceptionRequested;
    }

    public void setBenefitExceptionRequested(Boolean benefitExceptionRequested) {
        this.benefitExceptionRequested = benefitExceptionRequested;
    }

    public Boolean getIsBillingEntity() {
        return isBillingEntity;
    }

    public void setIsBillingEntity(Boolean billingEntity) {
        this.isBillingEntity = billingEntity;
    }

    public boolean getIsInNetworkRedirectProvider() {
        return isInNetworkRedirectProvider;
    }

    public void setIsInNetworkRedirectProvider(boolean inNetworkRedirectProvider) {
        isInNetworkRedirectProvider = inNetworkRedirectProvider;
    }

    public Boolean getIsManual() {
        return isManual;
    }

    public void setIsManual(Boolean manual) {
        isManual = manual;
    }

    public String getMedicareId() {
        return medicareId;
    }

    public void setMedicareId(String medicareId) {
        this.medicareId = medicareId;
    }

    public String getNetworkStatus() {
        return networkStatus;
    }

    public void setNetworkStatus(String networkStatus) {
        this.networkStatus = networkStatus;
    }

    public String getNgProviderId() {
        return ngProviderId;
    }

    public void setNgProviderId(String ngProviderId) {
        this.ngProviderId = ngProviderId;
    }

    public Boolean getOptOutLookupCompletedFlag() {
        return optOutLookupCompletedFlag;
    }

    public void setOptOutLookupCompletedFlag(Boolean optOutLookupCompletedFlag) {
        this.optOutLookupCompletedFlag = optOutLookupCompletedFlag;
    }

    public Boolean getOptOutLookupRequiredFlag() {
        return optOutLookupRequiredFlag;
    }

    public void setOptOutLookupRequiredFlag(Boolean optOutLookupRequiredFlag) {
        this.optOutLookupRequiredFlag = optOutLookupRequiredFlag;
    }

    public String getOptOutReviewAnswerSnapshotId() {
        return optOutReviewAnswerSnapshotId;
    }

    public void setOptOutReviewAnswerSnapshotId(String optOutReviewAnswerSnapshotId) {
        this.optOutReviewAnswerSnapshotId = optOutReviewAnswerSnapshotId;
    }

    public boolean getOptOutThroughReviewFlag() {
        return optOutThroughReviewFlag;
    }

    public void setOptOutThroughReviewFlag(boolean optOutThroughReviewFlag) {
        this.optOutThroughReviewFlag = optOutThroughReviewFlag;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public boolean getIsOptedOut() {
        return isOptedOut;
    }

    public void setIsOptedOut(boolean optedOut) {
        isOptedOut = optedOut;
    }

    public boolean getIsOrderingProvider() {
        return isOrderingProvider;
    }

    public void setIsOrderingProvider(boolean orderingProvider) {
        isOrderingProvider = orderingProvider;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPhysicianFirstName() {
        return physicianFirstName;
    }

    public void setPhysicianFirstName(String physicianFirstName) {
        this.physicianFirstName = physicianFirstName;
    }

    public String getPhysicianLastName() {
        return physicianLastName;
    }

    public void setPhysicianLastName(String physicianLastName) {
        this.physicianLastName = physicianLastName;
    }

    public PlaceOfServiceDTO getPlaceOfService() {
        return placeOfService;
    }

    public void setPlaceOfService(PlaceOfServiceDTO placeOfService) {
        this.placeOfService = placeOfService;
    }

    public String getProviderGroupId() {
        return providerGroupId;
    }

    public void setProviderGroupId(String providerGroupId) {
        this.providerGroupId = providerGroupId;
    }

    public Boolean getSanctionLookupCompletedFlag() {
        return sanctionLookupCompletedFlag;
    }

    public void setSanctionLookupCompletedFlag(Boolean sanctionLookupCompletedFlag) {
        this.sanctionLookupCompletedFlag = sanctionLookupCompletedFlag;
    }

    public Boolean getSanctionLookupRequiredFlag() {
        return sanctionLookupRequiredFlag;
    }

    public void setSanctionLookupRequiredFlag(Boolean sanctionLookupRequiredFlag) {
        this.sanctionLookupRequiredFlag = sanctionLookupRequiredFlag;
    }

    public String getSanctionReviewAnswerSnapshotId() {
        return sanctionReviewAnswerSnapshotId;
    }

    public void setSanctionReviewAnswerSnapshotId(String sanctionReviewAnswerSnapshotId) {
        this.sanctionReviewAnswerSnapshotId = sanctionReviewAnswerSnapshotId;
    }

    public boolean getSanctionedThroughReviewFlag() {
        return sanctionedThroughReviewFlag;
    }

    public void setSanctionedThroughReviewFlag(boolean sanctionedThroughReviewFlag) {
        this.sanctionedThroughReviewFlag = sanctionedThroughReviewFlag;
    }

    public String getServicingProvID() {
        return servicingProvID;
    }

    public void setServicingProvID(String servicingProvID) {
        this.servicingProvID = servicingProvID;
    }

    public String getServicingProvType() {
        return servicingProvType;
    }

    public void setServicingProvType(String servicingProvType) {
        this.servicingProvType = servicingProvType;
    }

    public String getSnapshotId() {
        return snapshotId;
    }

    public void setSnapshotId(String snapshotId) {
        this.snapshotId = snapshotId;
    }

    public String getThruDate() {
        return thruDate;
    }

    public void setThruDate(String thruDate) {
        this.thruDate = thruDate;
    }

    public boolean getUnknownProvider() {
        return unknownProvider;
    }

    public void setUnknownProvider(boolean unknownProvider) {
        this.unknownProvider = unknownProvider;
    }

    public boolean getIsSanctioned() {
        return isSanctioned;
    }

    public void setIsSanctioned(boolean sanctioned) {
        isSanctioned = sanctioned;
    }

    public String getLabelType() {
        return labelType;
    }

    public void setLabelType(String labelType) {
        this.labelType = labelType;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public String getClientPhysicianNumber() {
        return clientPhysicianNumber;
    }

    public void setClientPhysicianNumber(String clientPhysicianNumber) {
        this.clientPhysicianNumber = clientPhysicianNumber;
    }

    public String getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    public String getFacilityName() {
        return facilityName;
    }

    public void setFacilityName(String facilityName) {
        this.facilityName = facilityName;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }
}
