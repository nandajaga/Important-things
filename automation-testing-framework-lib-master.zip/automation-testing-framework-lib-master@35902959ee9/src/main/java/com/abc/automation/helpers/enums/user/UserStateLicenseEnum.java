package com.abc.automation.helpers.enums.user;

public enum UserStateLicenseEnum {

    ALASKA_STATE_LICENSE("AK", "01"),
    CALIFORNIA_STATE_LICENSE("CA","05");

    private String code;
    private String number;

    UserStateLicenseEnum(String code, String number) {
        this.code = code;
        this.number = number;
    }

    public String getCode() {
        return code;
    }

    public String getNumber() {
        return number;
    }
}
