package com.abc.automation.tests.base;

import com.abc.automation.dtos.ErrorDTO;
import com.abc.automation.factories.platformcontext.PlatformContextDTOFactory;
import com.abc.automation.helpers.CustomFilterableRequestSpecification;
import com.abc.automation.helpers.constants.PlatformContextConstants;
import com.abc.automation.helpers.convert.ConvertPlatformContextPOJOToString;
import com.abc.automation.helpers.dataproviders.DataProviders;
import com.abc.automation.helpers.enums.RequestHeadersEnum;
import com.abc.automation.steps.ErrorsSteps;
import com.abc.servicemodel.domain.PlatformContext;
import com.abc.servicemodel.domain.User;
import io.restassured.http.ContentType;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class DeleteWithPlatformContextTests extends DeleteTests {

    private CustomFilterableRequestSpecification specification;
    ErrorsSteps errorsSteps = new ErrorsSteps();

    @BeforeMethod (alwaysRun = true)
    public void initDeleteWithPlatformContext() {
        specification = new CustomFilterableRequestSpecification();
        specification.addBasePath(basePath);
        specification.addPathParams(pathParamsMap);
        specification.addQueryParams(queryParamsMap);
        specification.addHeaders(headers);
        specification.addHeaders(additionalHeaders);
        specification.setContentType(ContentType.JSON);
        specification.addPlatformContextToRequest(platformContextHeader);
    }

    @Test(dataProvider = "PlatformContextFieldsValidation", dataProviderClass = DataProviders.class)
    public void whenDeleteAndPlatformContextWithNullValueThenServiceReturnBadResponse(String field, String errorMSG) {
        PlatformContextDTOFactory factory = new PlatformContextDTOFactory();
        PlatformContext platformContextDTOFalse = factory.createPlatformContextDTO();
        platformContextDTOFalse = factory.editPlatformContextDTO(platformContextDTOFalse, field, null);
        String platformContextFalse = ConvertPlatformContextPOJOToString.convertPlatformContextToString(platformContextDTOFalse);

        specification.addCustomHeader(RequestHeadersEnum.PLATFORM_CONTEXT.getName(), platformContextFalse);
        ErrorDTO errorDTO = errorsSteps.sendGetRequestWithError(specification);

        softNG.assertEquals(errorDTO.getMessage(), errorMSG);
        softNG.assertAll();
    }

    @Test
    public void whenDeleteAndPlatformContextMissingServicesTreatmentCodeThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getServices().get(0).setTreatmentCode(null);
        String platformContextFalse = ConvertPlatformContextPOJOToString.convertPlatformContextToString(platformContextDTOFalse);

        specification.addCustomHeader(RequestHeadersEnum.PLATFORM_CONTEXT.getName(), platformContextFalse);
        ErrorDTO errorDTO = errorsSteps.sendDeleteRequestWithError(specification);

        softNG.assertTrue(errorDTO.getMessage().contains(String.format(PlatformContextConstants.PLATFORM_CONTEXT_MISSING_FIELD, PlatformContextConstants.SERVICES_TREATMENT_CODE)));
        softNG.assertAll();
    }

    @Test
    public void whenDeleteAndPlatformContextMissingServicesTreatmentCodeTypeThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getServices().get(0).setTreatmentCodeType(null);
        String platformContextFalse = ConvertPlatformContextPOJOToString.convertPlatformContextToString(platformContextDTOFalse);

        specification.addCustomHeader(RequestHeadersEnum.PLATFORM_CONTEXT.getName(), platformContextFalse);
        ErrorDTO errorDTO = errorsSteps.sendGetRequestWithError(specification);

        softNG.assertTrue(errorDTO.getMessage().contains(String.format(PlatformContextConstants.PLATFORM_CONTEXT_MISSING_FIELD, PlatformContextConstants.SERVICES_TREATMENT_CODE_TYPE)));
        softNG.assertAll();
    }

    @Test
    public void whenDeleteAndPlatformContextMissingUserRolesThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        User tempUser = new User();
        tempUser.setId(PlatformContextConstants.PC_USER_ID);
        platformContextDTOFalse.setUser(tempUser);
        String platformContextFalse = ConvertPlatformContextPOJOToString.convertPlatformContextToString(platformContextDTOFalse);

        specification.addCustomHeader(RequestHeadersEnum.PLATFORM_CONTEXT.getName(), platformContextFalse);
        ErrorDTO errorDTO = errorsSteps.sendGetRequestWithError(specification);

        softNG.assertTrue(errorDTO.getMessage().contains(String.format(PlatformContextConstants.PLATFORM_CONTEXT_MISSING_FIELD, PlatformContextConstants.USER_ROLES)));
        softNG.assertAll();
    }

}
