package com.abc.automation.steps.member.snapshot;

import com.abc.automation.helpers.CustomFilterableRequestSpecification;
import com.abc.automation.helpers.EnvironmentHelper;
import com.abc.automation.helpers.RequestOperationsHelper;
import com.abc.automation.helpers.constants.BasePathConstants;
import com.abc.automation.helpers.enums.DomainEnum;
import com.abc.automation.dtos.member.snapshot.MemberDemographicsSnapshotResponseDTO;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by PPetarcheva on 4/19/2019.
 */
public class CreateMemberDemographicsSnapshotSteps {

    private RequestOperationsHelper requestOperationsHelper;

    private CustomFilterableRequestSpecification requestSpecification;

    public CreateMemberDemographicsSnapshotSteps(String platformContext, Headers headers) {
        requestSpecification = new CustomFilterableRequestSpecification();
        requestOperationsHelper = new RequestOperationsHelper();
        EnvironmentHelper environmentHelper = new EnvironmentHelper();

        requestSpecification.addBasePath(BasePathConstants.MEMBER_CREATE_DEMOGRAPHICS_SNAPSHOT_BASE_PATH);
        requestSpecification.addPlatformContextToRequest(platformContext);

        requestSpecification.addBaseURI(environmentHelper.constructBaseURIForDomain(DomainEnum.MEMBER));
        requestSpecification.addHeaders(headers);
    }

    public CreateMemberDemographicsSnapshotSteps(CustomFilterableRequestSpecification requestSpecification) {
        this.requestSpecification = new CustomFilterableRequestSpecification();
        requestOperationsHelper = new RequestOperationsHelper();
        EnvironmentHelper environmentHelper = new EnvironmentHelper();

        Headers headers = requestSpecification.getFilterableRequestSpecification().getHeaders();

        this.requestSpecification.addHeaders(headers);
        this.requestSpecification.addBasePath(BasePathConstants.MEMBER_CREATE_DEMOGRAPHICS_SNAPSHOT_BASE_PATH);
        this.requestSpecification.addBaseURI(environmentHelper.constructBaseURIForDomain(DomainEnum.MEMBER));
    }

    public Response createMemberDemographicsSnapshotResponse(String clientId, String memberId) {
        Map<String, String> pathParams = new HashMap<>();
        pathParams.put("clientId", clientId);
        pathParams.put("memberId", memberId);

        requestSpecification.addPathParams(pathParams);

        return requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());
    }

    public MemberDemographicsSnapshotResponseDTO createMemberDemographicsSnapshot(String clientId, String memberId) {
        Response result = createMemberDemographicsSnapshotResponse(clientId, memberId);

        result.then().statusCode(HttpStatus.SC_CREATED);

        return result.as(MemberDemographicsSnapshotResponseDTO.class);
    }

    public String createMemberDemographicsSnapshotAndGetSnapshotId(String clientId, String memberId) {
        MemberDemographicsSnapshotResponseDTO memberDemographicsSnapshotResponseDTO = createMemberDemographicsSnapshot(clientId, memberId);

        return memberDemographicsSnapshotResponseDTO.getSnapshotId();
    }
}
