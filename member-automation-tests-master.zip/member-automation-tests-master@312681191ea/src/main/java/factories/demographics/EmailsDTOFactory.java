package factories.demographics;

import dtos.demographics.EmailsDTO;

import java.util.ArrayList;

import static helpers.constants.Constants.*;

public class EmailsDTOFactory {

    public ArrayList<EmailsDTO> createEmailsDTO(boolean clientSource, String emailType, String emailValue) {
        ArrayList<EmailsDTO> list = new ArrayList<>();
        EmailsDTO email = new EmailsDTO();

        email.setClientSource(clientSource);
        email.setType(emailType);
        email.setValue(emailValue);

        list.add(email);

        return list;
    }

    public ArrayList<EmailsDTO> createEmailsDTO() {
        return createEmailsDTO(EMAIL_CLIENT_SOURCE, EMAIL_TYPE, EMAIL_VALUE);
    }
}
//AREA 51
