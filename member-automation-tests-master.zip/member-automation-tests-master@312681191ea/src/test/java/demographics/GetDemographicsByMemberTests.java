
package demographics;

import com.aim.automation.helpers.PlatformContextUtils;
import com.aim.automation.tests.base.GetTests;
import dtos.ErrorDTO;
import dtos.datamanager.MemberResponseDTO;
import dtos.demographics.MemberDemographicsDTO;
import dtos.search.GETMemberSearchDTO;
import helpers.constants.BasePathConstants;
import helpers.dataproviders.DataProviders;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpStatus;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import steps.datamanager.MemberDataManagerSteps;
import steps.demographics.GetMemberDemographicsSteps;
import steps.rabbitmqsimulator.PublishEventSteps;
import steps.search.MemberSearchSteps;

import static helpers.constants.Constants.*;
import static helpers.constants.ConstantsClientIds.*;
import static helpers.constants.ConstantsClientIds.CLIENT_ID_85;
import static org.apache.http.HttpStatus.SC_NOT_FOUND;

/**
 * Created by VBaliyska on 4/3/2019.
 */
public class GetDemographicsByMemberTests extends GetTests {

    private GetMemberDemographicsSteps memberDemographicsSteps;
    public  String CLIENT_MEMBER_ID;

    @BeforeClass
    public void init() {
        basePath = BasePathConstants.BASE_PATH_GET_DEMOGRAPHICS;
        pathParamsMap.clear();

        pathParamsMap.put("clientId", CLIENT_ID_186);
        pathParamsMap.put("memberId", "8af2f59a-74d8-4f79-9833-4396d13bc024");
    }

    @BeforeMethod
    public void initMethod() {
        CLIENT_MEMBER_ID = RandomStringUtils.randomNumeric(10) + RandomStringUtils.randomAlphabetic(5).toUpperCase();
    }

    @Test
    public void whenSendValidMemberIdThenDemographicsInfoIsReturned() {
        MemberDataManagerSteps memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_186,CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();
        softly.then(memberId).isNotEmpty();

        memberDemographicsSteps = new GetMemberDemographicsSteps(platformContextHeader, headers);
        MemberDemographicsDTO response = memberDemographicsSteps.getMemberDemographics(CLIENT_ID_186, memberId);
        String email = response.getEmails().get(0).getValue();
        String phone = response.getPhones().get(0).getValue();

        softly.then(email).isNotEmpty();
        softly.then(phone).isNotEmpty();
        softly.then(response.getId()).isEqualTo(memberId);
        softly.then(response.getClientId()).contains(CLIENT_ID_186);
        softly.then(response.getClientSpecificDemographics()).isNotNull();
        softly.then(response.getDependentCode()).isEqualTo(DEPENDENT_CODE);
        softly.then(response.getDependentRelationCode()).isEqualTo(CLIENT_DEPENDENT_RELATION_CODE);
        softly.then(response.getEmails().get(0).getValue()).isNotEmpty();
        softly.assertAll();
    }

    @Test
    public void whenSendNullEmployergroupcodeAndNullIssuancestatecodeThenDemographicsInfoIsReturned() {
        PlatformContextUtils platformContextUtils=new PlatformContextUtils();
        platformContextHeader=platformContextUtils.changeIssuanceStateCode(platformContextHeader,null);
        platformContextHeader=platformContextUtils.changeEmployerGroupCode(platformContextHeader,null);

        MemberDataManagerSteps memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMember(CLIENT_ID_186,CLIENT_MEMBER_ID);

        String memberId = memberResponseDTO.getId();
        softly.then(memberId).isNotEmpty();

        memberDemographicsSteps = new GetMemberDemographicsSteps(platformContextHeader, headers);
        MemberDemographicsDTO response = memberDemographicsSteps.getMemberDemographics(CLIENT_ID_186, memberId);
        String email = response.getEmails().get(0).getValue();
        String phone = response.getPhones().get(0).getValue();

        softly.then(email).isNotEmpty();
        softly.then(phone).isNotEmpty();
        softly.then(response.getId()).isEqualTo(memberId);
        softly.then(response.getClientId()).contains(CLIENT_ID_186);
        softly.then(response.getClientSpecificDemographics()).isNotNull();
        softly.then(response.getDependentCode()).isEqualTo(DEPENDENT_CODE);
        softly.then(response.getDependentRelationCode()).isEqualTo(CLIENT_DEPENDENT_RELATION_CODE);
        softly.then(response.getEmails().get(0).getValue()).isNotEmpty();
        softly.assertAll();
    }

    //----------------------------------------CONTEXT-MODE-TESTS--------------------------------------------------------

    @Test(dataProvider = "contextModeValue", dataProviderClass = DataProviders.class)
    public void whenCreateMemberWithSpecificDemographicsAndEnrollmentWithTestModeAndGetTheDemographicsInformationThenResponseSC201(String contextMode) {

        PlatformContextUtils platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeContextMode(platformContextHeader, contextMode);

        //Create unique clientMemberId, so the created member is unique and it is easier to find
        String clientMemberId = RandomStringUtils.random(10, true, true);

        //Create a member with specific enrollment and demographics
        MemberDataManagerSteps memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMemberClientMemberId(CLIENT_ID_85, clientMemberId);

        //Get the memberId that is created
        String memberId = memberResponseDTO.getId();

        //Check that memberId is created
        softly.then(memberId).isNotNull().isNotEmpty().isNotBlank();

        //Get the demographics information
        memberDemographicsSteps = new GetMemberDemographicsSteps(platformContextHeader, headers);
        MemberDemographicsDTO response = memberDemographicsSteps.getMemberDemographics(CLIENT_ID_85, memberId);

        softly.then(response.getClientMemberId()).isEqualTo(clientMemberId);
        softly.then(response.getId()).isEqualTo(memberId);
        softly.then(response.getClientId()).isEqualTo(CLIENT_ID_85);
        softly.assertAll();
    }

    //----------------------------------------------------------NEGATIVE_TEST--STATUS-CODE-404---------------------------------------------------------
    @Test(dataProvider = "invalidMemberIdAndClientMemberId", dataProviderClass = DataProviders.class)
    public void whenSendInvalidClientIdAndInvalidMemberIdThenServiceReturnSC404(String clientId, String clientMemberId) {

        memberDemographicsSteps = new GetMemberDemographicsSteps(platformContextHeader, headers);
        ErrorDTO error = memberDemographicsSteps.getMemberDemographicsSC404(clientId, clientMemberId);

        softly.then(error.getCode()).isEqualTo(SC_NOT_FOUND);
        softly.then(error.getMessage()).contains(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }

    @Test(dataProvider = "clientMemberId", dataProviderClass = DataProviders.class)
    public void whenSendInvalidMemberIdThenServiceReturnsNotFoundResponseSC404(String clientMemberId) {

        memberDemographicsSteps = new GetMemberDemographicsSteps(platformContextHeader, headers);
        ErrorDTO error = memberDemographicsSteps.getMemberDemographicsSC404(CLIENT_ID_186, clientMemberId);

        softly.then(error.getCode()).isEqualTo(SC_NOT_FOUND);
        softly.then(error.getMessage()).contains(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }

    @Test(enabled = false)
    public void whenPutOnGetEndpointThenServiceReturnsMethodNotAllowedResponse() {
        // Need to overwrite the parent test because there is a PUT endpoint available with the same path
    }

    //-----------------------------------MANUAL-ADD-TESTS---RABBITMQ-CONSUMER---------------------------------------------
    /*
     *Test the manual added member via RabbitMq is distributed to member-demographics service
     */
    @Test
    public void whenSuccessfulAddMemberViaRabbitMqThenMemberIsLoadedInDemographics() {
        // create member through Rabbit Mq
        String clientMemberId = RandomStringUtils.random(24, true, true);

        PublishEventSteps publishEventSteps = new PublishEventSteps(platformContextHeader, headers);
        publishEventSteps.publishEventMemberManualAdd(CLIENT_ID_210, clientMemberId);

        //get member uuid
        GETMemberSearchDTO memberSearchDTO = new MemberSearchSteps(platformContextHeader, headers).getMemberSearch(CLIENT_ID_210, clientMemberId, null, null, null);
        String id = memberSearchDTO.getMembers().get(0).getId();

        //get member demographics
        memberDemographicsSteps = new GetMemberDemographicsSteps(platformContextHeader, headers);
        MemberDemographicsDTO response = memberDemographicsSteps.getMemberDemographics(CLIENT_ID_210, id);

        softly.then(response.getClientId()).isEqualTo(CLIENT_ID_210);
        softly.then(response.getClientMemberId()).isEqualTo(clientMemberId);
        softly.assertAll();
    }

    @Test(dataProvider = "contextModeInDataBase", dataProviderClass = DataProviders.class)
    public void whenCreateMemberWithSpecificDemographicsInformationWithContextModeTestAndGetTheDemographicsInformationWithContextModeProdThenResponseSC404(String contextMode, String dataBaseMode) {

        PlatformContextUtils platformContextUtils = new PlatformContextUtils();
        platformContextHeader = platformContextUtils.changeContextMode(platformContextHeader, contextMode);

        //Create unique clientMemberId, so the created member is unique and it is easier to find
        String clientMemberId = RandomStringUtils.random(10, true, true);

        //Create a member with specific enrollment and demographics
        MemberDataManagerSteps memberDataManagerSteps = new MemberDataManagerSteps(platformContextHeader, headers);
        MemberResponseDTO memberResponseDTO = memberDataManagerSteps.createMemberClientMemberId(CLIENT_ID_85, clientMemberId);

        //Get the memberId that is created
        String memberId = memberResponseDTO.getId();

        //Check that memberId is created
        softly.then(memberId).isNotNull().isNotEmpty().isNotBlank();

        //Create platformContext with the different context mode
        PlatformContextUtils platformContextUtilsDataBase = new PlatformContextUtils();
        platformContextHeader = platformContextUtilsDataBase.changeContextMode(platformContextHeader, dataBaseMode);

        //Get the demographics with the different context mode
        memberDemographicsSteps = new GetMemberDemographicsSteps(platformContextHeader, headers);
        ErrorDTO response = memberDemographicsSteps.getMemberDemographicsSC404(CLIENT_ID_85, memberId);

        softly.then(response.getCode()).isEqualTo(HttpStatus.SC_NOT_FOUND);
        softly.then(response.getMessage()).isEqualTo(ERROR_ENTITY_NOT_FOUND);
        softly.assertAll();
    }


}