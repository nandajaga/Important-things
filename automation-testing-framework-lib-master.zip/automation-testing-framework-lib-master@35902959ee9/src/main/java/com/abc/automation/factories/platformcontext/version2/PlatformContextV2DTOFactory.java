package com.abc.automation.factories.platformcontext.version2;


import com.abc.automation.factories.platformcontext.IPlatformContextFactory;
import com.abc.servicemodel.domainV2.*;

import static com.abc.automation.helpers.constants.PlatformContextConstants.*;

public class PlatformContextV2DTOFactory implements IPlatformContextFactory<PlatformContextV2> {

    public PlatformContextV2 createPlatformContextDTO(String contextMode, String interactionType, String interactionId, String channelCode, MemberV2 member, ProviderV2 provider, UserV2 user, CaseV2 casePC) {
        PlatformContextV2 platformContextV2 = new PlatformContextV2();

        platformContextV2.setContextMode(contextMode);
        platformContextV2.setInteractionType(interactionType);
        platformContextV2.setInteractionId(interactionId);
        platformContextV2.setChannelCode(channelCode);
        platformContextV2.setMember(member);
        platformContextV2.setProvider(provider);
        platformContextV2.setUser(user);
        platformContextV2.setCaseObject(casePC);

        return platformContextV2;
    }

    public PlatformContextV2 createPlatformContextDTO() {
        CaseV2 casePC = new CaseV2DTOFactory().createCaseDTO();
        MemberV2 member = new MemberV2DTOFactory().createMemberDTO();
        ProviderV2 provider = new ProviderV2DTOFactory().createProviderDTO();
        UserV2 user = new UserV2DTOFactory().createUserDTO();

        return createPlatformContextDTO(PC_CONTEXT_MODE, PC_INTERACTION_TYPE, PC_INTERACTION_ID, PC_CHANNEL_CODE, member, provider, user, casePC);

    }


}
