package dtos.clientconfig;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MemberReviewProgramEligibilityResponseDTO {

    private String reviewProgramCode;
    private boolean isEligible;

    public String getReviewProgramCode() {
        return reviewProgramCode;
    }

    public void setReviewProgramCode(String reviewProgramCode) {
        this.reviewProgramCode = reviewProgramCode;
    }


    public boolean getIsEligible() {
        return isEligible;
    }

    public void setIsEligible(boolean isEligible) {
        this.isEligible = isEligible;
    }

}
