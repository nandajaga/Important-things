package com.abc.automation.helpers.constants;

/**
 * Created by PPetarcheva on 3/18/2019.
 */
public class PlatformContextConstants {

    // TODO: Check the provided data and update with more relevant

    public static final String PLATFORM_CONTEXT = "platform-context";

    //Platform-Context fields values
    public static final String PC_CHANNEL_CODE = "CC";
    public static final Integer PC_APPLICATION_ID = 80;
    public static final String PC_USER_ID = "96f20e3f-43e3-4922-9ac3-91cb2672f231";
    public static final Integer PC_MEMBER_CLIENT_ID = 186;
    public static final Integer PC_SOLUTION_ID = 17;
    public static final String PC_SOLUTION_START_DATE = "2019-03-18";
    public static final String PC_SERVICES_TREATMENT_CODE = "trtmCode";
    public static final String PC_SERVICES_TREATMENT_CODE_TYPE = "trtmCodeType";
    public static final String PC_ENROLLMENT_EMPLOYER_GROUP_CODE = "100";
    public static final String PC_ENROLLMENT_NETWORK_CODE = "123";
    public static final String PC_ENROLLMENT_PRODUCT_CODE = "PPO";
    public static final String PC_ENROLLMENT_INSURANCE_STATE_CODE = "AL";
    public static final String PC_ENROLLMENT_JURISDICTION_CODE = "312";
    public static final String PC_ENROLLMENT_PROGRAM_CODE = "543";
    public static final String PC_ENROLLMENT_LINE_OF_BUSINESS_CODE = "medicaid";
    public static final String PC_LOCATION_STATE_CODE = "AL";
    public static final String PC_LOCATION_REGION_CODE = "county";
    public static final String PC_LOCATION_ZIP_CODE = "11111";
    public static final String PC_CASE_CREATION_START_DATE = "2019-03-18 01:00:00";
    public static final String PC_CASE_ID = "36d3b29a-5187-416e-b824-cc660ad0b57b";
    public static final String PC_INTERACTION_TYPE = "IC";
    public static final String PC_INTERACTION_ID = "65e2cf32-eabf-49c4-8b94-fded4f4a9717";

    //Platform-Context-V2 fields values
    public static final String PC_CONTEXT_MODE = "NEXTGEN";
    public static final String PC_ALPHA_PREFIX_CODE = "WMW";
    public static final String PC_FUNDING_TYPE_CODE = "FLF";
    public static final String PC_PLACE_OF_SERVICE_CODE = "OP";
    public static final String PC_SPECIALTY_CODE = "1";
    public static final String PC_CASE_CREATED_DATE = "2019-06-13T00:00:00.000Z";
    public static final String PC_REQUEST_CREATED_DATE = "2019-06-13T00:00:00.000Z";
    public static final String PC_DATE_OF_SERVICE = "2019-06-13";
    public static final Integer PC_PARENT_SOLUTION_ID = 14;
    public static final String PC_REQUEST_ID = "94d10a63-1f59-4481-8dfd-f3b741231988";
    public static final String PC_REVIEW_CATEGORY_CODE = "PROSPECTIVE";

    //Error message in case of missing required field in Platform-context header
    public static final String PLATFORM_CONTEXT_MISSING_FIELD = "PlatformContext %s cannot be null or empty";
    public static final String PLATFORM_CONTEXT_NULL_FIELD = "PlatformContext %s cannot be null";
    public static final String MEMBER_CLIENTID = "Member clientId";
    public static final String LOCATION_STATECODE = "Location stateCode";
    public static final String LOCATION_ZIPCODE = "Location zipCode";
    public static final String SERVICES_TREATMENT_CODE = "Service treatmentCode";
    public static final String SERVICES_TREATMENT_CODE_FIELD = "services.treatmentCode";
    public static final String SERVICES_TREATMENT_CODE_TYPE = "Service treatmentCodeType";
    public static final String SERVICES_TREATMENT_CODE_TYPE_FIELD = "services.treatmentCodeType";
    public static final String APPLICATION_ID = "applicationId";
    public static final String SOLUTION_ID = "Solution id";
    public static final String ENROLLMENT_EMPLOYER_GROUP_CODE = "Enrollment employerGroupCode";
    public static final String ENROLLMENT_PRODUCT_CODE = "Enrollment productCode";
    public static final String ENROLLMENT_ISSUANCE_STATE_CODE = "Enrollment issuanceStateCode";
    public static final String ENROLLMENT_JUSTISDICTION_CODE = "Enrollment jurisdictionCode";
    public static final String ENROLLMENT_PROGRAME_CODE = "Enrollment programCode";
    public static final String ENROLLMENT_LINE_OF_BUSINESS_CODE = "Enrollment lineOfBusinessCode";
    public static final String USER_ID = "User Id";
    public static final String USER_ROLES = "User roles";
    public static final String USER_ROLES_FIELD = "user.roles";
    public static final String MEMBER_LOCATION = "Member location";
    public static final String MEMBER_LOCATION_FIELD = "member.location";
}
