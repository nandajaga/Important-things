package steps.demographics.snapshots;

import com.aim.automation.helpers.CustomFilterableRequestSpecification;
import com.aim.automation.helpers.RequestOperationsHelper;
import dtos.ErrorDTO;
import dtos.demographics.snapshot.MemberDemographicsSnapshotDTO;
import helpers.constants.BasePathConstants;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by PPetarcheva on 5/28/2019.
 */
public class PostMemberDemographicsSnapshotSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification requestSpecification;

    public PostMemberDemographicsSnapshotSteps(String platformContext, Headers headers) {
        requestOperationsHelper = new RequestOperationsHelper();
        requestSpecification = new CustomFilterableRequestSpecification();

        requestSpecification.addBasePath(BasePathConstants.BASE_PATH_MEMBER_DEMOGRAPHICS_SNAPSHOT_POST);
        requestSpecification.addPlatformContextToRequest(platformContext);
        requestSpecification.setContentType(ContentType.JSON);
        requestSpecification.addHeaders(headers);
    }

    public MemberDemographicsSnapshotDTO createMemberDemographicsSnapshot(String clientId, String memberId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);
        pathParamsMap.put("memberId", memberId);

        requestSpecification.addPathParams(pathParamsMap);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        result.then().statusCode(HttpStatus.SC_CREATED);

        return result.as(MemberDemographicsSnapshotDTO.class);
    }

    public ErrorDTO createMemberDemographicsSnapshotError(String clientId, String memberId) {
        Map<String, String> pathParamsMap = new HashMap<>();
        pathParamsMap.put("clientId", clientId);
        pathParamsMap.put("memberId", memberId);

        requestSpecification.addPathParams(pathParamsMap);

        Response result = requestOperationsHelper.sendPostRequest(requestSpecification.getFilterableRequestSpecification());

        return result.as(ErrorDTO.class);
    }
}
