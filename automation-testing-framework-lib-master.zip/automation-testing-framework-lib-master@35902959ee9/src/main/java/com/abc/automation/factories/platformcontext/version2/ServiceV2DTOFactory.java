package com.abc.automation.factories.platformcontext.version2;

import com.abc.servicemodel.domainV2.ServiceV2;

import static com.abc.automation.helpers.constants.PlatformContextConstants.PC_SERVICES_TREATMENT_CODE;
import static com.abc.automation.helpers.constants.PlatformContextConstants.PC_SERVICES_TREATMENT_CODE_TYPE;

public class ServiceV2DTOFactory {
    public ServiceV2 createServiceDTO(String treatmentCode, String treatmentCodeType) {
        ServiceV2 service = new ServiceV2();

        service.setTreatmentCode(treatmentCode);
        service.setTreatmentCodeType(treatmentCodeType);

        return service;
    }

    public ServiceV2 createServiceDTO() {

        return createServiceDTO(PC_SERVICES_TREATMENT_CODE, PC_SERVICES_TREATMENT_CODE_TYPE);
    }
}
