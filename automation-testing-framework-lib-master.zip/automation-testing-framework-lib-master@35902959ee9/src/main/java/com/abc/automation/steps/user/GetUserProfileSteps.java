package com.abc.automation.steps.user;

import com.abc.automation.helpers.CustomFilterableRequestSpecification;
import com.abc.automation.helpers.EnvironmentHelper;
import com.abc.automation.helpers.RequestOperationsHelper;
import com.abc.automation.helpers.constants.BasePathConstants;
import com.abc.automation.helpers.enums.DomainEnum;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;

import java.util.Collections;

public class GetUserProfileSteps {

    private RequestOperationsHelper requestOperationsHelper;
    private CustomFilterableRequestSpecification filterableRequestSpecification;

    public GetUserProfileSteps(CustomFilterableRequestSpecification custSpec) {
        EnvironmentHelper environmentHelper = new EnvironmentHelper();
        requestOperationsHelper = new RequestOperationsHelper();
        filterableRequestSpecification = new CustomFilterableRequestSpecification(custSpec);
        filterableRequestSpecification.addBasePath(BasePathConstants.USER_MANAGEMENT_QUERY_GET_PATH);
        filterableRequestSpecification.addBaseURI(environmentHelper.constructBaseURIForDomain(DomainEnum.USER));
    }


    public boolean isExistingUser(String uid) {
        filterableRequestSpecification.addPathParams(Collections.singletonMap("uid", uid));
        Response response = requestOperationsHelper.sendGetRequest(filterableRequestSpecification.getFilterableRequestSpecification());

        return response.getStatusCode() == HttpStatus.SC_OK;
    }

}
