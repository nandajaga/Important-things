package com.abc.automation.helpers.enums;

import static org.testng.Assert.fail;

public enum ContextModeEnum {
    PROD("PROD"),
    TEST("TEST");

    private String mode;

    ContextModeEnum(String m) {
        mode = m;
    }

    public String getMode() {
        return mode;
    }

    public static ContextModeEnum fromString(String text) {
        for (ContextModeEnum v : ContextModeEnum.values()) {
            if (v.mode.equalsIgnoreCase(text)) {
                return v;
            }
        }

        fail("Context Mode '" + text + "' is not valid!");
        return null;
    }
}
