package dtos.workflow;

/**
 * Created by RKohli on 04/28/2020
 */
public class FlowDTO {
    private String businessKey;
    private String businessKeyCode;
    private String businessKeyCodeDescription;

    public String getBusinessKey() {
        return businessKey;
    }

    public void setBusinessKey(String businessKey) {
        this.businessKey = businessKey;
    }

    public String getBusinessKeyCode() {
        return businessKeyCode;
    }

    public void setBusinessKeyCode(String businessKeyCode) {
        this.businessKeyCode = businessKeyCode;
    }

    public String getBusinessKeyCodeDescription() {
        return businessKeyCodeDescription;
    }

    public void setBusinessKeyCodeDescription(String businessKeyCodeDescription) {
        this.businessKeyCodeDescription = businessKeyCodeDescription;
    }
}
