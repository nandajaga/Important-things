package com.abc.automation.tests.base;

import com.abc.automation.dtos.ErrorDTO;
import com.abc.automation.factories.platformcontext.PlatformContextDTOFactory;
import com.abc.automation.factories.platformcontext.SolutionDTOFactory;
import com.abc.automation.factories.platformcontext.UserDTOFactory;
import com.abc.automation.helpers.ReadContentResourceFiles;
import com.abc.automation.helpers.constants.Constants;
import com.abc.automation.helpers.constants.PlatformContextConstants;
import com.abc.automation.helpers.convert.ConvertPlatformContextPOJOToString;
import com.abc.automation.steps.ErrorsSteps;
import com.abc.servicemodel.domain.PlatformContext;
import com.abc.servicemodel.domain.User;
import org.testng.annotations.Test;

import java.io.InputStream;

import static org.apache.http.HttpStatus.SC_BAD_REQUEST;

public class PostMultipartTests extends PostWithPlatformContextTests {

    @Test
    public void whenPostAndPlatformContextMissingChannelIdThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.setChannelCode(null);
        String platformContextFalse = ConvertPlatformContextPOJOToString.convertPlatformContextToString(platformContextDTOFalse);

        InputStream stream = new ReadContentResourceFiles().readContentResourceFile(Constants.TEST_PDF_FILE);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        ErrorDTO errorDTO = errorsSteps.sendPostRequestWithOneFileAsMultiPartAndError(SC_BAD_REQUEST, platformContextFalse, headers, uploadFileName, stream, Constants.PDF_DOCUMENT_ATTACHMENT_TYPE, basePath, pathParamsMap, queryParamsMap);

        softNG.assertTrue(errorDTO.getMessage().contains(String.format(PlatformContextConstants.PLATFORM_CONTEXT_MISSING_FIELD, Constants.CHANNEL_CODE)));
        softNG.assertAll();
    }

    @Test(enabled = false)
    public void whenPostAndPlatformContextMissingSolutionThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.setSolution(null);
        String platformContextFalse = ConvertPlatformContextPOJOToString.convertPlatformContextToString(platformContextDTOFalse);

        String message = "Platform context header is not valid. Solution field is required.";

        InputStream stream = new ReadContentResourceFiles().readContentResourceFile(Constants.TEST_PDF_FILE);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        ErrorDTO errorDTO = errorsSteps.sendPostRequestWithOneFileAsMultiPartAndError(SC_BAD_REQUEST, platformContextFalse, headers, uploadFileName, stream, Constants.PDF_DOCUMENT_ATTACHMENT_TYPE, basePath, pathParamsMap, queryParamsMap);

        //Restore initial value of Solutions
        platformContextDTOFalse.setSolution(new SolutionDTOFactory().createSolutionPCDTO());

        //softNG.then(errorDTO.getMessage()).contains(message);
        softNG.assertAll();
    }

    @Test
    public void whenPostAndPlatformContextMissingMemberClientIdThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getMember().setClientId(null);
        String platformContextFalse = ConvertPlatformContextPOJOToString.convertPlatformContextToString(platformContextDTOFalse);

        InputStream stream = new ReadContentResourceFiles().readContentResourceFile(Constants.TEST_PDF_FILE);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        ErrorDTO errorDTO = errorsSteps.sendPostRequestWithOneFileAsMultiPartAndError(SC_BAD_REQUEST, platformContextFalse, headers, uploadFileName, stream, Constants.PDF_DOCUMENT_ATTACHMENT_TYPE, basePath, pathParamsMap, queryParamsMap);

        //Restore initial value of clientId
        platformContextDTOFalse.getMember().setClientId(PlatformContextConstants.PC_MEMBER_CLIENT_ID);

        softNG.assertTrue(errorDTO.getMessage().contains(String.format(PlatformContextConstants.PLATFORM_CONTEXT_NULL_FIELD, PlatformContextConstants.MEMBER_CLIENTID)));
        softNG.assertAll();
    }

    @Test
    public void whenPostAndPlatformContextMissingLocationStateCodeThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getMember().getLocation().setStateCode(null);
        String platformContextFalse = ConvertPlatformContextPOJOToString.convertPlatformContextToString(platformContextDTOFalse);

        InputStream stream = new ReadContentResourceFiles().readContentResourceFile(Constants.TEST_PDF_FILE);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        ErrorDTO errorDTO = errorsSteps.sendPostRequestWithOneFileAsMultiPartAndError(SC_BAD_REQUEST, platformContextFalse, headers, uploadFileName, stream, Constants.PDF_DOCUMENT_ATTACHMENT_TYPE, basePath, pathParamsMap, queryParamsMap);

        //Restore initial value of StateCode
        platformContextDTOFalse.getMember().getLocation().setStateCode(PlatformContextConstants.PC_LOCATION_STATE_CODE);

        softNG.assertTrue(errorDTO.getMessage().contains(String.format(PlatformContextConstants.PLATFORM_CONTEXT_MISSING_FIELD, PlatformContextConstants.LOCATION_STATECODE)));
        softNG.assertAll();
    }

    @Test
    public void whenPostAndPlatformContextMissingLocationZipCodeThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getMember().getLocation().setZipCode(null);
        String platformContextFalse = ConvertPlatformContextPOJOToString.convertPlatformContextToString(platformContextDTOFalse);

        InputStream stream = new ReadContentResourceFiles().readContentResourceFile(Constants.TEST_PDF_FILE);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        ErrorDTO errorDTO = errorsSteps.sendPostRequestWithOneFileAsMultiPartAndError(SC_BAD_REQUEST, platformContextFalse, headers, uploadFileName, stream, Constants.PDF_DOCUMENT_ATTACHMENT_TYPE, basePath, pathParamsMap, queryParamsMap);

        //Restore initial value of ZipCode
        platformContextDTOFalse.getMember().getLocation().setZipCode(PlatformContextConstants.PC_LOCATION_ZIP_CODE);

        softNG.assertTrue(errorDTO.getMessage().contains(String.format(PlatformContextConstants.PLATFORM_CONTEXT_MISSING_FIELD, PlatformContextConstants.LOCATION_ZIPCODE)));
        softNG.assertAll();
    }

    @Test
    public void whenPostAndPlatformContextMissingServicesTreatmentCodeThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getServices().get(0).setTreatmentCode(null);
        String platformContextFalse = ConvertPlatformContextPOJOToString.convertPlatformContextToString(platformContextDTOFalse);

        InputStream stream = new ReadContentResourceFiles().readContentResourceFile(Constants.TEST_PDF_FILE);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        ErrorDTO errorDTO = errorsSteps.sendPostRequestWithOneFileAsMultiPartAndError(SC_BAD_REQUEST, platformContextFalse, headers, uploadFileName, stream, Constants.PDF_DOCUMENT_ATTACHMENT_TYPE, basePath, pathParamsMap, queryParamsMap);

        //Restore initial value of TreatmentCode
        platformContextDTOFalse.getServices().get(0).setTreatmentCode(PlatformContextConstants.PC_SERVICES_TREATMENT_CODE);

        softNG.assertTrue(errorDTO.getMessage().contains(String.format(PlatformContextConstants.PLATFORM_CONTEXT_MISSING_FIELD, PlatformContextConstants.SERVICES_TREATMENT_CODE)));
        softNG.assertAll();
    }

    @Test
    public void whenPostAndPlatformContextMissingServicesTreatmentCodeTypeThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getServices().get(0).setTreatmentCodeType(null);
        String platformContextFalse = ConvertPlatformContextPOJOToString.convertPlatformContextToString(platformContextDTOFalse);

        InputStream stream = new ReadContentResourceFiles().readContentResourceFile(Constants.TEST_PDF_FILE);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        ErrorDTO errorDTO = errorsSteps.sendPostRequestWithOneFileAsMultiPartAndError(SC_BAD_REQUEST, platformContextFalse, headers, uploadFileName, stream, Constants.PDF_DOCUMENT_ATTACHMENT_TYPE, basePath, pathParamsMap, queryParamsMap);

        //Restore initial value ot Treatment Code Type
        platformContextDTOFalse.getServices().get(0).setTreatmentCodeType(PlatformContextConstants.PC_SERVICES_TREATMENT_CODE_TYPE);

        softNG.assertTrue(errorDTO.getMessage().contains(String.format(PlatformContextConstants.PLATFORM_CONTEXT_MISSING_FIELD, PlatformContextConstants.SERVICES_TREATMENT_CODE_TYPE)));
        softNG.assertAll();
    }

    @Test
    public void whenPostAndPlatformContextMissingApplicationIdThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.setApplicationId(null);
        String platformContextFalse = ConvertPlatformContextPOJOToString.convertPlatformContextToString(platformContextDTOFalse);

        InputStream stream = new ReadContentResourceFiles().readContentResourceFile(Constants.TEST_PDF_FILE);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        ErrorDTO errorDTO = errorsSteps.sendPostRequestWithOneFileAsMultiPartAndError(SC_BAD_REQUEST, platformContextFalse, headers, uploadFileName, stream, Constants.PDF_DOCUMENT_ATTACHMENT_TYPE, basePath, pathParamsMap, queryParamsMap);

        platformContextDTOFalse.setApplicationId(PlatformContextConstants.PC_APPLICATION_ID);

        softNG.assertTrue(errorDTO.getMessage().contains(String.format(PlatformContextConstants.PLATFORM_CONTEXT_NULL_FIELD, PlatformContextConstants.APPLICATION_ID)));
        softNG.assertAll();
    }

    @Test
    public void whenPostAndPlatformContextMissingSolutionIdThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getSolution().setId(null);
        String platformContextFalse = ConvertPlatformContextPOJOToString.convertPlatformContextToString(platformContextDTOFalse);

        InputStream stream = new ReadContentResourceFiles().readContentResourceFile(Constants.TEST_PDF_FILE);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        ErrorDTO errorDTO = errorsSteps.sendPostRequestWithOneFileAsMultiPartAndError(SC_BAD_REQUEST, platformContextFalse, headers, uploadFileName, stream, Constants.PDF_DOCUMENT_ATTACHMENT_TYPE, basePath, pathParamsMap, queryParamsMap);

        platformContextDTOFalse.getSolution().setId(PlatformContextConstants.PC_SOLUTION_ID);

        softNG.assertTrue(errorDTO.getMessage().contains(String.format(PlatformContextConstants.PLATFORM_CONTEXT_NULL_FIELD, PlatformContextConstants.SOLUTION_ID)));
        softNG.assertAll();
    }

    @Test
    public void whenPostAndPlatformContextMissingEnrollmentEmployerGroupCodeThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getMember().getEnrollment().setEmployerGroupCode(null);
        String platformContextFalse = ConvertPlatformContextPOJOToString.convertPlatformContextToString(platformContextDTOFalse);

        InputStream stream = new ReadContentResourceFiles().readContentResourceFile(Constants.TEST_PDF_FILE);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        ErrorDTO errorDTO = errorsSteps.sendPostRequestWithOneFileAsMultiPartAndError(SC_BAD_REQUEST, platformContextFalse, headers, uploadFileName, stream, Constants.PDF_DOCUMENT_ATTACHMENT_TYPE, basePath, pathParamsMap, queryParamsMap);

        //Restore initial value of EmployerGroupCode
        platformContextDTOFalse.getMember().getEnrollment().setEmployerGroupCode(PlatformContextConstants.PC_ENROLLMENT_EMPLOYER_GROUP_CODE);

        softNG.assertTrue(errorDTO.getMessage().contains(String.format(PlatformContextConstants.PLATFORM_CONTEXT_MISSING_FIELD, PlatformContextConstants.ENROLLMENT_EMPLOYER_GROUP_CODE)));
        softNG.assertAll();
    }

    @Test
    public void whenPostAndPlatformContextMissingEnrollmentProductCodeThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getMember().getEnrollment().setProductCode(null);
        String platformContextFalse = ConvertPlatformContextPOJOToString.convertPlatformContextToString(platformContextDTOFalse);

        InputStream stream = new ReadContentResourceFiles().readContentResourceFile(Constants.TEST_PDF_FILE);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        ErrorDTO errorDTO = errorsSteps.sendPostRequestWithOneFileAsMultiPartAndError(SC_BAD_REQUEST, platformContextFalse, headers, uploadFileName, stream, Constants.PDF_DOCUMENT_ATTACHMENT_TYPE, basePath, pathParamsMap, queryParamsMap);

        //Restore initial value of ProductCode
        platformContextDTOFalse.getMember().getEnrollment().setProductCode(PlatformContextConstants.PC_ENROLLMENT_PRODUCT_CODE);

        softNG.assertTrue(errorDTO.getMessage().contains(String.format(PlatformContextConstants.PLATFORM_CONTEXT_MISSING_FIELD, PlatformContextConstants.ENROLLMENT_PRODUCT_CODE)));
        softNG.assertAll();
    }

    @Test
    public void whenPostAndPlatformContextMissingEnrollmentIssuanceStateCodeThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getMember().getEnrollment().setIssuanceStateCode(null);
        String platformContextFalse = ConvertPlatformContextPOJOToString.convertPlatformContextToString(platformContextDTOFalse);

        InputStream stream = new ReadContentResourceFiles().readContentResourceFile(Constants.TEST_PDF_FILE);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        ErrorDTO errorDTO = errorsSteps.sendPostRequestWithOneFileAsMultiPartAndError(SC_BAD_REQUEST, platformContextFalse, headers, uploadFileName, stream, Constants.PDF_DOCUMENT_ATTACHMENT_TYPE, basePath, pathParamsMap, queryParamsMap);

        //Restore initial value of IssuanceStateCode
        platformContextDTOFalse.getMember().getEnrollment().setIssuanceStateCode(PlatformContextConstants.PC_ENROLLMENT_INSURANCE_STATE_CODE);

        softNG.assertTrue(errorDTO.getMessage().contains(String.format(PlatformContextConstants.PLATFORM_CONTEXT_MISSING_FIELD, PlatformContextConstants.ENROLLMENT_ISSUANCE_STATE_CODE)));
        softNG.assertAll();
    }

    @Test
    public void whenPostAndPlatformContextMissingEnrollmentJurisdictionCodeThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getMember().getEnrollment().setJurisdictionCode(null);
        String platformContextFalse = ConvertPlatformContextPOJOToString.convertPlatformContextToString(platformContextDTOFalse);

        InputStream stream = new ReadContentResourceFiles().readContentResourceFile(Constants.TEST_PDF_FILE);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        ErrorDTO errorDTO = errorsSteps.sendPostRequestWithOneFileAsMultiPartAndError(SC_BAD_REQUEST, platformContextFalse, headers, uploadFileName, stream, Constants.PDF_DOCUMENT_ATTACHMENT_TYPE, basePath, pathParamsMap, queryParamsMap);

        //Restore initial value of JustificationCode
        platformContextDTOFalse.getMember().getEnrollment().setJurisdictionCode(PlatformContextConstants.PC_ENROLLMENT_JURISDICTION_CODE);

        softNG.assertTrue(errorDTO.getMessage().contains(String.format(PlatformContextConstants.PLATFORM_CONTEXT_MISSING_FIELD, PlatformContextConstants.ENROLLMENT_JUSTISDICTION_CODE)));
        softNG.assertAll();
    }

    @Test
    public void whenPostAndPlatformContextMissingEnrollmentProgramCodeThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getMember().getEnrollment().setProgramCode(null);
        String platformContextFalse = ConvertPlatformContextPOJOToString.convertPlatformContextToString(platformContextDTOFalse);

        InputStream stream = new ReadContentResourceFiles().readContentResourceFile(Constants.TEST_PDF_FILE);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        ErrorDTO errorDTO = errorsSteps.sendPostRequestWithOneFileAsMultiPartAndError(SC_BAD_REQUEST, platformContextFalse, headers, uploadFileName, stream, Constants.PDF_DOCUMENT_ATTACHMENT_TYPE, basePath, pathParamsMap, queryParamsMap);

        //Restore initial value of ProgramCode
        platformContextDTOFalse.getMember().getEnrollment().setProgramCode(PlatformContextConstants.PC_ENROLLMENT_PROGRAM_CODE);

        softNG.assertTrue(errorDTO.getMessage().contains(String.format(PlatformContextConstants.PLATFORM_CONTEXT_MISSING_FIELD, PlatformContextConstants.ENROLLMENT_PROGRAME_CODE)));
        softNG.assertAll();
    }

    @Test
    public void whenPostAndPlatformContextMissingEnrollmentLineOfBusinessCodeThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getMember().getEnrollment().setLineOfBusinessCode(null);
        String platformContextFalse = ConvertPlatformContextPOJOToString.convertPlatformContextToString(platformContextDTOFalse);

        InputStream stream = new ReadContentResourceFiles().readContentResourceFile(Constants.TEST_PDF_FILE);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        ErrorDTO errorDTO = errorsSteps.sendPostRequestWithOneFileAsMultiPartAndError(SC_BAD_REQUEST, platformContextFalse, headers, uploadFileName, stream, Constants.PDF_DOCUMENT_ATTACHMENT_TYPE, basePath, pathParamsMap, queryParamsMap);

        //Restore initial value of LineOfBusiness
        platformContextDTOFalse.getMember().getEnrollment().setLineOfBusinessCode(PlatformContextConstants.PC_ENROLLMENT_LINE_OF_BUSINESS_CODE);

        softNG.assertTrue(errorDTO.getMessage().contains(String.format(PlatformContextConstants.PLATFORM_CONTEXT_MISSING_FIELD, PlatformContextConstants.ENROLLMENT_LINE_OF_BUSINESS_CODE)));
        softNG.assertAll();
    }

    @Test
    public void whenPostAndPlatformContextMissingUserIdThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        platformContextDTOFalse.getUser().setId(null);
        String platformContextFalse = ConvertPlatformContextPOJOToString.convertPlatformContextToString(platformContextDTOFalse);

        InputStream stream = new ReadContentResourceFiles().readContentResourceFile(Constants.TEST_PDF_FILE);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        ErrorDTO errorDTO = errorsSteps.sendPostRequestWithOneFileAsMultiPartAndError(SC_BAD_REQUEST, platformContextFalse, headers, uploadFileName, stream, Constants.PDF_DOCUMENT_ATTACHMENT_TYPE, basePath, pathParamsMap, queryParamsMap);

        //Restore initial value of UserId
        platformContextDTOFalse.getUser().setId(PlatformContextConstants.PC_USER_ID);

        softNG.assertTrue(errorDTO.getMessage().contains(String.format(PlatformContextConstants.PLATFORM_CONTEXT_MISSING_FIELD, PlatformContextConstants.USER_ID)));
        softNG.assertAll();
    }

    @Test
    public void whenPostAndPlatformContextMissingUserRolesThenServiceReturnBadResponse() {
        PlatformContext platformContextDTOFalse = new PlatformContextDTOFactory().createPlatformContextDTO();
        User tempUser = new User();
        tempUser.setId(PlatformContextConstants.PC_USER_ID);
        platformContextDTOFalse.setUser(tempUser);
        String platformContextFalse = ConvertPlatformContextPOJOToString.convertPlatformContextToString(platformContextDTOFalse);

        InputStream stream = new ReadContentResourceFiles().readContentResourceFile(Constants.TEST_PDF_FILE);

        ErrorsSteps errorsSteps = new ErrorsSteps();
        ErrorDTO errorDTO = errorsSteps.sendPostRequestWithOneFileAsMultiPartAndError(SC_BAD_REQUEST, platformContextFalse, headers, uploadFileName, stream, Constants.PDF_DOCUMENT_ATTACHMENT_TYPE, basePath, pathParamsMap, queryParamsMap);

        tempUser = new UserDTOFactory().createUserPCDTO();
        platformContextDTOFalse.setUser(tempUser);

        softNG.assertTrue(errorDTO.getMessage().contains(String.format(PlatformContextConstants.PLATFORM_CONTEXT_MISSING_FIELD, PlatformContextConstants.USER_ROLES)));
        softNG.assertAll();
    }

}
